/*
 * codelet.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Authors:
 * Martin Kong <kongm@cse.ohio-state.edu>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>
#include <ponos/objectives.h>
#include <ponos/codelet.h>

#ifndef PONOS_OBJECTIVE_MINIMIZE 
  #define PONOS_OBJECTIVE_MINIMIZE 1
#endif

#ifndef PONOS_OBJECTIVE_MAXIMIZE 
  #define PONOS_OBJECTIVE_MAXIMIZE 2
#endif



//# define get_name(i) space->vars[(i)]->name
# define get_name(i)  space->vars[i]->name


/**
 * 
 * Allocate an iterator map (aka G-Matrix of references)
 *
 */
s_af_iterator_map_t *
ponos_codelet_alloc_af_iterator_map (int dim)
{
  if (dim<1)
  {
    printf("[simd_codelets.c] Dimension given must be 1 or greater. Aborting.\n");
    exit (42);
  }
  s_af_iterator_map_t * G;
  G = XMALLOC (s_af_iterator_map_t,1);
  G->nonfvd = XMALLOC (int,dim);
  G->fvd = XMALLOC (int,dim);
  G->dim = dim;
  G->next = NULL;
  G->sum_nonfvd = 0;
  G->sum_fvd = 0;
  G->stmt = NULL;
  int i;
  for (i=0; i<dim; i++)
    G->nonfvd[i] = G->fvd[i] = 0;
  return G;  
}



/**
 * 
 * Free the linked list of iterator maps
 *
 */
void
ponos_codelet_free_af_iterator_map (s_af_iterator_map_t * G)
{
  if (!G)
  {
    printf("[simd_codelets.c] Attempting to free an unallocated map. Aborting.\n");
    exit (42);
  }
  s_af_iterator_map_t * temp, * curr;
  for (curr=G; curr; )
  {
    temp = curr;
    curr = curr->next;
    temp->next = NULL;
    XFREE (temp->nonfvd);
    XFREE (temp->fvd); 
    XFREE (temp);
  }
}


/**
 * 
 * Print a single access function iterator map
 *
 */
void
ponos_codelet_print_af_iterator_map (s_af_iterator_map_t * G)
{
  int i;
  printf("Reference at statement %d, reference %d, array %d(%d), dimension %d (stmtprt = %p):\n",
    G->stmt_id, G->ref_id, G->array_id, G->array_dim, G->dim, G->stmt);
  printf("Non-FVD\t:");
  for (i=0; i<G->dim; i++)
    printf("%d\t",G->nonfvd[i]);
  printf("\nFVD\t: ");
  for (i=0; i<G->dim; i++)
    printf("%d\t",G->fvd[i]);
  printf("\n\n");
}

/**
 * 
 * Print the complete linked list of access function iterator maps
 *
 */
void
ponos_codelet_print_all_af_iterator_map (s_af_iterator_map_t * G)
{
  s_af_iterator_map_t * temp;
  for (temp = G; temp; temp = temp->next)
  { 
    ponos_codelet_print_af_iterator_map (temp);
  }
}


/**
 * 
 * Build the iterator map for one lhs or rhs of an statement (ref)
 *
 */
s_af_iterator_map_t *
ponos_codelet_build_af_iterator_map (s_ponos_options_t* options,
    int dim, int stmt_id, int * ref_id_p, 
    scoplib_matrix_p ref,scoplib_statement_p stmt)
{
  int nrefs = 0;
  int ref_id = *ref_id_p;
  int row,col;
  for (row=0; row<ref->NbRows; row++)
    if (ref->p[row][0] != 0) nrefs++;
 
  int limits[nrefs+1];
  int i;
  for (row=0,i=0; row<ref->NbRows; row++)
    if (ref->p[row][0] != 0) 
    {
      limits[i++] = row;
    }
  limits[i] = ref->NbRows;

  if (options->debug == 1)
  {
    printf("[Ponos:Codelet] Found %d references in statement %d\n",nrefs,stmt_id);
    for (i=0; i<nrefs; i++)
      printf("From row %d to row %d\n",limits[i],limits[i+1]-1);
    printf("\n");
  }

  s_af_iterator_map_t * G = NULL, * Gstart = NULL; 
  for (i=0; i<nrefs; i++, ref_id++)
  {
    s_af_iterator_map_t * g;
    // number of columns in the map is the dimensionality of the statement
    // hence the number of loops enclosing it (dim)
    g = ponos_codelet_alloc_af_iterator_map (dim);
    g->stmt_id = stmt_id;
    g->array_id = ref->p[limits[i]][0]; 
    g->ref_id = ref_id;
    g->array_dim = limits[i+1] - limits[i];
    g->stmt = stmt;
    // fill non-fvd 

    if (g->array_dim > 1)
    {
      for (row=limits[i]; row<limits[i+1]-1; row++)
      {
        for (col=1; col<=dim; col++)
        {
          g->nonfvd[col-1] = g->nonfvd[col-1] || ( ref->p[row][col] != 0);
        }
      }
    }

/*
    if (g->array_dim == 1) 
    {
    //for (row=limits[i]; row<limits[i+1]-1; row++)
    {
      for (col=1; col<=dim; col++)
      {
        //g->nonfvd[col-1] = 1;
      }
    }
    }
*/
    // fill fvd    
    row = limits[i+1]-1;
    for (col=1; col<=dim; col++)
    {
      g->fvd[col-1] = ( ref->p[row][col] == 1);
    }


    // fill sum of nonfvd and fvd
    for (col=0; col<dim; col++)
    {
      g->sum_fvd += g->fvd[col]; 
      g->sum_nonfvd += g->nonfvd[col]; 
    }
   
    if (!G) 
      G = Gstart = g;
    else
    {
      G->next = g;
      G = G->next;
    }
    
  } 

  *ref_id_p = ref_id;
  return Gstart;

}



#define APPEND(G,g) \
  G->next = g;  \
  while (G->next) G = G->next; \

/**
 * 
 * Build the iterator map for all access functions
 *
 */
s_af_iterator_map_t *
ponos_codelet_build_complete_af_iterator_map (
  s_ponos_space_t * space, s_ponos_options_t* options)
{
  scoplib_scop_p scop = space->scop;
  scoplib_statement_p stmt;
  scoplib_matrix_p ref;
  s_af_iterator_map_t * G, * Gstart, * g;
  int ref_id = 1; 

  // process the first statement
  stmt = scop->statement;
  // initialize G and Gstart with write ref of 1st statement
  G = Gstart = ponos_codelet_build_af_iterator_map ( options,
    stmt->nb_iterators,1,&ref_id,stmt->write, stmt);

  // process the read references of the 1st statement
  g = ponos_codelet_build_af_iterator_map ( options, 
    stmt->nb_iterators,1,&ref_id,stmt->read, stmt);
  APPEND(G,g);

  int stmt_id = 2;
  // if more than 1 statement, continue building maps
  for (stmt = stmt->next; stmt; stmt = stmt->next, stmt_id++)
  {
    ref_id = 1;

    // extract iterator map from rhs (write reference)
    g = ponos_codelet_build_af_iterator_map ( options,
      stmt->nb_iterators,stmt_id,&ref_id,stmt->write,stmt);
    APPEND(G,g); 

    // extract iterator maps from lhs (read references)
    g = ponos_codelet_build_af_iterator_map ( options,
      stmt->nb_iterators,stmt_id,&ref_id,stmt->read,stmt);
    APPEND(G,g);
  }
 
  if (options->debug == 1)
    ponos_codelet_print_all_af_iterator_map (Gstart);

  return Gstart; 
}



/**
 *
 * Creates the constraint:
 * var1 - var2 \ge 0
 *
 */
void
ponos_codelet_create_ge(s_ponos_space_t* space,
			      int var1, int var2, int cst)
{
  if (! space || !space->vars )
    return;
  
  // 1. Count the max. id.
  int max_id = (var1>=var2?var1:var2);

  // 2. Create the constraint.
  s_fm_vector_t* v = fm_vector_alloc (max_id + 3);

  // 3. Fill it. Assume var != max_id.
  fm_vector_set_ineq (v);

  z_type_t one; Z_INIT(one); Z_ASSIGN_SI(one, 1);
  z_type_t mone; Z_INIT(mone); Z_ASSIGN_SI(mone, -1);

  fm_vector_assign_int_idx (v, one, var1 + 1);
  fm_vector_assign_int_idx (v, mone, var2 + 1);

  z_type_t zcst; Z_INIT(zcst); Z_ASSIGN_SI(zcst, -cst);
  fm_vector_assign_int_idx (v, zcst, max_id + 2);

  // 4. Insert.
  fm_solution_add_line_at (space->space, v, max_id + 1);

  // Be clean.
  Z_CLEAR(one);
  Z_CLEAR(mone);
  Z_CLEAR(zcst);
}

void
ponos_codelet_print_coefs_names (
   s_ponos_space_t* space,s_fm_vector_t * v)
{
  s_fm_rational_t * r;
  int i;
  printf ("Printing coefficient names(%ld)\n",v->size);
  for (i=1; i<v->size-1; ++i)
    if (Z_CMP_SI(v->vector[i].num, !=, 0))
      printf ("+ %Ld * %s ",Z_GET_SI(v->vector[i].num),get_name(i-1));
  printf (" + %Ld\n",Z_GET_SI(v->vector[i].num));
}

/**
 *
 * Creates the weighted summation constraint
 * \sum_i ( weight[i] \times other_vars[i]) - weight \times var  >= constant
 *
 */
void
ponos_codelet_create_weighted_summation (s_ponos_space_t* space,
			      int var, int* other_vars,
            int weight, int* other_weights,
            int constant)
{
  if (! space || !space->vars || !other_vars)
    return;
  
  // Count the max. id.
  int max_id = var;
  int i;
  for (i = 0; other_vars[i] != -1; ++i)
    if (other_vars[i] > max_id)
      max_id = other_vars[i];

  // Allocate the fm vector
  s_fm_vector_t* v = fm_vector_alloc (max_id + 3);
  // Use an inequality
  fm_vector_set_ineq (v);

  // set var's weight
  z_type_t z_w; Z_INIT(z_w); Z_ASSIGN_SI(z_w, -weight);
  if (var!=-1)
    fm_vector_assign_int_idx (v, z_w, var + 1);

  // weighted sum
  for (i = 0; other_vars[i] != -1; ++i)
  {
    Z_ASSIGN_SI(z_w,other_weights[i]);
  //  printf("other var idx = %d\n",other_vars[i]+1);
    fm_vector_assign_int_idx (v, z_w, other_vars[i] + 1);
  }

  // Set constant value.
  z_type_t zcst; Z_INIT(zcst); Z_ASSIGN_SI(zcst, -constant);
  fm_vector_assign_int_idx (v, zcst, max_id + 2);

  // Normalize. Needed because at least var won't be 1
  fm_vector_normalize_idx (v,v,max_id+1);
  //ponos_codelet_print_coefs_names (space,v);
  fm_solution_add_line_at (space->space, v,max_id+1);// var+1);

  // Be clean.
  Z_CLEAR(z_w);
  Z_CLEAR(zcst);
}


/**
 *
 * Set boolean constraints on a give type of variable
 *
 */
void
ponos_codelet_boolean_constraints (s_ponos_space_t* space,
				s_ponos_options_t* options,
        int coef_type )
{
  int i,dim;

  z_type_t one; Z_INIT(one); Z_ASSIGN_SI(one, 1);
  z_type_t mone; Z_INIT(mone); Z_ASSIGN_SI(mone, -1);
  z_type_t zero; Z_INIT(zero); Z_ASSIGN_SI(zero, 0);

  s_fm_vector_t* v;

  for (dim=0; dim<space->num_sched_dim; dim++)
  {
    int* ids = ponos_space_get_coefs_dim (space, dim, coef_type);

    for (i=0; ids[i]!=-1; i++)
    {

      v = fm_vector_alloc (ids[i] + 3);
      fm_vector_set_ineq (v);
      fm_vector_assign_int_idx (v, one, ids[i] + 1);
      fm_vector_assign_int_idx (v, zero, ids[i]+ 2);
      fm_solution_add_unique_line_at (space->space, v, ids[i] + 1);
      //printf("%s >= 0\n",get_name(ids[i]));

      v = fm_vector_alloc (ids[i] + 3);
      fm_vector_set_ineq (v);
      fm_vector_assign_int_idx (v, mone, ids[i] + 1);
      fm_vector_assign_int_idx (v, one, ids[i]+ 2);
      fm_solution_add_unique_line_at (space->space, v, ids[i] + 1);
      //printf("-%s + 1 >= 0\n",get_name(ids[i]));
    }
    XFREE (ids);
  }

  // Be clean.
  Z_CLEAR(one);
  Z_CLEAR(mone);
  Z_CLEAR(zero);
}


/**
 *
 * Adds \gamma_{i,j}  constraints:
 *  \theta_{i,j} \ge \gamma_{i,j}
 *
 */
int 
ponos_codelet_gamma_constraints (s_ponos_space_t* space,
				 s_af_iterator_map_t * G,
				s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return - 1;
  
  scoplib_scop_p scop = space->scop;
  scoplib_statement_p stmt;  
  int max_dim = space->num_sched_dim; 
  int i,j;
  int stmt_id;
  int ** gamma_iters;

  char buffer[32]; sprintf (buffer, "OPT_STRIDE_PROP");
  s_ponos_var_t* var =
    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
  ponos_space_insert_variable_last (space, var);        
  int optvar = space->num_vars-1;


  // allocate space for 3D array of gamma iterators
/*
  for (stmt=scop->statement, stmt_id=0; stmt; stmt=stmt->next,stmt_id++);
  gamma_iters = XMALLOC (int *, max_dim/2+1);
  int entries = stmt_id * max_dim ;
  for (i=0; i<max_dim/2; ++i)
  {
    gamma_iters[i] = XMALLOC (int , entries+1);
    gamma_iters[i][entries] = -1;
  }
  gamma_iters[i] = NULL;
*/


  // create all \gamma^R_{i,j}
/*
  for (i=0; i<max_dim; i++)
  {
    for (stmt=scop->statement, stmt_id=0; stmt; stmt=stmt->next, stmt_id++)
    {
      // iterator coefficients
      for (j=0; j<stmt->nb_iterators; j++)
      {
        char buffer[32]; sprintf (buffer, "G%d_i%d_%d", stmt_id, j, i);
        s_ponos_var_t* var =
          ponos_space_var_create (buffer, PONOS_VAR_GAMMA_ITER, i, 0, 0, stmt);
        ponos_space_insert_variable_last (space, var);        

        // new stuff: minimize gamma per iterator coefficient
        //gamma_iters[j][stmt_id * max_dim + i] = space->num_vars-1;
        //printf("GI[%d][%d][%d] = %d\n",stmt_idj,i,gamma_iters[j][i]);
      }
      // parameter coefficients
      for (j=0; j<space->num_pars; j++)
      {
        char buffer[32]; sprintf (buffer, "G%d_p%d_%d", stmt_id, j, i);
        s_ponos_var_t* var =
          ponos_space_var_create (buffer, PONOS_VAR_GAMMA_PARAM, i, 0, 0, stmt);
        ponos_space_insert_variable_last (space, var);        
      }
      // constant coefficient
      char buffer[32]; sprintf (buffer, "G%d_c_%d", stmt_id, i);
      s_ponos_var_t* var =
        ponos_space_var_create (buffer, PONOS_VAR_GAMMA_CST, i, 0, 0, stmt);
      ponos_space_insert_variable_last (space, var);        
      
    }    
  }
*/
  for (i = 0; i < space->num_sched_dim; ++i)
    {
      int* ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_THETA);
      int count = ponos_space_count_var_type_dim (space, i, PONOS_VAR_THETA);
      s_ponos_var_t* newvars[count + 1];
      int j;
      for (j = 0; ids[j] != -1; ++j)
	{
	  sprintf (buffer, "G%d_%d_%d", j, space->vars[ids[j]]->pos, i);
	  int type;
	  switch (space->vars[ids[j]]->type)
	    {
	    case PONOS_VAR_THETA_ITER:
	      type = PONOS_VAR_GAMMA_ITER; break;
	    case PONOS_VAR_THETA_PARAM:
	      type = PONOS_VAR_GAMMA_PARAM; break;
	    case PONOS_VAR_THETA_CST:
	      type = PONOS_VAR_GAMMA_CST; break;
	    }
	  newvars[j] = ponos_space_var_create (buffer, type,
					       i, space->vars[ids[j]]->pos,
					       j + space->num_vars,
					       space->vars[ids[j]]->scop_ptr);
	}
      newvars[j] = NULL;
      space->vars = XREALLOC (s_ponos_var_t*, space->vars,
			      space->num_vars + count + 1);
      for (j = 0; newvars[j]; ++j)
	space->vars[space->num_vars + j] = newvars[j];
      space->vars[space->num_vars + j] = NULL;
      space->num_vars += j;
      fm_solution_extend (space->space, space->num_vars);
      XFREE(ids);
    }





//  ponos_codelet_objectives_min_each_gamma_iterator (
//        space, options, gamma_iters);

  if (options->debug == 1)
  {
    printf("[Ponos:Codelet] Bounding gamma_{i,j} with theta_{i,j}\n");
    for (stmt=scop->statement, stmt_id=0; stmt; stmt=stmt->next,stmt_id++)
    {
      for (i=0; i<max_dim; i++)
      {
        printf("Statement %d, dimension %d:\n",stmt_id,i);
        printf("Thetas: ");
        ponos_codelet_print_vars_by_dim_type (stdout, 
            space, 
            stmt,
            i, PONOS_VAR_THETA);
        printf("Gammas: ");
        ponos_codelet_print_vars_by_dim_type (stdout, 
            space, 
            stmt,
            i, PONOS_VAR_GAMMA);
      }
    }
  }

  // add constraints: \theta^R_{i,j} >= \gamma^R_{i,j}
  for (i=0; i<max_dim; i++)
  { 
    int * theta_ids;
    int * gamma_ids;
    theta_ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_THETA);
    gamma_ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_GAMMA);

    for (j=0; theta_ids[j]!=-1; j++)
    {
      if (gamma_ids[j]==-1)
      {
        printf("Codelet.c: Gamma ids ended before theta ids. This shouldn't happen!!");
        exit(42);
      }
      if (options->debug == 1)
        printf("%s - %s >= 0\n",get_name(theta_ids[j]),get_name(gamma_ids[j]));
      ponos_codelet_create_ge (space, theta_ids[j], gamma_ids[j], 0);
    }
    XFREE (theta_ids);
    XFREE (gamma_ids);
  }

  int* ids = ponos_space_get_coefs (space, PONOS_VAR_GAMMA);
  ponos_space_create_summation (space, optvar, ids,
				PONOS_CONSTRAINT_EQUAL,
				PONOS_OBJECTIVE_MAXIMIZE_POS,
				PONOS_UNUSED_VALUE);
  XFREE (ids);

  //return gamma_iters;
  return optvar;
}


void
ponos_codelet_print_vars_by_dim_type (FILE* stream, 
    s_ponos_space_t* space, 
    scoplib_statement_p stmt,
    int dim, int coef_type)
{
  if (stream == NULL)
    {
      fprintf (stderr, "[NULL stream]\n");
      return;
    }
  if (space == NULL)
    {
      fprintf (stream, "[NULL]\n");
      return;
    }
  int i;
  int * ids = ponos_space_get_coefs_dim_stmt (space, stmt, dim, coef_type);
  for (i = 0; ids[i]!=-1; ++i)
    fprintf (stream, "[%d=%s] ", ids[i], space->vars[ids[i]]->name);
  fprintf (stream, "\n");
  XFREE (ids);
}


#define splat(v,i,val,n) for (i=0; i<(n); ++i) v[i]=val;
#define get_col(v1,v2,i,j,n) \
  for (i=0; i<(n); ++i) v1[(i)] = v2[(i)][(j)]; \
  v1[(n)] = -1;


/**
 *
 * Adds the stride-0/1 constraints to the space
 *
 */
void
ponos_codelet_stride_constraints (s_ponos_space_t* space,
        s_af_iterator_map_t * G,
				s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  s_af_iterator_map_t * g;
  int i,j;
  scoplib_statement_p stmt;
  int max_dim = space->num_sched_dim;
  int * gamma[max_dim];
  int rank_w[max_dim+1];
  int rank_n[max_dim+1];


  // Rank iterator by number of references
  for (i=0; i<max_dim+1; ++i) rank_w[i] = rank_n[i] = 0;
  for (g=G; g; g=g->next)
    for (i=0; i<g->dim; ++i)
    {
      rank_w[i] += g->fvd[i];
      rank_n[i] = rank_n[i] | g->fvd[i];
    } 
  
  int stride_cst = 0;
  int * theta[max_dim];


/*
  // ********************************************
  /// MK: minimize sum of gammas in each linear level
  // ********************************************
  int stmt_id = 0;
  for (stmt=space->scop->statement; stmt; stmt=stmt->next, stmt_id++)
  {
    // build the gamma-iterator-only matrix for the current statement
    // but only load the linear rows of gamma
    for (i=0; i<max_dim; ++i)
    {
      if (i%2==0) continue;
      gamma[i/2] = ponos_space_get_coefs_dim_stmt (
        space, stmt, i, PONOS_VAR_GAMMA_CST);
    }

    printf("a\n");


    // build the gamma-iterator-only matrix for the current statement
    // but only load the linear rows of gamma
    for (i=0; i<max_dim; ++i)
    {
      if (i%2==0) continue;
      ponos_space_create_summation (space, -1, gamma[i/2], PONOS_CONSTRAINT_EQUAL,
        PONOS_OBJECTIVE_MINIMIZE, 0);
    }


//    for (i=0; i<max_dim; ++i)
//    {
//      if (i%2==0) continue;
//      char buffer[32]; 
//      // s: statement, r: reference, i:iterator
//      sprintf (buffer, "MIN_GAMMA_SUM_%d_%d",stmt_id,i);
//      s_ponos_var_t* var =
//        ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, i, 0, 0, stmt);
//      ponos_space_insert_variable_first (space, var);        
//      int var_id = space->num_vars-1;
//
//      ponos_space_create_summation (space, 0, gamma[i/2], 
//        PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
//    }

  
    printf("b\n");

    for (i=0; i<max_dim; ++i)
    {
      if (i%2==0) continue;
      XFREE (gamma[i/2]); 
    }
  }
*/



  // ********************************************
  /// MK: avoid skewing 
  // ********************************************
/*
  for (stmt=space->scop->statement; stmt; stmt=stmt->next)
  {
    // build the gamma-iterator-only matrix for the current statement
    // but only load the linear rows of gamma
    for (i=0; i<max_dim; ++i)
    {
      if (i%2==0) continue;
      gamma[i/2] = ponos_space_get_coefs_dim_stmt (
        space, stmt, i, PONOS_VAR_GAMMA_ITER);
    }


    // Load theta iterator coefficients. Will use them to avoid skewing
    for (i=0; i<max_dim; ++i)
    {
      if (i%2==0) continue;
      theta[i/2] = ponos_space_get_coefs_dim_stmt (
        space, stmt, i, PONOS_VAR_THETA_ITER);
    }

    int ids[max_dim/2+1];
    // \sum^d_{k=1} ( rank[k] * gamma_{2d,k} ) = 1
    // this says: don't use any skwewing in the innermost level.
    for (i=j=0; i<max_dim/2; ++i) 
      if (rank_n[i] != 0) ids[j++] = gamma[max_dim/2-1][i];
    ids[j] = -1;
      
    ponos_space_create_summation (space, -1, ids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);
    stride_cst++;

    // \sum^d_{k=1} (rank[i] * \gamma[k][i] ) <= 1
    // If iterator associated has potential for being the innermost
    // loop iterator, then ask for it to be used only once in the
    // schedule.
    for (i=0; i<max_dim/2; ++i) // i is a column
      if (rank_n[i] != 0)
    {
      get_col(ids,gamma,j,i,max_dim/2); 
      ponos_space_create_summation (space, -1, ids, PONOS_CONSTRAINT_LOWEREQUAL, 
        PONOS_OBJECTIVE_MINIMIZE, 1);
      stride_cst++;
    }


    // Set \theta_{2d,k} <= \gamma_{2d,k}, for every k in 1..d
    // but only if the iterator has potential for being used in 
    // the innermost loop.
    // Hence, if some gamma is zero, so will be theta
    // This will perform an equality in the end, because
    // gammas are also upper bounded by thetas
    ids[1] = -1; 
    for (i=0; i<max_dim/2; ++i) // row 
      for (j=0; j<max_dim/2; ++j) // column
        if (rank_n[j] != 0)
    {
      ids[0] = gamma[i][j];
      ponos_space_create_summation (space, theta[i][j], ids, 
        PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
      stride_cst++;
    }

    // be clean
    for (i=0; i<max_dim/2; ++i) 
    {
      XFREE (theta[i]); 
      XFREE (gamma[i]);
    }
  }
*/
  // ********************************************
  /// MK: avoid skewing 
  // ********************************************



    // constraint: each coefficient of the loop iterator appearing
    // in the nonfvd must be nonzero at least once
    for (g=G; g; g=g->next)
//      if (g->stmt == stmt)
    {

      // build the gamma-iterator-only matrix for the current statement
      // but only load the linear rows of gamma
      for (i=0; i<max_dim; ++i)
      {
        if (i%2==0) continue;
        gamma[i/2] = ponos_space_get_coefs_dim_stmt (
          space, g->stmt, i, PONOS_VAR_GAMMA_ITER);
      }

      int gref_ids[g->dim+1];
      for (i=0; i<g->dim; i++)
      // Note: i is the iterator column
	{
        int W[max_dim/2];
        int gamma_j[max_dim/2+1];
        int w = g->nonfvd[i];
  
        splat(W,j,g->nonfvd[i],g->dim);

        // create the new \gamma^i_{F^A_R} variable and insert it last
        char buffer[32]; 
        // s: statement, r: reference, i:iterator
        sprintf (buffer, "gref_s%d_r%d_i%d", g->stmt_id, g->ref_id, i);
        s_ponos_var_t* var =
          ponos_space_var_create (buffer, PONOS_VAR_GAMMA_REF, i, 0, 0, g->stmt);
        ponos_space_insert_variable_last (space, var);        
        gref_ids[i] = space->num_vars-1;

        // reads column j of gamma into gamma_j 
        get_col(gamma_j,gamma,j,i,max_dim/2-1); 


        // create the constraint
        if (g->nonfvd[i] == 1) 
        {
          stride_cst++;
          /*
          int k;
          for (k=0; gamma_j[k]!=-1; ++k)
            printf("%d * %s + ",W[k],get_name(gamma_j[k]));
          printf("- %d * %s >= 0\n",w,get_name(space->num_vars-1));
          */

          ponos_codelet_create_weighted_summation (space,
            space->num_vars-1, gamma_j, w, W, 0);
    
        }
      }

      gref_ids[i] = -1;      
      int w_sigma = g->sum_nonfvd;
      // create the new \sigma^1_{F^A_R} variable and insert it last
      char buffer[32]; 
      // s: statement, r: reference, i:iterator
      sprintf (buffer, "sigma_1_s%d_r%d", g->stmt_id, g->ref_id);
      s_ponos_var_t* var =
        ponos_space_var_create (buffer, PONOS_VAR_SIGMA, 1, 0, 0, NULL);
      ponos_space_insert_variable_last (space, var);        

      // create the constraint
      // \sum (g->nonfvd[i] * var[gref_ids[i]]) - w_sigma * sigma^1_last >= 0
      if (g->sum_nonfvd > 0)
      {

        ponos_codelet_create_weighted_summation (space,
          space->num_vars-1, gref_ids, w_sigma, g->nonfvd, 0);

        //ponos_space_create_summation (space,
        //  -1, gref_ids, PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MAXIMIZE, g->sum_nonfvd);

        /*
        int k;
        for (k=0; gref_ids[k]!=-1; ++k)
          printf("%d * %s + ",g->nonfvd[k],get_name(gref_ids[k]));
        printf("- %d * %s >= 0\n",w_sigma,get_name(space->num_vars-1));
        */

      }

     

    // constraint: each coefficient of the loop iterator appearing
    // in the fvd must be zero at least once
    //for (g=G; g; g=g->next)
    //  if (g->stmt == stmt)
      int vref_ids[g->dim+1];
      for (i=0; i<g->dim; i++)
      // Note: i is the iterator column
	{
        int W[max_dim/2];
        int gamma_j[max_dim/2+1];
        int w = g->fvd[i];

        splat(W,j,g->fvd[i],g->dim);

        char buffer[32]; 
        // s: statement, r: reference, i:iterator
        sprintf (buffer, "vref_s%d_r%d_i%d", g->stmt_id, g->ref_id, i);
        s_ponos_var_t* var =
          ponos_space_var_create (buffer, PONOS_VAR_NU_REF, i, 0, 0, g->stmt);
        ponos_space_insert_variable_last (space, var);        
        vref_ids[i] = space->num_vars-1;
        // reads column j of gamma into gamma_j 
        get_col(gamma_j,gamma,j,i,max_dim/2-1); 
        
        // create the constraint if the iterator is used
        if (g->fvd[i] == 1) 
        {
          stride_cst++;
          ponos_codelet_create_weighted_summation (space,
            space->num_vars-1, gamma_j, w, W, 0);


          /*
          int k;
          for (k=0; gamma_j[k]!=-1; ++k)
            printf("%d * %s + ",W[k],get_name(gamma_j[k]));
          printf("- %d * %s >= 0\n",w,get_name(space->num_vars-1));
          */
        }
      }
      vref_ids[i] = -1;      
      w_sigma = g->sum_fvd;
      int cst = 2 * g->sum_fvd - 1;
      // create the new \sigma^1_{F^A_R} variable and insert it last
      //char buffer[32]; 
      // s: statement, r: reference, i:iterator
      sprintf (buffer, "sigma_2_s%d_r%d", g->stmt_id, g->ref_id);
      var =
        ponos_space_var_create (buffer, PONOS_VAR_SIGMA, 2, 0, 0, NULL);
      ponos_space_insert_variable_last (space, var);        
      
      int w_vref[g->dim];
      for (j=0; j<g->dim; ++j) w_vref[j] = -g->fvd[j];
      // create the constraint:
      // \sum (w_vref[j] * var[ref_ids[j]]) - w_sigma * sigma^2_last >= 0
      if (g->sum_fvd > 0)
      {

          /*
          int k;
          for (k=0; vref_ids[k]!=-1; ++k)
            printf("%d * %s + ",w_vref[k],get_name(vref_ids[k]));
          printf("- %d * %s <= %d\n",w_sigma,get_name(space->num_vars-1),cst);
          */

        ponos_codelet_create_weighted_summation (space,
          space->num_vars-1, vref_ids, w_sigma, w_vref, -cst); //Yup, it's -cst

        //ponos_space_create_summation (space,
        //  -1, vref_ids, PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MAXIMIZE, 2);
      }


    // be clean
    for (i=0; i<max_dim/2; ++i) 
      XFREE (gamma[i]);
  }
 

  if (options->debug == 1)
    printf("[Ponos:Codelet] Added %d stride constraints\n",stride_cst); 
}


/**
 * Returns a -1-terminated array of variable positions in the space,
 * that match a variable type
 *
 * For instance, to get all column ids (positions) of theta
 * coefficients of the first dimension, call with 
 * coef_type=PONOS_VAR_THETA.
 *
 */
int*
ponos_codelet_get_coefs_type (s_ponos_space_t* space, int coef_type)
{
  if (space == NULL || space->vars == NULL)
    return NULL;
  int coefs[space->num_vars + 1];
  int pos = 0;
  int i;

  for (i = 0; i < space->num_vars; ++i)
    {
      if ((space->vars[i]->type & coef_type) != 0)
	coefs[pos++] = i;
    }

  int* ret = XMALLOC(int, pos + 1);
  for (i = 0; i < pos; ++i)
    ret[i] = coefs[i];
  ret[i] = -1;

  return ret;
}




/**
 *
 * Embed constraints for maximizing the number of stride-0/1 references
 *
 */
void
ponos_codelet_objective_max_stride01_refs_oldest (s_ponos_space_t* space,
				s_ponos_options_t* options)
{
/*
  if (options->debug == 1)
    printf ("[Ponos:Codelet] Adding sigma^2 objective (stride-01 refs)\n");
  ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_SIGMA, 2);

  if (options->debug == 1)
    printf ("[Ponos:Codelet] Adding sigma^1 objective (stride-01 refs)\n");
  ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_SIGMA, 1);
*/

  char buffer[64]; sprintf (buffer, "Opt_Sigma_2");
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  ponos_space_insert_variable_first (space, optvar);

  int* ids = ponos_space_get_coefs_dim (space,
			   2, PONOS_VAR_SIGMA);

  int i;
  for (i=0; ids[i]!=-1; ++i);
  int W[i+1];
  for (i=0; ids[i]!=-1; ++i) W[i] = 1;

  ponos_codelet_create_weighted_summation (space,
    0, ids, -1, W, space->max_coef_pos_val);

  XFREE(ids);


  sprintf (buffer, "Opt_Sigma_1");
  optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  ponos_space_insert_variable_first (space, optvar);

  ids = ponos_space_get_coefs_dim (space,
			   1, PONOS_VAR_SIGMA);

  ponos_codelet_create_weighted_summation (space,
    0, ids, -1, W, space->max_coef_pos_val);

  XFREE(ids);

/*
  for (i=0; ids[i]!=-1; ++i) W[i] = -1;

  ponos_codelet_create_weighted_summation (space,
    0, ids, -1, W, 0);
*/

  // Be clean.
/*
  if (options->debug == 1)
    printf ("[Ponos:Codelet] Adding sigma^2 objective (stride-01 refs)\n");
  ponos_objectives_maximize_sum_of_dim(space, PONOS_VAR_SIGMA, 2);

  if (options->debug == 1)
    printf ("[Ponos:Codelet] Adding sigma^1 objective (stride-01 refs)\n");
  ponos_objectives_maximize_sum_of_dim(space, PONOS_VAR_SIGMA, 1);
*/
}


/**
 *
 * Embed constraints for maximizing stride-0/1 property
 *
 */
void
ponos_codelet_objective_max_stride01_prop_old(s_ponos_space_t* space,
				s_ponos_options_t* options)
{
  // 1. Create the optimization variable.
  char buffer[64]; sprintf (buffer, "Opt_Stride_Prop");
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  // 2. Insert it in the space, in first position.
  ponos_space_insert_variable_first (space, optvar);

  // 3. Collect all delta positions for the first dimension.
  int* ids = ponos_codelet_get_coefs_type(space, PONOS_VAR_GAMMA);
  int myids[space->num_vars+1];
  int i=0;
  int j;

  for (j = 0; j < space->num_vars; j++)
    {
      if (((space->vars[j]->type == PONOS_VAR_GAMMA_ITER )) &&
          (space->vars[j]->dim % 2==1))
  {
	myids[i++] = j;
    printf("BLEUGH %s, type=%d, dim=%d\n",space->vars[j]->name,space->vars[j]->type,space->vars[j]->dim);
  }
    }
  myids[i] = -1;

  int n = i;

  int W[n+1];
  for (i=0; myids[i]!=-1; ++i) W[i] = 1;

  // 4. Set summation of variables equal to newvar (or -newvar if mode
  // is maximize).
/*
  ponos_space_create_summation (
    space, 0, ids, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE, -8); // might be MAXIMIZE_POS?
*/


  ponos_codelet_create_weighted_summation (space,
    0, myids, -1, W, 2); /// MK: limit this to (d-1)^2 OR min {\sum \theta^R_(2d,j) >= nbr_stmt}

/*
  for (i=0; ids[i]!=-1; ++i) W[i] = -1;

  ponos_codelet_create_weighted_summation (space,
    0, ids, -1, W, 0);
*/

  // Be clean.
  XFREE(ids);

}


/**
 *
 * Count the number of bits set to 1 in value x
 *
 */
static inline
unsigned int countOnes(unsigned int x)
{
  unsigned int i=0;
  while (x>0)
  {
    i += x & 1;
    x = x >> 1;
  } 
  return i; 
}


/**
 *
 * Copy a subset of ids into myids.
 * The subset is determined by the bits that are set to 1
 * in the argument x, e.g., if ids = [a b c d] then
 * a is associated to the first bit, b to the second, and so
 * 
 **/
static
int ponos_codelet_fill_combination (int * ids, int * myids,unsigned int map,int n)
{
  int i = 0;
  int j = 0;
  while (i<n)
  {
    unsigned int idx = map & (1 << i);
    if (idx > 0)
      myids[j++] = ids[i];
    i++;
  } 
  myids[j] = -1;
  return j;
}

#define MAX_STMT 12

/**
 *
 * n: number of statements
 * m: number of variables to consider in the constraint
 * Generate C(n,m) * 2 constraints.
 * Each of the C(n,m) combinations uses only m variables from ids,
 * and is bounded by lb and ub.
 *
 */
int ponos_codelet_force_dist_constraint_bounds (
  s_ponos_space_t* space,
  s_ponos_options_t* options,
  unsigned int n, unsigned int m,
  int * ids, int * myids, int lb, int ub)
{
  // limit is the maximum number of possible combinations to check
  unsigned int limit = 1 << n;
  unsigned int i;
  int nbr_constraints = 0;
  
  // check all combinations
  for (i=0; i<limit; ++i)
  {
    // if combination has only m variables, then we generate
    // constraints for it
    if (countOnes(i)==m)
    {
      int k;
      // Copy only required ids to myids.
      // The ids copied are determined by the binary representation of i.
      k = ponos_codelet_fill_combination(ids,myids,i,n);

      // Add constraint:
      // \sum^{m}_{i=1} myids >= lb
      ponos_space_create_summation (space, -1, myids,
            PONOS_CONSTRAINT_GREATEREQUAL,
            PONOS_OBJECTIVE_MINIMIZE,
            lb);
  
      // Add constraint:
      // \sum^{m}_{i=1} myids <= ub
      ponos_space_create_summation (space, -1, myids,
            PONOS_CONSTRAINT_LOWEREQUAL,
            PONOS_OBJECTIVE_MINIMIZE,
            ub);

      if (n>MAX_STMT && m==2)
      {
        int varO1, varO2;
        int w1[k+1];
        int w0;
        char buffer[64]; 
        s_ponos_var_t* optvar;
  
        printf("myids[%d] = %d (%d)\n",k,myids[k],m);       
 
        // myids[0] - myids[1] - var1 > 0
        sprintf (buffer, "O_%d_%d",myids[0],myids[1]);
        optvar = ponos_space_var_create (buffer, PONOS_VAR_ORDER, 1,
                0, 0, NULL);

        ponos_space_insert_variable_last (space, optvar);
  
        w1[0]=1; w1[1]=-1; w0=1;
        varO1 = space->num_vars-1;
        ponos_codelet_create_weighted_summation (space,
              varO1, myids,
              w0, w1, 0);


        ponos_space_set_variable_to_value (space,
				   varO1,
				   n,
				   PONOS_CONSTRAINT_LOWEREQUAL);


        ponos_space_set_variable_to_value (space,
				   varO1,
				   -n,
				   PONOS_CONSTRAINT_GREATEREQUAL);


        // - myids[0] + myids[1] - var1 > 0
/*
        sprintf (buffer, "O_%d_%d",myids[1],myids[0]);
        optvar = ponos_space_var_create (buffer, PONOS_VAR_ORDER, 2,
                0, 0, NULL);


        ponos_space_insert_variable_last (space, optvar);

*/

        w1[0]=-1; w1[1]=1;
        varO2 = space->num_vars-1;
        ponos_codelet_create_weighted_summation (space,
              varO1, myids,
              w0, w1, 0);


/*
        ponos_space_set_variable_to_value (space,
				   varO2,
				   n-2,
				   PONOS_CONSTRAINT_LOWEREQUAL);


        ponos_space_set_variable_to_value (space,
				   varO2,
				   -(n),
				   PONOS_CONSTRAINT_GREATEREQUAL);
*/


      }


      nbr_constraints++;
    }
  }  
  return nbr_constraints;
}


# define pow2(n)  (1<<n)

/**
 *
 * Force distribution at 2nd innermost constant level
 *
 */
void
ponos_codelet_force_dist_constraints (s_ponos_space_t* space,
				   s_ponos_options_t* options,
           int level)
{
  int i;
  int nstmt;
  int nterms;
  int dist_cst = 0;
  scoplib_statement_p stmt;

  if (level%2==1)
  {
    printf ("[Ponos:Codelet] Ignoring distribution constraints at a linear level\n");
    return;
  }

  // Collect all theta constant coefficients at 2nd innermost constant level
  int* ids = ponos_space_get_coefs_dim (space, level, PONOS_VAR_THETA_CST);

  // Remapping array 
  for (i=0; ids[i]!=-1; ++i);
  int myids[i+1];

  // Count number of statements  
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);
  //printf("FORCE FD: %d statements\n",nstmt);
    
  // Will add \sum^{nstmt-1}_{i=0} Combination (nstmt,i) constraints
  for (nterms=1; nterms<=nstmt; ++nterms)
  {
    if (!(nterms==1 || nterms==2 || nterms==nstmt-1 || nterms==nstmt) && nstmt >10)
      continue;
    if (options->debug == 0) 
      printf(
        "[Ponos:Codelet] Will add C (nstmt = %d, nterms = %d) constraints for fision at level %d\n",
        nstmt,nterms,level);

    int lb = 0;
    int ub = 0;
  
    if (nstmt >=11)
{
    for (i=1; i<=nterms; ++i) lb += (1<<(i-1));
    for (i=nstmt-nterms+1; i<=nstmt; ++i) ub += (1<<(i-1));

}
else
{
    // Compute lower and upper bounds for fision
    for (i=1; i<=nterms; ++i) lb += i;
    for (i=nstmt-nterms+1; i<=nstmt; ++i) ub += i;
}

    // old:
    //for (i=0; i<nterms; ++i) lb += i;
    //for (i=nstmt-nterms; i<nstmt; ++i) ub += i;

    printf("lb = %d, ub = %d\n",lb,ub);


    // Add Combination (nstmt,nterm) constraints that involve nterms.
    // Will add constraints 2 constraints for each combination.
    dist_cst += ponos_codelet_force_dist_constraint_bounds (
      space,options,nstmt,nterms,ids,myids,lb,ub);
	}

  if (options->debug == 1)
    printf("[Ponos:Codelet] Added %d stride constraints\n",dist_cst); 

  XFREE(ids);
}


/**
 *
 * Objective function for forcing maximum distribution of statements
 *
 */
void
ponos_codelet_objective_max_dist (s_ponos_space_t* space,
				s_ponos_options_t* options)
{
  // 1. Create the optimization variable.
  char buffer[64]; sprintf (buffer, "Opt_Dist");
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  // 2. Insert it in the space, in first position.
  ponos_space_insert_variable_first (space, optvar);

  // 3. Collect all order variables
  int* ids = ponos_codelet_get_coefs_type(space, PONOS_VAR_ORDER);
  
  int i;
  printf("Order vars\n");
  for (i=0; ids[i]!=-1; ++i)
    printf(">> %s\n",get_name(ids[i]));
  printf("\n\n");

  // 4. Set summation of variables equal to newvar (or -newvar if mode
  // is maximize).
  ponos_space_create_summation (
    space, 0, ids, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0); // might be MAXIMIZE_POS?

  // Be clean.
  XFREE(ids);

}


/**
 *
 * Force full distribution of statements at level dim
 *
 */
int ponos_codelet_force_fision_constraints_boolean (
  s_ponos_space_t* space,
  s_ponos_options_t* options, 
  int dim)
{
  int i;
  int j;
  int k;
  int nbr_constraints = 0;
  int n;
  s_ponos_var_t* optvar;
  char buffer[64];

  int* ids = ponos_space_get_coefs_dim (space, dim, PONOS_VAR_THETA_CST);
  for (i=0,n=0; ids[i]!=-1; ++i, ++n);

  // boolean mappings
  int myids[n+1];
  int bids[3];
  int matLT[n][n]; 
  int matGT[n][n]; 
  // the last var inserted
  int avar;
  
  for (i=0; i<n; ++i)
    for (j=0; j<n; ++j)
      matLT[i][j] = matGT[i][j] = 0;

  // Build the LT boolean matrix. 
  // if LT[i][j] = 0, then (not ids[i] < ids[j]),
  // if LT[i][j] = 1, then (ids[i] < ids[j]
  for (i=0; i<n-1; ++i)
    for (j=i+1; j<n; ++j)
  {
    sprintf (buffer, "LT_%d_%d",i,j);
    optvar = ponos_space_var_create (buffer, PONOS_VAR_ORDER, 1,
            0, 0, NULL);
    ponos_space_insert_variable_last (space, optvar);

    matLT[i][j] = avar = space->num_vars-1;

    ponos_space_set_variable_to_value (space,
		   avar,
		   -1,
		   PONOS_CONSTRAINT_GREATEREQUAL);

    ponos_space_set_variable_to_value (space,
		   avar,
		   0,
		   PONOS_CONSTRAINT_GREATEREQUAL);

    nbr_constraints+=2;
  }

  // Build the GT boolean matrix. 
  // if GT[i][j] = 0, then (not ids[i] > ids[j]),
  // if GT[i][j] = 1, then (ids[i] > ids[j]
  for (i=0; i<n-1; ++i)
    for (j=i+1; j<n; ++j)
  {
    sprintf (buffer, "GT_%d_%d",i,j);
    optvar = ponos_space_var_create (buffer, PONOS_VAR_ORDER, 2,
            0, 0, NULL);
    ponos_space_insert_variable_last (space, optvar);

    matGT[i][j] = avar = space->num_vars-1;

    ponos_space_set_variable_to_value (space,
		   avar,
		   1,
		   PONOS_CONSTRAINT_LOWEREQUAL);

    ponos_space_set_variable_to_value (space,
		   avar,
		   0,
		   PONOS_CONSTRAINT_GREATEREQUAL);

    nbr_constraints+=2;
  }

  // Either LT[i][j]==1 or GT[i][j]==1, so add constraint:
  // LT[i][j] + GT[i][j] == 1
  bids[2] = -1;
  for (i=0; i<n-1; ++i)
    for (j=i+1; j<n; ++j)
  {
    bids[0] = matLT[i][j];
    bids[1] = matGT[i][j];

    ponos_space_create_summation (space, -1, bids,
         PONOS_CONSTRAINT_EQUAL,
         PONOS_OBJECTIVE_MINIMIZE,
         1);
    nbr_constraints++;
  }
  // Property: \sum^{n-1}_{i=0} \sum^n_{j=i+1} (LT[i][j] + GT[i][j])  = (n-1)n/2

  // Tough part. Order of statement ids[i] is determined by
  // the number of times that it is greater than some other
  // id[j] (hence, number of ones in row GT) plus the number
  // of times that it is greater than some other id in LT (hence, 
  // number of ones in column i of LT).
  // Take care in accessing upper triangular matrix!!
  for (i=0; i<n; ++i)
  {
    k=0;
    for (j=i+1; j<=n-1; ++j)
      myids[k++] = matGT[i][j];
    for (j=0; j<=i-1; ++j)
      myids[k++] = matLT[j][i];
    myids[k] = -1;

    ponos_space_create_summation (space, ids[i], myids,
         PONOS_CONSTRAINT_EQUAL,
         PONOS_OBJECTIVE_MINIMIZE,
         PONOS_UNUSED_VALUE);
  
    nbr_constraints++;
  }

  //ponos_space_pprint_cst (stdout, space);


  XFREE (ids);
  return nbr_constraints;
}


/**
 *
 * Objective function for forcing maximum fusion at outer dimensions 
 *
 */
int ponos_codelet_objective_force_outer_fusion (
  s_ponos_space_t* space,
  s_ponos_options_t* options)
{
  int dim;
  int myids[space->num_vars + 1];
  int i=0;
  int j;
  for (j = 0; j < space->num_vars; j++)
    {
      if (((space->vars[j]->type == PONOS_VAR_THETA_CST )) &&
          (space->vars[j]->dim <= space->num_sched_dim-5) &&
          (space->vars[j]->dim % 2==0))
  {
	  myids[i++] = j;
  }
    }
  myids[i] = -1;

  char buffer[64];
  sprintf (buffer, "MAX_OUTER_FUSION");
  s_ponos_var_t * optvar = 
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
            0, 0, NULL);
  ponos_space_insert_variable_last (space, optvar);

  int w1[2];
  ponos_space_create_summation  ( space, 
         space->num_vars-1, myids,
         PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  sprintf (buffer, "MAX_OUTER_FUSION_FAKE");
  optvar = 
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
            0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);
  w1[0] = space->num_vars-1;
  w1[1] = -1;
  ponos_space_create_summation (space,0,w1, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0 );


}



/**
 *
 * Objective function for minimizing sum of iters at level 2d
 *
 */
int ponos_codelet_objective_min_inner_coefs (
  s_ponos_space_t* space,
  s_ponos_options_t* options,
  int dim)
{
  int myids[space->num_vars + 1];
  int i=0;
  int j;
  for (j = 0; j < space->num_vars; j++)
    {
      if (((space->vars[j]->type == PONOS_VAR_GAMMA_ITER )) &&
          (space->vars[j]->dim == dim))
  {
	  myids[i++] = j;
  }
    }
  myids[i] = -1;
  int n = i;

  char buffer[64];
  sprintf (buffer, "OPT_GAMMA_ITER_COEFS_%d",dim);
  s_ponos_var_t * optvar = 
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
            0, 0, NULL);
  ponos_space_insert_variable_last (space, optvar);

  int w0 = -1;
  int w1[n+1];

  int obj_type;
  obj_type = PONOS_OBJECTIVE_MINIMIZE; //(dim==1? PONOS_OBJECTIVE_MINIMIZE:PONOS_OBJECTIVE_MAXIMIZE_POS);
  ponos_space_create_summation  ( space, 
         space->num_vars-1, myids,
         PONOS_CONSTRAINT_EQUAL, obj_type, 0);

  sprintf (buffer, "OPT_GAMMA_ITER_COEFS_FAKE_%d",dim);
  optvar = 
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
            0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);
  w1[0] = space->num_vars-1;
  w1[1] = -1;
  obj_type = PONOS_OBJECTIVE_MINIMIZE; 
  //(dim==space->num_sched_dim-2? PONOS_OBJECTIVE_MINIMIZE:PONOS_OBJECTIVE_MAXIMIZE_POS);
  ponos_space_create_summation (space,0,w1, PONOS_CONSTRAINT_EQUAL, obj_type, 0 );


}



/**
 *
 * Objective function for maximizing sum of gamma per each statement
 *
 */
void ponos_codelet_objective_max_stride01_prop(
  s_ponos_space_t* space,
  s_ponos_options_t* options)
{
  int dim;
  int i=0;
  int j;

  scoplib_scop_p scop = space->scop;
  scoplib_statement_p stmt;  
  int max_dim = space->num_sched_dim; 
  int stmt_id;

  int * all_gammas;
  int n;
  all_gammas = ponos_space_get_coefs (space, PONOS_VAR_GAMMA_ITER);
  for (n=0; all_gammas[n]!=-1; ++n);
  int myids[n+1];
  int obj[n];
  s_ponos_var_t * optvar;
  char buffer[64];

  // allocate space for 3D array of gamma iterators
  for (stmt=scop->statement, stmt_id=0; stmt; stmt=stmt->next,stmt_id++)
  {
    for (i = j = 0; all_gammas[j]!=-1; ++j)
      if (space->vars[all_gammas[j]]->scop_ptr == stmt &&
          space->vars[all_gammas[j]]->dim % 2 == 1)
    {
        myids[i++] = all_gammas[j];
    }
    myids[i] = -1;

    sprintf (buffer, "MAX_STRIDE_PROP_s%d",stmt_id);
    optvar = ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0, 0, 0, NULL);
    ponos_space_insert_variable_last (space, optvar);

    ponos_space_create_summation (
      space, space->num_vars-1, myids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0); // might be MAXIMIZE_POS?

    obj[stmt_id] = space->num_vars-1;
  }

  
  for (stmt=scop->statement, stmt_id=0; stmt; stmt=stmt->next,stmt_id++)
  {
    int w1[2];
    sprintf (buffer, "MAX_STRIDE_PROP_FAKE_s%d",stmt_id);
    optvar = ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0, 0, 0, NULL);
    ponos_space_insert_variable_first (space, optvar);
    w1[0] = obj[stmt_id]+stmt_id;
    w1[1] = -1;
    ponos_space_create_summation 
      (space,0,w1, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE_POS, 0 );
  }

  XFREE (all_gammas);
}


/**
 *
 * Embed constraints for maximizing the number of stride-0/1 references
 *
 */
void
ponos_codelet_objective_max_stride01_refs_old (s_ponos_space_t* space,
				s_ponos_options_t* options)
{
/*
  if (options->debug == 1)
    printf ("[Ponos:Codelet] Adding sigma^2 objective (stride-01 refs)\n");
  ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_SIGMA, 2);

  if (options->debug == 1)
    printf ("[Ponos:Codelet] Adding sigma^1 objective (stride-01 refs)\n");
  ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_SIGMA, 1);
*/
  
  int myids[2];
  myids[1] = -1;

  // Sigma 2 stuff
  char buffer[64]; 
  sprintf (buffer, "Opt_Sigma_2");
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  ponos_space_insert_variable_last (space, optvar);

  int* ids = ponos_space_get_coefs_dim (space,
			   2, PONOS_VAR_SIGMA);


  ponos_space_create_summation (space,
    space->num_vars-1, ids, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  XFREE(ids);


  sprintf (buffer, "Opt_Sigma_2_fake");
  optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  ponos_space_insert_variable_first (space, optvar);

  myids[0] = space->num_vars-1;
  ponos_space_create_summation (space,
    0, myids, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE_POS, 0);



  // Sigma 1 stuff
  sprintf (buffer, "Opt_Sigma_1");
  optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  ponos_space_insert_variable_last (space, optvar);

  ids = ponos_space_get_coefs_dim (space,
			   1, PONOS_VAR_SIGMA);

  ponos_space_create_summation (space,
    space->num_vars-1, ids, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  XFREE(ids);

  sprintf (buffer, "Opt_Sigma_1_fake");
  optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  ponos_space_insert_variable_first (space, optvar);

  myids[0] = space->num_vars-1;
  ponos_space_create_summation (space,
    0, myids, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE_POS, 0);


}




/**
 *
 * Objective function for minimizing sum of gammas for a given iterator
 *
 */
void ponos_codelet_objective_min_gamma_iterator (
  s_ponos_space_t* space,
  s_ponos_options_t* options, 
  int * gamma_col, int it_id )
{
  int dim;

  char buffer[64];
  sprintf (buffer, "MIN_G_i%d",it_id);
  s_ponos_var_t * optvar = 
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
            0, 0, NULL);
  ponos_space_insert_variable_last (space, optvar);

  ponos_space_create_summation (
    space, space->num_vars-1, gamma_col, 
    PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 1); 


  int w1[2];
  sprintf (buffer, "MIN_G_i%d_FAKE",it_id);
  optvar = 
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
            0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);
  w1[0] = space->num_vars-1;
  w1[1] = -1;
  ponos_space_create_summation (space,0,w1, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0 );

}



/**
 *
 * Objective function for minimizing sum of gammas for 
 * each iterator column of gamma
 *
 */
void ponos_codelet_objectives_min_each_gamma_iterator (
  s_ponos_space_t* space,
  s_ponos_options_t* options, 
  int ** gamma_iters)
{
  // gamma_iters is space->num_sched_dim/2 x max_dim+1
  int i;
  int j;
  int k;
  int dim = space->num_sched_dim;
  int prop[dim/2+1];
  prop[dim/2] = -1; 

  

/*
  i=0;
  for (j=i; gamma_iters[j]; ++j)
    for (k=0; gamma_iters[j][k]!=-1; ++k)
      gamma_iters[j][k]++;
*/

/*
  for (i=0; gamma_iters[i]; ++i)
  {
    ponos_codelet_objective_min_gamma_iterator (
      space,
      options, 
      gamma_iters[i], i);
    for (j=i+1; gamma_iters[j]; ++j)
      for (k=0; gamma_iters[j][k]!=-1; ++k)
        gamma_iters[j][k]++;
    prop[i] = i;
  }
*/

/*
  char buffer[64];
  sprintf (buffer, "MAX_STRIDE_PROP");
  s_ponos_var_t * optvar = 
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
            0, 0, NULL);
  ponos_space_insert_variable_last (space, optvar);

  ponos_space_create_summation (
    space, space->num_vars-1, prop, 
    PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MAXIMIZE, 1); 


  int w1[2];
  sprintf (buffer, "MAX_STRIDE_PROP_FAKE");
  optvar = 
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
            0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);
  w1[0] = space->num_vars-1;
  w1[1] = -1;
  ponos_space_create_summation (space,0,w1, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE, 0 );
*/

  // be clean
  for (i=0; gamma_iters[i]; ++i)
    XFREE (gamma_iters[i]);
  XFREE (gamma_iters);
  
}



/**
 *
 * Embed constraints for maximizing the number of stride-0/1 references
 *
 */
void
ponos_codelet_objective_max_stride01_refs (s_ponos_space_t* space,
				s_ponos_options_t* options)
{
/*
  if (options->debug == 1)
    printf ("[Ponos:Codelet] Adding sigma^2 objective (stride-01 refs)\n");
  ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_SIGMA, 2);

  if (options->debug == 1)
    printf ("[Ponos:Codelet] Adding sigma^1 objective (stride-01 refs)\n");
  ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_SIGMA, 1);
*/
  

  // Sigma 2 stuff
  char buffer[64]; 
  sprintf (buffer, "Opt_Sigma_2");
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  ponos_space_insert_variable_first (space, optvar);

  int* ids = ponos_space_get_coefs_dim (space,
			   2, PONOS_VAR_SIGMA);


  ponos_space_create_summation (space,
    0, ids, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE_POS, 0);

  XFREE(ids);


  // Sigma 1 stuff
  sprintf (buffer, "Opt_Sigma_1");
  optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  ponos_space_insert_variable_first (space, optvar);

  ids = ponos_space_get_coefs_dim (space,
			   1, PONOS_VAR_SIGMA);

  ponos_space_create_summation (space,
    0, ids, PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE_POS, 0);


  XFREE(ids);

}



/**
 *
 * Pin gamma coefficients associated to vector iterators to a single use (1)
 *
 */
void
ponos_codelet_pin_vector_iterator (s_ponos_space_t* space,
  s_ponos_options_t * options)
{
  int i;
  int j;
  scoplib_statement_p stmt;
  int max_dim = space->num_sched_dim;
  int gamma_iters [max_dim][max_dim/2+1];

  
  
  for (stmt=space->scop->statement; stmt; stmt=stmt->next)
  {
    for (i = 0; i < max_dim; ++i)
      {
        int* ids = ponos_space_get_coefs_dim_stmt (space, stmt, i, PONOS_VAR_GAMMA_ITER);

        for (j=0; j<max_dim/2; ++j)
        {
          gamma_iters[i][j] = 0;
        }
        
      }

    }

}



void
ponos_codelet_smart_stride_constraints (s_ponos_space_t* space,
        s_af_iterator_map_t * G,
				s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  s_af_iterator_map_t * g;
  int i,j;
  scoplib_statement_p stmt;
  int max_dim = space->num_sched_dim;
  int * gamma[max_dim];
  int rank_w[max_dim+1];
  int rank_n[max_dim+1];


  // Rank iterator by number of references
  for (i=0; i<max_dim+1; ++i) rank_w[i] = rank_n[i] = 0;
  for (g=G; g; g=g->next) {
    for (i=0; i<g->dim; ++i) {
      rank_w[i] += g->fvd[i];
      rank_n[i] = rank_n[i] | g->fvd[i];
    } 
  }
  
  int stride_cst = 0;
  int * theta[max_dim];

  // ********************************************
  /// MK: avoid skewing 
  // ********************************************

  // constraint: each coefficient of the loop iterator appearing
  // in the nonfvd must be nonzero at least once
  for (g=G; g; g=g->next) 
    if (g->stmt->nb_iterators >= 2)
  {

    // build the gamma-iterator-only matrix for the current statement
    // but only load the linear rows of gamma
    for (i=0; i<max_dim; ++i)
    {
      if (i%2==0) continue;
      gamma[i/2] = ponos_space_get_coefs_dim_stmt (
        space, g->stmt, i, PONOS_VAR_GAMMA_ITER);
    }

    int gref_ids[g->dim+1];
    for (i=0; i<g->dim; i++) {
    // Note: i is the iterator column
      int W[max_dim/2];
      int gamma_j[max_dim/2+1];
      int w = g->nonfvd[i];
  
      splat(W,j,g->nonfvd[i],g->dim);

      // create the new \gamma^i_{F^A_R} variable and insert it last
      char buffer[32]; 
      // s: statement, r: reference, i:iterator
      sprintf (buffer, "gref_s%d_r%d_i%d", g->stmt_id, g->ref_id, i);
      s_ponos_var_t* var =
        ponos_space_var_create (buffer, PONOS_VAR_GAMMA_REF, i, 0, 0, g->stmt);
      ponos_space_insert_variable_last (space, var);        
      gref_ids[i] = space->num_vars-1;

      // reads column j of gamma into gamma_j 
      get_col(gamma_j,gamma,j,i,max_dim/2-1); 

      // create the constraint
      if (g->nonfvd[i] == 1) {
        stride_cst++;
        ponos_codelet_create_weighted_summation (space,
          space->num_vars-1, gamma_j, w, W, 0);
      }
    }

    gref_ids[i] = -1;      
    int w_sigma = g->sum_nonfvd;
    // create the new \sigma^1_{F^A_R} variable and insert it last
    char buffer[32]; 
    // s: statement, r: reference, i:iterator
    sprintf (buffer, "sigma_1_s%d_r%d", g->stmt_id, g->ref_id);
    s_ponos_var_t* var =
      ponos_space_var_create (buffer, PONOS_VAR_SIGMA, 1, 0, 0, NULL);
    ponos_space_insert_variable_last (space, var);        

    // create the constraint
    // \sum (g->nonfvd[i] * var[gref_ids[i]]) - w_sigma * sigma^1_last >= 0
    if (g->sum_nonfvd > 0) {
      ponos_codelet_create_weighted_summation (space,
        space->num_vars-1, gref_ids, w_sigma, g->nonfvd, 0);
    }

    // constraint: each coefficient of the loop iterator appearing
    // in the fvd must be zero at least once
    //for (g=G; g; g=g->next)
    //  if (g->stmt == stmt)
    int vref_ids[g->dim+1];
    for (i=0; i<g->dim; i++) {
    // Note: i is the iterator column
      int W[max_dim/2];
      int gamma_j[max_dim/2+1];
      int w = g->fvd[i];

      splat(W,j,g->fvd[i],g->dim);

      char buffer[32]; 
      // s: statement, r: reference, i:iterator
      sprintf (buffer, "vref_s%d_r%d_i%d", g->stmt_id, g->ref_id, i);
      s_ponos_var_t* var =
        ponos_space_var_create (buffer, PONOS_VAR_NU_REF, i, 0, 0, g->stmt);
      ponos_space_insert_variable_last (space, var);        
      vref_ids[i] = space->num_vars-1;
      // reads column j of gamma into gamma_j 
      get_col(gamma_j,gamma,j,i,max_dim/2-1); 
      
      // create the constraint if the iterator is used
      if (g->fvd[i] == 1) {
        stride_cst++;
        ponos_codelet_create_weighted_summation (space,
          space->num_vars-1, gamma_j, w, W, 0);
      }
    }

    vref_ids[i] = -1;      
    w_sigma = g->sum_fvd;
    int cst = 2 * g->sum_fvd - 1;
    // create the new \sigma^1_{F^A_R} variable and insert it last
    //char buffer[32]; 
    // s: statement, r: reference, i:iterator
    sprintf (buffer, "sigma_2_s%d_r%d", g->stmt_id, g->ref_id);
    var =
      ponos_space_var_create (buffer, PONOS_VAR_SIGMA, 2, 0, 0, NULL);
    ponos_space_insert_variable_last (space, var);        
    
    int w_vref[g->dim];
    for (j=0; j<g->dim; ++j) w_vref[j] = -g->fvd[j];
    // create the constraint:
    // \sum (w_vref[j] * var[ref_ids[j]]) - w_sigma * sigma^2_last >= 0
    if (g->sum_fvd > 0) {
      ponos_codelet_create_weighted_summation (space,
        space->num_vars-1, vref_ids, w_sigma, w_vref, -cst); //Yup, it's -cst
    }

    // be clean
    for (i=0; i<max_dim/2; ++i) 
      XFREE (gamma[i]);
  }
 

  if (options->debug == 1)
    printf("[Ponos:Codelet] Added %d stride constraints\n",stride_cst); 
}
