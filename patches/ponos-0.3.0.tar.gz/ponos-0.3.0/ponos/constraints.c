/*
 * constraints.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>
#include <ponos/constraints.h>



/**
 * Make the \sum_i \theta_i > 0, for the space.
 *
 */
  void
ponos_constraints_sum_iter_pos (s_ponos_space_t* space,
    s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j, stmt_id;
  scoplib_statement_p s;
  for (s = space->scop->statement, stmt_id = 0; s; s = s->next, ++stmt_id)
  {
    for (i = 0; i < space->num_sched_dim; ++i)
    {
      if (options->build_2d_plus_one && ((i % 2) == 0))
        continue;

      // 1. Collect all theta iterators positions for s at dim i.
      int* ids = ponos_space_get_coefs_dim_stmt
        (space, s, i, PONOS_VAR_THETA_ITER);

      // 2. Set summation > 0.
      ponos_space_create_summation (space, -1, ids,
          PONOS_CONSTRAINT_GREATER,
          PONOS_OBJECTIVE_MINIMIZE,
          PONOS_UNUSED_VALUE);

      // Be clean.
      XFREE(ids);
    }
  }
}



/**
 * Make the parameter coefficients of linear dimensions = 0.
 *
 */
  void
ponos_constraints_param_coef_zero (s_ponos_space_t* space,
    s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  for (i = 0; i < space->num_sched_dim; ++i)
  {
    if (options->build_2d_plus_one && ((i % 2) == 0))
      continue;

    // 1. Collect all theta parameters positions at dim i.
    int* ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_THETA_PARAM);
    for (j = 0; ids[j] != -1; ++j)
    {
      // 2. Set constraint variable = 0.
      ponos_space_set_variable_to_value
        (space, ids[j], 0, PONOS_CONSTRAINT_EQUAL);
    }
    // Be clean.
    XFREE(ids);
  }
}




/**
 * Make the \sum_i \theta_{i,j} > 0, for a given j, for the space.
 *
 */
  void
ponos_constraints_linear_indep (s_ponos_space_t* space,
    s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j, stmt_id;
  scoplib_statement_p s;
  for (s = space->scop->statement, stmt_id = 0; s; s = s->next, ++stmt_id)
  {
    int added_var = 0;
    // Store the ids of all theta_{i,j} for a statement.
    int* all_ids[space->num_sched_dim + 1];
    int idx = 0;
    all_ids[0] = NULL;
    for (i = 0; i < space->num_sched_dim; ++i)
    {
      if (options->build_2d_plus_one && ((i % 2) == 0))
        continue;

      int* ids = ponos_space_get_coefs_dim_stmt
        (space, s, i, PONOS_VAR_THETA_ITER);
      all_ids[idx++] = ids;
    }
    for (; idx < space->num_sched_dim; ++idx)
      all_ids[idx] = NULL;

    if (all_ids[0] == NULL)
      continue;

    // Iterate on all iterators.
    int newids[space->num_sched_dim + 1];
    for (i = 0; all_ids[0][i] != -1; ++i)
    {
      // 1. Set the variable ids to update.
      for (j = 0; j  < space->num_sched_dim && all_ids[j]; ++j)
        newids[j] = all_ids[j][i];
      newids[j] = -1;

      // 2. Insert summation > 0.
      ponos_space_create_summation (space, -1, newids,
          PONOS_CONSTRAINT_GREATER,
          PONOS_OBJECTIVE_MINIMIZE,
          PONOS_UNUSED_VALUE);
    }
    for (i = 0; i < space->num_sched_dim && all_ids[i]; ++i)
      XFREE(all_ids[i]);
  }
}


/**
 * Make delta 1 as soon as the schedule fully satisfy the dependence.
 *
 */
  void
ponos_constraints_delta_up (s_ponos_space_t* space,
    s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;


  // Sum delta for a dim, and maximize it, last position in the problem.
  // Pushes dependences to be strongly solved as early as possible if
  // the schedule does indeed satisfy fully the dependence.
  int i, j;
  for (i = space->num_sched_dim - 1; i >= 0; --i)
  {
    // 2. Create the constraint variable.
    char buffer[32]; sprintf (buffer, "delta_up_opt%d_%d", 0, i);
    s_ponos_var_t* optvar =
      ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0,
          0, 0, NULL);
    // 3. Add it. We choose last here.
    ponos_space_insert_variable_last (space, optvar);

    int* ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_DELTA);

    // 4. Set summation.
    ponos_space_create_summation (space, space->num_vars - 1, ids,
        PONOS_CONSTRAINT_EQUAL,
        PONOS_OBJECTIVE_MAXIMIZE,
        PONOS_UNUSED_VALUE);
    XFREE(ids);
  }
}

