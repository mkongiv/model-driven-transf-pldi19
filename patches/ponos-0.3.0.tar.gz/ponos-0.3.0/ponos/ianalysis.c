/*
 * ianalysis.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012-2018 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Authors:
 * Martin Kong <martin.richard.kong@gmail.com>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>
#include <ponos/objectives.h>
#include <ponos/codelet.h>
#include <ponos/chunked.h>

#include <time.h>
#include <sys/time.h>
#include <scoplib/scop.h>
#include "iutil.c"

int chunked_get_stencil_width_statement (s_chunked_info_t *CI, int stmt_id)
{
  scoplib_matrix_p refs;
  int nc;
  int nr;
  int row;
  int n_iter = CI->SA[stmt_id]->nb_iterators;
  refs = CI->SA[stmt_id]->read; 
  nr = refs->NbRows;
  nc = refs->NbColumns;
  int min_shift = 100;
  int max_shift = 0;
  for (row = 0; row < nr; row++)
  {
    int scal;
    SCOPVAL_get_si (refs->p[row][nc-1]);
    min_shift = (scal < min_shift ? scal : min_shift);
    max_shift = (scal > max_shift ? scal : max_shift);
  }
  return max_shift - min_shift;
}


int is_stencil (s_ponos_space_t* space)
{
  scoplib_statement_p stmt;
  int n_stmt;
  int shifted = 0;
  for (stmt=space->scop->statement, n_stmt = 0; stmt; stmt = stmt->next, n_stmt ++)
  {
    scoplib_matrix_p refs = stmt->read; 
    int i;
    int nc;
    nc = refs->NbColumns - 1;
    int has_shift = 0;
    int n_shifts = 0;
    // FIXME: this is over-simplified; this should be done in a per reference basis!!!
    for (i = 0; i < refs->NbRows; i++)
      if (SCOPVAL_notzero_p (refs->p[i][nc]))
      {
        has_shift = 1;
        n_shifts ++;
      }
    refs = stmt->write;
    nc = refs->NbColumns - 1;
    for (i = 0; i < refs->NbRows; i++)
      if (SCOPVAL_notzero_p (refs->p[i][nc]))
      {
        has_shift = 1;
        n_shifts ++;
      }
    // Consider the statement shifted if it has 2 or more shifts
    if (n_shifts >= 1) // 2 makes fdtd-2d a gemm-like kernel >.<#!
      shifted++;
  }
  if (shifted >= 0.5 * n_stmt)
    return 1;
  return 0;
}


int uses_parameters (scoplib_statement_p stmt)
{
  int shifted = 0;
  scoplib_matrix_p refs;
  int i;
  int nc;

  int row;
  int n_iter = stmt->nb_iterators;
  refs = stmt->read; 
  int n_rows = refs->NbRows;
  int ranges[n_rows+1];
  int n_refs = 0;
  for (row = 0; row < n_rows; row++)
    if (SCOPVAL_pos_p(refs->p[row][0]))
  {
    ranges[n_refs++] = row;
  }
  ranges[n_refs] = row;
  
  nc = refs->NbColumns - 1;
  int is_const = 1;
  int rid;
  int uses_param = 0;
  int col;
  for (rid = 0; rid < n_refs; rid++)
  {
    for (row = ranges[rid]; row < ranges[rid+1]; row++)
    {
      for (col = n_iter+1; col < nc; col++)
      {
        int si;
        si = SCOPVAL_get_si(refs->p[row][col]);
        printf ("%d ", si);
        if (SCOPVAL_notzero_p (refs->p[row][col]))
          uses_param = 1;
      }
    }
  }

  refs = stmt->write;
  nc = refs->NbColumns - 1;
  for (row = 0; row < refs->NbRows; row++)
  {
    for (col = n_iter+1; col < nc; col++)
      if (SCOPVAL_notzero_p (refs->p[row][col]))
        uses_param = 1;
  }
  
  return uses_param;
}


/*
 * Conditions for a stencil statement:
 * a) at least two refs must use a constant shift
 * b) no constant access
 * c) no parameters used in refs
 */
int is_stencil_statement (scoplib_statement_p stmt)
{
  int shifted = 0;
  scoplib_matrix_p refs;
  int i;
  int nc;
  int has_shift;

  int row;
  int n_iter = stmt->nb_iterators;
  refs = stmt->read; 
  int n_rows = refs->NbRows;
  int ranges[n_rows+1];
  int n_refs = 0;
  for (row = 0; row < n_rows; row++)
    if (SCOPVAL_pos_p(refs->p[row][0]))
  {
    ranges[n_refs++] = row;
  }
  ranges[n_refs] = row;
  
  nc = refs->NbColumns - 1;
  has_shift = 0;
  int is_const = 1;
  int rid;
  int num_shifts = 0;
  for (rid = 0; rid < n_refs; rid++)
  {
    for (row = ranges[rid]; row < ranges[rid+1]; row++)
    {
      if (SCOPVAL_notzero_p (refs->p[row][nc]))
        has_shift = 1;
      int col;
      for (col = 1; col <= n_iter; col++)
        if (SCOPVAL_notzero_p (refs->p[row][col]))
          is_const = 0;
      if (SCOPVAL_notzero_p (refs->p[row][nc]) && !is_const)
        num_shifts++;
    }
  }

  refs = stmt->write;
  nc = refs->NbColumns - 1;
  for (row = 0; row < refs->NbRows; row++)
  {
    if (SCOPVAL_notzero_p (refs->p[row][nc]))
      has_shift = 1;
    int col;
    for (col = 1; col <= n_iter; col++)
      if (SCOPVAL_notzero_p (refs->p[row][col]))
        is_const = 0;
    if (SCOPVAL_notzero_p (refs->p[row][nc]) && !is_const)
      num_shifts++;
  }
  
  if (is_const)
    return 0;
  if (! has_shift)
    return 0;
  if (num_shifts < 2)
    return 0;
  return 1;
}

int has_single_outer_loop (s_ponos_space_t * space)
{
  scoplib_statement_p stmt;
  int n_stmt;
  int shifted = 0;
  scoplib_matrix_p refs; 
  stmt=space->scop->statement;
  int first_si = SCOPVAL_get_si (stmt->schedule->p[0][1]);
  int single_loop = 1;
  for (stmt = stmt->next, n_stmt = 1; stmt; stmt = stmt->next, n_stmt ++)
  {
    int curr_si = SCOPVAL_get_si (stmt->schedule->p[0][1]);
    if (first_si != curr_si)
      single_loop = 0;
  }
  return single_loop;
}



int is_jacobi (int n_dep, int n_stmt, int n_dim)
{
  if (n_dim <= 5)
    return 0;
  if (n_dep * 1.0 / n_dim < n_stmt)
    return 0;
  if (n_dep * 1.0 / n_dim >= 3)
    return 0;
  return 1;
}



void
ponos_chunked_show_dependence_info (s_ponos_space_t* space,
    s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int* ids = ponos_space_get_coefs_dim (space, 0,  PONOS_VAR_DELTA);
  int ii;
  for (ii = 0; ids[ii] != -1; ii++)
  {
    int varid = ids[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
    int is_self = dep->source == dep->target;
    const char * deptype;
    if (dep->type == CANDL_RAW)
      deptype = "RAW";
    if (dep->type == CANDL_RAR)
      deptype = "RAR";
    if (dep->type == CANDL_WAW)
      deptype = "WAW";
    if (dep->type == CANDL_WAR)
      deptype = "WAR";
    printf ("Dependence %d (%d->%d), is_self = %d, type = %s, level = %d\n",
      ii,dep->source->label,dep->target->label,is_self,deptype,dep->depth);
  }
  XFREE (ids);
}


void ponos_chunked_free_info (s_chunked_info_t * CI)
{
  XFREE (CI->W_stmt);
  XFREE (CI->W_ref);
  XFREE (CI->W_lat);
  XFREE (CI->SA);
  XFREE (CI->self_dep);
  XFREE (CI);
}

s_chunked_mode_t * 
ponos_chunked_mode_init (s_chunked_info_t * CI, int chunk_mode)
{
  s_chunked_mode_t * ret;
  ret = XMALLOC (s_chunked_mode_t, 1);
  ret->type = chunk_mode;
  switch (ret->type)
  {
    case PONOS_CHUNKED_LIMIT_NONE: 
      break;
    case PONOS_CHUNKED_LIMIT_REF:
      ret->suffix = "^(ref)";  
      ret->limit = CI->max_loop_ref;
      ret->W = CI->W_ref;
      break;
    case PONOS_CHUNKED_LIMIT_STMT:
      ret->suffix = "^(stmt)";  
      ret->limit = CI->max_loop_stmt;
      ret->W = CI->W_stmt;
      break;
    case PONOS_CHUNKED_LIMIT_LAT:
      ret->suffix = "^(lat)";  
      ret->limit = CI->max_loop_lat;
      ret->W = CI->W_lat;
      break;
  }
  return ret;
}



// Chunked graph: Stuff for detecting SCCs

void do_dfs (s_ponos_space_t* space,
    s_chunked_info_t * CI, s_chunked_graph_t * CG, int start)
{
  int ee;
  for (ee = 0; ee < CI->n_stmt; ee++)
  {
    if (CG->graph[start][ee])
    {
      if (CG->status[ee] == CHUNKED_WHITE)
      {
        CG->status[ee] = CHUNKED_GRAY;
        CG->pred[ee] = start;
        //printf ("Adding edge (%d -> %d)\n",start,ee);
        do_dfs (space, CI, CG, ee);
      }
      else if (CG->status[ee] == CHUNKED_GRAY)// || CG->status[ee] == CHUNKED_BLACK)
      {
        // back-edge found
        CG->loops[0][CG->n_loop] = start;
        CG->loops[1][CG->n_loop] = ee;
        //printf ("Adding back-edge (%d -> %d)\n",start,ee);
        CG->n_loop++;
      }
      else if (CG->status[ee] == CHUNKED_BLACK)
      {
        continue;
      }
    }
  }
  CG->status[start] = CHUNKED_BLACK;
}


void
dfs_start_old (s_ponos_space_t* space,
    s_chunked_info_t * CI, s_chunked_graph_t * CG)
{
  int ii, jj;
  CG->n_loop = 0;
  printf ("Showing dependence graph: \n");
  for (ii = 0; ii < CI->n_stmt; ii++)
  {
    for (jj = 0; jj < CI->n_stmt; jj++)
      printf ("%d ",CG->graph[ii][jj]);
    printf ("\n");
  }
  CG->time = 0;
  for (ii = 0; CG->scc[ii]; ii++)
  {
    for (jj = 0; CG->scc[ii][jj] != CHUNKED_END; jj++);
    // skip the rest if we have only one statement in the current SCC
    if (jj == 1)
      continue;
    int last_node = jj -1;
    for (jj = 0; jj <= last_node; jj++)
    {
      int node_id = CG->scc[ii][jj];
      if (CG->status[ii] == CHUNKED_WHITE)
      {
        CG->status[node_id] = CHUNKED_GRAY;
        do_dfs (space, CI, CG, node_id);
      }
    }
  }
}


void chunked_dfs (s_ponos_space_t* space,
    s_chunked_info_t * CI, s_chunked_graph_t * CG, int start)
{
  int ii;
  if (CG->status[start] != CHUNKED_WHITE)
    return;
  CG->leader[start] = CG->curr_leader;
  CG->status[start] = CHUNKED_GRAY;
  for (ii = 0; ii < CI->n_stmt; ii++)
    if (CG->graph[start][ii] ==  CHUNKED_HAS_DEP)
  {
    if (CG->status[ii] == CHUNKED_WHITE)
    {
      //printf ("Setting predecessor of %d to %d\n", ii, start);
      CG->pred[ii] = start;
    }
    if (CG->status[ii] == CHUNKED_GRAY)
    {
      //printf ("Setting predecessor of %d to %d\n", ii, start);
      CG->back[start] = 1;
      //printf ("Marking back edge (%d,%d)\n",start, ii);
    }
    chunked_dfs (space, CI, CG, ii);
  }
  CG->ftime[start] = CG->time++;
  CG->status[start] = CHUNKED_BLACK;
}


void
dfs_start (s_ponos_space_t* space,
    s_chunked_info_t * CI, s_chunked_graph_t * CG)
{
  int ii, jj;
  CG->time = 0;
  for (ii = 0; ii < CI->n_stmt; ii++)
  {
    int nodeid = !CG->order ? ii : CG->order[ii];
    if (CG->status[nodeid] == CHUNKED_WHITE)
    {
      //printf ("On node %d\n", nodeid);
      CG->curr_leader = nodeid;
      chunked_dfs (space, CI, CG, nodeid); 
    }
  }
}


s_chunked_graph_t * 
ponos_chunked_init_graph (s_ponos_space_t * space, s_chunked_info_t * CI, int reverse_edges)
{
  int nstmt = CI->n_stmt;
  s_chunked_graph_t * CG;
  int ii;

  printf ("Chunked CG: init...\n");

  CG = XMALLOC (s_chunked_graph_t, 1);
  CG->graph = XMALLOC (int*, nstmt);
  int ** scc;
  scc = XMALLOC (int*, nstmt+1);
  CG->scc = scc;
  CG->status = XMALLOC (int, nstmt);

  CG->size = XMALLOC (int, nstmt);
  CG->intra = XMALLOC (int, nstmt);
  CG->inter = XMALLOC (int, nstmt);
  CG->self = XMALLOC (int, nstmt);
  CG->bmin = XMALLOC (int, nstmt);
  CG->bmax = XMALLOC (int, nstmt);
  CG->back = XMALLOC (int, nstmt);

  CG->leader = XMALLOC (int, nstmt+1);
  CG->ftime = XMALLOC (int, nstmt+1);
  CG->pred = XMALLOC (int, nstmt);
  CG->loops[0] = XMALLOC (int, nstmt*nstmt+1);
  CG->loops[1] = XMALLOC (int, nstmt*nstmt+1);
  CG->scc_map = XMALLOC (int, nstmt);
  CG->xpath = XMALLOC (int*, nstmt+1);
  CG->fgraph = NULL;
  for (ii = 0; ii <= nstmt; ii++)
  {
    CG->scc[ii] = NULL;
    CG->xpath[ii] = NULL;
  }
  for (ii = 0; ii < nstmt*nstmt+1; ii++)
  {
    CG->loops[0][ii] = CHUNKED_UNDEF;
    CG->loops[1][ii] = CHUNKED_UNDEF;
  }
  for (ii = 0; ii < nstmt; ii++)
  {
    CG->graph[ii] = XMALLOC (int, nstmt);
    CG->status[ii] = CHUNKED_WHITE;
    CG->pred[ii] = CHUNKED_NO_PRED;
    CG->leader[ii] = -1;
    CG->ftime[ii] = 0;
    CG->size[ii] = 0;
    CG->intra[ii] = 0;
    CG->inter[ii] = 0;
    CG->self[ii] = 0;
    CG->bmin[ii] = 0;
    CG->bmax[ii] = 0;
    CG->back[ii] = 0;
    int jj;
    for (jj = 0; jj < nstmt; jj++)
    {
      CG->graph[ii][jj] = CHUNKED_NO_DEP;
    }
  }

  printf ("Chunked CG: setting dependences...\n");

  // Collect the delta variables of dimension 0 to fetch the set of dependences
  int* ids = ponos_space_get_coefs_dim (space, 0,  PONOS_VAR_DELTA);
  for (ii = 0; ids[ii] != -1; ii++)
  {
    int varid = ids[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
    // We consider all dependences (RAW,WAR,WAW)
    int is_self = dep->source == dep->target;
    int dep_level = dep->depth;
    //if (dep_level != level)
    //  continue;
    int src_id = dep->source->label;
    int dst_id = dep->target->label;
    // Also filter out self-dependences
    if (src_id == dst_id)
      continue;
    if (!reverse_edges)
      CG->graph[src_id][dst_id] = CHUNKED_HAS_DEP;
    else
      CG->graph[dst_id][src_id] = CHUNKED_HAS_DEP;
  }
  XFREE (ids);

  return CG;
}

static
void ponos_chunked_instantiate_path (s_chunked_graph_t * CG, int loop, int * path)
{
  int start = CG->loops[0][loop]; 
  int end   = CG->loops[1][loop];
  int len1 = 0;
  int jj;
  //printf ("Instantiating loop %d (%d ~~> %d)\n",loop, start, end);
  for (jj = start; 
       jj != end && jj != CHUNKED_NO_PRED && jj != CHUNKED_UNDEF;
       jj = CG->pred[jj])
  {
    //printf ("Placing %d at position %d\n",jj,len1);
    path[len1++] = jj;
  }
  //printf ("Placing %d at position %d\n",end,len1);
  path[len1++] = end;
  path[len1] = CHUNKED_END;
}

void
ponos_show_fgraph (s_fgraph_t * fgraph)
{
  int ii;
  if (!fgraph)
  {
   fprintf (stderr, "F-Graph has not been constructed.\n");
   fprintf (stderr, "Invoke function ponos_chunked_build_fgraph.\n");
    return;
  }

  fprintf (fgraph->logfile, "F-Graph summary\n");
  fprintf (fgraph->logfile, "---------------\n");
  fprintf (fgraph->logfile, "Number of nodes: %d\n",fgraph->n_nodes);
  fprintf (fgraph->logfile, "Number of edges: %d\n",fgraph->n_edges);
  fprintf (fgraph->logfile, "Statement to node map:\n");
  for (ii = 0; ii < fgraph->n_stmt; ii++)
  {
    fprintf (fgraph->logfile, "--> Statement %d: Node %d\n",ii,fgraph->map[ii]);
  }
  fprintf (fgraph->logfile, "Node members:\n");
  for (ii = 0; ii < fgraph->n_nodes; ii++)
  {
    int jj;
    int nodetype = fgraph->nodes[ii].nodetype;
    int self =  fgraph->nodes[ii].n_self_dep;
    int all =  fgraph->nodes[ii].n_dep;
    fprintf (fgraph->logfile, "--> Node %d (%s,%d/%d)\n",ii, 
      (nodetype == FNODE_TYPE_SCC ? "SCC" : nodetype == FNODE_TYPE_STEN ? "STEN" : "SET"),
      self, all);
    for (jj = 0; jj < fgraph->nodes[ii].n_members; jj++)
     fprintf (fgraph->logfile, "    |--> Statement %d\n",fgraph->nodes[ii].members[jj]);
  }
 fprintf (fgraph->logfile, "F-Graph summary end. \n\n");
}


void ponos_chunked_graph_free (s_chunked_graph_t * CG)
{
  int ii;
  printf ("Chunked CG: Freeing stuff...\n");
  XFREE (CG->graph); CG->graph = NULL;
  XFREE (CG->status); CG->status = NULL;
  XFREE (CG->pred); CG->pred = NULL;
  XFREE (CG->leader); CG->leader = NULL;
  XFREE (CG->ftime); CG->ftime = NULL;
  XFREE (CG->intra); CG->intra = NULL;
  XFREE (CG->inter); CG->inter = NULL;
  XFREE (CG->self); CG->self = NULL;
  XFREE (CG->size); CG->size = NULL;
  XFREE (CG->bmin); CG->bmin = NULL;
  XFREE (CG->bmax); CG->bmax = NULL;
  XFREE (CG->back); CG->back = NULL;
  if (CG->loops[0])
  {
    XFREE (CG->loops[0]); CG->loops[0] = NULL;
  }
  if (CG->loops[1])
  {
    XFREE (CG->loops[1]); CG->loops[1] = NULL;
  }
  for (ii = 0; CG->scc[ii]; ii++)
    XFREE (CG->scc[ii]);

  for (ii = 0; CG->xpath[ii]; ii++)
    XFREE (CG->xpath[ii]);
  XFREE (CG->scc);
  XFREE (CG->scc_map);
  XFREE (CG->xpath);

  if (CG->fgraph)
  {
    for (ii = 0; ii < CG->fgraph->n_nodes; ii++)
    {
      XFREE (CG->fgraph->nodes[ii].members);
    }
    if (CG->fgraph->nodes)
      XFREE (CG->fgraph->nodes);
    if (CG->fgraph->edges)
      XFREE (CG->fgraph->edges);
    if (CG->fgraph->map)
      XFREE (CG->fgraph->map);
  }
}



/*
 * This function builds the "Fusibility Graph" or "F-graph".
 * It's a high-level DAG. 
 * Properties:
 * - Each node is a: i) SCC or ii) Set of statements delimited by a SCC
 * - Used to construct a topological sorting of the nodes
 * - Provides structure to the high-level fusion constraints
 * - Each node will have one beta coefficient, which will be used to
 *   bound and derive the beta coefficients of each statement in a cluster
 * - Nodes (clusters) will be sorted by their read-reuse (only RAR deps)
 * - 
 */
void
ponos_chunked_build_fgraph (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;
  
  int ii;
  int nstmt = CI->n_stmt;

  scoplib_statement_p stmt;
  scoplib_statement_p * SS = CI->SA;

  //printf ("Building F-GRAPH...\n");

  int singlesccs[nstmt];
  // collect statements which we expect to be alone in a SCC
  // Set respective entry to 1 if it's a single SCC
  int * delta_ids = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_DELTA);
  for (ii = 0; ii < nstmt; ii++)
  {
    int jj;
    int count = 0;
    for (jj = 0; delta_ids[jj] != -1; jj++)
    {
      int varid = delta_ids[jj];
      CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
      assert (dep && "CandlDependence not found in delta variable");
      int is_self = dep->source == dep->target;
      // We look for self-dependences on statement ii
      if (is_self && dep->source->label == ii)
        count++;
    }
    // We assume this statement must be in its own SCC if we have at least
    // as many dependences as scheduling dimensions
    int res = count >= SS[ii]->nb_iterators;
    singlesccs[ii] = (res ? 1 : 0); 
    //printf ("Statement %d is Single SCC ? %d\n",ii,res);
  }

  XFREE (delta_ids);


  CG->fgraph = XMALLOC (s_fgraph_t, 1);
  CG->fgraph->nodes = NULL;
  CG->fgraph->edges = NULL;


  // Worst case scenario, each statement is its own SCC, 
  // so allocate as many nodes as statements
  CG->fgraph->nodes = XMALLOC (s_fnode_t, nstmt);
  CG->fgraph->map = XMALLOC (int, nstmt);

  // Keep track of which statements have been included in some SET/SCC
  int nscc = CG->n_scc;
  int inscc[nstmt];
  for (ii = 0; ii < nstmt; ii++)
  {
    inscc[ii] = 0;
    CG->fgraph->map[ii] = -1;
  }
  // Ditto but for the SCCs in the graph.
  int sccmask[nscc];
  for (ii = 0; ii < nscc; ii++)
  {
    sccmask[ii] = 0;
  }


  int n_stmt_in_scc = 0;
  int n_clusters = 0;
  // Phase 1: copy statements as "true SCCs"


  int actual_n_scc = 0;
  for (ii = 0; CG->scc[ii]; ii++)
  {
    int jj;
    // Count number of statements in SCC.
    // If we have more than 1 statement in the SCC, then we have a real SCC.
    int cluster_size = CG->size[ii]; 
    if (cluster_size > 1 || (cluster_size == 1 && singlesccs[CG->scc[ii][0]]))
    {
      s_fnode_t * fnode = &CG->fgraph->nodes[n_clusters];
      fnode->nodetype = FNODE_TYPE_SCC; // default nodetype of F-GRAPH nodes
      fnode->n_members = cluster_size;
      fnode->members = XMALLOC (int, cluster_size);
      fnode->flexibility = 0.0;

      //fnode->beta = SCOPVAL_get_si (sched->p[0][n_col-1]);
      fnode->betamin = CG->bmin[ii];
      fnode->betamax = CG->bmax[ii];
      fnode->n_dep = CG->intra[ii] + CG->self[ii];
      fnode->n_intra = CG->intra[ii];
      fnode->n_self_dep = CG->self[ii];

      int max_depth = 0;
      int has_cycle = 0;
      for (jj = 0; CG->scc[ii][jj] != CHUNKED_END; jj++)
      {
        int stmtid = CG->scc[ii][jj];
        fnode->members[jj] = stmtid;
        inscc[stmtid] = 1;
        CG->fgraph->map[stmtid] = n_clusters;
        if (SS[stmtid]->nb_iterators > max_depth)
          max_depth = SS[stmtid]->nb_iterators;
        has_cycle = has_cycle || CG->back[stmtid];
      }
      fnode->max_depth = max_depth;

      float dep_weight; 
      float clu_size = fnode->n_members;
      float clu_depth = fnode->max_depth;
      if (fnode->n_self_dep < fnode->n_dep)
        dep_weight = fnode->n_intra;
      else
        dep_weight = fnode->n_self_dep;
      fnode->flexibility = dep_weight / clu_depth;

      if (!has_cycle && fnode->n_self_dep < fnode->n_dep) // || fnode->betamin < fnode->betamax)
        fnode->nodetype = FNODE_TYPE_SET;

      if (fnode->nodetype == FNODE_TYPE_SCC) 
        actual_n_scc++;

      n_stmt_in_scc += cluster_size;  // to determine how many statements we have left
      n_clusters++;
    }
  }


  // Phase 2: do "dumb" sort of current SCCs by their beta value
  #if 0
  for (ii = 0; ii < n_clusters - 1; ii++)
  {
    int jj;
    for (jj = ii + 1; jj < n_clusters; jj++)
      if (CG->fgraph->nodes[jj].beta < CG->fgraph->nodes[ii].beta)
    {
      s_fnode_t temp = CG->fgraph->nodes[ii];
      CG->fgraph->nodes[ii] = CG->fgraph->nodes[jj];
      CG->fgraph->nodes[jj] = temp;
    }
  }
  // Also fix the map entries after reordering
  for (ii = 0; ii < n_clusters; ii++)
  {
    int jj;
    for (jj = 0; jj < CG->fgraph->nodes[ii].n_members; jj++)
    {
      int stmtid = CG->fgraph->nodes[ii].members[jj];
      CG->fgraph->map[stmtid] = ii;
    }
  }
  #endif


  

  // Phase 3: 
  // Traverse the list of inclustered statements and put them in some set.
  // Query their outer beta coefficient to decide in which set to place.
  int n_clustered_stmts = nstmt - n_stmt_in_scc;
  //printf ("Number of statements accounted for in SCCs: %d (pending=%d)\n",n_stmt_in_scc,n_clustered_stmts);
  //s_fnode_t endnode;
  //endnode.beta = nstmt * 10;
  int old_n_clusters = n_clusters;


  int beta_cluster = 1000; // This will never be used with 1000 statements :-)
  while (n_clustered_stmts > 0)
  {
    int jj;
    int bmin = -1;
    int bmax = -1;
    for (jj = 0; jj < CG->n_scc; jj++)
      if (CG->size[jj] == 1)
    {
      int stmtid = CG->scc[jj][0];
      if (!inscc[stmtid])
      {
        bmin = CG->bmin[jj];
        bmax = CG->bmax[jj];
        break;
      }
    }

    int betanext = 1000; //CG->n_scc;
    // Find the next SCC not yet processed with the smallest beta and keep it.
    for (jj = 0; jj < CG->n_scc; jj++)
      if (CG->size[jj] > 1 && CG->bmin[jj] < betanext && !sccmask[jj])
      {
        sccmask[jj] = 1;
        betanext = CG->bmin[jj];
        break;
      }
    // If we have used all the SCC as delimiters, then the @betanext will keep
    // the initialized value, and all remaining statements will be collected.

    // Found more statements
    if (bmin >= 0 && bmax >= 0)
    {
      s_fnode_t * fnode = &CG->fgraph->nodes[n_clusters];
      fnode->n_dep = 0;
      fnode->n_self_dep = 0;
      fnode->n_intra = 0;
      int clusterbuf[CI->n_stmt];
      for (jj = 0; jj < CI->n_stmt; jj++)
        clusterbuf[jj] = -1;

      int n_members = 0;
      int max_depth = 0;
      int added;
      //for (added = 1; bmin < betanext; bmin++)
      {
        added = 0;
        //printf ("Current SCC beta limit: %d (bmin is %d)\n", betanext, bmin);
        for (jj = 0; jj < CG->n_scc; jj++)
          if (CG->size[jj] == 1)
        {
          int stmtid = CG->scc[jj][0];
          if (!inscc[stmtid] && (CG->bmin[jj] < betanext || actual_n_scc == 0)) // && CG->bmax[jj] == bmax)
          {
            clusterbuf[n_members++] = stmtid;
            inscc[stmtid] = 1;
            n_clustered_stmts--;
            CG->fgraph->map[stmtid] = n_clusters;
            fnode->n_dep += CG->intra[jj] + CG->self[jj];
            fnode->n_intra += CG->intra[jj];
            fnode->n_self_dep += CG->self[jj];
            if (SS[stmtid]->nb_iterators > max_depth)
              max_depth = SS[stmtid]->nb_iterators;
            added = 1;
          }
        }
      }
      if (n_members)
      {
        fnode->nodetype = FNODE_TYPE_SET;
        fnode->members = XMALLOC (int, n_members);
        fnode->n_members = n_members;
        fnode->betamin = bmin;
        fnode->betamax = bmin + n_members - 1;
        fnode->max_depth = max_depth;


        float dep_weight; 
        float clu_size = fnode->n_members;
        float clu_depth = fnode->max_depth;
        if (fnode->n_self_dep < fnode->n_dep)
          dep_weight = fnode->n_intra;
        else
          dep_weight = fnode->n_self_dep;
        fnode->flexibility = dep_weight / clu_depth;
      
        assert (n_members > 0);
        for (jj = 0; jj < n_members; jj++)
          fnode->members[jj] = clusterbuf[jj];
        n_clusters++;
        beta_cluster = bmin;
      }
    }
  }

  CG->fgraph->n_nodes = n_clusters;
  CG->fgraph->n_stmt = nstmt;
}

void
ponos_chunked_show_nodetype (s_fnode_t fnode)
{
  printf ("\n\n");
  printf ("FNODE-info:\n");
  printf ("==> No.members: %d\n", fnode.n_members);
  printf ("==> Beta range: [%d:%d]\n", fnode.betamin, fnode.betamax);
  printf ("==> Max. depth: %d\n", fnode.max_depth);
  printf ("==> #deps     : %d\n", fnode.n_dep);
  printf ("==> #n_intra  : %d\n", fnode.n_intra);
  printf ("==> #self.deps: %d\n", fnode.n_self_dep);
  printf ("==> nodetype  : ");
  switch (fnode.nodetype) {
    case FNODE_TYPE_SCC: printf ("SCC"); break;
    case FNODE_TYPE_SET: printf ("SET"); break;
    case FNODE_TYPE_STEN: printf ("STEN"); break;
  }
  printf ("\n");
  int ii;
  printf ("==> Members   :");
  for (ii = 0; ii < fnode.n_members; ii++)
  {
    if (ii)
      printf (",");
    printf ("%d", fnode.members[ii]);
  }
  printf ("\n");
  float dep_weight; 
  if (fnode.n_self_dep < fnode.n_dep)
    dep_weight = fnode.n_intra;
  else
    dep_weight = fnode.n_self_dep;
  printf ("==> Flexibility = %f (%f/%d)\n",fnode.flexibility, dep_weight, fnode.max_depth);
}


/*
 * Construct the set of SCCs of the given SCOP and at the given level.
 * Return an array NULL terminated array, where each row is a SCC.
 * Entries in the same row are in the same SCC.
 * The user must free the returned array.
 */
s_chunked_graph_t *
ponos_chunked_compute_scc_level_old (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, int level)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return NULL;
  
  int ii;
  int nstmt = CI->n_stmt;
  scoplib_statement_p stmt;
  scoplib_statement_p * SS;

  s_chunked_graph_t * CG;
  CG = ponos_chunked_init_graph (space, CI, 0);

  SS = XMALLOC (scoplib_statement_p, nstmt);
  for (ii = 0, stmt=space->scop->statement; stmt; stmt = stmt->next, ii++)
    SS[ii] = stmt;

  printf ("Chunked CG: initializing SCCs...\n");

  // Start by placing statements which have different scalar coefficient values
  // at the requested level.
  for (ii = 0; ii < nstmt; ii++)
  {
    // fetch the scalar coefficient of the requested level for the current stmt
    scoplib_matrix_p sched = SS[ii]->schedule;
    int n_col = sched->NbColumns;
    int scalar_si = SCOPVAL_get_si (sched->p[2*level][n_col-1]);
    // If the scc for this coefficient does not exist, create it 
    // and initialize it
    if (!CG->scc[scalar_si])
    {
      CG->scc[scalar_si] = XMALLOC(int,nstmt+1);
      CG->scc[scalar_si][0] = CHUNKED_END;
    }
    int jj;
    // Find the end of the array and add the stmt id to it
    for (jj = 0; CG->scc[scalar_si][jj] != CHUNKED_END; jj++);
    CG->scc[scalar_si][jj++] = ii;
    CG->scc[scalar_si][jj] = CHUNKED_END;
  }

  for (ii = 0; CG->scc[ii]; ii++)
  {
    int jj;
    for (jj = 0; CG->scc[ii][jj] != CHUNKED_END; jj++)
    {
    }
  }

  // Now run DFS and check if the statements that appear in the same SCC
  // actually require to be in the same SCC.

  printf ("Chunked CG: starting DFS...\n");

  dfs_start (space, CI, CG);

  #if 0
  printf ("Chunked CG: Number of loops found : %d\n",CG->n_loop);
  if (CG->n_loop > 0)
  {
    int jj;
    assert (CG->loops[0]);
    assert (CG->loops[1]);
    for (jj = 0; jj < CG->n_loop; jj++)
    {
      printf ("Loop %d: (%d ~~> %d)\n ==>",jj,CG->loops[0][jj],CG->loops[1][jj]);
      int kk;
      for (kk = CG->loops[0][jj]; kk != CG->loops[1][jj]; kk = CG->pred[kk])
        printf ("%d ", kk);
      printf ("%d",kk);
      printf ("\n");
    }
  }

  printf ("Predecessor list: \n");
  for (ii = 0; ii < CI->n_stmt; ii++)
  {
    printf ("Predecessor of node %d = %d\n",ii,CG->pred[ii]);
  }
  #endif

  printf ("[Chunked CG: Merging apparently disconnected loops]\n");
  int * path1;
  int * path2;
  int len1;
  int len2;
  path2 = XMALLOC (int, nstmt+2);
  int i_path;
  for (ii = 0, i_path = 0; ii < CG->n_loop; ii++)
  {
    if (CG->loops[0][ii] == CHUNKED_UNDEF)
      continue;
    len1 = 0;
    path1 = XMALLOC (int, nstmt+2);
    int jj;
    ponos_chunked_instantiate_path (CG, ii, path1);
    for (jj = 0; path1[jj] != CHUNKED_END; jj++)
    {
      //printf ("Node %d at position %d of path %d\n", path1[jj], jj, ii);
    }
    for (jj = ii + 1; jj < CG->n_loop; jj++)
    {
      if (CG->loops[0][jj] == CHUNKED_UNDEF)
        continue;
      //printf ("Testing mergeability of cycle %d with cycle %d\n", ii, jj);
      ponos_chunked_instantiate_path (CG, jj, path2);
      int k1,k2;
      int must_merge = 0;
      // Find an intersection between the two paths
      for (k1 = 0; path1[k1] != CHUNKED_END; k1++)
      {
        for (k2 = 0; path2[k2] != CHUNKED_END; k2++)
          if (path1[k1] == path2[k2])
          {
            must_merge = 1;
            break;
          }
      }
      // if we need to merge, copy the elements that don't exist in path1
      if (must_merge)
      {
        printf ("Merging loop (%d) with loop (%d)\n",jj,ii);
        for (k1 = 0; path1[k1] != CHUNKED_END; k1++);
        int end1 = k1;
        #if 1
        for (k2 = 0; path2[k2] != CHUNKED_END; k2++)
        {
          int is_in = 0;
          for (k1 = 0; path1[k1] != CHUNKED_END; k1++)
            if (path1[k1] == path2[k2])
              is_in = 1;
          if (!is_in)
          {
            assert (end1 < nstmt+1);
            path1[end1++] = path2[k2];
            path1[end1] = CHUNKED_END;
          }
        }
        #endif

        //printf ("Showing merged path (%d = %d U %d): ",ii, ii, jj);
        //for (k1 = 0; path1[k1] != CHUNKED_END; k1++)
        //  printf ("%d ",path1[k1]);
        //printf ("\n");
        CG->loops[0][jj] = CHUNKED_UNDEF;
        CG->loops[1][jj] = CHUNKED_UNDEF;
      }
    }
    //printf ("Consolidated path %d is: ",i_path);
    //for (jj = 0; path1[jj] != CHUNKED_END; jj++)
    //  printf ("stmt_%d ",path1[jj]);
    //printf ("\n");
    CG->xpath[i_path++] = path1;
  }
  CG->xpath[i_path] = NULL;
  XFREE (path2);

  printf ("Chunked CG: separating independent statements in SCCs...\n");
  for (ii = 0; ii < i_path && CG->xpath[ii]; ii++)
  {
    int jj;
    printf ("Nodes in XPATH %d = ",ii);
    for (jj = 0; CG->xpath[ii][jj] != CHUNKED_END; jj++)
      printf ("%d ",CG->xpath[ii][jj]);
    printf ("\n");
  }
  printf ("Total number of paths founds: %d\n\n",ii);
  


  // Update the SCC with the predecesor information
  // For every pair of statements in a current SCC, check if they are in a loop
  // If they are not, create a new 
  int same[CI->n_stmt];
  for (ii = 0; CG->scc[ii]; ii++)
  {
    //printf ("Testing nodes of SCC %d\n",ii);
    int jj;
    // Initialize boolean vector to determine who stays in the current SCC
    for (jj = 0; jj < CI->n_stmt; jj++)
    {
      same[jj] = 0;
    }
    // If we have only 1 node in the SCC, skip
    if (CG->scc[ii][1] == CHUNKED_END)
      continue;
    int ll;
    // Check all the loops found
    for (ll = 0; CG->xpath[ll]; ll++)
    {
      int nn;
      int count = 0;
      int n_nodes_in_scc = 0;
      int found = 0;
      //printf ("Testing belongedness of nodes in path %d\n",ll);
      for (nn = 0; CG->xpath[ll][nn] != CHUNKED_END; nn++)
      {
        //printf ("==> Node in path: %d\n", CG->xpath[ll][nn]);
        for (jj = 0; jj < CI->n_stmt && CG->scc[ii][jj] != CHUNKED_END ; jj++)
        {
          if (CG->scc[ii][jj] == CG->xpath[ll][nn])
          {
            //printf ("Value in SCC[%d][%d] = %d\n", ii, jj, CG->scc[ii][jj]);
            same[jj] = 1;
            count++;
          }
        }
      }
      n_nodes_in_scc = jj;
      //printf ("At SCC%d, count=%d, #nodes orinally in SCC = %d\n", ii,count,n_nodes_in_scc);
      if (count < n_nodes_in_scc && count > 0)
      {
        // Find the end of the SCC list (the first NULL entry)
        for (jj = 0; CG->scc[jj]; jj++);
        int new_scc = jj;
        int start_of_move;
        start_of_move = (count == 0 ? 1 : 0);
        CG->scc[new_scc] = XMALLOC (int, CI->n_stmt + 1);
        //printf ("Chunked CG: creating new SCC at position %d\n",new_scc);
        // move nodes not in the scc to a new scc for future processing
        int scc_it = 0;
        int stay[CI->n_stmt];
        int i_stay = 0;
        for (jj = 0/*start_of_move*/; jj < n_nodes_in_scc && CG->scc[ii][jj] != CHUNKED_END; jj++)
        {
          if (!same[jj])
          {
            found = 1;
            CG->scc[new_scc][scc_it++] = CG->scc[ii][jj];
            CG->scc[new_scc][scc_it] = CHUNKED_END;
            CG->scc[ii][jj] = CHUNKED_END;
          }
          else
          {
            stay[i_stay++] = CG->scc[ii][jj];
          }
        }
        if (i_stay > 0)
        {
          //printf ("Chunked CG: moved %d nodes from SCC%d to SCC%d\n",scc_it,ii,new_scc);
          // Compact the list of nodes in the current SCC
          for (jj = 0; jj < i_stay; jj++)
            CG->scc[ii][jj] = stay[jj];
          CG->scc[ii][jj] = CHUNKED_END;
        }
        assert (i_stay + scc_it == n_nodes_in_scc);
      }
      if (found)
        break;
    }
    // No loop, fully distribute the SCC
    if (CG->n_loop == 0)
    {
      int jj;
      // Move all the nodes, from the 2nd one in the current SCC to 
      // separate and independent SCCs.
      for (jj = 1; CG->scc[ii][jj] != CHUNKED_END; jj++)
      {
        int kk;
        for (kk = 0; CG->scc[kk]; kk++);
        //printf ("Creating new SCC at position %d, moving statement %d\n",kk,CG->scc[ii][jj]);
        CG->scc[kk] = XMALLOC (int, CI->n_stmt+1);
        CG->scc[kk][0] = CG->scc[ii][jj];
        CG->scc[kk][1] = CHUNKED_END;
        CG->scc[ii][jj] = CHUNKED_END;
      }
    }
  }


  // Finally, create the scc_map in CG
  for (ii = 0; CG->scc[ii]; ii++)
  {
    int jj;
    for (jj = 0; CG->scc[ii][jj] != CHUNKED_END; jj++)
      CG->scc_map[CG->scc[ii][jj]] = ii;
  }
  // Store the number of SCC
  CG->n_scc = ii;

  #if 0
  printf ("Chunked CG: Strongly connected components at level %d\n",level);
  for (ii = 0; CG->scc[ii]; ii++)
  {
    int jj;
    printf ("SCC %d: ",ii);
    for (jj = 0; CG->scc[ii][jj] != CHUNKED_END; jj++)
    {
      printf ("stmt %d ",CG->scc[ii][jj]);
    }
    printf ("\n");
  }

  printf ("Chunked CG: Strongly connected components at level %d\n",level);
  for (ii = 0; ii < CI->n_stmt; ii++)
  {
    printf ("Statement %d => SCC %d\n",ii,CG->scc_map[ii]);
  }
  printf ("\n");
  #endif


  XFREE (SS);
  return CG;
}






void
ponos_chunked_subclassify_sccs (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;
  
  int ii;
  int nstmt = CI->n_stmt;
  scoplib_statement_p stmt;

  s_fgraph_t * fgraph = CG->fgraph;
  int nn;
  for (nn = 0; nn < fgraph->n_nodes; nn++)
  {
    int has_stmt_sten = 0;
    int uses_param = 0;
    for (ii = 0, stmt=space->scop->statement; ii < nstmt; ii++, stmt = stmt->next)
    {
      int sten = is_stencil_statement (stmt);
      int up = uses_parameters (stmt);
      uses_param = uses_param || up;
      int anode = CG->fgraph->map[ii];
      int self = CG->fgraph->nodes[anode].n_self_dep;
      int all = CG->fgraph->nodes[anode].n_dep;
      //fprintf (CI->logfile, "Subclassify: STMT_%d, sten=%d, self=%d, all=%d\n",
      //  ii, sten, self, all);
      if (CG->fgraph->nodes[anode].nodetype == FNODE_TYPE_SCC && anode == nn &&
          (sten  && self >= fgraph->nodes[anode].n_members))
      {
        has_stmt_sten ++;
      }
    }
    if (has_stmt_sten)
    {
      CG->fgraph->nodes[nn].nodetype = FNODE_TYPE_STEN;
    }
  }
}



s_chunked_info_t * ponos_chunked_compute_info (
  s_ponos_space_t * space, s_ponos_options_t* options, int n_dep)
{
  scoplib_statement_p stmt;
  int nstmt;

  s_chunked_info_t * ret;
  ret = XMALLOC (s_chunked_info_t,1);
  #ifdef CHUNKED_PREDICATE_OBJECTIVE
  ret->obj_level = 100;
  #endif
  // Compute the real number of dependence from the number of delta
  // variables in the space
  {
    int * ids;
    ids = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_DELTA);
    int ii;
    for (ii = 0; ids[ii] != -1; ii++);
    //ret->n_dep = i / space->num_sched_dim;
    ret->n_dep = ii;

    ret->self_dep = XMALLOC (int, ret->n_dep + 1);
    int kk = 0;
    for (ii = 0; ids[ii] != -1; ii++)
    {
      int varid = ids[ii];
      CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
      int is_self = dep->source == dep->target;
      if (is_self)
        ret->self_dep[kk++] = ii;
    }
    ret->self_dep[kk] = -1;
    ret->n_self_dep = kk;
    XFREE (ids);
  }

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  ret->SA = XMALLOC (scoplib_statement_p, nstmt+1);
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++)
    ret->SA[nstmt] = stmt;
  ret->SA[nstmt] = NULL;

  ret->W_stmt = XMALLOC (int,nstmt);
  ret->W_ref  = XMALLOC (int,nstmt);
  ret->W_lat  = XMALLOC (int,nstmt);

  ret->max_dim = 0;
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++)
  {
    ret->W_stmt[nstmt] = 1;
    int nrefs = 0;
    scoplib_matrix_p refs = stmt->read; 
    int i;
    for (i = 0; i < refs->NbRows; i++)
      if (SCOPVAL_notzero_p (refs->p[i][0]))
        nrefs++;
    ret->W_ref[nstmt] = nrefs;

    if (ret->max_dim < stmt->nb_iterators)
      ret->max_dim = stmt->nb_iterators;
  }
  ret->n_stmt = nstmt;

  // count number of statements which are full dimensional
  ret->n_stmt_max_dim = 0;
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++)
    if (ret->max_dim == stmt->nb_iterators)
      ret->n_stmt_max_dim++;
  
	ret->max_fusion = options->chunked_max_fusion    ;
	ret->min_fusion = options->chunked_min_fusion    ;
	ret->max_loop_stmt = options->chunked_loop_max_stmt ;
	ret->max_loop_ref  = options->chunked_loop_max_ref  ;
	ret->max_loop_lat  = options->chunked_loop_max_lat  ;

  printf ("Max refs = %d\n",ret->max_loop_ref);
  printf ("Max stmt = %d\n",ret->max_loop_stmt);
  printf ("Max lats = %d\n",ret->max_loop_lat);

  // Set up initial values for architecture info structure field
  ret->archinfo.arch_id = options->chunked_arch;
  if (options->fp_precision == 0)
    ret->archinfo.fp_precision = 64;
  ret->archinfo.n_cores = 10;
  ret->archinfo.l1_size = 32 * 1024 / 8;
  // L2 is private
  ret->archinfo.l2_size = 256 * 1024 / 8;
  // L3 is shared, we divide it among the number of cores
  ret->archinfo.l3_size = 12 * 1024 * 1024 / (ret->archinfo.n_cores * ret->archinfo.fp_precision);
  ret->archinfo.simdlen = 256;
  ret->archinfo.regfile_size = 32;
  ret->archinfo.rob_size = 112;
   
  return ret; 
}


/*
 * Compute the minimum and maximum values of the outer beta coefficients
 * for SCC and losely connected statements.
 * This step computes these metrics for each statement. We have not
 * clustered the statements into fnodes of type SET, yet. This is done
 * in ponos_chunked_build_fgraph.
 */
static
void 
chunked_compute_beta_ranges (
  s_ponos_space_t* space, s_chunked_info_t * CI, s_chunked_graph_t * CG)
{
  int* ids = ponos_space_get_coefs_dim (space, 0,  PONOS_VAR_DELTA);
  int ii;
  for (ii = 0; ids[ii] != -1; ii++);
  int ndep = ii;
  int nscc = CG->n_scc;
  int nstmt = CI->n_stmt;
  int * queue = XMALLOC (int, nstmt * nstmt * ndep);
  int qs = 0;
  int qe = -1;
  int * status = XMALLOC (int, nscc);
  // None that no nodes are target of dependences: 
  // status[ii] = 1 means node ii is not the target of any edge
  for (ii = 0; ii < nscc; ii++)
    status[ii] = 1;
  // Find the nodes that do not have incoming edges
  for (ii = 0; ids[ii] != -1; ii++)
  {
    int varid = ids[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
    int src_id = dep->source->label;
    int dst_id = dep->target->label;
    int src_scc = CG->scc_map[src_id];
    int dst_scc = CG->scc_map[dst_id];
    if (src_scc != dst_scc)
      status[dst_scc] = 0;
  }
  // Initialize the queue with the nodes that do not have incoming edges
  for (ii = 0; ii < nscc; ii++)
    if (status[ii])
    {
      queue[++qe] = ii;
      //printf ("Adding node %d to initial set at pos %d\n", queue[qe], qe);
    }


  for (ii = 0; ii < nscc; ii++)
    CG->bmin[ii] = CG->bmax[ii] = 0;

  int globmax = 0;
  while (qs <= qe)
  {
    int src_scc = queue[qs];
    int kk;
    for (kk = 0; kk < nscc; kk++)
      if (CG->graph[src_scc][kk] == CHUNKED_HAS_DEP)
    {
      int dst_scc = kk;
      //printf ("Processing edge (%d->%d)\n",src_scc, dst_scc);
      int bsrc = CG->bmax[src_scc];
      int bdst = CG->bmin[dst_scc];
      CG->bmin[dst_scc]++;// = (bsrc > bdst ? bsrc : bdst) + 1;
      CG->bmax[dst_scc] = CG->bmin[dst_scc] + 1;// + CG->size[dst_scc] - 1;
      if (CG->bmax[dst_scc] > globmax)
        globmax = CG->bmax[dst_scc];
      queue[++qe] = dst_scc;
      //CG->graph[src_scc][kk] = CHUNKED_NO_DEP;
      //printf ("==> At %d:%d\n",qs,qe);
    }
    qs++;
  }

  for (ii = 0; ii < nscc; ii++)
  {
    int bmax = globmax;
    int jj;
    for (jj = 0; jj < nscc; jj++)
      if (CG->bmin[jj] < bmax && CG->bmin[jj] > CG->bmin[ii])
        bmax = CG->bmin[jj];
    if (bmax - 1 >= CG->bmin[ii])
      CG->bmax[ii] = bmax - 1;
  }

  XFREE (ids);
  XFREE (queue);
  XFREE (status);
}

void print_dependence_signature (depsig_t * ds)
{
  printf ("<%d,%d,%d:%d,%d,%d:",ds->id,ds->src_id,ds->dst_id,ds->dim_src,ds->dim_tgt,ds->dim_data);
  printf ("%d,%d:",ds->rect_src_dom,ds->rect_tgt_dom);
  printf ("%d,%d,",ds->has_dep,ds->self_dep);
  switch (ds->type) {
    case DEP_TYPE_NONE: printf ("none"); break;
    case DEP_TYPE_FLOW: printf ("flow"); break;
    case DEP_TYPE_ANTI: printf ("anti"); break;
    case DEP_TYPE_WRITE: printf ("write"); break;
    case DEP_TYPE_READ: printf ("read"); break;
  }
  printf (",");
  switch (ds->card) {
    case DEP_CARD_0_0: 
      printf("none");
      break;
    case DEP_CARD_1_1:
      printf("1-1");
      break;
    case DEP_CARD_1_N:
      printf("1-N");
      break;
    case DEP_CARD_N_1:
      printf("N-1");
      break;
    case DEP_CARD_N_N:
      printf("N-N");
      break;
  }
  printf (">\n");
}

void show_all_dependence_signatures (depsig_t * ds, int n_dep)
{
  int ii;
  printf ("Showing ALL dependence signatures: \n");
  for (ii = 0; ii < n_dep; ii++)
    print_dependence_signature (&ds[ii]);
  printf ("\n"); 
}

static
int is_domain_rectangular (scoplib_statement_p stmt)
{
  scoplib_matrix_p domain = stmt->domain->elt;
  int nrows = domain->NbRows;
  int niter = stmt->nb_iterators;
  int rr;
  for (rr = 0; rr < nrows; rr++)
  {
    int nnz = 0;
    int cc;
    for (cc = 1; cc <= niter; cc++)
      if (SCOPVAL_notzero_p (domain->p[rr][cc]))
        nnz++;
    // If we find more than 1 iteration coefficient being used in
    // an inequality, then the domain will not be rectangular.
    // Thus, we just return 0.
    if (nnz > 1)
      return 0;
  }
  // Return 1 if we reach this point,, i.e. the domain is rectangular
  return 1;
}


depsig_t
compute_dependence_signature (s_chunked_info_t * CI, candl_dependence_p cdep)
{
  depsig_t ret;
  int dim_src = cdep->source->depth;
  int dim_tgt = cdep->target->depth;

  // Store statement IDs
  ret.src_id = cdep->source->label;
  ret.dst_id = cdep->target->label;

  int ndim = 0;
  int refa = cdep->ref_source;
  int refb = cdep->ref_target;
  printf ("Dependence (%d-%d) on reference (%d,%d)\n", dim_src, dim_tgt, refa, refb);
  
  scoplib_statement_p src_stmt = CI->SA[cdep->source->label];
  scoplib_statement_p tgt_stmt = CI->SA[cdep->target->label];
  int sid;
  //for (stmt = scop->statement, sid = 0; 
  //     sid < cdep->target->label; stmt = stmt->next, sid++);
  scoplib_matrix_p acc = tgt_stmt->read;
  int rid;
  int row;
  for (rid = 1, row = 0; row < acc->NbRows && rid < refb; row++)
    if (SCOPVAL_notzero_p (acc->p[row][0]))
      rid++;
  int start = row;
  for (row++ ; row < acc->NbRows && SCOPVAL_zero_p(acc->p[row][0]); row++);
  ndim = row - start;
  ret.dim_src = dim_src;
  ret.dim_tgt = dim_tgt;
  ret.dim_data = ndim;
  ret.rect_src_dom = is_domain_rectangular (src_stmt);
  ret.rect_tgt_dom = is_domain_rectangular (tgt_stmt);

  switch (cdep->type) {
    case CANDL_RAW:
      ret.type = DEP_TYPE_FLOW;
      break;
    case CANDL_WAR:
      ret.type = DEP_TYPE_ANTI;
      break;
    case CANDL_WAW:
      ret.type = DEP_TYPE_WRITE;
      break;
    case CANDL_RAR:
      ret.type = DEP_TYPE_READ;
      break;
    case CANDL_UNSET:
      ret.type = DEP_TYPE_ANY;
      break;
  }
  ret.has_dep = 1;
  ret.self_dep = (cdep->source->label == cdep->target->label);

  if (ret.dim_src == ret.dim_tgt)
  {
    if (ret.dim_src <= ret.dim_data)
      ret.card = DEP_CARD_1_1;
    else
      ret.card = DEP_CARD_N_N;
  }
  else if (ret.dim_data <= ret.dim_src && ret.dim_src < ret.dim_tgt)
  {
    if (ret.dim_data < ret.dim_src)
      ret.card = DEP_CARD_N_N;
    else
      ret.card = DEP_CARD_1_N;
  }
  else if (ret.dim_data <= ret.dim_tgt && ret.dim_tgt < ret.dim_src)
  {
    if (ret.dim_data < ret.dim_tgt)
      ret.card = DEP_CARD_N_N;
    else
      ret.card = DEP_CARD_N_1;
  }
  else if (ret.dim_src <= ret.dim_data && ret.dim_data < ret.dim_tgt)
  {
    printf ("//%d,%d,%d\n",ret.dim_src,ret.dim_tgt,ret.dim_data);
    ret.card = DEP_CARD_1_N;
  }
  else if (ret.dim_tgt <= ret.dim_data && ret.dim_data < ret.dim_src)
  {
    printf ("//%d,%d,%d\n",ret.dim_src,ret.dim_tgt,ret.dim_data);
    ret.card = DEP_CARD_N_1;
  }
  else if (ret.dim_src < ret.dim_data && ret.dim_data <= ret.dim_tgt)
  {
    printf ("//%d,%d,%d\n",ret.dim_src,ret.dim_tgt,ret.dim_data);
    ret.card = DEP_CARD_1_N;
  }
  else if (ret.dim_tgt < ret.dim_data && ret.dim_data <= ret.dim_src)
  {
    printf ("//%d,%d,%d\n",ret.dim_src,ret.dim_tgt,ret.dim_data);
    ret.card = DEP_CARD_N_1;
  }
  else
  {
    printf ("//%d,%d,%d\n",ret.dim_src,ret.dim_tgt,ret.dim_data);
    print_dependence_signature (&ret);
    exit (0);
    assert (0 && "ponos/ianalysis.c: Unexpected case found.");
  }

  return ret;
}

#define max_dep_dim(ds) (ds->dim_src >= ds->dim_tgt ? ds->dim_src : ds->dim_tgt)
int compare_dependence (depsig_t * ds1, depsig_t * ds2)
{
  int maxdim1 = max_dep_dim (ds1);
  int maxdim2 = max_dep_dim (ds2);

  // First criterion: highest statement dimensionality
  if (maxdim1 > maxdim2)
    return 1;
  if (maxdim1 < maxdim2)
    return -1;

  if (ds1->dim_data > ds2->dim_data)
    return 1;
  if (ds1->dim_data < ds2->dim_data)
    return -1;

  if (ds1->card > ds2->card)
    return 1;
  if (ds1->card < ds2->card)
    return -1;

  int dim_sum1 = ds1->dim_src + ds1->dim_tgt;
  int dim_sum2 = ds2->dim_src + ds2->dim_tgt;

  if (dim_sum1 > dim_sum2)
    return 1;
  if (dim_sum1 < dim_sum2)
    return -1;

  return 0;
}

int dependence_compare (depsig_t * ds1, depsig_t * ds2)
{
  return compare_dependence (ds2, ds1);
}

void sort_dependences (depsig_t * deps, int n_dep)
{
  int ii,jj;
  qsort (deps, n_dep, sizeof(depsig_t), &dependence_compare);
}



/*
 * Build the SCC graph at the level @level 
 * WARNING: Likely will only work at level-0.
 * Return a populated structure of type s_chunked_graph *.
 * The structure stores the SCCs and indiviaul "loose" statements.
 * Finally, compute the SCC meta graph induced by the SCCs.
 */
s_chunked_graph_t *
ponos_chunked_compute_scc_level (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, int level)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return NULL;

  int ii;
  int nstmt = CI->n_stmt;
  scoplib_statement_p stmt;
  scoplib_statement_p * SS;

  s_chunked_graph_t * CG;
  CG = ponos_chunked_init_graph (space, CI, 0);
  s_chunked_graph_t * CGrev;
  CGrev = ponos_chunked_init_graph (space, CI, 1);

  SS = XMALLOC (scoplib_statement_p, nstmt);
  for (ii = 0, stmt=space->scop->statement; stmt; stmt = stmt->next, ii++)
    SS[ii] = stmt;

  CGrev->order = NULL;
  dfs_start (space, CI, CGrev);

  /* 
  for (ii = 0; ii < nstmt; ii++)
  {
    printf ("(rev) Node %d: status=%d, leader=%d, finish_time=%d\n", 
      ii, CGrev->status[ii], CGrev->leader[ii], CGrev->ftime[ii]);
  }
  */
  int order[nstmt];
  for (ii = 0; ii < nstmt; ii++)
    order[ii] = ii;
  for (ii = 0; ii < nstmt-1; ii++)
  {
    int jj;
    for (jj = ii+1; jj < nstmt; jj++)
      if (CGrev->ftime[jj] > CGrev->ftime[ii])
    {
      int temp = order[ii];
      order[ii] = order[jj];
      order[jj] = temp;
    }
  }

  /*
  printf ("Will visit in the following order: \n");
  for (ii = 0; ii < nstmt; ii++)
  {
    printf ("Node %d => %d\n", ii, order[ii]);
  }
  */
  CG->order = order;
  dfs_start (space, CI, CG);
  CG->order = NULL;

  /*
  for (ii = 0; ii < nstmt; ii++)
  {
    printf ("(direct) Node %d: status=%d, leader=%d, finish_time=%d\n", 
      ii, CG->status[ii], CG->leader[ii], CG->ftime[ii]);
  }
  */

  int is_leader[nstmt];
  int lead2scc_map[nstmt];
  for (ii = 0; ii < nstmt; ii++)
  {
    is_leader[ii] = 0;
    lead2scc_map[ii] = -1;
  }
  for (ii = 0; ii < nstmt; ii++)
  {
    is_leader[CG->leader[ii]] = 1;
  }
  CG->n_scc = 0;
  for (ii = 0; ii < nstmt; ii++)
    if (is_leader[ii])
      CG->n_scc++;
  int scc_id = 0;
  for (ii = 0; ii < nstmt; ii++)
    if (is_leader[ii])
      lead2scc_map[ii] = scc_id++;
  /*
  for (ii = 0; ii < nstmt; ii++)
    if (is_leader[ii])
  {
    printf ("Node %d (is_leader=%d) with scc_id %d\n",
      ii, is_leader[ii], lead2scc_map[ii]);
  }
  */
  for (ii = 0; ii < nstmt; ii++)
    CG->scc_map[ii] = lead2scc_map[CG->leader[ii]];

  printf("\nSTMT-to-SCC map\n");
  for (ii = 0; ii < nstmt; ii++)
  {
    printf ("S%d -> SCC%d\n",ii, CG->scc_map[ii]);
  }

  // Copy the list of statement ids to each entry of CG->scc
  // The list is finalized with the CHUNKED_END constant.
  for (ii = 0; ii < CG->n_scc; ii++)
  {
    int ss;
    int * scc  = XMALLOC (int,nstmt+1);
    CG->scc[ii] = scc;
    for (ss = 0; ss < nstmt + 1; ss++)
      scc[ss] = CHUNKED_END;
    int pos;
    for (ss = 0, pos = 0; ss < nstmt; ss++)
      if (CG->scc_map[ss] == ii)
        scc[pos++] = ss;
    CG->size[ii] = pos;
  }

  #if 0
  printf ("showing statements per SCC\n");
  for (ii = 0; ii < CG->n_scc; ii++)
  {
    int jj;
    printf ("SCC%d = {", ii);
    for (jj = 0; CG->scc[ii][jj] != CHUNKED_END; jj++)
    {
      if (jj > 0)
        printf (", ");
      printf ("%d",CG->scc[ii][jj]);
    }
    printf ("}\n");
  }
  #endif

  // It should be safe to reuse CG->graph to build the program's meta-graph
  for (ii = 0; ii < nstmt; ii++)
  {
    int jj;
    for (jj = 0; jj < nstmt; jj++)
      CG->graph[ii][jj] = CHUNKED_NO_DEP;
  }

  // Collect the delta variables of dimension 0 to fetch the set of dependences
  // Compute some statistics of the SCC/SET
  
  int* ids = ponos_space_get_coefs_dim (space, 0,  PONOS_VAR_DELTA);
  for (ii = 0; ids[ii] != -1; ii++);
  int n_dep = ii;
  depsig_t * signatures;
  signatures = (depsig_t*)(malloc (sizeof(depsig_t) * n_dep));
  for (ii = 0; ids[ii] != -1; ii++)
  {
    int varid = ids[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
    // We consider all dependences (RAW,WAR,WAW)
    int is_self = dep->source == dep->target;
    int dep_level = dep->depth;
    //if (dep_level != level)
    //  continue;
    int src_id = dep->source->label;
    int dst_id = dep->target->label;
    printf ("Computing dependence signature >> dep_%d[%d->%d]\n",ii,src_id, dst_id);
    int src_scc = CG->scc_map[src_id];
    int dst_scc = CG->scc_map[dst_id];
    // Also filter out self-dependences
    if (is_self)
      CG->self[src_scc]++;
    else if (src_scc == dst_scc)
      CG->intra[src_scc]++;
    else 
    {
      CG->inter[src_scc]++;
      CG->inter[dst_scc]++;
      CG->graph[src_scc][dst_scc] = CHUNKED_HAS_DEP;
    }
    // The following was added for the work of PLDI'20
    signatures[ii] = compute_dependence_signature (CI, dep);
    signatures[ii].id = ii;
    print_dependence_signature (&signatures[ii]);
  }
  sort_dependences (signatures, n_dep);
  show_all_dependence_signatures (signatures, n_dep);
  CI->signatures = signatures;
  XFREE (ids);
  
  chunked_compute_beta_ranges (space, CI, CG);
  XFREE (CGrev);
  return CG;
}


void
ponos_chunked_read_user_fgraph (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;
  
  int ii;
  int nstmt = CI->n_stmt;

  scoplib_statement_p stmt;
  scoplib_statement_p * SS = CI->SA;

  printf ("Building U-GRAPH...\n");

  int singlesccs[nstmt];
  // collect statements which we expect to be alone in a SCC
  // Set respective entry to 1 if it's a single SCC
  int * delta_ids = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_DELTA);

  CG->ugraph = XMALLOC (s_fgraph_t, 1);
  CG->ugraph->edges = NULL;


  // Worst case scenario, each statement is its own SCC, 
  // so allocate as many nodes as statements
  CG->ugraph->map = XMALLOC (int, nstmt);

  FILE * ff = fopen ("partitions.txt", "r");
  int npart = 0;

  fscanf (ff,"%d", &npart);
  //printf ("Got %d partitions\n", npart);
  CG->ugraph->nodes = XMALLOC (s_fnode_t, npart);
  int pp; 
  CG->ugraph->n_stmt = 0;
  int partitionable = 1;
  for (pp = 0; pp < npart; pp++)
  {
    int n_mbm;
    s_fnode_t * node = &CG->ugraph->nodes[pp];
    fscanf (ff,"%d", &n_mbm);
    //printf ("Reading statements (%d) for partition %d\n",n_mbm, pp);
    node->n_members = n_mbm;
    int kk; 
    int * members = XMALLOC (int, n_mbm+1);
    int original_part = -1;
    int max_depth = 0;
    for (kk = 0; kk < n_mbm; kk++)
    {
      int sid;
      fscanf (ff, "%d", &sid);
      members[kk] = sid; 
      assert (0 <= sid && sid < nstmt && "ponos/ianalysis: Invalid statement ID found.");
      CG->ugraph->map[sid] = pp; // map statement to partition
      int current_part = CG->fgraph->map[sid];
      if (kk == 0)
        original_part = current_part;
      else
        partitionable = partitionable && (current_part == original_part);

      if (SS[sid]->nb_iterators > max_depth)
        max_depth = SS[sid]->nb_iterators;
    }
    node->max_depth = max_depth;
    assert (partitionable && "ponos: invalid statement partition given.");
    node->members = members;
    CG->ugraph->n_stmt += n_mbm;

    // Extract this from the true fgraph
    s_fnode_t * ofnode = &CG->fgraph->nodes[original_part];
    node->nodetype = ofnode->nodetype; 
    node->betamin = ofnode->betamin;
    node->betamax = ofnode->betamax;
    node->n_dep = 0;
    node->n_self_dep = 0;
    node->flexibility = 0.0;
  }
  CG->ugraph->n_nodes = npart; 
  CG->ugraph->logfile = CG->fgraph->logfile;

  //printf ("About to dump graph (#stmt = %d)\n", CG->ugraph->n_stmt);
  fclose (ff);

  XFREE (delta_ids);
}

