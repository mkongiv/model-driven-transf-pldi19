/*
 * chunked.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012-2018 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Authors:
 * Martin Kong <martin.richard.kong@gmail.com>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>
#include <ponos/objectives.h>
#include <ponos/constraints.h>
#include <ponos/codelet.h>
#include <ponos/chunked.h>

#include <time.h>
#include <sys/time.h>
#include "iutil.c"

void
ponos_chunked_mode_finalize (s_chunked_mode_t * CM)
{
  XFREE (CM);
}


void 
ponos_chunked_development_test_schedule (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * cinfo)
{
  FILE * cf;
  cf = fopen ("sched.txt", "r");
  char filename[100];
  int ret;
  ret = fscanf (cf,"%s",filename);
  fclose (cf);
  FILE * f;
  f = fopen (filename, "r");
  int idx;
  int nstmt = cinfo->n_stmt;

  scoplib_statement_p stmt;
  for (idx = 0, stmt = space->scop->statement; 
       idx < nstmt; 
       idx++, stmt = stmt->next)
  {
    int rows, cols;
    ret =  fscanf (f, "%d %d",&rows,&cols);
    int level;
    for (level = 0; level < space->num_sched_dim; level++)
    {
      int * ids;
      ids = ponos_space_get_coefs_dim_stmt (space, stmt, level, PONOS_VAR_THETA);
      int ii;
      int bound;
      int var_idx;
      for (ii = 0; ii < stmt->nb_iterators; ii++)
      {
        var_idx = ids[ii];
        ret = fscanf (f, "%d", &bound);
        printf ("Setting variable %s to %d\n", space->vars[var_idx]->name, bound);
        ponos_chunked_set_var_eq (space, var_idx, 1, bound);
      }
      for ( ; ids[ii] != -1; ii++);
      ii--;
      var_idx = ids[ii];
      // ids[ii] should be the fixed coefficient
      ret = fscanf (f, "%d", &bound);
      printf ("Setting variable %s to %d\n", space->vars[var_idx]->name, bound);
      ponos_chunked_set_var_eq (space, var_idx, 1, bound);
      XFREE (ids);
    }
  }
  fclose (f);
}

void 
ponos_chunked_create_constraints_cnc (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    //int n_dep, CandlDependence * deps)
    s_chunked_graph_t * CG,
    s_chunked_info_t * CI)
{
  int n_stmt = CI->n_stmt;
  int ss;
  int filter[n_stmt];
  for (ss = 0; ss < n_stmt; ss++)
    filter[ss] = 1;
  int n_dep = CI->n_dep;
  int clusterid = SINGLECLUSTER;

  printf ("#deps = %d, #stmts = %d\n",CI->n_dep, CI->n_stmt);

  // Insert PI and PSI variables. Prerequisite for any parallelism related obj.
  ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, -1);

  // PONOS_PERFIDIOM_OPIR
  //ponos_perfidiom_outerpar_innerreuse_with_filter (
  //  space, options, CI, CG, 0, clusterid, filter);

  // parallel dimension alignment: PONOS_PERFIDIOM_ADA
  printf ("Adding ADA\n");
  //ponos_perfidiom_outerpar_innerreuse_with_filter (
  //  space, options, CI, CG, 1, clusterid, filter);

  // Stride Minimization: PONOS_PERFIDIOM_SO
  //ponos_perfidiom_stride_optimization (space, options, CI, filter);

  // Simple outer-parallelism: PONOS_PERFIDIOM_OP)
  //ponos_objectives_max_outer_par (space, options);

  // Increase the dependence distance among unrelated statements and 
  // statements binded by WAR and WAW dependences: PONOS_PERFIDIOM_SIS
  printf ("Adding SIS\n");
  ponos_perfidiom_separate_independent_statements (
    space, options, CI, CG, clusterid, filter);

  // PONOS_PERFIDIOM_DGF
  printf ("Adding DGF\n");
  ponos_perfidiom_dependence_guided_fusion (
    space, options, CI, CG, clusterid, filter);

  // Maximize inner parallelism: PONOS_PERFIDIOM_IP
  // ponos_perfidiom_inner_parallelism (space, options, CI, CG, clusterid, filter);

  // Embed constraints for skewing minimization that affects vector (stencils)
  // PONOS_PERFIDIOM_VSKW)
  //ponos_chunked_stencil_minimize_vector_skewing (
  //  space, options, CI, CG, clusterid, filter);

  // Stencils: classify dependences by type; force specific level of satisfaction
  // PONOS_PERFIDIOM_SDC
  //ponos_chunked_stencil_dependence_classification (
  //  space, options, CI, CG, clusterid, filter);

  // Stencils how to extract paralellism: parallel constraints: PONOS_PERFIDIOM_SPC
  //ponos_chunked_stencil_par_constraints (
  //  space, options, CI, CG, clusterid, filter);

  // Stencil ? PONOS_PERFIDIOM_SMP
  //ponos_chunked_stencil_max_parallelism (space, options, CI, CG, clusterid, filter);

  // Fusion preserving parallelism: PONOS_PERFIDIOM_FPP

  // LU parallelism style: PONOS_PERFIDIOM_SKEWPAR
  //ponos_perfidiom_skew_parallelism (space, options, CI, CG, clusterid, filter);

  // Multi-level parallelism? PONOS_PERFIDIOM_MLP)
  // TBD

  // Permutability: PONOS_PERFIDIOM_PERM
  printf ("Adding PERM\n");
  ponos_perfidiom_permutability (space, options, CI, CG, clusterid, filter); 

  #if 0
  if (is_stencil (space) && (CI->n_dep * 1.0 / space->num_sched_dim <= 3))
  {
    //CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
    //ponos_chunked_stencil_minimize_vector_skewing (space, options, CI, CG, SINGLECLUSTER, filter);
    CI->mode = CHUNKED_MODE_STENCIL;
  }
  else if (space->num_sched_dim <= 5)
  {
    printf ("[CNC] MatVec-like mode ...\n");

    //CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
    //ponos_perfidiom_stride_optimization (space, options, CI, filter);
    CI->mode = CHUNKED_MODE_2D_SPACE;
  }
  else if (CG->n_scc >= CI->n_self_dep && CI->n_self_dep * 1.0 / CI->n_dep <= 0.6 && CI->n_dep < 70) 
  {
    printf ("[CNC] Chunked strategy : Gemm-like mode\n");
    CI->mode = CHUNKED_MODE_DENSE_LA;
  }
  else //if (CI->n_dep >= 30 || CI->n_dep * 1.0 / CI->n_stmt >= 8)
  {
    printf ("[CNC] Chunked strategy : Gemm-like mode\n");
    CI->mode = CHUNKED_MODE_HARD;
  }
  #endif
  CI->unroll = 0;
}



void 
ponos_chunked_create_constraints_skx (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    //int n_dep, CandlDependence * deps)
    s_chunked_graph_t * CG,
    s_chunked_info_t * CI)
{
  int n_stmt = CI->n_stmt;
  int ss;
  int filter[n_stmt];
  for (ss = 0; ss < n_stmt; ss++)
    filter[ss] = 1;
  //s_chunked_info_t * CI;
  //CI = ponos_chunked_compute_info (space, options, n_dep);
  int n_dep = CI->n_dep;

  //ponos_chunked_fix_theta_bounds (space, options);
  printf ("#deps = %d, #stmts = %d\n",CI->n_dep, CI->n_stmt);
  //ponos_chunked_show_dependence_info (space, options);
  //s_chunked_graph_t * CG;
  //CG = ponos_chunked_compute_scc_level (space, options, CI, 0);

  #if 0
  //if (CI->n_dep > 3 * (CI->n_stmt << 1))
  if (CI->n_dep * 1.0 / space->num_sched_dim >=  (CI->n_stmt)) // << 1))
  {
    if (!is_jacobi (n_dep, CI->n_stmt, space->num_sched_dim))
      ponos_chunked_constraints_linear_indep (space, options, CI);
    else
      ponos_chunked_constraints_linear_indep_desc (space, options, CI);
  }
  #endif
  if (CI->max_loop_lat > 0 || CI->max_loop_stmt > 0 || CI->max_loop_ref > 0)
  {
    ponos_chunked_insert_phi_variables (space, options, CI);
    ponos_chunked_insert_pi_variables (space, options, CI);
    //printf ("ponos_chunked_constraints_phi_sums ( \n"); 
    ponos_chunked_constraints_phi_sums (space, options, CI);
    //printf ("ponos_chunked_activate_partitions ( \n"); 
    ponos_chunked_activate_partitions (space, options, CI);
    //printf ("ponos_chunked_phi_fusion ( \n"); 
    ponos_chunked_phi_fusion (space, options, CI, 0);
    if (CI->max_loop_lat > 0)
    {
      s_chunked_mode_t * CM = ponos_chunked_mode_init (CI, PONOS_CHUNKED_LIMIT_LAT);
      //printf ("ponos_chunked_omega_constraints ( \n"); 
      ponos_chunked_omega_constraints (space, options, CI, CM);
      ponos_chunked_mode_finalize (CM);
    }
    if (CI->max_loop_stmt > 0)
    {
      s_chunked_mode_t * CM = ponos_chunked_mode_init (CI, PONOS_CHUNKED_LIMIT_STMT);
      //printf ("ponos_chunked_omega_constraints ( \n"); 
      ponos_chunked_omega_constraints (space, options, CI, CM);
      ponos_chunked_mode_finalize (CM);
    }
    if (CI->max_loop_ref > 0)
    {
      s_chunked_mode_t * CM = ponos_chunked_mode_init (CI, PONOS_CHUNKED_LIMIT_REF);
      //printf ("ponos_chunked_omega_constraints ( \n"); 
      ponos_chunked_omega_constraints (space, options, CI, CM);
      ponos_chunked_mode_finalize (CM);
    }
    ponos_chunked_minimize_nbr_partitions (space, options, CI);
  }
  //ponos_chunked_constraints_fusion_par (space, options, CI, n_dep);

  //ponos_chunked_free_scalar_dimensions (space, options, CI);

  #if 0
  if (space->num_sched_dim <= 5)
  {
    ponos_objectives_max_inner_par (space, options);
    ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep);
    ponos_objectives_max_outer_par (space, options); 
  }
  else
  {
    ponos_chunked_free_scalar_dimensions (space, options, CI);
    ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep);
    if ( ! (CI->n_dep * 1.0 / space->num_sched_dim >=  (CI->n_stmt))) // << 1))
    {
      ponos_objectives_max_outer_par (space, options); // testing this only for syrk
    }
    ponos_objectives_max_inner_par (space, options);
  }
  #endif

  if (is_stencil (space) && (CI->n_dep * 1.0 / space->num_sched_dim <= 3))
  {
    #if 0
    if (n_dep * 1.0 / space->num_sched_dim >= 3)
    {
      printf ("Stencil mode (Non-jacobians) ...\n");
      ponos_chunked_free_scalar_dimensions (space, options, CI);
      ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_STENCIL_NONJAC);
      //ponos_objectives_max_outer_par (space, options); // testing this only for syrk
      //ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
      ponos_objectives_max_inner_par (space, options);
    }
    else
    {
      printf ("Stencil mode (Jacobians) ...\n");
      //ponos_chunked_free_scalar_dimensions (space, options, CI);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_THETA_ITER, 3);
      ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_STENCIL_JAC);
    }
    ponos_perfidiom_stride_optimization (space, options, CI);
    #endif

    printf ("[SKX] Chunked Strategy: Stencil mode ...\n");
    #if 0 // this setup work well for fdtd-2d
    ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_STENCIL);
    ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_THETA_ITER, 3);
    ponos_perfidiom_stride_optimization (space, options, CI);
    #endif

    #if 0 // not bad for jacobi
    ponos_chunked_constraints_linear_indep_desc (space, options, CI);
    //ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_STENCIL);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_THETA_ITER, 3);
    ponos_perfidiom_stride_optimization (space, options, CI);
    #endif

    #if 0 // very good for jacobi
    //ponos_chunked_free_scalar_dimensions (space, options, CI);
    ponos_chunked_stencil_skewing_constraints (space, options, CI);
    if (CI->n_stmt > 2)
    {
      ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    }
    ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_THETA_ITER, 3);
    ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_STENCIL);
    ponos_chunked_maximize_fusion (space, options, CI); // minimize theta scalars of fusion
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_THETA_ITER, 1);
    ponos_objectives_max_inner_par (space, options);
    ponos_perfidiom_stride_optimization (space, options, CI);
    #endif

    #if 0 // very good for seidel
    //ponos_chunked_free_scalar_dimensions (space, options, CI);
    ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_STENCIL);
    ponos_chunked_stencil_skewing_constraints (space, options, CI);
    ponos_objectives_max_inner_par (space, options);
    ponos_perfidiom_stride_optimization (space, options, CI);
    #endif

    #if 0 // unified
    ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_STENCIL);
    printf ("Done adding outer par constraints\n");
    ponos_chunked_stencil_skewing_constraints (space, options, CI);
    printf ("Done adding skewing constraints \n");
    ponos_objectives_max_inner_par (space, options);
    printf ("Done adding max inner par objectives..\n");
    ponos_perfidiom_stride_optimization (space, options, CI);
    printf ("Done adding stride constraints and objectives \n");
    #endif

    //ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_STENCIL);
    //ponos_chunked_force_outer_fusion (space, options);
    //ponos_chunked_force_skewing_factors  (space, options);

    #ifdef MY_PRETTY_STENCIL
    //if (CI->n_stmt <= 2)
    {
      ponos_chunked_stencil_skewing_constraints (space, options, CI);
    }
    if (CI->n_stmt > 2)
    {
    //  ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    }
    //ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_THETA_ITER, 1); //space->num_sched_dim - 4);

    //ponos_chunked_maximize_fusion (space, options, CI); // minimize theta scalars of fusion

    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_THETA_ITER, 1);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
    //ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 5);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 4);
    ponos_perfidiom_inner_parallelism (space, options, CI, CG, 0, filter);
    //ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
    //ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 2);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 1);
    //ponos_chunked_optimize_reuse (space, options, CI);
    //ponos_objectives_max_inner_par (space, options);
    //ponos_chunked_parallelize_stencil (space, options, CI);


    if (CI->n_stmt >= 2)
    {
      // fdtd-2d doesn't like these constraints
      //if (CI->n_dep * 1.0 / space->num_sched_dim <= 3)
      {
        ponos_chunked_stencil_objectives (space, options, CI);
      }
    }
    ponos_perfidiom_stride_optimization (space, options, CI, filter);
    #endif

    // The following two were enabled as of july 28th
    //ponos_chunked_stencil_skewing_constraints (space, options, CI);
    //ponos_chunked_stencil_objectives (space, options, CI);
    //ponos_chunked_development_test_schedule (space, options, CI);
    //ponos_chunked_optimize_reuse (space, options, CI);
    //ponos_perfidiom_outerpar_innerreuse (space, options, CI);
    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //ponos_perfidiom_stride_optimization (space, options, CI);

    //CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,3)
    ponos_chunked_stencil_par_constraints (space, options, CI, CG, SINGLECLUSTER, filter);
    //CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,2)
    ponos_chunked_stencil_dependence_classification (space, options, CI, CG, SINGLECLUSTER, filter);
    //CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
    ponos_chunked_stencil_minimize_vector_skewing (space, options, CI, CG, SINGLECLUSTER, filter);
    CI->unroll = 0;
    CI->mode = CHUNKED_MODE_STENCIL;
  }
  else if (space->num_sched_dim <= 5)
  {
    printf ("[SKX] MatVec-like mode ...\n");
    /*
    //ponos_objectives_max_inner_par (space, options);
    ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep);
    ponos_objectives_max_outer_par (space, options); 
    */

    #if 0 // good one
    //ponos_chunked_distribute_when_linear_delta_satisfied (space, options, CI);
    //ponos_chunked_distribute_independent_statements (space, options, CI, deps);
    //ponos_chunked_free_scalar_dimensions (space, options, CI);
    //ponos_chunked_maximize_fusion (space, options, CI); // minimize theta scalars of fusion
    ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_MATVEC);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2);
    //ponos_objectives_max_outer_par (space, options); 
    ponos_perfidiom_stride_optimization (space, options, CI);
    #endif

    //ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_MATVEC);
    //ponos_chunked_distribute_independent_statements (space, options, CI, deps); // disabling this for durbin
    //ponos_chunked_set_easy_coefficients (space, options, CI);

    #if 0 // best one!
    ponos_chunked_optimize_reuse (space, options, CI);
    ponos_perfidiom_inner_parallelism (space, options, CI);
    ponos_perfidiom_stride_optimization (space, options, CI);
    #endif

    //ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG);
    //ponos_chunked_outer_linear_fusion (space, options, CI, CG);
    //ponos_perfidiom_separate_independent_statements (space, options, CI, CG);
    //ponos_chunked_optimize_reuse (space, options, CI);

    // This helps gesummv:
    //ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_MATVEC);
    //ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d

    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,6)
    ponos_objectives_max_outer_par (space, options);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,5)
    ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG, 0, filter);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,4)
    ponos_perfidiom_separate_independent_statements (space, options, CI, CG, 0, filter);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,3)
    ponos_perfidiom_outerpar_innerreuse (space, options, CI, 0);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,2)
    ponos_perfidiom_inner_parallelism (space, options, CI, CG, 0, filter);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
    ponos_perfidiom_stride_optimization (space, options, CI, filter);
    CI->unroll = 1;
    CI->mode = CHUNKED_MODE_2D_SPACE;
  }
  //else if (CI->n_dep * 1.0 / CI->n_stmt <= 3.5 || CI->n_stmt >= 7) // gemm-like
  // GOOD one : else if (CG->n_scc > 1 && CI->n_self_dep * 1.0 / CI->n_dep <= 0.6 && CI->n_dep < 70) 
  else if (CG->n_scc >= CI->n_self_dep && CI->n_self_dep * 1.0 / CI->n_dep <= 0.6 && CI->n_dep < 70) 
    // / CI->n_stmt <= 10) // && CI->n_self_dep  / CI->n_dep <= 1)
  {
    printf ("[SKX] Chunked strategy : Gemm-like mode\n");

    /*
    ponos_chunked_insert_phi_variables (space, options, CI);
    ponos_chunked_insert_pi_variables (space, options, CI);
    ponos_chunked_constraints_phi_sums (space, options, CI);
    ponos_chunked_activate_partitions (space, options, CI);
    ponos_chunked_phi_fusion (space, options, CI, 1);
    ponos_chunked_minimize_nbr_partitions (space, options, CI);
    */

    #if 0 // good one so far!
    ponos_chunked_distribute_when_linear_delta_satisfied (space, options, CI);
    ponos_chunked_distribute_independent_statements (space, options, CI, deps);
    ponos_chunked_free_scalar_dimensions (space, options, CI);
    ponos_chunked_maximize_fusion (space, options, CI); // minimize theta scalars of fusion
    ponos_chunked_maximize_outer_parallelism (space, options, CI, n_dep, PAT_GEMM);
    ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2);
    ponos_objectives_max_outer_par (space, options); // testing this only for syrk
    ponos_objectives_max_inner_par (space, options);
    ponos_perfidiom_stride_optimization (space, options, CI);
    #endif

    // ponos_chunked_distribute_when_linear_delta_satisfied (space, options, CI);
    // ponos_chunked_distribute_independent_statements (space, options, CI, deps);
    // ponos_chunked_outer_linear_fusion (space, options, CI, CG);
    // ponos_chunked_optimize_reuse (space, options, CI);
    // ponos_chunked_rebound_theta_iter (space, options, CI);
    // ponos_chunked_full_distribution (space, options, CI, CG);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,6)
    ponos_objectives_max_outer_par (space, options); // testing this only for syrk

    printf ("Including flow fusion and distribution of non-flow and non-related statements\n");
    //ponos_chunked_maximize_outer_parallelism (space, options, CI, CG, n_dep, PAT_GEMM);
    //ponos_objectives_max_outer_par (space, options); 

    //int use_outer;
    //use_outer = ponos_chunked_scop_can_use_outer_parallelism (space, options, CI, CG);
    if (CG->n_scc > 2)
    {
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,5)
      ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG, 0, filter);
    }
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,4)
    ponos_perfidiom_separate_independent_statements (space, options, CI, CG, 0, filter);
    //if (CI->n_self_dep * 1.0 / CI->n_stmt <= 0.5 &&
    //  CI->n_ref * 1.0 / CI->n_stmt <= 4 && CI->n_dep < 50)
    if (CI->n_self_dep <= CG->n_scc)
    {
      if (CG->n_scc == CI->n_stmt) // Note: correlation seems to not produce the same nbr of SCC
      {
        CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,3)
        ponos_perfidiom_outerpar_innerreuse (space, options, CI, 0);
      }
      //if (CI->n_self_dep <= CG->n_scc)
      printf ("Adding inner parallelism constraints \n");
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,2)
      ponos_perfidiom_inner_parallelism (space, options, CI, CG, 0, filter);
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
      ponos_perfidiom_stride_optimization (space, options, CI, filter);
    }
    //ponos_chunked_scalar_dependence_objective (space, options, CI);
    CI->unroll = 1;
    CI->mode = CHUNKED_MODE_DENSE_LA;
  }
  else //if (CI->n_dep >= 30 || CI->n_dep * 1.0 / CI->n_stmt >= 8)
  {
      printf ("[SKX] Chunked Strategy: Super hard mode >= 30\n");
      //ponos_chunked_free_scalar_dimensions (space, options, CI);
      //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, space->num_sched_dim-2);
      CI->unroll = 0;
      #if 0 // this is not too bad for fdtd-apm, but adi and ludcmp are ok
      ponos_chunked_set_easy_coefficients (space, options, CI);
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2);
      ponos_perfidiom_stride_optimization (space, options, CI);
      #endif

      #if 0 // this is very bad for fdtd-apm, adi and ludcmp are ok
      ponos_chunked_set_easy_coefficients (space, options, CI);
      ponos_chunked_maximize_fusion (space, options, CI); // minimize theta scalars of fusion
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2);
      ponos_perfidiom_inner_parallelism (space, options, CI);
      ponos_perfidiom_stride_optimization (space, options, CI);
      #endif

      #if 0 // seems like maximize_fusion raises the complexity too much
      ponos_chunked_set_easy_coefficients (space, options, CI);
      ponos_chunked_maximize_fusion (space, options, CI); // minimize theta scalars of fusion
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2);
      ponos_perfidiom_stride_optimization (space, options, CI);
      #endif

      #if 0 // keep this just in case
      ponos_chunked_set_easy_coefficients (space, options, CI);
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2);
      //ponos_perfidiom_inner_parallelism (space, options, CI);
      ponos_perfidiom_stride_optimization (space, options, CI);
      #endif

      //ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG);
      //ponos_perfidiom_separate_independent_statements (space, options, CI, CG);

      ponos_chunked_rebound_theta_iter (space, options, CI);
      //ponos_chunked_scc_separation_constraints (space, options, CI, CG);
      ponos_chunked_set_easy_coefficients (space, options, CI, CG);
      //ponos_chunked_big_split (space, options, CI, 2);
      //ponos_chunked_auto_satisfy_inter_stmt_dependences (space, options, CI, CG);
      //ponos_chunked_optimize_reuse (space, options, CI);
      //ponos_perfidiom_inner_parallelism (space, options, CI);
      if (CG->n_scc == 1)
        ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
      else
        ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 1);
      //ponos_objectives_max_outer_par (space, options); // testing this only for syrk
      //ponos_chunked_scalar_dependence_objective (space, options, CI);
      //ponos_perfidiom_stride_optimization (space, options, CI);
      if (CI->n_dep < 50)
      {
        ponos_perfidiom_stride_optimization (space, options, CI, filter);
        CI->unroll = 1;
      }
      if (CG->n_scc < CI->n_self_dep)
        CI->unroll = 0;
      CI->mode = CHUNKED_MODE_HARD;
  }

  // This is done in the main constraints routine
  //ponos_chunked_graph_free (CG);
  //ponos_chunked_free_info (CI);
}


void 
ponos_chunked_create_constraints_knl (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_graph_t * CG,
    s_chunked_info_t * CI)
{
  int n_stmt = CI->n_stmt;
  int ss;
  int filter[n_stmt];
  for (ss = 0; ss < n_stmt; ss++)
    filter[ss] = 1;
  //else if (is_stencil (space) && (CI->n_dep * 1.0 / space->num_sched_dim <= 3))
  //if (CG->n_scc == 1 && space->num_sched_dim <= 7 && is_stencil (space)) //CI->n_self_dep / CI->n_stmt >= 1)
  if (is_stencil (space) && (CI->n_dep * 1.0 / space->num_sched_dim <= 3))
  {
    printf ("[KNL] Chunked Strategy: Stencils mode...\n");
    #ifdef MY_PRETTY_STENCIL
    //if (CI->n_stmt <= 2)
    {
      ponos_chunked_stencil_skewing_constraints (space, options, CI);
    }
    if (CI->n_stmt > 2)
    {
    //  ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    }
    //ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    //ponos_chunked_maximize_fusion (space, options, CI); // minimize theta scalars of fusion
    ponos_perfidiom_inner_parallelism (space, options, CI, CG, 0, filter);
    //ponos_chunked_optimize_reuse (space, options, CI);
    //ponos_objectives_max_inner_par (space, options);
    //ponos_chunked_parallelize_stencil (space, options, CI);

    if (CI->n_stmt >= 2)
    {
      // fdtd-2d doesn't like these constraints
      //if (CI->n_dep * 1.0 / space->num_sched_dim <= 3)
      {
        ponos_chunked_stencil_objectives (space, options, CI);
      }
    }
    ponos_perfidiom_stride_optimization (space, options, CI, filter);
    #endif

    //ponos_chunked_optimize_reuse (space, options, CI);
    //ponos_chunked_stencil_skewing_constraints (space, options, CI);
    //ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_THETA_ITER, 3); //space->num_sched_dim - 4);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 4);
    //ponos_chunked_stencil_par_constraints (space, options, CI, CG);
    //ponos_chunked_maximize_outer_parallelism (space, options, CI, CI->n_dep, PAT_STENCIL);


    //ponos_chunked_set_easy_coefficients (space, options, CI);
    //ponos_chunked_big_split (space, options, CI, 2);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,5)
    ponos_chunked_stencil_par_constraints (space, options, CI, CG, SINGLECLUSTER, filter);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,4)
    ponos_chunked_stencil_dependence_classification (space, options, CI, CG, SINGLECLUSTER, filter);
    if (CI->n_dep < 50)
    {
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,3)
      ponos_perfidiom_stride_optimization (space, options, CI, filter);
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,2)
      ponos_perfidiom_inner_parallelism (space, options, CI, CG, 0, filter);
    }
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
    ponos_chunked_stencil_minimize_vector_skewing (space, options, CI, CG, SINGLECLUSTER, filter);
    CI->unroll = 0;
    CI->mode = CHUNKED_MODE_STENCIL;
  }
  else if (space->num_sched_dim <= 5)
  {
    printf ("[KNL] Chunked Strategy: MatVec-like mode...\n");
    //ponos_chunked_preserve_parallelism (space, options, CI, CG);
    //ponos_chunked_optimize_reuse (space, options, CI);

    //ponos_perfidiom_outerpar_innerreuse (space, options, CI);
    //ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,2)
    ponos_perfidiom_separate_independent_statements (space, options, CI, CG, 0, filter);
    //ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //ponos_perfidiom_stride_optimization (space, options, CI);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
    ponos_objectives_max_outer_par (space, options);


      #if 1
    //ponos_objectives_max_outer_par (space, options);
      #endif

    #if 0
    ponos_perfidiom_separate_independent_statements (space, options, CI, CG);
    ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    ponos_perfidiom_stride_optimization (space, options, CI);
    ponos_perfidiom_inner_parallelism (space, options, CI);
    ponos_objectives_max_outer_par (space, options);
    #endif
    CI->unroll = 1;
    CI->mode = CHUNKED_MODE_2D_SPACE;
  }
  //else if (CI->n_dep / CI->n_stmt <= 3 && CI->n_self_dep  / CI->n_dep <= 1)
  //else if (CI->n_dep / CI->n_stmt <= 10 && CI->n_self_dep  / CI->n_dep <= 1)
  else if (CG->n_scc > 1 && CI->n_self_dep * 1.0 / CI->n_dep <= 0.6 && CI->n_dep < 70) 
  {
    printf ("[KNL] Chunked Strategy: Gemm-like mode ...\n");
    //  printf ("Including flow fusion and distribution of non-flow and non-related statements\n");

    if (CG->n_scc > 1)
    {
      #ifdef OLD_KNL
      printf ("==> Adding dependendence driven fusion and split indep.statements\n");
      //ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG);
      ponos_perfidiom_separate_independent_statements (space, options, CI, CG, 0, filter);
      //ponos_perfidiom_outerpar_innerreuse (space, options, CI);
      ponos_perfidiom_inner_parallelism (space, options, CI, CG, 0, filter);
      ponos_perfidiom_stride_optimization (space, options, CI, filter);
      ponos_objectives_max_outer_par (space, options);
      //ponos_chunked_maximize_outer_parallelism (space, options, CI, CI->n_dep, PAT_GEMM);
      #endif

      // these are essentially the same constraints as PWR9
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,4)
      ponos_perfidiom_outerpar_innerreuse (space, options, CI, 1); // <--
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,3)
      ponos_objectives_max_outer_par (space, options);
      //ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG); // <--
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,2)
      ponos_perfidiom_separate_independent_statements (space, options, CI, CG, 0, filter);
      //ponos_perfidiom_inner_parallelism (space, options, CI);
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
      ponos_perfidiom_stride_optimization (space, options, CI, filter);
      //ponos_chunked_maximize_outer_parallelism (space, options, CI, CI->n_dep, PAT_GEMM);
    }
    else
    {
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 1);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2);
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
    }
    CI->unroll = 1;
    CI->mode = CHUNKED_MODE_DENSE_LA;
  }
  else //if (CI->n_dep >= 30 || CI->n_dep * 1.0 / CI->n_stmt >= 8)
  {

    printf ("[KNL] Chunked Strategy: Super hard mode (n_dep >= 50)\n");
    CI->unroll = 0;
    ponos_chunked_rebound_theta_iter (space, options, CI);
    //ponos_chunked_scc_separation_constraints (space, options, CI, CG);
    ponos_chunked_set_easy_coefficients (space, options, CI, CG);
    //ponos_chunked_big_split (space, options, CI, 2);
    //ponos_chunked_auto_satisfy_inter_stmt_dependences (space, options, CI, CG);
    //ponos_chunked_optimize_reuse (space, options, CI);
    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, space->num_sched_dim - 3);
    if (CG->n_scc == 1)
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
    else
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 1);

    #if 0
    //ponos_chunked_set_easy_coefficients (space, options, CI);
    ponos_chunked_big_split (space, options, CI, 2);
    //ponos_chunked_stencil_par_constraints (space, options, CI, CG);
    //ponos_chunked_stencil_dependence_classification (space, options, CI, CG);
    //ponos_chunked_optimize_reuse (space, options, CI);
    //ponos_perfidiom_outerpar_innerreuse (space, options, CI);
    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //if (CG->n_scc > 1)
    {
      printf ("==> Adding outer parallelism maximization objective\n");
      //ponos_chunked_maximize_outer_parallelism (space, options, CI, CI->n_dep, PAT_GEMM);
      ponos_perfidiom_inner_parallelism (space, options, CI);
    }
    //else
    {
      //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2); //space->num_sched_dim - 4);
      //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 4); //space->num_sched_dim - 4);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 1); //space->num_sched_dim - 4);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 5); //space->num_sched_dim - 4);
      //ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3); //space->num_sched_dim - 4);
      //ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 1); //space->num_sched_dim - 4);
    }
    #endif
    if (CI->n_dep < 50)
    {
      ponos_perfidiom_stride_optimization (space, options, CI, filter);
      CI->unroll = 1;
    }
    CI->mode = CHUNKED_MODE_HARD;
  }
  if (0)
  {
    assert (0);
    printf ("Chunked Strategy: Other mode ...\n");
    //ponos_chunked_stencil_par_constraints (space, options, CI, CG);
    //ponos_chunked_stencil_dependence_classification (space, options, CI, CG);
    //ponos_perfidiom_stride_optimization (space, options, CI);
    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //ponos_chunked_stencil_minimize_vector_skewing (space, options, CI, CG);
    //ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG);
    //ponos_perfidiom_separate_independent_statements (space, options, CI, CG);
    //ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 1);

    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //ponos_perfidiom_stride_optimization (space, options, CI);

    //ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2);

    ponos_chunked_development_test_schedule (space, options, CI);

    //ponos_chunked_maximize_outer_parallelism (space, options, CI, CI->n_dep, PAT_STENCIL);
    CI->mode = CHUNKED_MODE_UNKNOWN;
  }
}


void 
ponos_chunked_create_constraints_pwr9 (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_graph_t * CG,
    s_chunked_info_t * CI)
{
  int n_stmt = CI->n_stmt;
  int ss;
  int filter[n_stmt];
  for (ss = 0; ss < n_stmt; ss++)
    filter[ss] = 1;
  //else if (is_stencil (space) && (CI->n_dep * 1.0 / space->num_sched_dim <= 3))
  //if (CG->n_scc == 1 && space->num_sched_dim <= 7 && is_stencil (space)) //CI->n_self_dep / CI->n_stmt >= 1)
  if (is_stencil (space) && (CI->n_dep * 1.0 / space->num_sched_dim <= 3))
  {
    printf ("[PWR9] Chunked Strategy: Stencils mode...\n");

    //ponos_chunked_optimize_reuse (space, options, CI);
    //ponos_chunked_stencil_skewing_constraints (space, options, CI);
    //ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_THETA_ITER, 3); //space->num_sched_dim - 4);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 4);
    //ponos_chunked_stencil_par_constraints (space, options, CI, CG);
    //ponos_chunked_maximize_outer_parallelism (space, options, CI, CI->n_dep, PAT_STENCIL);


    //ponos_chunked_set_easy_coefficients (space, options, CI);
    //ponos_chunked_big_split (space, options, CI, 2);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,5)
    ponos_chunked_stencil_par_constraints (space, options, CI, CG, SINGLECLUSTER, filter);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,4)
    ponos_chunked_stencil_dependence_classification (space, options, CI, CG, SINGLECLUSTER, filter);
    if (CI->n_dep < 50)
    {
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,3)
      ponos_perfidiom_stride_optimization (space, options, CI, filter);
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,2)
      ponos_perfidiom_inner_parallelism (space, options, CI, CG, 0, filter);
    }
    if (CI->obj_level >= 1)
    {
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
      ponos_chunked_stencil_minimize_vector_skewing (space, options, CI, CG, SINGLECLUSTER, filter);
    }
    CI->unroll = 0;
    CI->mode = CHUNKED_MODE_STENCIL;
  }
  else if (space->num_sched_dim <= 5)
  {
    printf ("[PWR9] Chunked Strategy: MatVec-like mode...\n");
    //ponos_chunked_preserve_parallelism (space, options, CI, CG);
    //ponos_chunked_optimize_reuse (space, options, CI);

    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,3)
    ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG, 0, filter);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,2)
    ponos_perfidiom_separate_independent_statements (space, options, CI, CG, 0, filter);
    //ponos_perfidiom_outerpar_innerreuse (space, options, CI);
    //ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //ponos_perfidiom_stride_optimization (space, options, CI);
    CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
    ponos_objectives_max_outer_par (space, options);

    CI->unroll = 1;
    CI->mode = CHUNKED_MODE_2D_SPACE;
  }
  //else if (CI->n_dep / CI->n_stmt <= 3 && CI->n_self_dep  / CI->n_dep <= 1)
  //else if (CI->n_dep / CI->n_stmt <= 10 && CI->n_self_dep  / CI->n_dep <= 1)
  else if (CG->n_scc > 1 && CI->n_self_dep * 1.0 / CI->n_dep <= 0.6 && CI->n_dep < 70) 
  {
    printf ("[PWR9] Chunked Strategy: Gemm-like mode ...\n");
    //  printf ("Including flow fusion and distribution of non-flow and non-related statements\n");

    if (CG->n_scc > 1)
    {
      printf ("==> Adding dependendence driven fusion and split indep.statements\n");
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,4)
      ponos_perfidiom_outerpar_innerreuse (space, options, CI, 1); // <--
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,3)
      ponos_objectives_max_outer_par (space, options);
      //ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG); // <--
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,2)
      ponos_perfidiom_separate_independent_statements (space, options, CI, CG, 0, filter);
      //ponos_perfidiom_inner_parallelism (space, options, CI);
      CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,1)
      ponos_perfidiom_stride_optimization (space, options, CI, filter);
      //ponos_chunked_maximize_outer_parallelism (space, options, CI, CI->n_dep, PAT_GEMM);
    }
    else
    {
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 1);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2);
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
    }
    CI->unroll = 1;
    CI->mode = CHUNKED_MODE_DENSE_LA;
  }
  else //if (CI->n_dep >= 30 || CI->n_dep * 1.0 / CI->n_stmt >= 8)
  {

    printf ("[PWR9] Chunked Strategy: Super hard mode (n_dep >= 50)\n");
    CI->unroll = 0;
    ponos_chunked_rebound_theta_iter (space, options, CI);
    //ponos_chunked_scc_separation_constraints (space, options, CI, CG);
    ponos_chunked_set_easy_coefficients (space, options, CI, CG);
    //ponos_chunked_big_split (space, options, CI, 2);
    //ponos_chunked_auto_satisfy_inter_stmt_dependences (space, options, CI, CG);
    //ponos_chunked_optimize_reuse (space, options, CI);
    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, space->num_sched_dim - 3);
    if (CG->n_scc == 1)
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
    else
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 1);
    ponos_perfidiom_outerpar_innerreuse (space, options, CI, 1);
    #if 0
    //ponos_chunked_set_easy_coefficients (space, options, CI);
    ponos_chunked_big_split (space, options, CI, 2);
    //ponos_chunked_stencil_par_constraints (space, options, CI, CG);
    //ponos_chunked_stencil_dependence_classification (space, options, CI, CG);
    //ponos_chunked_optimize_reuse (space, options, CI);
    //ponos_perfidiom_outerpar_innerreuse (space, options, CI);
    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //if (CG->n_scc > 1)
    {
      printf ("==> Adding outer parallelism maximization objective\n");
      //ponos_chunked_maximize_outer_parallelism (space, options, CI, CI->n_dep, PAT_GEMM);
      ponos_perfidiom_inner_parallelism (space, options, CI);
    }
    //else
    {
      //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2); //space->num_sched_dim - 4);
      //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 4); //space->num_sched_dim - 4);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 1); //space->num_sched_dim - 4);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 5); //space->num_sched_dim - 4);
      //ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3); //space->num_sched_dim - 4);
      //ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 1); //space->num_sched_dim - 4);
    }
    #endif
    if (CI->n_dep < 50)
    {
      ponos_perfidiom_stride_optimization (space, options, CI, filter);
      CI->unroll = 1;
    }
    CI->mode = CHUNKED_MODE_HARD;
  }
  if (0)
  {
    assert (0);
    printf ("Chunked Strategy: Other mode ...\n");
    //ponos_chunked_stencil_par_constraints (space, options, CI, CG);
    //ponos_chunked_stencil_dependence_classification (space, options, CI, CG);
    //ponos_perfidiom_stride_optimization (space, options, CI);
    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //ponos_chunked_stencil_minimize_vector_skewing (space, options, CI, CG);
    //ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG);
    //ponos_perfidiom_separate_independent_statements (space, options, CI, CG);
    //ponos_chunked_free_scalar_dimensions (space, options, CI); // good for fdtd-2d
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 1);

    //ponos_perfidiom_inner_parallelism (space, options, CI);
    //ponos_perfidiom_stride_optimization (space, options, CI);

    //ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
    //ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 2);

    ponos_chunked_development_test_schedule (space, options, CI);

    //ponos_chunked_maximize_outer_parallelism (space, options, CI, CI->n_dep, PAT_STENCIL);
    CI->mode = CHUNKED_MODE_UNKNOWN;
  }
}

void 
ponos_chunked_create_constraints_fake (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_graph_t * CG,
    s_chunked_info_t * CI)
{
  if (is_stencil (space) && (CI->n_dep * 1.0 / space->num_sched_dim <= 3))
  {
    printf ("[FAKE-ARCH] Chunked Strategy: Stencil mode ...\n");
  }
  else if (space->num_sched_dim <= 5)
  {
    printf ("[FAKE-ARCH] MatVec-like mode ...\n");
  }
  else if (CG->n_scc >= CI->n_self_dep) // && CI->n_self_dep * 1.0 / CI->n_dep <= 0.6 && CI->n_dep < 70) 
    // / CI->n_stmt <= 10) // && CI->n_self_dep  / CI->n_dep <= 1)
  {
    printf ("[FAKE-ARCH] Chunked strategy : Gemm-like mode\n");
  }
  else
  {
    printf ("[FAKE-ARCH] Chunked strategy : Other mode\n");
  }
}

void ponos_chunked_read_arch_file (s_ponos_space_t * space, 
     s_ponos_options_t* options, s_chunked_info_t * CI)
{
  FILE * f;
  printf ("[Chunked Info] Architecture: %s\n",get_chunked_arch_string(options));
  if (!options->chunked_arch_file ||
      options->chunked_arch != PONOS_CHUNKED_ARCH_FILE)
  {
    if (options->chunked_arch == PONOS_CHUNKED_ARCH_NONE)
    {
      CI->archinfo.arch_id = options->chunked_arch;
      if (options->fp_precision == 0)
        CI->archinfo.fp_precision = 64;
      CI->archinfo.n_cores = 10;
      CI->archinfo.l1_size = 32 * 1024 / 8;
      // L2 is private
      CI->archinfo.l2_size = 256 * 1024 / 8;
      // L3 is shared, we divide it among the number of cores
      CI->archinfo.l3_size = 12 * 1024 * 1024 / (CI->archinfo.n_cores * CI->archinfo.fp_precision);
      CI->archinfo.simdlen = 256;
      CI->archinfo.regfile_size = 32;
      CI->archinfo.rob_size = 112;
    }
    if (options->chunked_arch == PONOS_CHUNKED_ARCH_SKX)
    {
      CI->archinfo.arch_id = options->chunked_arch;
      if (options->fp_precision == 0)
        CI->archinfo.fp_precision = 64;
      CI->archinfo.n_cores = 10;
      CI->archinfo.l1_size = 32 * 1024 / 8;
      // L2 is private
      CI->archinfo.l2_size = 1024 * 1024 / 8;
      // L3 is shared, we divide it among the number of cores
      CI->archinfo.l3_size = 13.25 * 1024 * 1024 / (CI->archinfo.n_cores * CI->archinfo.fp_precision);
      CI->archinfo.simdlen = 512;
      CI->archinfo.regfile_size = 32;
      CI->archinfo.rob_size = 224;
    }
    if (options->chunked_arch == PONOS_CHUNKED_ARCH_KNL)
    {
      CI->archinfo.arch_id = options->chunked_arch;
      if (options->fp_precision == 0)
        CI->archinfo.fp_precision = 64;
      CI->archinfo.n_cores = 72;
      CI->archinfo.l1_size = 32 * 1024 / 8;
      // L2 is shared between two cores in a single tile
      CI->archinfo.l2_size = 1024 * 1024 / (2 * CI->archinfo.fp_precision); // the 2 is from a KNL tile (2 cores)
      // no L3
      CI->archinfo.l3_size = 0;
      CI->archinfo.simdlen = 512;
      CI->archinfo.regfile_size = 32;
      CI->archinfo.rob_size = 72;
    }
    if (options->chunked_arch == PONOS_CHUNKED_ARCH_PWR9)
    {
      CI->archinfo.arch_id = options->chunked_arch;
      if (options->fp_precision == 0)
        CI->archinfo.fp_precision = 64;
      CI->archinfo.n_cores = 32;
      CI->archinfo.l1_size = 32 * 1024 / 8;
      // private
      CI->archinfo.l2_size = 256 * 1024 / (8); // the 2 is from a KNL tile (2 cores)
      // 120 MB split into 12 regions of 10 MB each
      CI->archinfo.l3_size = 120 * 1024 * 1024 / (CI->archinfo.n_cores * CI->archinfo.fp_precision);
      CI->archinfo.simdlen = 512;
      CI->archinfo.regfile_size = 16; // 32 or 16?!?!
      CI->archinfo.rob_size = 72;
    }

    printf ("Architecture      : %d\n", CI->archinfo.arch_id);
    printf ("FP precision      : %d\n", CI->archinfo.fp_precision);
    printf ("Nbr. of cores     : %d\n", CI->archinfo.n_cores);
    printf ("SIMD len          : %d\n", CI->archinfo.simdlen);
    printf ("Regfile size      : %d\n", CI->archinfo.regfile_size);
    printf ("ROB size          : %d\n", CI->archinfo.rob_size);
    printf ("L1 size (entries) : %d\n", CI->archinfo.l1_size);
    printf ("L2 size (entries) : %d\n", CI->archinfo.l2_size);
    printf ("L3 size (entries1) : %d\n", CI->archinfo.l3_size);

    return;
  }
  if (options->chunked_arch_file &&
      options->chunked_arch == PONOS_CHUNKED_ARCH_FILE)
    printf ("[Chunked Info] Spec file   : %s\n",options->chunked_arch_file);
  f = fopen (options->chunked_arch_file, "r");
  CI->archinfo.fp_precision = 64; // default to doubles
  do 
  {
    int res;
    char hwfeat[50];
    char hwprop[50];
    char hwprop_units[50];
    char hwval_str[50];
    int  hwval_int;
    res = fscanf (f,"%s", hwfeat);
    if (res <= 0)
      break;
    if (strcmp (hwfeat,"arch") == 0)
    {
      res = fscanf (f,"%s", hwval_str);
      if (strcmp (hwval_str, "skx") == 0)
        CI->archinfo.arch_id = PONOS_CHUNKED_ARCH_SKX;
      if (strcmp (hwval_str, "knl") == 0)
        CI->archinfo.arch_id = PONOS_CHUNKED_ARCH_KNL; 
      if (strcmp (hwval_str, "pwr9") == 0)
        CI->archinfo.arch_id = PONOS_CHUNKED_ARCH_PWR9; 
      continue;
    }
    if (strcmp (hwfeat, "cores") == 0)
    {
      res = fscanf (f,"%d", &CI->archinfo.n_cores); 
      if (CI->archinfo.n_cores <= 1) 
        CI->archinfo.n_cores = 10;
      continue;
    }
    if (strcmp (hwfeat, "fp_precision") == 0)
    {
      res = fscanf (f,"%d", &CI->archinfo.fp_precision); 
      if (CI->archinfo.fp_precision != 4 && CI->archinfo.fp_precision != 8)
        CI->archinfo.fp_precision = 8;
      continue;
    }
    if (strcmp (hwfeat, "simdlen") == 0)
    {
      res = fscanf (f,"%d", &CI->archinfo.simdlen); 
      if (CI->archinfo.simdlen != 256 && CI->archinfo.simdlen != 512)
        CI->archinfo.simdlen = 512;
      continue;
    }
    if (strcmp (hwfeat, "simdreg") == 0)
    {
      res = fscanf (f,"%d", &CI->archinfo.regfile_size); 
      if (CI->archinfo.regfile_size <= 16)
        CI->archinfo.regfile_size = 32;
      continue;
    }
    if (strcmp (hwfeat, "rob") == 0)
    {
      res = fscanf (f,"%d", &CI->archinfo.rob_size); 
      if (CI->archinfo.rob_size < 50); 
      {
        if (CI->archinfo.regfile_size == 0)
          CI->archinfo.rob_size = 64;
        else
        {
          if (CI->archinfo.regfile_size <= 16)
            CI->archinfo.rob_size = 3 * CI->archinfo.regfile_size;
          else
            CI->archinfo.rob_size = 6 * CI->archinfo.regfile_size;
        }
      }
      continue;
    }
    if (strcmp (hwfeat, "l1") == 0 ||
        strcmp (hwfeat, "l2") == 0 ||
        strcmp (hwfeat, "l3") == 0)
    {
      int lx_size;
      res = fscanf (f,"%s %s %d", hwprop, hwprop_units, &lx_size);
      int factor;
      if (strcmp (hwprop_units, "kb") == 0)
        factor = 1024;
      if (strcmp (hwprop_units, "mb") == 0)
        factor = 1024 * 1024;
      factor = factor / (CI->archinfo.fp_precision / 8);
      lx_size *= factor;
      if (strcmp (hwfeat, "l1") == 0)
        CI->archinfo.l1_size = lx_size;
      if (strcmp (hwfeat, "l2") == 0)
        CI->archinfo.l2_size = lx_size;
      if (strcmp (hwfeat, "l3") == 0)
        CI->archinfo.l3_size = lx_size;
      continue;
    }
  } while (1);
  fclose (f);

  printf ("Architecture      : %d\n", CI->archinfo.arch_id);
  printf ("FP precision      : %d\n", CI->archinfo.fp_precision);
  printf ("Nbr. of cores     : %d\n", CI->archinfo.n_cores);
  printf ("SIMD len          : %d\n", CI->archinfo.simdlen);
  printf ("Regfile size      : %d\n", CI->archinfo.regfile_size);
  printf ("ROB size          : %d\n", CI->archinfo.rob_size);
  printf ("L1 size (entries) : %d\n", CI->archinfo.l1_size);
  printf ("L2 size (entries) : %d\n", CI->archinfo.l2_size);
  printf ("L3 size (entries2) : %d\n", CI->archinfo.l3_size);
}

static
void
write_arch_file_for_unrolling (s_chunked_info_t * CI)
{
  FILE * f;
  f = fopen (".chunked-unroll.txt", "w");
  #ifdef CHUNKED_PREDICATE_OBJECTIVE
  if (CI->unroll && CI->obj_level >= 7)
  #else
  if (CI->unroll) //CI->mode == CHUNKED_MODE_DENSE_LA || CI->mode == CHUNKED_MODE_2D_SPACE)
  #endif
  {
    int allow_outer;
    int outbound_factor;
    if (CI->mode == CHUNKED_MODE_DENSE_LA)
    {
      allow_outer = 1;
      outbound_factor = 1;
    }
    if (CI->mode == CHUNKED_MODE_2D_SPACE)
    {
      allow_outer = 1;
      if (CI->archinfo.arch_id == PONOS_CHUNKED_ARCH_KNL)
        outbound_factor = 2;
      else
        outbound_factor = 1;
    }
    fprintf (f,"%d %d",CI->archinfo.regfile_size * outbound_factor, allow_outer);
  }
  else
    fprintf (f,"-1 0");
  fclose (f);
}

static
void
read_obj_level_file (s_chunked_info_t * CI)
{
  #ifdef CHUNKED_PREDICATE_OBJECTIVE
  FILE * f;
  f = fopen (".chunked-obj-level.txt", "r");
  int res;
  res = fscanf (f, "%d", &CI->obj_level);
  fclose(f);
  #endif
}

void 
ponos_chunked_create_constraints (s_ponos_space_t* space,
    s_ponos_options_t* options, CandlProgram * cprogram, 
    int n_dep, CandlDependence * deps)
{

  s_chunked_info_t * CI;
  CI = ponos_chunked_compute_info (space, options, n_dep);
  CI->cprogram = cprogram;
  n_dep = CI->n_dep;

  ponos_chunked_read_arch_file (space, options, CI);
  //read_obj_level_file (CI);

  printf ("here\n");
  ponos_chunked_fix_theta_bounds (space, options);
 fprintf (CI->logfile, "#deps = %d, #stmts = %d\n",CI->n_dep, CI->n_stmt);
  ponos_chunked_show_dependence_info (space, options);
  s_chunked_graph_t * CG;
  CG = ponos_chunked_compute_scc_level (space, options, CI, 0);
  assert (CG && "Error when computing chunked graph");

  if (CI->archinfo.arch_id  == PONOS_CHUNKED_ARCH_SKX)
  {
   fprintf (CI->logfile, "Starting Chunked-SKX scheduling\n");
    ponos_chunked_create_constraints_skx (space, options, CG, CI);
   fprintf (CI->logfile, "Ending Chunked-SKX scheduling\n");
  }

  if (CI->archinfo.arch_id == PONOS_CHUNKED_ARCH_KNL)
  {
   fprintf (CI->logfile, "Starting Chunked-KNL scheduling\n");
    ponos_chunked_create_constraints_knl (space, options, CG, CI);
   fprintf (CI->logfile, "Ending Chunked-KNL scheduling\n");
  }

  if (CI->archinfo.arch_id == PONOS_CHUNKED_ARCH_PWR9)
  {
   fprintf (CI->logfile, "Starting Chunked-PWR9 scheduling\n");
    ponos_chunked_create_constraints_pwr9 (space, options, CG, CI);
   fprintf (CI->logfile, "Ending Chunked-PWR9 scheduling\n");
  }

  if (CI->archinfo.arch_id == PONOS_CHUNKED_ARCH_CNC)
  {
   fprintf (CI->logfile, "Starting Chunked-CNC scheduling\n");
    //ponos_chunked_create_constraints_cnc (space, options, CG, CI);
    //generate_pipes_program (space, options, cprogram, deps);

   fprintf (CI->logfile, "Ending Chunked-CNC scheduling\n");
  }

  if (CI->archinfo.arch_id == PONOS_CHUNKED_ARCH_FAKE)
  {
   fprintf (CI->logfile, "Starting Chunked-FAKE scheduling\n");
    ponos_chunked_create_constraints_fake (space, options, CG, CI);
   fprintf (CI->logfile, "Ending Chunked-FAKE scheduling\n");
  }

  write_arch_file_for_unrolling (CI);
  ponos_chunked_graph_free (CG);
  ponos_chunked_free_info (CI);
}



/*
 *
 *
 */
void ponos_perfidiom_embed_one (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, 
    s_chunked_graph_t * CG,
    int clusterid,
    int * filter,
    int idiom_code)
{
  if (idiom_code == PONOS_PERFIDIOM_OPIR)
  {
    printf ("==> OPIR\n");
    ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, -1);
    ponos_perfidiom_outerpar_innerreuse_with_filter (
      space, options, CI, CG, 0, clusterid, filter);
  }
  // parallel dimension alignment
  if (idiom_code == PONOS_PERFIDIOM_ADA)
  {
    printf ("==> ADA\n");
    ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, -1);
    ponos_perfidiom_force_dependence_at_level (space, options, CI, CG, clusterid, filter, 0);
    ponos_perfidiom_outerpar_innerreuse_with_filter (space, options, CI, CG, 1, clusterid, filter);
  }
  if (idiom_code == PONOS_PERFIDIOM_SOIP)
  {
    printf ("==> SOIP\n");
    ponos_perfidiom_stride_optimization (space, options, CI, filter);
    ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, -1);
    ponos_perfidiom_inner_parallelism (space, options, CI, CG, clusterid, filter);
  }
  // Stride Minimization
  if (idiom_code == PONOS_PERFIDIOM_SO)
  {
    if (CG->fgraph->nodes[clusterid].max_depth >= 1)
    {
      printf ("==> SO\n");
      ponos_perfidiom_stride_optimization (space, options, CI, filter);
    }
  }
  // Simple outer-parallelism
  if (idiom_code == PONOS_PERFIDIOM_OP)
  {
    if (CG->fgraph->nodes[clusterid].max_depth >= 1)
    {
      printf ("==> OP\n");
      //ponos_objectives_max_outer_par (space, options);
      ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, 1);
      ponos_perfidiom_outer_parallelism (space, options, CI, CG, clusterid, filter, 1);
    }
  }
  if (idiom_code == PONOS_PERFIDIOM_2OP)
  {
    if (CG->fgraph->nodes[clusterid].max_depth >= 3)
    {
      printf ("==> 2ND-OP\n");
      ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, -1);
      ponos_perfidiom_force_dependence_at_level (space, options, CI, CG, clusterid, filter, 4);
      ponos_perfidiom_force_dependence_at_level (space, options, CI, CG, clusterid, filter, 2);
      ponos_perfidiom_outer_parallelism (space, options, CI, CG, clusterid, filter, 3);
      ponos_perfidiom_force_dependence_at_level (space, options, CI, CG, clusterid, filter, 1);
    }
  }
  if (idiom_code == PONOS_PERFIDIOM_2OP_EASY)
  {
    printf ("==> 2ND-OP (EASY)\n");
    ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, 3);
    ponos_perfidiom_outer_parallelism (space, options, CI, CG, clusterid, filter, 3);
    //ponos_perfidiom_force_dependence_at_level (space, options, CI, CG, clusterid, filter, 2);
    //ponos_perfidiom_force_dependence_at_level (space, options, CI, CG, clusterid, filter, 4);
  }
  // Increase the dependence distance among unrelated statements and 
  // statements binded by WAR and WAW dependences
  if (idiom_code == PONOS_PERFIDIOM_SIS)
  {
    printf ("==> SIS\n");
    ponos_perfidiom_separate_independent_statements (space, options, CI, CG, clusterid, filter);
  }
  if (idiom_code == PONOS_PERFIDIOM_DGF)
  {
    printf ("==> DGF\n");
    ponos_perfidiom_dependence_guided_fusion (space, options, CI, CG, clusterid, filter);
  }
  // Maximize inner parallelism
  if (idiom_code == PONOS_PERFIDIOM_IP)
  {
    if (CG->fgraph->nodes[clusterid].max_depth >= 1)
    {
      printf ("==> IP\n");
      // Insert all psi variables for convenience. 
      // Depending on the dimensionality of each statement.
      ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, -1);
      ponos_perfidiom_inner_parallelism (space, options, CI, CG, clusterid, filter);
    }
  }
  // Minimize Iterator Coefficients (MIC) sum.
  if (idiom_code == PONOS_PERFIDIOM_MIC)
  {
    if (CG->fgraph->nodes[clusterid].max_depth >= 1)
    {
      printf ("==> MiIC\n");
      ponos_perfidiom_minimize_iterator_coefficient_sum (space, options, CI, CG, clusterid, filter, -1);
    }
  }
  // Satisfy Dependence Once!
  if (idiom_code == PONOS_PERFIDIOM_SDO)
  {
    printf ("==> SDO\n");
    // Critical for the stencil types.
    // Increases the complexity of SCC types.
    // Does not affect (too much) nodes of type SET.
    ponos_chunked_satisfy_dependence_once (space, options, CI, CG, filter);
  }
  // Embed constraints for skewing minimization that affects vector (stencils)
  if (idiom_code == PONOS_PERFIDIOM_VSKW)
  {
    printf ("==> VSKW\n");
    ponos_chunked_stencil_minimize_vector_skewing (space, options, CI, CG, clusterid, filter);
  }
  // Stencils: classify dependences by type; force specific level of satisfaction
  if (idiom_code == PONOS_PERFIDIOM_SDC)
  {
    printf ("==> SDC\n");
    ponos_chunked_stencil_dependence_classification (space, options, CI, CG, clusterid, filter);
  }
  // Stencils how to extract paralellism: parallel constraints
  if (idiom_code == PONOS_PERFIDIOM_SPC)
  {
    printf ("==> SPC\n");
    ponos_chunked_stencil_par_constraints (space, options, CI, CG, clusterid, filter);
  }
  if (idiom_code == PONOS_PERFIDIOM_SMP)
  {
    printf ("==> SMP\n");
    ponos_chunked_stencil_max_parallelism (space, options, CI, CG, clusterid, filter);
  }
  if (idiom_code == PONOS_PERFIDIOM_FPP)
  {
    printf ("==> FPP\n");
    ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, -1);
    ponos_perfidiom_fusion_preserving_parallelism (space, options, CI, CG, clusterid, filter);
  }
  if (idiom_code == PONOS_PERFIDIOM_SKEWPAR)
  {
    printf ("==> SKWPAR\n");
    ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, -1);
    ponos_perfidiom_skew_parallelism (space, options, CI, CG, clusterid, filter);
  }
  if (idiom_code == PONOS_PERFIDIOM_MLP)
  {
    printf ("==> MLP\n");
  
  }
  if (idiom_code == PONOS_PERFIDIOM_PERM)
  {
    printf ("==> PERM\n");
    ponos_perfidiom_permutability (space, options, CI, CG, clusterid, filter); 
  }
}

/*
const int SCC_OPTS[] = {
  PONOS_PERFIDIOM_OPIR, 
  PONOS_PERFIDIOM_SKEWPAR,
	PONOS_PERFIDIOM_DGF,
	PONOS_PERFIDIOM_FPP,
	PONOS_PERFIDIOM_IP,
	PONOS_PERFIDIOM_SO,
	PONOS_PERFIDIOM_PERM
};


const int SET_OPTS[] = {
  PONOS_PERFIDIOM_OPIR, 
  PONOS_PERFIDIOM_ADA, 
  PONOS_PERFIDIOM_SIS,
  PONOS_PERFIDIOM_DGF,
  PONOS_PERFIDIOM_FPP,
  //PONOS_PERFIDIOM_SOIP,
	PONOS_PERFIDIOM_IP,
	PONOS_PERFIDIOM_SO,
  PONOS_PERFIDIOM_PERM
};

const int STEN_OPTS[] = {
  PONOS_PERFIDIOM_VSKW, 
  PONOS_PERFIDIOM_SPC, 
  PONOS_PERFIDIOM_SDC, 
  PONOS_PERFIDIOM_SO, 
  PONOS_PERFIDIOM_FPP,
  PONOS_PERFIDIOM_DGF,
  PONOS_PERFIDIOM_IP, 
  PONOS_PERFIDIOM_PERM
};
*/



/*
 * Sort the objectives by some predetermined priority:
 * by a list (1st = highest) or by a hardwired order.
 * Neither of these options are meant to be used extensively.
 */
static
void ponos_perfidiom_prioritize (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, 
    s_chunked_graph_t * CG,
    int clusterid,
    int * objectives)
{
  int ii, jj, nobj;
  for (ii = 0; objectives[ii] != -1; ii++);
  nobj = ii;
  if (options->chunked_olist)
  {
    // Invert the order given, i.e. first in the list 
    // is the highest priority.
    for (ii = 0; ii < nobj/2; ii++)   
    {
      e_perfidiom temp = objectives[ii];
      objectives[ii] = objectives[nobj - 1 - ii];
      objectives[nobj - 1 - ii] = temp;
    }
  }
  else
  {
    // Use pre-established priorities for objectives.
    for (ii = 0; ii < nobj - 1; ii++)
      for (jj = ii + 1; jj < nobj; jj++)
        if (objectives[jj] < objectives[ii])
    {
      e_perfidiom temp = objectives[ii];
      objectives[ii] = objectives[jj];
      objectives[jj] = temp;
    }
  }
}


/*
 * Given a clusterid, generate the statement filter vector.
 * 1 = statement included in cluster; 0 = not included.
 */
static
void ponos_perfidiom_filter (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, 
    s_chunked_graph_t * CG,
    int clusterid,
    int * filter)
{
  s_fgraph_t * fgraph = CG->fgraph;
  s_fnode_t * fnode = &CG->fgraph->nodes[clusterid];
  int jj;
  for (jj = 0; jj < CI->n_stmt; jj++)
    filter[jj] = 0;
  for (jj = 0; jj < fnode->n_members; jj++)
  {
    //  printf ("    |--> Statement %d\n",fgraph->nodes[ii].members[jj]);
    filter[fnode->members[jj]] = 1;
  }
  /*
  fprintf (CI->logfile, "Showing activated members for cluster %d\n",clusterid);
  for (jj = 0; jj < fnode->n_members; jj++)
  {
    fprintf (CI->logfile, "==> Statement %d\n",fnode->members[jj]);
  }
  fprintf (CI->logfile, "--- end of activation ---\n");
  */
}


/*
 * Count self-deps and all dependences in a specific cluster.
 * Both the source and target of the dependence must live within the cluster.
 * The function updates entries in all of the fnode structures.
 * DO NOT USE: we are computing this and the intra-cluster deps in the
 * ponos_chunked_build_fgraph routine.
 */
static
void count_dependences_in_clusters (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, 
    s_chunked_graph_t * CG)
{
  int filter[CI->n_stmt];
  for (int ii = 0; ii < CG->fgraph->n_nodes; ii++)
  {
    ponos_perfidiom_filter     (space, options, CI, CG, ii, filter);
    int * ids = collect_delta_ids_from_cluster (space, CI, 0, filter);
    int self = 0;
    int all = 0;
    for (int dd = 0; ids && ids[dd] != -1; dd++)
    {
      int varid = ids[dd];
      CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
      int is_self = dep->source == dep->target;
      if (is_self)
        self++;
      all ++;
    }
    CG->fgraph->nodes[ii].n_dep = all;
    CG->fgraph->nodes[ii].n_self_dep = self;
    XFREE (ids);
  }
}




const int SCC_OPTS[] = {
	PONOS_PERFIDIOM_IP,
	PONOS_PERFIDIOM_SO,
	PONOS_PERFIDIOM_DGF,
  PONOS_PERFIDIOM_OPIR, 
  PONOS_PERFIDIOM_ADA, 
  PONOS_PERFIDIOM_SKEWPAR,
//	PONOS_PERFIDIOM_FPP,
	PONOS_PERFIDIOM_PERM
};


const int SET_OPTS[] = {
	PONOS_PERFIDIOM_IP,
	PONOS_PERFIDIOM_SO,
  PONOS_PERFIDIOM_DGF,
  PONOS_PERFIDIOM_OPIR, 
  PONOS_PERFIDIOM_ADA, 
//  PONOS_PERFIDIOM_FPP,
  //PONOS_PERFIDIOM_SOIP,
  PONOS_PERFIDIOM_SIS,
  PONOS_PERFIDIOM_PERM
};

const int STEN_OPTS[] = {
  PONOS_PERFIDIOM_IP, 
  PONOS_PERFIDIOM_SO, 
  PONOS_PERFIDIOM_DGF,
  PONOS_PERFIDIOM_SPC, 
  PONOS_PERFIDIOM_SDC, 
  PONOS_PERFIDIOM_VSKW, 
//  PONOS_PERFIDIOM_FPP,
  PONOS_PERFIDIOM_PERM
};

const int ALL_OPTS[] = {
	PONOS_PERFIDIOM_IP,
	PONOS_PERFIDIOM_SO,
  PONOS_PERFIDIOM_DGF,
  PONOS_PERFIDIOM_SIS,
  PONOS_PERFIDIOM_OPIR, 
  PONOS_PERFIDIOM_ADA, 
  PONOS_PERFIDIOM_FPP,
  PONOS_PERFIDIOM_SKEWPAR,
  PONOS_PERFIDIOM_PERM,
  PONOS_PERFIDIOM_SPC, 
  PONOS_PERFIDIOM_SDC, 
  PONOS_PERFIDIOM_VSKW 
};
const char * lexicon_names[] = {
  "IP",
  "SO",
  "DGF",
  "SIS",
  "OPIR",
  "ADA",
  "FPP",
  "SKEWPAR",
  "PERM",
  "SPC",
  "SDC",
  "VSKW"
};

const int *CHUNK_OPTS[] = {SCC_OPTS, SET_OPTS, STEN_OPTS};

const char * idiomsec[] = {
  "PERM",
	"DGF",
	"OP",
  "2OP",
  "2OPEC",
	"OPIR",
	"ADA",
  "MIC",
  "SDO",
	"SMP",
	"SPC",
  "FDS",
	"SDC",
	"NONE",
	"MLP",
	"FPP",
	"SIS",
	"SO",
	"IP",
	"SOIP",
	"VSKW",
	"SKEWPAR"
};


/*
 * Proceed to insert the selected constraints and objectives.
 *
 */
static
void ponos_perfidiom_embed (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, 
    s_chunked_graph_t * CG,
    int clusterid,
    int * objectives,
    int * filter)
{
  int ii;
  for (ii = 0; objectives[ii] != -1; ii++)
  {
    fprintf (CI->logfile, "Embedding objective %s\n",idiomsec[objectives[ii]]);
    ponos_perfidiom_embed_one (space, options, CI, CG, clusterid, filter, objectives[ii]);
  }
}


#define add_objective(code,objlist) (objlist[nobj++] = code);
static
void ponos_perfidiom_select (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, 
    s_chunked_graph_t * CG,
    int clusterid,
    int * objectives)
{
  s_fgraph_t * fgraph = CG->fgraph;
  s_fnode_t * fnode = &CG->fgraph->nodes[clusterid];
  int nodetype = fnode->nodetype;
  int nobj = 0;
  fprintf (CI->logfile, "chunked_olist is %d\n", options->chunked_olist);
  int tempobj[30];
  if (options->chunked_olist)
  {
    FILE * ff;
    fprintf (CI->logfile, "Reading objective list...\n");
    ff = fopen ("chunked-olist.txt", "r");
    while (1) {
      int entry;
      int res = fscanf (ff,"%d",&entry);
      if (entry == -1)
        break;
      //int obj_code = CHUNK_OPTS[nodetype][entry];
      //fprintf (CI->logfile, "Read objective code [%d][%d]: %d\n",nodetype, entry, obj_code);
      //fprintf (CI->logfile, "Adding performance objective: %s\n", idiomsec[obj_code]);
      int obj_code = ALL_OPTS[entry];
      fprintf (CI->logfile, "Read objective code [%d]: %d\n", entry, obj_code);
      fprintf (CI->logfile, "Adding performance objective: %s\n", lexicon_names[entry]);

      add_objective(obj_code, tempobj);
    }
    fprintf (CI->logfile, "Reversing order of objectives to match semantics of embedding\n");
    int ii;
    for (ii = 0; ii < nobj; ii++)
      objectives[ii] = tempobj[nobj - ii - 1];
    fclose(ff);
  }
  else
  {
    //add_objective(PONOS_PERFIDIOM_PERM,objectives);

    s_fnode_t * fnode = &CG->fgraph->nodes[clusterid];
    float clu_depth = fnode->max_depth;
    float clu_size = fnode->n_members;
    float flexibility = fnode->flexibility;

    if (nodetype == FNODE_TYPE_SET)
    {
      int op_low_priority = CI->archinfo.n_cores <= CI->archinfo.simdlen / CI->archinfo.fp_precision;
      printf ("<SET-mode>\n");
      //CI->unroll = 1;
      {
        add_objective(PONOS_PERFIDIOM_MIC, objectives);    
      }
      if (clu_depth >= 3)
      {
        if (fnode->n_self_dep > 0)
        {
          if (op_low_priority)
          {
            add_objective(PONOS_PERFIDIOM_OPIR, objectives);
          }
        }
        else
        {
          add_objective(PONOS_PERFIDIOM_ADA,objectives);
        }
      }
      if (clu_depth <= 2 && op_low_priority)
      {
        add_objective(PONOS_PERFIDIOM_OP, objectives);
      }

      if (clu_size >= 2)
      {
        if (op_low_priority)
        {
          add_objective(PONOS_PERFIDIOM_DGF,objectives);
        }
        add_objective(PONOS_PERFIDIOM_SIS,objectives);
      }
      if (clu_depth <= 2 && ! op_low_priority)
      {
        //add_objective(PONOS_PERFIDIOM_OP, objectives);
      }
      if (clu_depth >= 2 && !op_low_priority)
      {
        add_objective(PONOS_PERFIDIOM_ADA,objectives);
      }
      if (clu_depth >= 2)
      {
        add_objective(PONOS_PERFIDIOM_IP,objectives);
        add_objective(PONOS_PERFIDIOM_SO,objectives);
      }
    }
    if (nodetype == FNODE_TYPE_SCC)
    {
      CI->unroll = 0;
      printf ("<SCC-mode>\n");
      //add_objective(PONOS_PERFIDIOM_ADA,objectives);
      // LU requires OPIR; OPIR break SYMM
      if (flexibility <= 7.0)
      {
        //add_objective(PONOS_PERFIDIOM_OPIR, objectives);
        add_objective(PONOS_PERFIDIOM_2OP, objectives);
        add_objective(PONOS_PERFIDIOM_IP,objectives);
        add_objective(PONOS_PERFIDIOM_SO,objectives);
      }
      else 
      {
        add_objective(PONOS_PERFIDIOM_2OP_EASY, objectives);
        //add_objective(PONOS_PERFIDIOM_SO,objectives);
      }
    }
    if (nodetype == FNODE_TYPE_STEN)
    {
      printf ("<STEN-mode>\n");
      #ifdef PLDI19_MAX_STEN_PAR
      add_objective(PONOS_PERFIDIOM_SMP,objectives);
      #endif
      if (flexibility <= 3.0)
      {
        add_objective(PONOS_PERFIDIOM_SDO,objectives);
        add_objective(PONOS_PERFIDIOM_SPC,objectives);
        //add_objective(PONOS_PERFIDIOM_SO,objectives);
      }
      else if (flexibility <= 5.0)
      {
        add_objective(PONOS_PERFIDIOM_SDO,objectives);
        add_objective(PONOS_PERFIDIOM_SPC,objectives);
        add_objective(PONOS_PERFIDIOM_SDC,objectives);
        add_objective(PONOS_PERFIDIOM_VSKW,objectives);
      }
      else
      {
        // REALLY HARD
        if (clu_depth >= 3)
          add_objective(PONOS_PERFIDIOM_2OP_EASY, objectives);
      }
    }
  }
  objectives[nobj] = -1;
}


void 
ponos_chunked_auto_select_objectives (s_ponos_space_t* space,
    s_ponos_options_t* options, CandlProgram * cprogram, 
    int n_dep, CandlDependence * deps, int space_id)
{
  s_chunked_info_t * CI;
  char logfilename[100];
  sprintf (logfilename,"ppiv-%d.log", space_id);

  printf ("Collecting info for chunked...\n");
  CI = ponos_chunked_compute_info (space, options, n_dep);
  CI->logfile = fopen (logfilename,"w");
  CI->cprogram = cprogram;
  n_dep = CI->n_dep;

  printf ("Reading arch file...\n");
  ponos_chunked_read_arch_file (space, options, CI);
  //read_obj_level_file (CI);

  printf ("About to fix theta bounds...\n");

  ponos_chunked_fix_theta_bounds (space, options);
  printf ("#deps = %d, #stmts = %d\n",CI->n_dep, CI->n_stmt);
  ponos_chunked_show_dependence_info (space, options);
  s_chunked_graph_t * CG;
  CG = ponos_chunked_compute_scc_level (space, options, CI, 0);
  assert (CG && "Error when computing chunked graph");

  ponos_chunked_build_fgraph (space, options, CI, CG);
  //count_dependences_in_clusters (space, options, CI, CG);
  ponos_chunked_subclassify_sccs (space, options, CI, CG);

  CG->fgraph->logfile = CI->logfile;
  ponos_show_fgraph (CG->fgraph);


  int dounroll[3] = {0,0,0};
  s_fgraph_t * fgraph = CG->fgraph;
  int ii;
  CI->unroll = 1; 
  for (ii = 0; ii < fgraph->n_nodes; ii++)
  {
    ponos_chunked_show_nodetype (fgraph->nodes[ii]);
    int jj;
    int nodetype = fgraph->nodes[ii].nodetype;
    int objectives[PONOS_LAST_PERFIDIOM+1];
    int filter[CI->n_stmt];
    if (nodetype != FNODE_TYPE_SET)
      CI->unroll = 0;
    // Select statements from the current cluster
    ponos_perfidiom_filter     (space, options, CI, CG, ii, filter);
    // Select the performance objectives
    fprintf (CI->logfile, "Selecting objectives...\n");
    ponos_perfidiom_select     (space, options, CI, CG, ii, objectives);
    // Sort the objectives
    fprintf (CI->logfile, "Prioritizing objectives...\n");
    //ponos_perfidiom_prioritize (space, options, CI, CG, ii, objectives);
    // Add the objectives to the ILP
    fprintf (CI->logfile, "Embedding objectives...\n");
    ponos_perfidiom_embed      (space, options, CI, CG, ii, objectives, filter);
  }

  write_arch_file_for_unrolling (CI);

  fclose (CI->logfile);

  ponos_chunked_graph_free (CG);
  ponos_chunked_free_info (CI);
}


static
char * string_dup_and_remove_space (char * body)
{
  int thelen = strlen(body);
  char * ret = XMALLOC (char, thelen+1);
  char * ptr;
  int ii;
  for (ii = 0, ptr = body; ptr && *ptr != '\0'; ptr++)
    if (*ptr != ' ')
      ret[ii++] = *ptr;
  ret[ii] = '\0';
  return ret;
}

static
void print_tag_array (FILE * fout, scoplib_scop_p scop)
{
  int ii;
  fprintf (fout,"\n<arrays>\n");
  fprintf (fout, "%d\n",scop->nb_arrays);
  for (ii = 0; ii < scop->nb_arrays; ii++)
  {
    fprintf (fout, "%d %s\n", ii+1, scop->arrays[ii]);
  }
  fprintf (fout,"</arrays>\n");
}

void
ponos_multi_objective_space_generate (scoplib_scop_p scop,
    CandlProgram* cprogram, CandlDependence* deps,
    s_ponos_space_t * space, s_ponos_options_t* options)
{
  FILE * ff;
  ff = fopen ("chunked-space.txt", "r");
  if (!ff)
  {
    fprintf (stderr,"Could not open chunked-space.txt file. Aborting...\n");
    exit (1);
  }
  options->chunked_olist = 1;

  CandlDependence* mydep;
  int n_dep = 0;
  for (mydep = deps; mydep; mydep = mydep->next, n_dep++);
  int n_stmt = 0;
  scoplib_statement_p stmt;
  // Update the body string of each statement by removing all spaces.
  for (stmt=space->scop->statement, n_stmt=0; stmt; stmt = stmt->next, n_stmt++)
    if (stmt->body)
  {
    char * newbody = string_dup_and_remove_space (stmt->body);
    XFREE (stmt->body);
    stmt->body = newbody;
  }
  scoplib_matrix_p * schedules = XMALLOC (scoplib_matrix_p, n_stmt);
  int kk;
  printf ("Allocating array for schedules (%d)\n", n_stmt);
  for (stmt=space->scop->statement, kk=0; stmt; stmt = stmt->next, kk++)
  {
    schedules[kk] = scoplib_matrix_copy (stmt->schedule);
  }
  printf ("Got here\n");


  ponos_constraints_param_coef_zero (space, options);
  ponos_constraints_sum_iter_pos (space, options);
  ponos_constraints_linear_indep (space, options);
  ponos_objectives_min_iter_coef (space, options);

  s_ponos_space_t * original_space = ponos_space_clone (space);

  printf ("Ready for many variants!!!\n");

  int n_variants, n_obj;
  int ignoreme = fscanf (ff,"%d %d", &n_variants, &n_obj);
  int vv;
  int objs[n_obj+1]; // max. number of objectives
  char logfilename[100];
  for (vv = 0; vv < n_variants; vv++)
  {
    printf ("Generating scop variant %d\n", vv);
    int ii = 0;
    for (stmt=space->scop->statement, ii=0; stmt; stmt = stmt->next, ii++)
    {
      scoplib_matrix_free (stmt->schedule);
      stmt->schedule = scoplib_matrix_copy (schedules[ii]);
    }
    // Write current line of performance objectives to file.
    ii = 0;
    do 
    {
      ignoreme = fscanf (ff,"%d", &objs[ii]);
      ii++;
    } while (ii < n_obj + 1 && objs[ii-1] != -1);
    FILE * ftmp;
    ftmp = fopen ("chunked-olist.txt", "w");
    assert (ftmp && "Ponos/Chunked: could not open chunked-olist.txt file. Aborting ...\n");
    for (ii = 0; ii < n_obj && objs[ii] != -1; ii++)
    {
      fprintf (ftmp,"%d ", objs[ii]);
    }
    fprintf (ftmp," -1");
    fclose (ftmp);
    ponos_chunked_auto_select_objectives (space, options, cprogram, n_dep, deps, vv);

    // Solve the system.
    if (! options->quiet)
      printf ("[Ponos] Solve PIP\n");
    if (options->pipsolve_gmp)
      ponos_solver_gmp (space, scop, options);
    else
      ponos_solver (space, scop, options);

    // Save scop in file 
    char scopfile[100];
    sprintf (scopfile, "mobj-%d.txt", vv);
    ftmp = fopen (scopfile, "w");
    //scoplib_scop_print (ftmp, scop);
    //scoplib_scop_print_dot_scop (ftmp, scop);
    //scoplib_scop_print_structure (ftmp, scop, 0);
    scoplib_scop_print_dot_scop_options (ftmp, scop, SCOPLIB_SCOP_PRINT_ARRAYSTAG);
    //print_tag_array (ftmp, scop);
    fclose (ftmp);

    sprintf (logfilename,"ppiv-%d.log",vv);
    FILE * lf = fopen (logfilename, "a");
	  fprintf (lf, "\n[Ponos][INFO] Cplex result:\n");
	  ponos_solver_cplex_pprint_solution (lf, space);
    fclose (lf);

    // free work-space and restore original one
    printf ("Freeing work-space\n");
    ponos_space_free (space);
    printf ("Reloading original space\n");
    space = ponos_space_clone  (original_space);
    printf ("Ready for next round (variant %d)\n", vv+1);
  }
  fclose (ff);
  fprintf (stderr, "Generated %d multi-objective variants\n", n_obj);
  for (kk = 0; kk < n_stmt; kk++)
    scoplib_matrix_free (schedules[kk]);
  XFREE (schedules);
  ponos_space_free (original_space);
  ponos_space_free (space);
  exit (0);
}

static
void run_mdt_query (
  depsig_t * dep, int * obj, int * prefix, int prefsize, int par_priority)
{
  char cmd[1000];
  char query[1000];
  char prefixstr[500];
  int num_stmt = dep->self_dep ? 1 : 2;
  sprintf (query,"%d %d %d %d %d %d %d %d %d %d %d",
    num_stmt, par_priority,
    dep->dim_src, dep->dim_tgt, dep->rect_src_dom, dep->rect_tgt_dom,
    dep->dim_data, 
    dep->has_dep, dep->self_dep, dep->type, dep->card);

  int ii;
  char * ptr;
  for (ii = 0, ptr=prefixstr; ii < prefsize; ii++)
  {
    char objstr[10];
    if (ii>0)
    {
      sprintf (ptr,":");
      ptr++;
    }
    sprintf (objstr,"%d", prefix[ii]);
    int nb = sprintf (ptr, "%s", objstr);
    ptr += nb;
  }
  *ptr = '\0';
  if (prefsize == 0)
    sprintf (ptr,"-1");
  
  sprintf (cmd, "./gen-nano-tests/query-db.py mdt-db.txt '%s' '%s'", query, prefixstr);
  printf ("The fancy command is: {%s}\n", cmd);
  FILE * ff = popen (cmd, "r");

  int a,b,c;
  fscanf (ff,"%d %d %d", &a, &b, &c);
  obj[0] = a;
  obj[1] = b;
  obj[2] = c;
  printf ("Retrieved: %d %d %d\n", obj[0], obj[1], obj[2]);
  pclose (ff);
}


static
void adaptive_schedule (
  depsig_t * dep, int n_dep, int * obj, int * filter, int cluster_id, int par_priority)
{
  int last_obj = -1;
  int suffix[3];
  int original_ndep = n_dep;
  int obj_used = 0;
  int lexicon_size = 6; //LEXICON_SIZE; // FIXME: this is temporary
  int dd = 0;
  int kk;
  obj[0] = -1;
  printf ("[Cluster %d] Number of dependences is: %d\n", cluster_id, n_dep);
  printf ("[Cluster %d] used objectives: %d\n", cluster_id, obj_used);
  while (n_dep > 0 && obj_used < lexicon_size)
  {
    depsig_t * currdep = &dep[dd];
    printf ("[Cluster %d] Dependence found from S%d to S%d\n",cluster_id, currdep->src_id, currdep->dst_id);
    // Skip when any of the dependences is not fully contained within the
    // current cluster
    if (!filter[currdep->src_id] || !filter[currdep->dst_id])
    {
      n_dep--;
      dd++;
      continue;
    }
    run_mdt_query (currdep, suffix, obj, obj_used, par_priority);
    if (suffix[0] >= 0) 
    {
      printf ("For dependence %d : ", dd);
      for (kk = 0; kk < 3; kk++)
        printf ("%d ", suffix[kk]);
      printf ("\n");
      for (kk = (obj_used >= 1 ? 1 : 0); kk < 3; kk++) // skip the 1st one, which == last_obj
        if (suffix[kk] >= 0)
          obj[obj_used++] = suffix[kk];
      //last_obj = obj[obj_used-1];
    }
    n_dep--;
    dd++;
  }
  obj[obj_used] = -1;
  printf ("Summary of selected objectives (In Reverse Order of Application): \n");
  for (kk = 0; kk < obj_used; kk++)
  {
    printf("[Cluster %d] Using objective %d\n", cluster_id, obj[kk]);
  }
}

void static
translate_idiom_position_to_code (int * pos, int * codes)
{
  int ii;
  int nn = 0;
  for (ii = 0; pos[ii] != -1; ii++);
  nn = ii;
  // Fetch code and store IN REVERSE ORDER!!!!
  for (ii = 0; pos[ii] != -1; ii++)
    codes[nn - 1 - ii] = ALL_OPTS[pos[ii]];
  codes[nn] = -1;
}


/*
 * Given a clusterid, generate the statement filter vector.
 * 1 = statement included in cluster; 0 = not included.
 */
static
void ponos_perfidiom_user_filter (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, 
    s_chunked_graph_t * CG,
    int clusterid,
    int * filter)
{
  s_fgraph_t * fgraph = CG->fgraph;
  s_fnode_t * fnode = &CG->fgraph->nodes[clusterid];
  int jj;
  for (jj = 0; jj < CI->n_stmt; jj++)
    filter[jj] = 0;
  for (jj = 0; jj < fnode->n_members; jj++)
  {
    //  printf ("    |--> Statement %d\n",fgraph->nodes[ii].members[jj]);
    filter[fnode->members[jj]] = 1;
  }
  printf ("Showing activated members for cluster %d\n",clusterid);
  for (jj = 0; jj < fnode->n_members; jj++)
  {
    printf ("==> Statement %d\n",fnode->members[jj]);
  }
  printf ("--- end of activation ---\n");
}

void 
ponos_chunked_adaptive_assembly (s_ponos_space_t* space,
    s_ponos_options_t* options, CandlProgram * cprogram, 
    int n_dep, CandlDependence * deps, int space_id)
{
  s_chunked_info_t * CI;
  char logfilename[100];
  sprintf (logfilename,"ppiv-%d.log", space_id);

  printf ("[PoCC/Ponos] Starting Adaptive ILP Assembly ...\n");
  CI = ponos_chunked_compute_info (space, options, n_dep);
  CI->logfile = fopen (logfilename,"w");
  CI->cprogram = cprogram;
  CI->mdt_db_file = strdup (options->mdt_db_file);
  n_dep = CI->n_dep;

  printf ("Reading arch file...\n");
  ponos_chunked_read_arch_file (space, options, CI);

  printf ("About to fix theta bounds...\n");

  ponos_chunked_fix_theta_bounds (space, options);
  printf ("#deps = %d, #stmts = %d\n",CI->n_dep, CI->n_stmt);
  ponos_chunked_show_dependence_info (space, options);
  s_chunked_graph_t * CG;
  CG = ponos_chunked_compute_scc_level (space, options, CI, 0);
  assert (CG && "Error when computing chunked graph");

  printf ("Got to here ...\n");
  ponos_chunked_build_fgraph (space, options, CI, CG);
  printf ("Built fgraph\n");
  CG->fgraph->logfile = CI->logfile;
  ponos_chunked_subclassify_sccs (space, options, CI, CG);

  ponos_show_fgraph (CG->fgraph);
  
  printf ("Built ugraph\n");
  ponos_chunked_read_user_fgraph (space, options, CI, CG);

  ponos_show_fgraph (CG->ugraph);

  #define PAR_PRIORITY_LOW 0
  #define PAR_PRIORITY_MEDIUM 1
  #define PAR_PRIORITY_HIGH  2

  int par_priority = 0;
  if (CI->archinfo.n_cores < 8)
    par_priority = PAR_PRIORITY_LOW;
  else if (CI->archinfo.n_cores < 20)
    par_priority = PAR_PRIORITY_MEDIUM;
  else
    par_priority = PAR_PRIORITY_HIGH;


  s_fgraph_t * default_fgraph = CG->fgraph;
  CG->fgraph = CG->ugraph;

  int dounroll[3] = {0,0,0};
  s_fgraph_t * fgraph = CG->fgraph;
  int ii;
  CI->unroll = 1; 
  for (ii = 0; ii < fgraph->n_nodes; ii++)
  {
    printf ("Computing objectives for partition %d\n", ii);
    ponos_chunked_show_nodetype (fgraph->nodes[ii]);
    int jj;
    int nodetype = fgraph->nodes[ii].nodetype;
    int objectives[PONOS_LAST_PERFIDIOM+1];
    int objpos[PONOS_LAST_PERFIDIOM+1];
    int filter[CI->n_stmt];
    if (nodetype != FNODE_TYPE_SET)
      CI->unroll = 0;
    // Select statements from the current cluster
    ponos_perfidiom_user_filter     (space, options, CI, CG, ii, filter);
    // Select the performance objectives
    fprintf (CI->logfile, "Selecting objectives...\n");
    //ponos_perfidiom_select     (space, options, CI, CG, ii, objectives);
    adaptive_schedule (CI->signatures, n_dep, objpos, filter, ii, par_priority);
    translate_idiom_position_to_code (objpos, objectives);
    // Add the objectives to the ILP
    fprintf (CI->logfile, "Embedding objectives...\n");
    ponos_perfidiom_embed      (space, options, CI, CG, ii, objectives, filter);
  }

  CG->fgraph = default_fgraph;

  write_arch_file_for_unrolling (CI);

  fclose (CI->logfile);

  free (CI->mdt_db_file);

  ponos_chunked_graph_free (CG);
  ponos_chunked_free_info (CI);
}
