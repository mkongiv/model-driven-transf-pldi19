/*
 * igeneric.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012-2018 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Authors:
 * Martin Kong <martin.richard.kong@gmail.com>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>
#include <ponos/objectives.h>
#include <ponos/codelet.h>
#include <ponos/chunked.h>

#include <time.h>
#include <sys/time.h>


void 
ponos_chunked_rebound_theta_iter (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int nstmt;
  scoplib_statement_p stmt;

  // Rebound all theta iter coefficients between 0 and 2 to reduce the space 
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++)
  {
    int* ids;
    ids = ponos_space_get_coefs_stmt (space, stmt, PONOS_VAR_THETA_ITER);
    int ii;
    for (ii = 0; ids[ii] != -1; ii++)
    {
      ponos_codelet_create_ge_cst (space, ids[ii], -1, -2);
      ponos_codelet_create_ge_cst (space, ids[ii], 1, 0);

    }
    XFREE (ids);
  }

}


void 
ponos_chunked_auto_satisfy_inter_stmt_dependences (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo, 
    s_chunked_graph_t * CG)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int ii;
  int jj;
  int * ids;

  if (CG->n_scc != cinfo->n_stmt)
    return;

  for (jj = 0; jj < space->num_sched_dim; jj++)
  {
    if (jj % 2 == 1)
      continue;
    ids = ponos_space_get_coefs_dim (space, jj, PONOS_VAR_DELTA);
    int bound = (jj == 0 ? 1 : 0);
    for (ii = 0; ids && ids[ii] != -1; ii++)
    {
      CandlDependence * dep;
      int varid = ids[ii];
      dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
      if (dep->source != dep->target)   
      {
        ponos_codelet_create_ge_cst (space, ids[ii], -1, -bound);
        ponos_codelet_create_ge_cst (space, ids[ii], 1, bound);
      }
    }
    XFREE (ids);
  }
}


/*
 * Guarantee that each dependence is satisfied at a single schedule level.
 */
void 
ponos_chunked_satisfy_dependence_once (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI,
    s_chunked_graph_t * CG, int * filter)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int ii;
  int dd;
  int * ids = collect_delta_ids_from_cluster (space, CI, -1, filter);
  for (ii = 0; ids[ii] != -1; ii++);
  int nsd = space->num_sched_dim;
  int ndep = ii / nsd;

  int locids[nsd+1];
  locids[nsd] = -1;
  int ww[nsd+1];
  for (ii = 0; ii < nsd; ii++)
    ww[ii] = 1;

  for (dd = 0; dd < ndep; dd++)
  {
    for (ii = 0; ii < nsd; ii++)
      locids[ii] = ids[ii * ndep + dd];
    locids[ii] = -1;
    //for (ii = 0; locids[ii] != -1; ii++)
    //  printf ("Delta %d : %s\n", locids[ii], space->vars[locids[ii]]->name);

    //ponos_space_create_weighted_summation (space, -1, 0, locids, ww,
    //    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, -1);
    ponos_space_create_summation (space, -1, locids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);
  }
  XFREE (ids);
}



/*
 * This function sets some obvious and non-impactful 
 * coefficients. In particular, it sets the outermost scalar
 * dimension to 0, the innermost scalar dimensions to their lexical
 * order, and copies the original schedule of the outermost linear
 * dimension to the output schedule.
 */
void 
ponos_chunked_set_easy_coefficients (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo,
    s_chunked_graph_t * CG)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;


  if (CG->n_scc > 1)
    return;

  int max_dim = space->num_sched_dim;
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++)
  {
    //scoplib_matrix_print (stdout, stmt->schedule);
    int n_iter = stmt->nb_iterators;

    int* ids;
    
    ids = ponos_space_get_coefs_dim_stmt (space, stmt, n_iter * 2, PONOS_VAR_THETA_CST);
    ponos_space_create_summation (space, -1, ids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, nstmt);
    XFREE (ids);

    ids = ponos_space_get_coefs_dim_stmt (space, stmt, 0, PONOS_VAR_THETA_CST);
    int n_col = stmt->schedule->NbColumns;
    ponos_space_create_summation (space, -1, ids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 
      SCOPVAL_get_si(stmt->schedule->p[0][n_col-1]));
    XFREE (ids);


    ids = ponos_space_get_coefs_dim_stmt (space, stmt, 1, PONOS_VAR_THETA_ITER);
    int col;
    for (col = 1; col <= n_iter; col++)
    {
      int coef[2];
      coef[1] = -1;
      coef[0] = ids[col-1];
      int si = SCOPVAL_get_si(stmt->schedule->p[1][col]);
      //ponos_space_create_summation (space, ids[col-1], 0,
      //  PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, si); 
      ponos_codelet_create_ge_cst (space, ids[col-1], -1, -si);
      ponos_codelet_create_ge_cst (space, ids[col-1], 1, si);
      printf ("Setting linear coefficient of %s to %d\n",space->vars[ids[col-1]]->name,si);
    }
    XFREE (ids);
  }
}



/*
 * Create constraints such that for a given pair of statements, we can 
 * detect if any of these statements carry a dependence at the outermost
 * linear dimension. If so, the variable we create will be inserted last:
 * \forall delta_D{R1,R2}_0 s.t. R1 = S1 or R1 = S2 or R2 = S1 or R2 = S2:
 *    DETECT_DEP_S1_S2 >= delta_D{R1,R2}
 */

int
ponos_chunked_detect_dependence_satisfaction (s_ponos_space_t* space,
    s_chunked_info_t * CI, s_chunked_graph_t * CG, 
    int * delta_ids, int stmt1_id, int stmt2_id)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return -1;

  int * ids = XMALLOC (int, CI->n_dep + 1);
  int ii;
  int kk;
  for (ii = 0, kk = 0; delta_ids[ii] != -1; ii++)
  {
    int var_id = delta_ids[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[var_id]->scop_ptr);
    int src_id = dep->source->label;
    int dst_id = dep->target->label;
    if (src_id == stmt1_id || src_id == stmt2_id ||
        dst_id == stmt1_id || dst_id == stmt2_id)
      ids[kk++] = var_id;
  }
  ids[kk] = -1;
  
  int var_pos = -1;
  if (kk > 0)
  {
    printf ("Creating dependence detection at linear level\n");
    char buffer[32]; 
    sprintf (buffer, "DEP_DETECT_S%d_S%d", stmt1_id, stmt2_id);
    s_ponos_var_t* optvar =
      ponos_space_var_create (buffer, PONOS_VAR_BIN_USERDEF, 0, 0, 0, NULL);
    ponos_space_insert_variable_last (space, optvar);
    var_pos = space->num_vars - 1;

    for (ii = 0; ids[ii] != -1; ii++)
    {
      int one_id[2];
      one_id[0] = ids[ii];
      one_id[1] = -1;
      ponos_space_create_summation (space, var_pos, one_id,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

      ponos_codelet_create_ge_cst (space, var_pos, -1, -1);
      ponos_codelet_create_ge_cst (space, var_pos, 1, 0);
    }
  }

  XFREE (ids);
  return var_pos;
}


/*
 * Set the values for the THETA_CST variables. Otherwise we get quite 
 * a few 0/0 in the solutions.
 */
void
ponos_chunked_fix_theta_bounds (s_ponos_space_t* space,
    s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int* ids = ponos_space_get_coefs (space, PONOS_VAR_THETA);
  int ii;
  for (ii = 0; ids[ii] != -1; ii++)
  {
    s_ponos_var_t * v = space->vars[ids[ii]];
    int ub = options->schedule_bound;
    ponos_codelet_create_ge_cst (space, ids[ii], -1, -ub);
    ponos_codelet_create_ge_cst (space, ids[ii], 1, 0);
  }
  XFREE (ids);

  int nstmt;
  scoplib_statement_p stmt;
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  // Set the THETA_CST coefficients (scalar dimensions) to the range [0..#2*STMT]
  for (ii = 0; ii < space->num_sched_dim; ii++)
    if (ii % 2 == 0)
  {
    int* ids = ponos_space_get_coefs_dim (space, ii, PONOS_VAR_THETA_CST);
    int jj;
    for (jj = 0; ids[jj] != -1; jj++)
    {
      ponos_codelet_create_ge_cst (space, ids[jj], -1, -2*nstmt);
      ponos_codelet_create_ge_cst (space, ids[jj], 1, 0);
    }
    XFREE (ids);
  }

}


void
ponos_chunked_fix_theta_skew (s_ponos_space_t* space,
    s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int* ids = ponos_space_get_coefs (space, PONOS_VAR_THETA_ITER);
  int ii;
  for (ii = 0; ids[ii] != -1; ii++)
  {
    s_ponos_var_t * v = space->vars[ids[ii]];
    int ub = options->schedule_bound;
    ponos_codelet_create_ge_cst (space, ids[ii], -1, -ub);
    ponos_codelet_create_ge_cst (space, ids[ii], 1, 0);
  }
  XFREE (ids);

}



void
ponos_chunked_force_skewing_factors (s_ponos_space_t* space,
    s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int ii;
  for (ii = 0; ii < 2; ii++)
  {
    int* ids = ponos_space_get_coefs_dim (space, 2*ii + 1,  PONOS_VAR_THETA_ITER);
    int jj;
    int skew = 2;
    for (jj = 0; ids[jj] != -1; jj++, skew--)
    {
      printf ("Seeting variable %s to range [%d,%d]\n",space->vars[ids[jj]]->name, 0, 0);
      ponos_chunked_set_theta_bounds (space, options, ids[jj], --skew, -skew);
    }
    XFREE (ids);
  }
}


/**
 * Returns a -1-terminated array of variable positions in the space,
 * that match a variable type for a given statement.
 *
 */
int*
ponos_space_get_coefs_stmt (s_ponos_space_t* space,
    scoplib_statement_p stm, int coef_type)
{
  if (space == NULL || space->vars == NULL)
    return NULL;
  int coefs[space->num_vars + 1];
  int pos = 0;
  int i;

  for (i = 0; i < space->num_vars; ++i)
  {
    if (((space->vars[i]->type & coef_type) != 0) &&
        space->vars[i]->scop_ptr == stm)
      coefs[pos++] = i;
  }

  int* ret = XMALLOC(int, pos + 1);
  for (i = 0; i < pos; ++i)
    ret[i] = coefs[i];
  ret[i] = -1;

  return ret;
}

void
ponos_space_create_summation_with_equality_cst (s_ponos_space_t* space,
    int var, int* other_vars,
    int mode,
    int sum_type,
    int val)
{
  if (! space || !space->vars || !other_vars)
    return;

  // 1. Count the max. id.
  int max_id = var;
  int i;
  for (i = 0; other_vars[i] != -1; ++i)
    if (other_vars[i] > max_id)
      max_id = other_vars[i];
  if (max_id == -1)
    return;

  // 2. Create the constraint.
  s_fm_vector_t* v = fm_vector_alloc (max_id + 3);
  z_type_t one; Z_INIT(one); Z_ASSIGN_SI(one, 1);
  z_type_t mone; Z_INIT(mone); Z_ASSIGN_SI(mone, -1);
  z_type_t cst; Z_INIT(cst); Z_ASSIGN_SI(cst, 0);
  z_type_t zval; Z_INIT(zval); Z_ASSIGN_SI(zval, val);

  fm_vector_set_eq (v);
  fm_vector_assign_int_idx (v, mone, var + 1);
  for (i = 0; other_vars[i] != -1; ++i)
    fm_vector_assign_int_idx (v, one, other_vars[i] + 1);
  fm_vector_assign_int_idx (v, zval, max_id + 2);

  fm_solution_add_unique_line_at (space->space, v, max_id + 1);

  // Be clean.
  Z_CLEAR(one);
  Z_CLEAR(mone);
  Z_CLEAR(cst);
  Z_CLEAR(zval);
}


void
ponos_codelet_create_ge_cst (s_ponos_space_t* space, int var1, int val1, int cst)
{
  if (! space || !space->vars )
    return;
  
  // 1. Count the max. id.
  int max_id = var1;

  // 2. Create the constraint.
  s_fm_vector_t* v = fm_vector_alloc (max_id + 3);

  // 3. Fill it. Assume var != max_id.
  fm_vector_set_ineq (v);

  z_type_t one; Z_INIT(one); Z_ASSIGN_SI(one, val1);

  fm_vector_assign_int_idx (v, one, var1 + 1);

  z_type_t zcst; Z_INIT(zcst); Z_ASSIGN_SI(zcst, -cst);
  fm_vector_assign_int_idx (v, zcst, max_id + 2);

  // 4. Insert.
  fm_solution_add_line_at (space->space, v, max_id + 1);

  // Be clean.
  Z_CLEAR(one);
  Z_CLEAR(zcst);
}



void
ponos_chunked_set_theta_bounds (s_ponos_space_t* space,
    s_ponos_options_t* options, int idx, int lb, int ub)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;
  if (idx < 0)
    return;
  
  ponos_codelet_create_ge_cst (space, idx, -1, -lb);
  ponos_codelet_create_ge_cst (space, idx, 1, ub);
}



void
ponos_chunked_space_bulk_var_creation (s_ponos_space_t* space,
    s_ponos_options_t* options, const char * prefix, int n_var)
{
  int ii;
  s_ponos_var_t ** AA;
  AA = XMALLOC (s_ponos_var_t*, n_var + 1);
  for (ii = 0; ii < n_var; ii++)
  {
    char buffer[32]; 
    sprintf (buffer, "%s%d",(char*)(prefix),ii);
    AA[ii] =
      ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, ii, 0, 0, NULL);
  }
  AA[ii] = NULL;
  ponos_space_bulk_variable_insertion_at_start (space, AA, n_var);
  XFREE (AA);
}


int *
collect_psi_ids_from_cluster (s_ponos_space_t* space,
  s_chunked_info_t * CI, int level, int * filter)
{
  int idx;
  int * psi_ids;
  if (level == -1)
    psi_ids = ponos_space_get_coefs (space, PONOS_VAR_PSI);
  else
    psi_ids = ponos_space_get_coefs_dim (space, level, PONOS_VAR_PSI);
  if (!filter)
    return psi_ids;
  for (idx = 0; filter && psi_ids && psi_ids[idx] != -1; idx++);
  int n_psi = idx;
  int * ids = XMALLOC (int, n_psi + 1);
  int count = 0;
  for (idx = 0; filter && psi_ids && psi_ids[idx] != -1; idx++)
  {
    s_ponos_var_t * psi_var = space->vars[psi_ids[idx]];
    //if (level > -1 && psi_var->dim != level)
    //  continue;
    scoplib_statement_p stmt = ((scoplib_statement_p)(psi_var->scop_ptr));
    int ss;
    int found = 0;
    for (ss = 0; ss < CI->n_stmt; ss++)
      if (CI->SA[ss] == stmt)
      {
        found = 1;
        break;
      }
    //assert (ss < CI->n_stmt && found);
    if (!filter[ss])
      continue;
    ids[count++] = psi_ids[idx];
  }
  ids[count] = -1;
  //for (idx = 0; filter && ids && ids[idx] != -1; idx++);
  //printf ("Number of collected psi variables: %d\n",idx);
  XFREE (psi_ids);
  return ids;
}


int *
collect_rho_ids_from_cluster (s_ponos_space_t* space,
  s_chunked_info_t * CI, int level, int * filter)
{
  int idx;
  int * rho_ids;
  if (level == -1)
    rho_ids = ponos_space_get_coefs (space, PONOS_VAR_RHO);
  else
    rho_ids = ponos_space_get_coefs_dim (space, level, PONOS_VAR_RHO);
  if (!filter)
    return rho_ids;
  for (idx = 0; filter && rho_ids && rho_ids[idx] != -1; idx++);
  int nrho = idx;
  int * ids = XMALLOC (int, nrho + 1);
  int count = 0;
  for (idx = 0; filter && rho_ids && rho_ids[idx] != -1; idx++)
  {
    s_ponos_var_t * rho_var = space->vars[rho_ids[idx]];
    CandlDependence* dep = ((CandlDependence*)(rho_var->scop_ptr));
    if (!filter[dep->source->label] || !filter[dep->target->label])
      continue;
    ids[count++] = rho_ids[idx];
  }
  ids[count] = -1;
  XFREE (rho_ids);
  return ids;
}

int *
collect_delta_ids_from_cluster (s_ponos_space_t* space,
  s_chunked_info_t * CI, int level, int * filter)
{
  int idx;
  int * delta_ids;
  if (level == -1)
    delta_ids = ponos_space_get_coefs (space, PONOS_VAR_DELTA);
  else
    delta_ids = ponos_space_get_coefs_dim (space, level, PONOS_VAR_DELTA);
  if (!filter)
    return delta_ids;
  for (idx = 0; filter && delta_ids && delta_ids[idx] != -1; idx++);
  int ndep = idx;
  int * ids = XMALLOC (int, ndep + 1);
  int count = 0;
  for (idx = 0; filter && delta_ids && delta_ids[idx] != -1; idx++)
  {
    s_ponos_var_t * delta_var = space->vars[delta_ids[idx]];
    CandlDependence* dep = ((CandlDependence*)(delta_var->scop_ptr));
    if (!filter[dep->source->label] || !filter[dep->target->label])
      continue;
    ids[count++] = delta_ids[idx];
  }
  ids[count] = -1;
  XFREE (delta_ids);
  return ids;
}


int *
collect_theta_ids_from_cluster (s_ponos_space_t* space,
  s_chunked_info_t * CI, int level, int * filter, int varmask)
{
  int idx;
  int * theta_ids;
  if (level == -1) // all levels
    theta_ids = ponos_space_get_coefs (space, varmask);
  else
    theta_ids = ponos_space_get_coefs_dim (space, level, varmask);
  if (!filter)
    return theta_ids;
  for (idx = 0; filter && theta_ids[idx] != -1; idx++);
  int ntheta = idx;
  int * ids = XMALLOC (int, ntheta + 1);
  int count = 0;
  for (idx = 0; filter && theta_ids[idx] != -1; idx++)
  {
    s_ponos_var_t * pvar = space->vars[theta_ids[idx]];
    scoplib_statement_p stmt = ((scoplib_statement_p)(pvar->scop_ptr));
    assert (stmt);
    int ii;
    int found = 0;
    for (ii = 0 ; ii < CI->n_stmt && !found; ii++)
    {
      if (stmt == CI->SA[ii])
      {
        found = 1;
        break;
      }
    }
    assert (found);
    int stmt_id = ii;
    if (!filter[stmt_id])
      continue;
    ids[count++] = theta_ids[idx];
  }
  ids[count] = -1;
  XFREE (theta_ids);
  return ids;
}


/**
 *
 * Creates the constraint:
 * weight1 x var1 + weight2 x var2 - cst \ge 0
 * Warning: This routines always sums the weights, i.e, for substracting, the weights
 * must be negative
 */
void
ponos_codelet_create_weighted_ge(s_ponos_space_t* space,
			      int var1, int var2, int weight1, int weight2, int cst)
{
  if (! space || !space->vars )
    return;
  
  // 1. Count the max. id.
  int max_id = (var1>=var2?var1:var2);

  // 2. Create the constraint.
  s_fm_vector_t* v = fm_vector_alloc (max_id + 3);

  // 3. Fill it. Assume var != max_id.
  fm_vector_set_ineq (v);

  z_type_t z_w1; Z_INIT(z_w1); Z_ASSIGN_SI(z_w1, weight1);
  z_type_t z_w2; Z_INIT(z_w2); Z_ASSIGN_SI(z_w2, weight2);

  fm_vector_assign_int_idx (v, z_w1, var1 + 1);
  fm_vector_assign_int_idx (v, z_w2, var2 + 1);

  z_type_t zcst; Z_INIT(zcst); Z_ASSIGN_SI(zcst, -cst);
  fm_vector_assign_int_idx (v, zcst, max_id + 2);

  // 4. Insert.
  fm_solution_add_line_at (space->space, v, max_id + 1);

  // Be clean.
  Z_CLEAR(z_w1);
  Z_CLEAR(z_w2);
  Z_CLEAR(zcst);
}

s_ponos_var_t **
ponos_space_vars_dup (s_ponos_space_t * space)
{
  s_ponos_var_t ** ret;
  ret = XMALLOC (s_ponos_var_t*, space->num_vars+1);
  int ii;
  for (ii = 0; ii < space->num_vars; ii++)
  {
    ret[ii] = XMALLOC (s_ponos_var_t, 1);
    //memcpy (ret[ii], space->vars[ii], sizeof(s_ponos_var_t));
    *ret[ii] = *space->vars[ii];
    ret[ii]->name = strdup (space->vars[ii]->name);
    ret[ii]->usr = space->vars[ii]->usr;
    ret[ii]->scop_ptr = space->vars[ii]->scop_ptr;
  }
  ret[ii] = NULL;
  return ret;
}

void ponos_space_vars_free (s_ponos_space_t * space)
{
  int ii;
  for (ii = 0; ii < space->num_vars; ii++)
    ponos_space_var_free (space->vars[ii]);
  XFREE (space->vars);
}

s_ponos_space_t *
ponos_space_clone (s_ponos_space_t* space)
{
  s_ponos_space_t * ret;
  ret = ponos_space_malloc ();
  //memcpy (ret, space, sizeof(s_ponos_space_t));
  *ret = *space;
  ret->vars = ponos_space_vars_dup (space);
  ret->space = fm_solution_dup (space->space);
  ret->scop = space->scop;
  printf ("Cloned space has %d vars\n", ret->num_vars);
  return ret;
}

