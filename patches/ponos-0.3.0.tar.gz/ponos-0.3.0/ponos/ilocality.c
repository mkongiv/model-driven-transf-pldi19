/*
 * ilocality.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012-2018 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Authors:
 * Martin Kong <martin.richard.kong@gmail.com>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>
#include <ponos/objectives.h>
#include <ponos/codelet.h>
#include <ponos/chunked.h>

#include <time.h>
#include <sys/time.h>
#include "iutil.c"

/*
 * This function sets some obvious and non-impactful 
 * coefficients. In particular, it sets the outermost scalar
 * dimension to 0, the innermost scalar dimensions to their lexical
 * order, and copies the original schedule of the outermost linear
 * dimension to the output schedule.
 */
void 
ponos_chunked_big_split (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo, int split_level)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int ii, jj;
  int nstmt;
  scoplib_statement_p stmt;
  int n_stmt = cinfo->n_stmt;
  int half = n_stmt / 2;

  int* ids;
  ids = ponos_space_get_coefs_dim(space, split_level, PONOS_VAR_THETA_CST);
  int max_dim = space->num_sched_dim;
  for (ii = 0; ii < half; ii++)
    for (jj = half; jj < n_stmt; jj++)
  {
    int ID[3];
    int WW[3];
    ID[0] = ids[ii];
    ID[1] = ids[jj];
    ID[2] = -1;
    WW[0] = -1;
    WW[1] = 1;

    ponos_space_create_weighted_summation (space, -1, 0, ID, WW,
      PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
  }
  XFREE (ids);
}


/*
 * Collect the THETA_CST for each scalar dimension, and minimize their sum
 * Insert the sum variables in leading position.
 * \forall k in 0..d-1: min \sum theta_k
 */
void 
ponos_chunked_maximize_fusion (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;

  //for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);
  nstmt = cinfo->n_stmt;

  int max_dim = space->num_sched_dim;

  // Only attempt to fuse from the last but one scalar dimension outwards,
  // (towards the first scalar dimension)
  for (i = max_dim - 3; i >= 0; i -= 2)
  {
    char buffer[32]; 
    s_ponos_var_t* optvar;
    sprintf (buffer, "OPT_SUM_THETA_CST_%d",i);
    optvar = ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, i, 0, 0, NULL);
    ponos_space_insert_variable_first (space, optvar);

    int* ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_THETA_CST);
    ponos_space_create_summation (space, 0, ids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
    XFREE (ids);
  }
}



void
ponos_chunked_force_outer_fusion (s_ponos_space_t* space,
    s_ponos_options_t* options)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int ii;
  for (ii = 0; ii < 2; ii++)
  {
    int* ids = ponos_space_get_coefs_dim (space, ii*2, PONOS_VAR_THETA_CST);
    int jj;
    for (jj = 0; ids[jj] != -1; jj++)
    {
      //fprintf (CI->logfile, "Seeting variable %s to range [%d,%d]\n",space->vars[ids[jj]]->name, 0, 0);
      ponos_chunked_set_theta_bounds (space, options, ids[jj], 0, 0);
    }
    XFREE (ids);
  }
}


void 
ponos_chunked_full_distribution (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo, 
    s_chunked_graph_t * CG)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int ii;
  int nstmt;
  scoplib_statement_p stmt;

  if (CG->n_scc != cinfo->n_stmt)
    return;

  int max_dim = space->num_sched_dim;
  int* ids;
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++)
  {
    ids = ponos_space_get_coefs_dim_stmt (space, stmt, 0, PONOS_VAR_THETA_CST);
    ponos_space_create_summation (space, -1, ids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, nstmt);
    XFREE (ids);
  }
}



void 
ponos_chunked_constraints_linear_indep_desc (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  int * ids;
  int * jds;
  int n_iter = (space->num_sched_dim - 1) / 2;
  int weights[2 * n_iter];
  int all_ids[2 * n_iter + 1];
  all_ids[2 * n_iter] = -1;

  int prime[10];
  prime[0] = 0;
  prime[1] = 0;
  prime[2] = 0;
  prime[3] = 0;
  prime[4] = 0;
  int bigM[10][10];
  bigM[0][0] = 1;
  bigM[0][1] = 1;
  bigM[0][2] = 1;
  bigM[0][3] = 1;

  bigM[1][0] = 1;
  bigM[1][1] = 1;
  bigM[1][2] = 1;
  bigM[1][3] = 1;

  bigM[2][0] = 1;
  bigM[2][1] = 1;
  bigM[2][2] = 1;
  bigM[2][3] = 1;

  bigM[3][0] = 1;
  bigM[3][1] = 1;
  bigM[3][2] = 1;
  bigM[3][3] = 1;

  int * xds[nstmt][n_iter];
  for (stmt=space->scop->statement, i = 0; stmt; stmt = stmt->next, i++)
    for (j = 1; j < space->num_sched_dim; j+=2)
      xds[i][j/2] = ponos_space_get_coefs_dim_stmt (space, 
        stmt, j, PONOS_VAR_THETA_ITER);
  
  int l,k;
  for (i = 0; i < nstmt; i++)
  {
    for (j = 1; j < n_iter; j++)
    {

      k = 0;
      int sign;
      sign = -1;
      for (l = 0; xds[i][j][l] != -1; l++)
        if (xds[i][j][l])
      {
        all_ids[k] = xds[i][j][l];
        weights[k] = sign * bigM[j][l];
        k++;
      }

      for (l = 0; xds[i][j-1][l] != -1; l++)
        if (xds[i][j-1][l])
      {
        all_ids[k] = xds[i][j-1][l];
        weights[k] = - sign * bigM[j-1][l];
        k++;
      }

      all_ids[k] = -1;

      ponos_space_create_weighted_summation (space, -1, 0, all_ids, weights,
        PONOS_CONSTRAINT_GREATER, PONOS_OBJECTIVE_MINIMIZE, prime[j-1]); 
    }
    for (l = 1; l < n_iter; l++)
    {

      k = 0;
      int sign;
      sign = - 1;
      for (j = 0; j < n_iter; j++)
        if (xds[i][j][l])
      {
        all_ids[k] = xds[i][j][l];
        weights[k] = sign * bigM[j][l];
        k++;
      }

      for (j = 0; j < n_iter; j++)
        if (xds[i][j][l-1])
      {
        all_ids[k] = xds[i][j][l-1];
        weights[k] = - sign * bigM[j][l-1];
        k++;
      }

      all_ids[k] = -1;

      ponos_space_create_weighted_summation (space, -1, 0, all_ids, weights,
        PONOS_CONSTRAINT_GREATER, PONOS_OBJECTIVE_MINIMIZE, prime[l-1]); 
    }
    //for (l = n_iter - 1; l < n_iter; l++)
    l = n_iter - 1;
    {
      k = 0;
      int sign;
      sign = 1;
      all_ids[1] = -1;
      for (j = 0; j < n_iter; j++)
        if (xds[i][j][l])
      {
        all_ids[k] = xds[i][j][l];
        weights[k] = sign * bigM[j][l];
        if (j < n_iter - 1)
          ponos_space_create_weighted_summation (space, -1, 0, all_ids, weights,
            PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE, 0);
        else
          ponos_space_create_weighted_summation (space, -1, 0, all_ids, weights,
            PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MAXIMIZE, 1);
      }
    }
  }

  for (i = 0; i < nstmt; i++)
    for (j = 0; j < n_iter; j++)
      XFREE (xds[i][j]);
}



void 
ponos_chunked_scc_separation_constraints (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, 
    s_chunked_graph_t * CG)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int n_scc = CG->n_scc;
  int sccg[n_scc][n_scc];
  int ii,jj;
  int n_stmt = CI->n_stmt;

  for (ii = 0; ii < n_scc; ii++)
    for (jj = 0; jj < n_scc; jj++)
      sccg[ii][jj] = 0;

  for (ii = 0; ii < n_stmt; ii++)
    for (jj = 0; jj < n_stmt; jj++)
  {
    if (ii == jj)
      continue;
    int scc1 = CG->fgraph->map[ii];
    int scc2 = CG->fgraph->map[jj];
    if (scc1 == scc2)
      continue;
    sccg[scc1][scc2] = 1;
  }

 fprintf (CI->logfile, "showing scc connectivity: \n");
  for (ii = 0; ii < n_scc; ii++)
  {
    for (jj = 0; jj < n_scc; jj++)
     fprintf (CI->logfile, "%d ",sccg[ii][jj]);
   fprintf (CI->logfile, "\n");
  }

  int * theta = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_THETA_CST);
  for (ii = 0; ii < n_stmt; ii++)
    for (jj = 0; jj < n_stmt; jj++)
  {
    int scc1 = CG->fgraph->map[ii];
    int scc2 = CG->fgraph->map[jj];
    if (sccg[scc1][scc2])
    {
      int id[3];
      int WW[2];
      id[0] = theta[ii];
      id[1] = theta[jj];
      id[2] = -1;
      WW[0] = -1;
      WW[1] = 1;

      ponos_space_create_weighted_summation (space, -1, 0, id, WW,
        PONOS_CONSTRAINT_GREATER, PONOS_OBJECTIVE_MINIMIZE, 0);
    }
  }

  XFREE (theta);

}


void 
ponos_chunked_constraints_linear_indep (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  int * ids;
  int * jds;
  int n_iter = (space->num_sched_dim - 1) / 2;
  int weights[2 * n_iter];
  int all_ids[2 * n_iter + 1];
  all_ids[2 * n_iter] = -1;

  int prime[10];
  prime[0] = 2;
  prime[1] = 3;
  prime[2] = 5;
  prime[3] = 7;
  prime[4] = 11;
  int bigM[10][10];
  bigM[0][0] = 1;
  bigM[0][1] = 1;
  bigM[0][2] = 1;
  bigM[0][3] = 1;

  bigM[1][0] = 2;
  bigM[1][1] = 3;
  bigM[1][2] = 2;
  bigM[1][3] = 5;

  bigM[2][0] = 5;
  bigM[2][1] = 7;
  bigM[2][2] = 5;
  bigM[2][3] = 2;

  bigM[3][0] = 5;
  bigM[3][1] = 7;
  bigM[3][2] = 5;
  bigM[3][3] = 1;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++)
  {
    ids = ponos_space_get_coefs_dim_stmt (space, 
      stmt, 1, PONOS_VAR_THETA_ITER);

    int diff = 0;
    for (j = 3; j < space->num_sched_dim; j+=2, diff++)
    {
      jds = ponos_space_get_coefs_dim_stmt (space, 
        stmt, j, PONOS_VAR_THETA_ITER);

      for (i = 0; ids[i] != -1; i++)
      {
        all_ids[i] = ids[i];
        weights[i] = 1 * bigM[j/2][i];
      }
      int shift = i;
      for (i = 0; jds[i] != -1; i++)
      {
        all_ids[i+shift] = jds[i];
        weights[i+shift] = - 1 * bigM[j/2-1][i];
      }
      fprintf (CI->logfile, "Next entry in all ids = %d (%d) \n", i+shift, n_iter);

      ponos_space_create_weighted_summation (space, -1, 0, all_ids, weights,
        PONOS_CONSTRAINT_GREATER, PONOS_OBJECTIVE_MINIMIZE, prime[j/2]-1); 

      XFREE (ids);
      ids = jds;
    }
    XFREE (jds);
  }
}


/*
 * Create constraints so that each full-dimensional statement is mapped
 * to exactly one loop partition. This means that given the logical matrix 
 * of phi_{i,j}, if the statement is full dimensional, the column must sum
 * to 1, and 0 otherwise. Moreover, \sum phi_{i,j} must be equal to the number
 * of statements which are full dimensional.
 */
void
ponos_chunked_constraints_phi_sums (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  // Add sum constraints on phi variables:
  // 1) Each column of the phi matrix should sum to 1
  // 2) All the entries of the phi matrix should sum to S (number of statements)
  int i, j;
  int nstmt;
  scoplib_statement_p stmt;
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);
  int phi_sum_ids[nstmt+1];
  phi_sum_ids[nstmt] = -1;

  // A) Each statement must be mapped to a partition exactly once.
  //    Foreach statement s in S: \sum_i=1^{S} \phi^s_{i} = 1
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++)
  {
    int* ids = ponos_space_get_coefs_stmt (space, stmt, PONOS_VAR_PHI);

    for (i = 0; ids[i] != -1; i++);
    fprintf (CI->logfile, ">> ids arrays contains %d entries ...\n",i);

    phi_sum_ids[nstmt] = space->num_vars - 1;

    int must_map;
    if (stmt->nb_iterators == CI->max_dim)
      must_map = 1;
    else
      must_map = 0;

    ponos_space_create_summation (space, -1, ids,
        PONOS_CONSTRAINT_EQUAL,
        PONOS_OBJECTIVE_MINIMIZE,
        must_map);

    XFREE(ids);
  }

  // All statements must be mapped.
  // Sum all the phi_col_i: \sum_{s in S} phi^s = #full_dim_stmts

  int* ids = ponos_space_get_coefs (space, PONOS_VAR_PHI);

  ponos_space_create_summation (space, -1, ids,
      PONOS_CONSTRAINT_EQUAL,
      PONOS_OBJECTIVE_MINIMIZE,
      CI->n_stmt_max_dim);

  XFREE (ids);
}

/*
 * Add constraints for partition activation.
 * A partition is activated when at least one of the phi variables
 * associated to the partition becomes 1.
 * This constraints links pi_i variables to all phi_{i,j} vars.
 */
void 
ponos_chunked_activate_partitions (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  // Link pi and phi variables:
  // \forall S: pi_i >= phi^S_{i}, 0 <= i < |S|

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  for (i = 0; i < nstmt; i++)
  {
    int* pi_id = ponos_space_get_coefs_dim (space, i, PONOS_VAR_PI);
    int* phi_ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_PHI);
    //int n_pi, n_phi;
    //for (n_pi = 0; pi_id[n_pi] != -1; n_pi++);
    //for (n_phi = 0; phi_ids[n_phi] != -1; n_phi++);
    //printf ("Found %d pi indices and %d phi indices ...\n",n_pi,n_phi);
    for (j = 0; j < nstmt; j++)
      ponos_codelet_create_ge(space, pi_id[0], phi_ids[j], 0);
    XFREE(phi_ids);
    XFREE(pi_id);
  }
}


/*
 * Create the 1st objective: minimizing the number of partitions.
 * This indirectly should maximize the omega_i of each partition.
 * We create a variable pi_sum at position 'first'.
 * Then we create the constraints: pi_sum = \sum_i \pi_i
 */
void 
ponos_chunked_minimize_nbr_partitions (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  // Min { \sum_{i=0}^{S-1} \pi_{i} }

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  char buffer[32]; sprintf (buffer, "pi_sum");
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);

  // Since we are inserting 'first' the objective variable "pi_sum",
  // we have to collect the ids after inserting the new variable.
  int* ids = ponos_space_get_coefs (space,  PONOS_VAR_PI);

  ponos_space_create_summation (space, 0, ids,
				PONOS_CONSTRAINT_GREATEREQUAL,
				PONOS_OBJECTIVE_MINIMIZE,
				PONOS_UNUSED_VALUE);

  XFREE(ids);
}

/*
 * Force the beta coefficients associated to the last but one scalar
 * dimension to a particular value, depending on which phi_{i,j}
 * variable has been activated.
 */
void 
ponos_chunked_phi_fusion (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI,
    int outer)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  // Link theta^S_{2(d-1)} and phi^S variables:
  // \forall S, \forall j: \theta^S_{2(d-1)} - j . \phi^S_j >= 0

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;
  int fuse_dim;
  if (outer)
    fuse_dim = 0;
  else
    fuse_dim = 2 * (CI->max_dim - 1);
  int id[2];
  id[1] = -1;
  int weight[2];

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  for (stmt=space->scop->statement; stmt; stmt = stmt->next)
  {
    int* theta_id = ponos_space_get_coefs_dim_stmt 
      (space, stmt, fuse_dim, PONOS_VAR_THETA_CST);
    int* phi_ids = ponos_space_get_coefs_stmt (space, stmt, PONOS_VAR_PHI);
    fprintf (CI->logfile, "Creating weighted >= constraint ...\n");
    for (j = 0; j < nstmt; j++)
    {
      //ponos_codelet_create_weighted_ge (space, theta_id[0], phi_ids[j], 1, - (j+1), 0);
      id[0] = phi_ids[j];
      weight[0] = (j+1);
      ponos_space_create_weighted_summation (space, theta_id[0], 1, id, weight,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
    }
    XFREE(theta_id);
    XFREE(phi_ids);
  }
}

/*
 * Insert all \phi_{i,j} variables and set their boolean constraints
 * We have a total of S^2 phi variables (S is the number of statements 
 * in the SCoP
 */
void 
ponos_chunked_insert_phi_variables (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  int ids[nstmt*nstmt+1];
  ids[nstmt*nstmt] = -1; // array must be finalized with -1

  int k = 0;
  for (stmt=space->scop->statement, j = 0; stmt; stmt = stmt->next, j++)
    for (i = 0; i < nstmt; i++) // i is the dimension, as many as statements
  {
    char buffer[32]; sprintf (buffer, "phi_%d_%d", i,j);
    s_ponos_var_t* optvar =
      ponos_space_var_create (buffer, PONOS_VAR_PHI, i, 0, 0, stmt);
    ponos_space_insert_variable_last (space, optvar);

    ids[k] = space->num_vars - 1;

    k++;
  }
  ponos_codelet_boolean_constraints (space, options, PONOS_VAR_PHI);
}


/*
 * Insert the pi variables and set their boolean constraints.
 * pi variables are created 'last'.
 */
void 
ponos_chunked_insert_pi_variables (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  int ids[nstmt*nstmt+1];
  ids[nstmt*nstmt] = -1; // array must be finalized with -1

  int k = 0;
  for (i = 0; i < nstmt; i++) // i is the dimension, as many as statements
  {
    char buffer[32]; sprintf (buffer, "pi_%d", i);
    s_ponos_var_t* optvar =
      ponos_space_var_create (buffer, PONOS_VAR_PI, i, 0, 0, NULL);
    ponos_space_insert_variable_last (space, optvar);

    ids[k++] = space->num_vars - 1;
  }
  ponos_codelet_boolean_constraints (space, options, PONOS_VAR_PI);
}

/*
 * Sum the weights of the statements mapped to a loop partition.
 * Weights are summed to omega_i variables.
 * In addition, we create omega_i_p variables, which are linked to omega_i
 * by the constraint: omega_i + omega_i_p = K. Then, minimizing omega_i_p
 * maximizes omega_i. omega_i_p variables are inserted 'first' and omega_i
 * variables are inserted 'last'
 */
void 
ponos_chunked_omega_constraints (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI,
    s_chunked_mode_t * CM)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  int weights[nstmt];
  // Do: 
  // omega_i = \sum_{j=0}^{S-1}  W_{j} . \phi_{i,j}
  // 0 <= omega_i <= K
  // 0 <= omega_i_p <= K
  // omega_i + omega_i_p = K
  // min omega_i_p => max omega_i
  for (i = nstmt-1; i >= 0; i--)
  {
    char buffer[32]; sprintf (buffer, "omega_%d_p%s", i, CM->suffix);
    s_ponos_var_t* optvar =
      ponos_space_var_create (buffer, PONOS_VAR_OMEGA, i, 0, 0, NULL);
    ponos_space_insert_variable_first (space, optvar);

    sprintf (buffer, "omega_%d%s", i, CM->suffix);
    optvar =
      ponos_space_var_create (buffer, PONOS_VAR_OMEGA, i, 0, 0, NULL);
    ponos_space_insert_variable_last (space, optvar);

    int last_var = space->num_vars-1;

    int* ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_PHI);
    for (j = 0; j < nstmt; j++)
    {
      weights[j] = CM->W[j]; //abs(cinfo->max_loop_ref - cinfo->W_ref[j]);
      fprintf (CI->logfile, "W_j[%d] = %d\n", j, weights[j]);
    }

    ponos_space_create_weighted_summation (space, last_var, -1, ids, weights,
        PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE, 0);

    ponos_codelet_create_ge_cst (space, 0, -1, - CM->limit);
    ponos_codelet_create_ge_cst (space, 0, 1, 0);
    ponos_codelet_create_ge_cst (space, last_var, -1, - CM->limit);
    ponos_codelet_create_ge_cst (space, last_var, 1, 0);

    int jds[3];
    jds[0] = 0;
    jds[1] = last_var;
    jds[2] = -1;
    ponos_space_create_summation (space, -1, jds, PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, CM->limit);

    XFREE(ids);
  }
}

/*
 * Set the range of the outer beta coefficients.
 *
 */
void 
ponos_chunked_set_outer_beta_ranges (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, s_chunked_graph_t * CG)
{
  int n_stmt = CI->n_stmt;
  int filter[n_stmt];
  int ii;
  for (ii = 0; ii < n_stmt; ii++)
    filter[ii] = 1;

  if (CG->fgraph->n_nodes <= 1)
    return;

  int * thetas = collect_theta_ids_from_cluster (space, CI, 0, filter, PONOS_VAR_THETA_CST);

  for (ii = 0; thetas && thetas[ii] != -1; ii++)
  {
    int varid = thetas[ii];
    scoplib_statement_p stmt = space->vars[varid]->scop_ptr;
    int stmtid;
    for (stmtid = 0; CI->SA[stmtid] != stmt; stmtid++);
    assert (CI->SA[stmtid] == stmt && "ponos/ilocality.c: Did not find scoplib statement.");
    int clusterid = CG->fgraph->map[stmtid];
    int bmin = CG->fgraph->nodes[clusterid].betamin;
    int bmax = CG->fgraph->nodes[clusterid].betamax;
    ponos_chunked_set_var_lb_ub (space, varid, 1, bmin, bmax);
    ponos_space_var_set_bounds (space->vars[varid], bmin, bmax);
  }
  XFREE (thetas);
}

/*
 * Embed constraints to separate groups of statements classified
 * as SET, SCC and STEN.
 * 
 */
void 
ponos_chunked_separate_clusters (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, s_chunked_graph_t * CG)
{
  int n_stmt = CI->n_stmt;
  int filter[n_stmt];
  int ii;
  for (ii = 0; ii < n_stmt; ii++)
    filter[ii] = 1;

  if (CG->fgraph->n_nodes <= 1)
    return;

  char buffer[100];
  sprintf (buffer,"CLUSTER_SEP_NEG");
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);

  sprintf (buffer,"CLUSTER_SEP_POS");
  optvar =
    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
  ponos_space_insert_variable_last (space, optvar);

  int negvar = 0;
  int posvar = space->num_vars - 1;

  int * deltas = collect_delta_ids_from_cluster (space, CI, 0, filter);
  int * thetas = collect_theta_ids_from_cluster (space, CI, 0, filter, PONOS_VAR_THETA_CST);

  int ids[CI->n_dep+2];
  int ZZ[CI->n_dep+2];


  int count = 0;
  for (ii = 0; deltas && deltas[ii] != -1; ii++)
  {
    int varid = deltas[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr); 

    int src_id = dep->source->label;
    int dst_id = dep->target->label;
      
    // skip dependences which are self
    if (src_id == dst_id)
      continue;

    if (CG->fgraph->map[src_id] == CG->fgraph->map[dst_id])
      continue;


    ZZ[count] = 1;
    ids[count++] = deltas[ii];

    int ids[4], WW[3];
    ids[0] = thetas[dst_id];
    ids[1] = thetas[src_id];
    ids[2] = deltas[ii];
    ids[3] = -1;
    WW[0] = 1;
    WW[1] = -1;
    WW[2] = -1;

    // beta_dst - beta_src >= delta_0
    ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
      PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
  }

  // \sum delta^k_0 >= cluster_pos
  ids[count] = -1;
  ponos_space_create_weighted_summation (space, posvar, 1, ids, ZZ,
    PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  ids[0] = negvar;
  ids[1] = posvar;
  ids[2] = -1;
  ZZ[0] = ZZ[1] = 1;
  ponos_space_create_weighted_summation (space, -1, 0, ids, ZZ, 
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE, count);
  
  ponos_chunked_set_var_lb_ub (space, negvar, 1, 0, count);
  ponos_chunked_set_var_lb_ub (space, posvar, 1, 0, count);
  ponos_space_var_set_bounds (space->vars[negvar], 0, count);
  ponos_space_var_set_bounds (space->vars[posvar], 0, count);

  XFREE (deltas);
  XFREE (thetas);
}


void 
ponos_chunked_distribute_independent_statements (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * cinfo, CandlDependence * alldeps)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;
  scoplib_statement_p stmt_src;
  scoplib_statement_p stmt_dst;
  CandlDependence* deps;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);
  int * SS[nstmt];
  for (i = 0; i < nstmt; i++) {
    SS[i] = (int*) XMALLOC(int, nstmt);
    for (j = 0; j < nstmt; j++)
      SS[i][j] = 0;
  }

  int * delta_ids;
  delta_ids = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_DELTA);
  int dd;
  for (dd = 0; delta_ids[dd] != -1; dd++)
  {
    deps = (CandlDependence*)(space->vars[delta_ids[dd]]->scop_ptr);
    int i_src;
    int j_dst;
    i_src = deps->source->label;
    j_dst = deps->target->label;
    SS[i_src][j_dst] = 1;
  }

  int num_vars = space->num_vars;

  int ids[4];
  ids[2] = -1;
  int weights[4];
  weights[0] = -1;
  weights[1] = 1;
  for (stmt_src = space->scop->statement, i = 0; i < nstmt - 1; i++, stmt_src = stmt_src->next)
    for (stmt_dst = stmt_src->next, j = i + 1; j < nstmt; j++, stmt_dst = stmt_dst->next)
      if (SS[i][j] == 0)
  {
    int * ids1 = ponos_space_get_coefs_dim_stmt (space, 
      stmt_src, 0, PONOS_VAR_THETA_CST);
    int * ids2 = ponos_space_get_coefs_dim_stmt (space, 
      stmt_dst, 0, PONOS_VAR_THETA_CST);
    ids[0] = ids1[0];
    ids[1] = ids2[0];
    ponos_space_create_weighted_summation (space, -1, 0, ids, weights,
      PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);
    XFREE (ids1);
    XFREE (ids2);
  }
}


/*
 * For every dependence and every linear dimension, if the delta variable
 * associated to this dimension is set to 1, force distribution on the
 * previous scalar dimension.
 * This only applies to non-self dependences.
 */
void 
ponos_chunked_distribute_when_linear_delta_satisfied (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);
  scoplib_statement_p array_stmt[nstmt];
  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++)
    array_stmt[nstmt] = stmt;

  int * delta_ids;
  int * theta_ids;

  delta_ids = ponos_space_get_coefs (space, PONOS_VAR_DELTA);
  theta_ids = ponos_space_get_coefs (space, PONOS_VAR_THETA_CST);

  int num_vars = space->num_vars;

  int ids[4];
  ids[3] = -1;
  int weights[4];
  weights[0] = 1;
  weights[1] = -1;
  weights[2] = -1;
  for (i = 0; delta_ids[i] != -1; i++)
  {
    int id = delta_ids[i];
    s_ponos_var_t * delta_var = space->vars[id];
    CandlDependence* dep = ((CandlDependence*)(delta_var->scop_ptr));
    // Skip self dependences and scalar dimensions
    if (dep->source != dep->target && delta_var->dim >= 0 && delta_var->dim % 2 == 1)
    //if (delta_var->dim >= 0 && delta_var->dim % 2 == 1)
    {
      int theta_src = -1;
      int theta_dst = -1;
      int delta     = id;
      int jdx;
      for (jdx = 0; 
           theta_ids[jdx] != -1 && (theta_src == -1 || theta_dst == -1); jdx++)
      {
        int tid = theta_ids[jdx];
        if (space->vars[tid]->scop_ptr == array_stmt[dep->source->label] &&
            space->vars[tid]->dim == delta_var->dim - 1 && theta_src == -1)
        {
          theta_src = tid;
        }
        if (space->vars[tid]->scop_ptr == array_stmt[dep->target->label] &&
            space->vars[tid]->dim == delta_var->dim - 1 && theta_dst == -1)
        {
          theta_dst = tid;
        }
      }
      assert (theta_dst >= 0 && theta_src >= 0);
      ids[0] = theta_dst;
      ids[1] = theta_src;
      ids[2] = delta;
      ponos_space_create_weighted_summation (space, -1, 0, ids, weights,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
    }
  }
 fprintf (CI->logfile, "Processed %d delta variables \n",i);
  XFREE (theta_ids);
  XFREE (delta_ids);
}



/*
 * Minimize the stride impact.
 * Compute a cost for each statement depending on which iterator appears
 * in the innermost loop.
 * The cost of statement is comprised of the cost of the references in it.
 *  cost(statement) = \sum_{ref} cost(ref)
 *  cost(ref) = \sum_{i=1}^{n_iter} STRIDE_PENALTY x theta_{n_iter,i}
 *
 */
void 
ponos_perfidiom_stride_optimization (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, int * filter)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  int i, j;
  int nstmt = CI->n_stmt;
  scoplib_statement_p stmt;

  // Format of matrix is: stride-0, stride-1, stride-N
  int * SS[nstmt];
  int idx;


  #define HIGH_STRIDE_PENALTY 10
  #define STRIDE_0_PENALTY 3
  #define STRIDE_1_PENALTY 1
  for (stmt=space->scop->statement, idx=0; stmt; stmt = stmt->next, idx++)
    if (filter[idx])
  {
    scoplib_matrix_p refs;
    refs = stmt->read;
    int n_iter = stmt->nb_iterators;
    if (n_iter <= 2)
      continue;
    if (n_iter < space->num_sched_dim / 2)
      continue;
    int col;
    int ITC[n_iter]; // iterator count
    SS[idx] = XMALLOC (int, n_iter);
    for (col = 0; col < n_iter; col++)
    {
      SS[idx][col] = 0;
      ITC[col] = 0;
    }
    
    // Determine the number of read references by counting the number 
    // of non-zeros on the first column of the matrix
    int row;
    int n_rows = refs->NbRows;
    int ranges[n_rows+1];
    int n_refs = 0;
    for (row = 0; row < n_rows; row++)
      if (SCOPVAL_pos_p(refs->p[row][0]))
    {
      ranges[n_refs++] = row;
    }
    ranges[n_refs] = row;
    for (col = 1; col <= n_iter; col++)
    {
      int ref_id;
      for (ref_id = 0; ref_id < n_refs; ref_id++)
      {
        int found = 0;
        for (row = ranges[ref_id]; row < ranges[ref_id+1]; row++)
          if (SCOPVAL_notzero_p(refs->p[row][col]))
        {
          found = 1;
          ITC[col-1] ++;
          if (row == ranges[ref_id+1] - 1)
            SS[idx][col-1] += STRIDE_1_PENALTY;
          else
            SS[idx][col-1] += HIGH_STRIDE_PENALTY;
        }
        if (!found)
          SS[idx][col-1] += STRIDE_0_PENALTY;
      }
    }

    refs = stmt->write;
    for (col = 1; col <= n_iter; col++)
    {
      int found = 0;
      for (row = 0; row < refs->NbRows; row++)
        if (SCOPVAL_notzero_p(refs->p[row][col]))
      {
        found = 1;
        ITC[col-1] ++;
        if (row == refs->NbRows - 1)
          SS[idx][col-1] += STRIDE_1_PENALTY * 2;
        else
          SS[idx][col-1] += HIGH_STRIDE_PENALTY * 2;
      }
      if (!found)
        SS[idx][col-1] += STRIDE_0_PENALTY * 2;
    }

   fprintf (CI->logfile, "Showing cost matrix for statement %d ...\n",idx);
    for (col = 0; col < n_iter; col++)
    {
     fprintf (CI->logfile, "%d ",SS[idx][col]);
    }
   fprintf (CI->logfile, "\n");

    int * theta_ids = XMALLOC (int, n_iter * n_iter + 1);
    theta_ids[n_iter * n_iter] = -1;
    int * weights =  XMALLOC (int, n_iter * n_iter);
    int jdx = 0;
    for (jdx = 0; jdx < n_iter * n_iter; jdx++)
      weights[jdx] = 0;
    jdx = 0;
    int sum_iter = 0;
    for (col = 0; col < n_iter; col++)
    {
     fprintf (CI->logfile, "Statement %d, iterator %d = %d appearances\n",idx,col,ITC[col]);
      sum_iter += ITC[col];
    }
   fprintf (CI->logfile, "\n");

    char buffer[100]; 
    s_ponos_var_t* optvar;

    // Create the stride var
    sprintf (buffer, "STRIDE_S%d",idx);
    optvar =
      ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, idx, 2 * n_iter - 1, 0, stmt);
    ponos_space_insert_variable_first (space, optvar);
    //printf ("Creating stride var %s, with %d iterators \n", buffer, n_iter);

    // Create a variable for minimizing the sum of theta coefficients for
    // a given statement
    sprintf (buffer, "SUM_THETA_S%d",idx);
    optvar =
      ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, idx, 0, 0, stmt);
    ponos_space_insert_variable_first (space, optvar);

    
    int localub = 0;
    for (row = space->num_sched_dim - 2; row >= 1; row -= 2)
    {
      int * ids = ponos_space_get_coefs_dim_stmt (
        space, stmt, row, PONOS_VAR_THETA_ITER);

      if (row == n_iter * 2 - 1) {
        for (int xy = 0; ids && ids[xy] != -1; xy++)
          localub += SS[idx][xy];
        ponos_space_create_weighted_summation (space, 1, 1, ids, SS[idx],
          PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
        ponos_space_var_set_bounds (space->vars[1], 0, localub);
      }
      if (row <= n_iter * 2 - 1) {
        int kdx;
        for (kdx = 0; ids[kdx] != -1; kdx++, jdx++)
        {
          theta_ids[jdx] = ids[kdx];
          weights[jdx] = ITC[kdx];
        }
        if (kdx != n_iter)
        {
         fprintf (CI->logfile, "Found %d THETA_ITER instead of %d\n",kdx,n_iter);
          assert (kdx == n_iter && "Number of theta variables collected does not match expected value");
        }

      }

      XFREE (ids);
    }

    ponos_space_create_summation (space, 0, theta_ids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

    int sched_bound = options->schedule_bound;
    ponos_space_var_set_bounds (space->vars[0], 0, (n_refs+1) * sched_bound);
    ponos_chunked_set_var_lb_ub (space, 0, 1, 0, (n_refs+1) * sched_bound);

    ponos_space_var_set_bounds (space->vars[1], 0, localub);
    ponos_chunked_set_var_lb_ub (space, 1, 1, 0, localub);



    XFREE (theta_ids);
    XFREE (weights);
    XFREE (SS[idx]);
  }
 fprintf (CI->logfile, "Done with all stride\n");


  timer_end = rtclock ();
 fprintf (CI->logfile, "[Ponos/Chunked] Min.Strides time: %.4fs\n",timer_end - timer_start);
}



void 
ponos_perfidiom_permutability (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter)
{
  if (! space || !space->vars || !space->space || !space->scop || !filter)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  int n_stmt = CI->n_stmt;
  int cluster_size = (clusterid == SINGLECLUSTER ? 
    CI->n_stmt : CG->fgraph->nodes[clusterid].n_members);
  int ii;
  char buffer[100];

  int * rho_ids = collect_rho_ids_from_cluster (space, CI, 0, filter);
  int nrho = count_ids (rho_ids);
  XFREE (rho_ids);

  s_ponos_var_t ** frontvars;
  frontvars = XMALLOC (s_ponos_var_t *, space->num_sched_dim + 1);
  int count = 0;
  for (int ll = 0; ll < space->num_sched_dim - 1; ll++)
  //  if (ll % 2 == 1)
  {
    sprintf (buffer, "RHO_SUM_CLUSTER%d_L%d_NEG",clusterid,ll);
    frontvars[count] = ponos_space_var_create (buffer, 
      PONOS_VAR_OPT_SUM_VAR, ll, 0, 0, NULL);
    ponos_space_var_set_bounds (frontvars[count], 0, nrho);
    count ++;
  }
  frontvars[count] = NULL;
  ponos_space_bulk_variable_insertion_at_start (space, frontvars, count);
  XFREE (frontvars);
  int start_back = space->num_vars;
  for (int ll = 0; ll < space->num_sched_dim - 1; ll++)
  //  if (ll % 2 == 1)
  {
    sprintf (buffer, "RHO_SUM_CLUSTER%d_L%d_POS",clusterid,ll);
    s_ponos_var_t * posvar  = ponos_space_var_create (buffer, 
      PONOS_VAR_OPT_SUM_VAR, ll, 0, 0, NULL);
    ponos_space_var_set_bounds (posvar, 0, nrho);
    ponos_space_insert_variable_last (space, posvar);
    ponos_space_var_skip_cplex (posvar);
  }
  for (int ll = 0, count = 0; ll < space->num_sched_dim - 1; ll++)
  //  if (ll % 2 == 1)
  {
    int * rho_vars = collect_rho_ids_from_cluster (space, CI, ll, filter);
    int n_rho = count_ids (rho_vars);
    int kk;
    int * WW = XMALLOC (int, n_rho + 1);
    for (kk = 0; kk <= n_rho; kk++)
      WW[kk] = 1;

    // rho_sum_k_neg + rho_sum_k_pos = cluster_size
    int ids[3];
    ids[0] = count;
    ids[1] = start_back + count;
    ids[2] = -1;
    int ZZ[2];
    ZZ[0] = 1;
    ZZ[1] = 1;
    // sum_rho_neg + sum_rho_pos = n_rho
    ponos_space_create_weighted_summation (space, -1, 1, ids, ZZ,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, n_rho);

    if (n_rho == 0)
    {
      XFREE (rho_vars);
      ponos_space_var_set_bounds (space->vars[start_back + count], 0, 0);
      continue;
    }

    // rho_sum_k_pos <= \sum rho_k
    ponos_space_create_weighted_summation (space, start_back + count, 1, rho_vars, WW,
      PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MAXIMIZE, 0);

    XFREE (rho_vars);
    XFREE (WW);
    count++;
  }
  timer_end = rtclock ();
 fprintf (CI->logfile, "[Ponos/Chunked] Permutability maximization time: %.4fs\n",timer_end - timer_start);
}





/*
 * For all dependences, force delta_0 >= delta_1
 *
 */
void 
ponos_chunked_outer_linear_fusion (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int nstmt = CI->n_stmt;
  int ii;
  scoplib_statement_p stmt;
  int n_dep;
  int * sca_deltas = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_DELTA);
  int * lin_deltas = ponos_space_get_coefs_dim (space, 1, PONOS_VAR_DELTA);

  for (ii = 0; sca_deltas[ii] != -1; ii++)
  {
    int ids[3];
    ids[0] = lin_deltas[ii];
    ids[1] = -1;

    ponos_space_create_summation (space, sca_deltas[ii], ids, 
      PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MAXIMIZE, 0);
  }

  XFREE (sca_deltas);
  XFREE (lin_deltas);
}



/*
 * Increase the lexicographic distance between statements unrelated
 * or which have a WAR or WAW relationship.
 */
void 
ponos_perfidiom_separate_independent_statements (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  int nstmt = CI->n_stmt;
  int cluster_size;
  if (clusterid == SINGLECLUSTER)
    cluster_size = nstmt;
  else
    cluster_size = CG->fgraph->nodes[clusterid].n_members;
  int ii;
  scoplib_statement_p stmt;
  int n_dep;

  // Create a 2D array to determine the statements that can be separated.
  // At first we assume that all pairs can be separated (init with value 1).
  int flag[nstmt][nstmt];
  for (ii = 0; ii < nstmt; ii++)
  {
    int jj;
    for (jj = 0; jj < nstmt; jj++)
    {
      if (ii != jj && filter[ii] && filter[jj])
        flag[ii][jj] = 1;
      else
        flag[ii][jj] = 0;
    }
  }

  // Collect the delta variables at level 0 (outer scalar)
  //int * delta_ids = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_DELTA);
  int * delta_ids = collect_delta_ids_from_cluster (space, CI, 0, filter);
  for (ii = 0; delta_ids[ii] != -1; ii++)
  {
    // We are interested in separating statements which are not linked
    // by a RAW or RAR dependence. 
    // In other words, we only proceed to unmark RAW and RAR dependences.
    CandlDependence * dep = (CandlDependence*)(space->vars[delta_ids[ii]]->scop_ptr); 
    if (dep->type == CANDL_RAW || dep->type == CANDL_RAR)
     fprintf (CI->logfile, "Dependence %d is raw type\n",ii);
    else
     fprintf (CI->logfile, "Dependence %d is not raw type \n",ii);

    //if (dep->type != CANDL_RAW)
    //  continue;
    int is_raw = (dep->type == CANDL_RAW || dep->type == CANDL_RAR);

    // If the dependence is not of type RAW, the statements related by it
    // are good candidates for separation.
    int src_id = dep->source->label;
    int dst_id = dep->target->label;
    
    if (src_id == dst_id)
     fprintf (CI->logfile, "Dependence %d has same source and target statement (%d)\n",ii,src_id);
    else
     fprintf (CI->logfile, "Dependence %d has different source and target statement (%d,%d)\n",ii,src_id,dst_id);

    int is_self = (src_id == dst_id);

    int same_scc = (CG->fgraph->map[src_id] == CG->fgraph->map[dst_id]);

    // skip non-flow deps, self-deps and statements that must be in same SCC
    if (is_raw || is_self || same_scc)
    {
     fprintf (CI->logfile, "Cancelling entry (%d,%d)\n",src_id,dst_id);
      flag[src_id][dst_id] = 0;
      flag[dst_id][src_id] = 0;
    }
  }

 fprintf (CI->logfile, "Separation matrix: \n");
  for (ii = 0; ii < nstmt; ii++)
  {
    int jj;
    for (jj = 0; jj < nstmt; jj++)
     fprintf (CI->logfile, "%d ",flag[ii][jj]);
   fprintf (CI->logfile, "\n");
  }

  // Guarantee that the sum of outer scalars is <= \sum_{i=0 to n_stmt-1}
  {
    int * outer_theta_ids = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_THETA_CST);
    int WW[nstmt+1];
    int jj;
    for (jj = 0; jj < nstmt; jj++)
      WW[jj] = 1;
    int sum_scal = (nstmt - 1)*(nstmt)/2;
    ponos_space_create_weighted_summation (space, -1, 0, outer_theta_ids, WW,
      PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MAXIMIZE, sum_scal);

    XFREE (outer_theta_ids);
  }

  int jj;
  int count = 0;
  for (ii = 0; ii < nstmt-1; ii++)
    for (jj = ii+1; jj < nstmt; jj++)
  {
    if (flag[ii][jj] == 0)
      continue;
    char buffer[100]; 
    s_ponos_var_t* optvar;
    sprintf (buffer, "SEP_DIST_S%d_S%d_N",ii,jj);
    optvar = ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
    ponos_space_insert_variable_first (space, optvar);
    ponos_space_var_set_bounds (optvar, 0, cluster_size);
    int neg_id = 0;

    sprintf (buffer, "SEP_DIST_S%d_S%d_P",ii,jj);
    optvar = ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
    ponos_space_insert_variable_last (space, optvar);
    ponos_space_var_set_bounds (optvar, 0, cluster_size);
    int pos_id = space->num_vars - 1;

    // Theta variables are returned in the same order as the statement list!!!
    int * outer_theta_ids = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_THETA_CST);

    int ids[3];
    ids[0] = outer_theta_ids[ii];
    ids[1] = outer_theta_ids[jj];
    ids[2] = -1;

    int WW[4];
    WW[0] = -1;
    WW[1] = 1;

    // pos_sep_X_Y - theta_Y + theta_X = diff_scc_X_Y
    //ponos_space_create_weighted_summation (space, pos_id, 1, ids, WW,
    //  PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
    int same_scc = (CG->fgraph->map[ii] == CG->fgraph->map[jj]);
    ponos_space_create_weighted_summation (space, pos_id, 1, ids, WW,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, !same_scc);

    ids[0] = neg_id;
    ids[1] = pos_id;

    // Bound by the original lexical distance.
    // This forbids clustering of statements (e.g. when the non-flow 
    // dependences induce a bi-partite graph
    int dist_ub = jj - ii;

    // pos_sep_X_Y + neg_sep_X_Y = #STMT-1
    ponos_space_create_summation (space, -1, ids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, dist_ub); //nstmt-1);

    // Bound neg_sep_X_Y; lower bound is zero always
    ponos_codelet_create_ge_cst (space, neg_id, -1, -dist_ub); //-(nstmt-1));
    ponos_codelet_create_ge_cst (space, neg_id, 1, 0);
    // Bound pos_sep_X_Y; lower bound is defined by the need (or not) of
    // having both statements in the same SCC
    ponos_codelet_create_ge_cst (space, pos_id, -1, -dist_ub); //-(nstmt-1));
    ponos_codelet_create_ge_cst (space, pos_id, 1, 0); //!same_scc);
  
    count ++;
    XFREE (outer_theta_ids);
  }
  XFREE (delta_ids);

  if (count)
  {
    char buffer[32];
    sprintf (buffer, "SEP_DIST_SUM_FULL");
    s_ponos_var_t * optvar;
    optvar = ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
    ponos_space_insert_variable_first (space, optvar);
    int WW[count+1];
    int n = count * nstmt; //(nstmt*(nstmt-1))/2;
    int * ids = XMALLOC (int, n);
    int ll;
    // REMINDER: if the insertion position of the above variables is ever
    // changed, this loop has to change too!!!!
    for (ll = 0; ll < count; ll++)
      ids[ll] = ll+1;
    ids[ll] = -1;
    for (ll = 0; ll < count; ll++)
      WW[ll] = 1;

    ponos_space_create_weighted_summation (space, 0, 1, ids, WW,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

    ponos_codelet_create_ge_cst (space, 0, -1, -(n));
    ponos_codelet_create_ge_cst (space, 0, 1, 0);
    ponos_space_var_set_bounds (optvar, 0, n);


    XFREE (ids);
  }
  
  timer_end = rtclock ();
 fprintf (CI->logfile, "[Ponos/Chunked] SIS time: %.4fs\n",timer_end - timer_start);
}


/*
 * The following set of objectives guide the fusion of statements.
 * We leverage the flow dependences to minimize a weighted dependence distance.
 * For a given dependence D^{R,S} we take their beta vectors \beta^R and \beta^S
 * and built the objective:
 * depdist^{D^{R,S}} = (\beta^S - \beta^R ) . vec(pow2)
 * where vec(pow2) = [2^(d-1), 2^(d-2), ..., 2, 1], and d = #scalar dimensions.
 */
void 
ponos_perfidiom_dependence_guided_fusion (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter)
{
  if (! space || !space->vars || !space->space || !space->scop || !filter)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  int nstmt = CI->n_stmt;
  int cluster_size = (clusterid == SINGLECLUSTER ? 
    CI->n_stmt : CG->fgraph->nodes[clusterid].n_members);
  int ii;
  int n_dep;
  scoplib_statement_p * SS = CI->SA;

  int n_scc = CG->n_scc;
  int scc_fus[n_scc][n_scc];

  // Initialize a map to store which scc have already been separated
  for (ii = 0; ii < n_scc; ii++)
  {
    int jj;
    for (jj = 0; jj < n_scc; jj++)
      scc_fus[ii][jj] = 0;
  }

  int * delta_ids;
  // Collect all delta variables at level 0
  //delta_ids = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_DELTA);
  delta_ids = collect_delta_ids_from_cluster (space, CI, 0, filter);

  int * filtered_delta_ids;
  filtered_delta_ids = XMALLOC (int, CI->n_dep + 1);
  // Count the number of flow dependences
  for (ii = 0, n_dep = 0; delta_ids && delta_ids[ii] != -1; ii++)
  {
    int var_id = delta_ids[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[var_id]->scop_ptr);
    if (dep->type != CANDL_RAW)
      continue;
    int stmt_src_id = dep->source->label;
    int stmt_dst_id = dep->target->label;
    // Skip self-dependences
    if (stmt_src_id == stmt_dst_id)
      continue;
    // Must use fgraph!
    //int scc1 = CG->scc_map[stmt_src_id];
    //int scc2 = CG->scc_map[stmt_dst_id];
    int scc1 = CG->fgraph->map[stmt_src_id];
    int scc2 = CG->fgraph->map[stmt_dst_id];
    if (scc1 == scc2)
      continue;
    // skip if the statements have already been separated 
    if (scc_fus[scc1][scc2])
      continue;

    scc_fus[scc1][scc2] = 1;
    scc_fus[scc2][scc1] = 1;
    filtered_delta_ids[n_dep] = var_id;
    n_dep++;
  }
  filtered_delta_ids[n_dep] = -1;
  XFREE (delta_ids);
  delta_ids = filtered_delta_ids;

  // Create n_dep + 1 variables inserted at leading positions
  //ponos_chunked_space_bulk_var_creation (space, options, "DepDist", n_dep + 1);

  char buffer[100]; 
  s_ponos_var_t ** AA;
  AA = XMALLOC (s_ponos_var_t*, n_dep+1);
  for (ii = 0; ii < n_dep + 1; ii++)
  {
    if (ii > 0)
    {
      int var_id = delta_ids[ii-1];
      CandlDependence * dep = (CandlDependence*)(space->vars[var_id]->scop_ptr);
      int stmt_src_id = dep->source->label;
      int stmt_dst_id = dep->target->label;
      sprintf (buffer, "DEP_DIST_CLUSTER%d_DEP%d_S%d_to_S%d",clusterid,ii-1,stmt_src_id,stmt_dst_id);
    }
    else
    {
      sprintf (buffer, "SUM_DEP_DIST_CLUSTER%d",clusterid);
    }
    AA[ii] =
      ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0, 0, 0, NULL);
  }
  ponos_space_bulk_variable_insertion_at_start (space, AA, n_dep + 1);
  XFREE (AA);

  // Since we read the delta ids before the bulk insertion, we shift all
  // the delta ids before proceeding.
  for (ii = 0; delta_ids && delta_ids[ii] != -1; ii++)
    delta_ids[ii] += n_dep + 1;

  int max_dim = space->num_sched_dim / 2 + 1; // num scalar dimensions
  int * WW;
  int * ZZ;
  WW = XMALLOC (int, 2 * max_dim + 1);
  ZZ = XMALLOC (int, 2 * max_dim + 1);
  for (ii = 0; ii < max_dim; ii++)
    WW[ii] = (1 << (max_dim - ii - 1));
  for ( ; ii < 2 * max_dim; ii++)
    WW[ii] = - (1 << (2 * max_dim - ii - 1));
  // If max_dim is 3 then WW = [4,2,1,-4,-2,-1]

  // Collect all the THETA_CST ids, including linear dimensions
  int * all_theta_ids;
  //all_theta_ids = ponos_space_get_coefs (space, PONOS_VAR_THETA_CST);
  all_theta_ids = collect_theta_ids_from_cluster (space, CI, -1, filter, PONOS_VAR_THETA_CST);
  // Need to filter out the variables of the linear dimensions
  int ** theta_ids;
  theta_ids = XMALLOC (int *, nstmt);
  for (ii = 0; ii < nstmt; ii++)
    theta_ids[ii] = XMALLOC (int, max_dim + 1);
  int i_dim;
  int j_stmt;
  // Filter linear dimensions and write to theta_ids
  for (i_dim = 0; i_dim < max_dim; i_dim++)
  {
    for (j_stmt = 0; j_stmt < nstmt; j_stmt++)
      if (filter[j_stmt])
    {
      theta_ids[j_stmt][i_dim] = all_theta_ids[(i_dim*2) * nstmt + j_stmt];
    }
  }
  for (j_stmt = 0; j_stmt < nstmt; j_stmt++)
    if (filter[j_stmt])
  {
    theta_ids[j_stmt][max_dim] = -1;
  }
  XFREE (all_theta_ids);

  // coefficients will come level by level, and in each level, all statements
  int * depdist = XMALLOC (int, 2 * max_dim + 1);
  int kk;
  int chunk_ub = 0;
  for (ii = 0, kk = 1; delta_ids && delta_ids[ii] != -1; ii++)
  {
    // ii is all dependences
    // kk is only the flow dependences
    int var_id = delta_ids[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[var_id]->scop_ptr);
    // Skip non-flow dependences.
    // Don't need this condition. We already filter the dependences previously
    //if (dep->type != CANDL_RAW)
    //  continue;
    int stmt_src_id = dep->source->label;
    int stmt_dst_id = dep->target->label;
    assert (filter[stmt_src_id] && filter[stmt_dst_id]);
    // Skip self-dependences
    if (stmt_src_id == stmt_dst_id)
      continue;
    if (CG->fgraph->map[stmt_src_id] == CG->fgraph->map[stmt_dst_id])
      continue;
    assert (filter[stmt_src_id] && filter[stmt_dst_id]);
    int nb_it_src = SS[stmt_src_id]->nb_iterators;
    int nb_it_dst = SS[stmt_dst_id]->nb_iterators;
    int jj;
    int * theta_src = theta_ids[stmt_src_id];
    int * theta_dst = theta_ids[stmt_dst_id];

    int write_ref_id = SCOPVAL_get_si(SS[stmt_dst_id]->write->p[0][0]);
    int factor = (write_ref_id == dep->ref_source ? 1 : 2);
    fprintf (CI->logfile, "dep(%d,%d) = %d,%d\n",stmt_src_id,stmt_dst_id,dep->ref_source,write_ref_id);
    // Copy the ids of the dependence target to the first half of the depdist array
    // Copy the ids of the dependence source to the second half of the depdist array
    for (jj = 0; jj <= nb_it_src && jj <= nb_it_dst; jj++)
    {
      assert (jj < 2 * max_dim + 1);
      depdist[jj] = theta_dst[jj];
      WW[jj] = (1 << (max_dim - jj - 1)) * factor;
      ZZ[jj] = 1;
    }
    int offset = jj;
    for (jj = 0; jj <= nb_it_src && jj <= nb_it_dst; jj++)
    {
      assert (offset + jj < 2 * max_dim + 1);
      depdist[offset+jj] = theta_src[jj];
      WW[offset+jj] = - (1 << (max_dim - jj - 1)) * factor;
      ZZ[offset+jj] = -1;
    }
    depdist[2*offset] = -1;

    // The objective variable for individual dependences start at position 1.
    // Position 0 is reserved for the sum of all dependences

    ponos_space_create_weighted_summation (space, kk, 1, depdist, WW,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);


    // Upper bound of summation is 2^(ndim+1) * (max_scalar_value - min_scalar_value)
    int ub = (1 << max_dim + 1) * (nstmt - 1);
    ponos_codelet_create_ge_cst (space, kk, -1, -ub); 
    ponos_codelet_create_ge_cst (space, kk, 1, 0);
    ponos_space_var_set_bounds (space->vars[kk], 0, ub);
    chunk_ub += ub;
    kk++;
  }

  int * dd_ids;
  dd_ids = XMALLOC (int, n_dep + 1);
  for (ii = 0; ii < n_dep; ii++)
    dd_ids[ii] = ii + 1;
  dd_ids[n_dep] = -1;
  ponos_space_create_summation (space, 0, dd_ids, 
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  ponos_space_var_set_bounds (space->vars[0], 0, chunk_ub);

  XFREE (delta_ids);
  XFREE (WW);
  XFREE (depdist);
  XFREE (dd_ids);
  XFREE (theta_ids);

  timer_end = rtclock ();
 fprintf (CI->logfile, "[Ponos/Chunked] DGF time: %.4fs\n",timer_end - timer_start);
}
