/*
 * chunked.h: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2019 Martin Kong
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Martin Kong <martin.richard.kong@gmail.com>
 */

#ifndef PONOS_CHUNKED_H
# define PONOS_CHUNKED_H


# ifndef LINEAR_VALUE_IS_LONGLONG
#  define LINEAR_VALUE_IS_LONGLONG
# endif
# ifndef CANDL_SUPPORTS_SCOPLIB
#  define CANDL_SUPPORTS_SCOPLIB
# endif
# include <candl/program.h>
# include <candl/dependence.h>
# include <candl/options.h>
# ifndef SCOPLIB_INT_T_IS_LONGLONG
#  define SCOPLIB_INT_T_IS_LONGLONG
# endif
# include <scoplib/scop.h>
# include <ponos/space.h>


BEGIN_C_DECLS

#define SINGLECLUSTER 1000

// testing change

//#define PLDI19_MAX_STEN_PAR
//#define PLDI19_BOUND_DEP_SAT
//#define PLDI19_PRIORITIZE_LEVELS

#define PONOS_CHUNKED_LIMIT_NONE 0
#define PONOS_CHUNKED_LIMIT_REF 1
#define PONOS_CHUNKED_LIMIT_STMT 2
#define PONOS_CHUNKED_LIMIT_LAT 3


#define CHUNKED_MODE_UNKNOWN 0
#define CHUNKED_MODE_STENCIL 1
#define CHUNKED_MODE_2D_SPACE 2
#define CHUNKED_MODE_DENSE_LA 3
#define CHUNKED_MODE_HARD 4


#define DEP_CARD_0_0  0
#define DEP_CARD_1_1  1
#define DEP_CARD_1_N  2
#define DEP_CARD_N_1  4
#define DEP_CARD_N_N  8
#define DEP_CARD_ANY  15

#define LEXICON_SIZE 12

#define DEP_TYPE_NONE 0
#define DEP_TYPE_FLOW 1
#define DEP_TYPE_ANTI 2
#define DEP_TYPE_READ 4
#define DEP_TYPE_WRITE 8
#define DEP_TYPE_ANY  15

struct s_depsig {
  int id;
  int src_id;
  int dst_id;
  int dim_src;
  int dim_tgt;
  int dim_data;
  int rect_src_dom;  
  int rect_tgt_dom;  

  int has_dep;
  int self_dep; // 
  int type; // none, flow, anti, write, read
  int card; // dependence cardinality
};
typedef struct s_depsig depsig_t;

enum perfidiom { 
  PONOS_PERFIDIOM_PERM,
  PONOS_PERFIDIOM_DGF,
// coarse grained parallelism
  PONOS_PERFIDIOM_OP, 
  PONOS_PERFIDIOM_2OP,  // 2nd outer parallelism
  PONOS_PERFIDIOM_2OP_EASY,  // 2nd outer parallelism (for hard problems)
  PONOS_PERFIDIOM_OPIR, 
  PONOS_PERFIDIOM_ADA,
  PONOS_PERFIDIOM_MIC, // minimize iterator coefficient
  PONOS_PERFIDIOM_SDO, // satisfy dependence once!
  PONOS_PERFIDIOM_SMP,
  PONOS_PERFIDIOM_SPC,
  PONOS_PERFIDIOM_FDS, // Force Dependence Satisfaction
  PONOS_PERFIDIOM_SDC,
  PONOS_PERFIDIOM_NONE,
// intra-cluster locality
  PONOS_PERFIDIOM_MLP,
  PONOS_PERFIDIOM_FPP,
  PONOS_PERFIDIOM_SIS,
// fine grained parallelism
  PONOS_PERFIDIOM_SO,
  PONOS_PERFIDIOM_IP,
  PONOS_PERFIDIOM_SOIP,
  PONOS_PERFIDIOM_VSKW,
  PONOS_PERFIDIOM_SKEWPAR
};
typedef enum perfidiom e_perfidiom;
#define PONOS_FIRST_PERFIDIOM PONOS_PERFIDIOM_PERM
#define PONOS_LAST_PERFIDIOM  (PONOS_PERFIDIOM_SKEWPAR + 1)



#define get_chunked_arch_string(options) \
  (options->chunked_arch == PONOS_CHUNKED_ARCH_NONE ? "arch-none" : \
    (options->chunked_arch == PONOS_CHUNKED_ARCH_KNL ? "arch-knl" : \
      (options->chunked_arch == PONOS_CHUNKED_ARCH_SKX ? "arch-skx" : \
        (options->chunked_arch == PONOS_CHUNKED_ARCH_CNC ? "arch-cnc" : \
          (options->chunked_arch == PONOS_CHUNKED_ARCH_TILED_CNC ? "arch-ticnc" : \
            (options->chunked_arch == PONOS_CHUNKED_ARCH_PWR9 ? "arch-power9" : \
              "spec-file"))))))

struct s_chunked_arch_info
{
  int arch_id;
  int n_cores;
  int l1_size;
  int l2_size;
  int l3_size;
  int simdlen;  // in bits, so 128, 256 or 512
  int fp_precision; // 32 for floats, 64 for doubles
  int regfile_size; // physical register file size
  int rob_size; // 224 for skx
};
typedef struct s_chunked_arch_info s_chunked_arch_info_t;

struct s_chunked_ref_info
{
  int id;  // id of reference in statement
  char * name;
  int row_start; // row where the access function starts in the matrix
  int n_dim; // number of array dimensions
  int * mask; // loop dimensions used in the aray (1=appears,0=does not appear)
  int is_const; // 1 if its a scalar, 0 otherwise
  int coef[4][5]; // consider at most 4D arrays and 5 loop dimensions
  int skip;    // skip for some reason, e.g. A[i - k]
};
typedef struct s_chunked_ref_info s_chunked_ref_info_t;

struct s_chunked_statement_info
{
  int id;
  int n_ref; // number of array references in the statement
  int n_non_const_ref; // = n_ref - #scalars
  int n_dim; // number of surrounding loop dimensions
  scoplib_statement_p scop_stmt;
  s_chunked_ref_info_t * ref;
  int skip;   // skip for some reason, e.g. A[i - k]
};
typedef struct s_chunked_statement_info  s_chunked_statement_info_t;

#define CHUNKED_PREDICATE_OBJECTIVE
#ifdef CHUNKED_PREDICATE_OBJECTIVE
  #define CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,lev) \
    if (CI->obj_level >= lev)
#else
  #define CHUNKED_IF_OBJECTIVE_ABOVE_LEVEL(CI,lev) 
#endif

struct s_chunked_info
{
  int type;
  int max_fusion;
  int min_fusion;
  int max_loop_lat;
  int max_loop_stmt;
  int max_loop_ref;
  int n_stmt;
  int max_dim;
  int n_stmt_max_dim;
  int * W_stmt;
  int * W_ref;
  int * W_lat;
  const char * suffix;
  int n_dep;
  int * self_dep;  // store IDs of self-dependences 
  int n_self_dep;  // number of self dependences
  scoplib_statement_p * SA; // statement array (only manage the array, not items)
  s_chunked_arch_info_t archinfo;
  CandlProgram * cprogram;
  int unroll;
  int mode;
  int n_ref;
  #ifdef CHUNKED_PREDICATE_OBJECTIVE
  int obj_level; // 0: none --> 100 all
  #endif
  FILE * logfile;
  int space_id;
  depsig_t * signatures;
  char * mdt_db_file;
};


struct s_chunked_mode
{
  int * W;
  int limit;
  int type;
  const char * suffix;
};

typedef struct s_chunked_info s_chunked_info_t;
typedef struct s_chunked_mode s_chunked_mode_t;


#define CHUNKED_NO_DEP (0)
#define CHUNKED_HAS_DEP (1)
#define CHUNKED_WHITE (0)
#define CHUNKED_GRAY (1)
#define CHUNKED_BLACK (2)
#define CHUNKED_END (-1)
#define CHUNKED_UNDEF (-1)
#define CHUNKED_EMPTY (-2)
#define CHUNKED_NO_PRED (-1)

#define FNODE_TYPE_SCC 0
#define FNODE_TYPE_SET 1
#define FNODE_TYPE_STEN 2

struct s_fnode {
  int nodetype;  // either FNODE_TYPE_SCC or FNODE_TYPE_SET
  int n_members; // number of statements in the fnode
  int * members; // 
  int betamin;      // 
  int betamax;      // 
  int n_dep;
  int n_self_dep; // self-statement dependences
  int n_intra;    // intra-SCC/SET dependence
  int max_depth;
  float flexibility;
};
typedef struct s_fnode s_fnode_t;

struct s_fedge {
  int weight; // dimensionality of the array inducing the dependence
};
typedef struct s_fedge s_fedge_t;

struct s_fgraph {
  s_fnode_t * nodes;
  s_fedge_t * edges;
  int n_nodes;
  int n_edges;
  int * map;   // statement to node map
  int n_stmt;
  FILE * logfile;
};
typedef struct s_fgraph s_fgraph_t;



struct s_chunked_graph {
  int ** graph;
  int * status;
  int * pred;    // Predecessor
  int * loops[2]; // Start / end
  int ** xpath;
  int ** scc;    // Each scc[i] stores a set of statements
  int n_loop;
  int * scc_map; // as many entries as statements
  int n_scc;     // number of SCC
  s_fgraph_t * fgraph;  // High-Level Fusibility graph
  s_fgraph_t * ugraph;  // user-driven statement preference graph
  int time;
  int * ftime;
  int * leader;
  int curr_leader;
  int * order;
  int * size;
  int * intra; // nbr deps within same SCC
  int * self; // number of self statement deps in each SCC
  int * inter; // number of inter SCC deps
  int * bmin; //  beta min
  int * bmax; // beta max
  int * back; // has back edge
};
typedef struct s_chunked_graph s_chunked_graph_t;

// ***********************************************************************
// Performance Idioms
// Start date: January 12th 2018
// *********************************************************************

// *********************************
// Implemented in ianalysis.c
// *********************************


extern
int is_jacobi (int n_dep, int n_stmt, int n_dim);

extern
int is_stencil_statement (scoplib_statement_p stmt);

extern
int is_stencil (s_ponos_space_t* space);

extern
int chunked_get_stencil_width_statement (s_chunked_info_t *CI, int stmt_id);

extern
void
ponos_chunked_show_dependence_info (s_ponos_space_t* space,
    s_ponos_options_t* options);

extern
void ponos_chunked_free_info (s_chunked_info_t * CI);

extern
s_chunked_graph_t * 
ponos_chunked_init_graph (s_ponos_space_t * space, s_chunked_info_t * CI, int reverse_edges);

extern
s_chunked_graph_t *
ponos_chunked_compute_scc_level (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, int level);

extern
void
ponos_chunked_build_fgraph (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG);

extern
void ponos_chunked_graph_free (s_chunked_graph_t * CG);

extern
void
ponos_chunked_build_fgraph (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG);

extern
void
ponos_chunked_subclassify_sccs (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG);


extern
void
ponos_chunked_read_user_fgraph (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG);

extern
void
ponos_show_fgraph (s_fgraph_t * fgraph);


extern
s_chunked_info_t * ponos_chunked_compute_info (
  s_ponos_space_t * space, s_ponos_options_t* options, int n_dep);


extern
s_chunked_mode_t * 
ponos_chunked_mode_init (s_chunked_info_t * CI, int chunk_mode);


// *********************************
// Implemented in istencil.c
// *********************************

extern
void 
ponos_chunked_stencil_skewing_constraints (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);

extern
void 
ponos_chunked_stencil_skewing_constraints (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);

extern
void 
ponos_chunked_stencil_max_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter);


// *********************************
// Implemented in iparallelism.c
// *********************************

extern
void 
ponos_chunked_select_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);


extern
void 
ponos_perfidiom_force_dependence_at_level (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter, int level);

extern
void 
ponos_chunked_maximize_outer_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo, s_chunked_graph_t * CG,
    int n_dep, int pattern);

extern
void
ponos_perfidiom_skew_parallelism (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, 
  s_chunked_graph_t * CG, int clusterid, int * filter);

extern
void
ponos_perfidiom_inner_parallelism (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, 
  s_chunked_graph_t * CG, int clusterid, int * filter);


extern
void 
ponos_perfidiom_outer_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter, int level);


extern
void 
ponos_perfidiom_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter, int level);


// *********************************
// Implemented in istencil.c
// *********************************

extern
void
ponos_chunked_parallelize_stencil (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);

extern
void 
ponos_chunked_stencil_dependence_classification (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
  int clusterid, int * filter);

extern
void 
ponos_chunked_stencil_minimize_vector_skewing (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter);

extern
void 
ponos_chunked_stencil_par_constraints (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter);


extern
void 
ponos_perfidiom_minimize_iterator_coefficient_sum (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter, int level);

// *********************************
// Implemented in ilocality.c
// *********************************


extern
void 
ponos_chunked_outer_linear_fusion (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG);


extern
void 
ponos_chunked_distribute_when_linear_delta_satisfied (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);


extern
void 
ponos_chunked_distribute_independent_statements (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * cinfo, CandlDependence * alldeps);


extern
void
ponos_chunked_constraints_phi_sums (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);

extern
void 
ponos_chunked_insert_phi_variables (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);


extern
void 
ponos_chunked_insert_pi_variables (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);


extern
void 
ponos_chunked_phi_fusion (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo,
    int outer);


extern
void 
ponos_chunked_minimize_nbr_partitions (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);


extern
void 
ponos_chunked_activate_partitions (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);


extern
void 
ponos_chunked_omega_constraints (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo,
    s_chunked_mode_t * CM);

extern
void 
ponos_perfidiom_stride_optimization (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * cinfo, int * filter);


extern
void 
ponos_perfidiom_dependence_guided_fusion (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter);


extern
void 
ponos_perfidiom_separate_independent_statements (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter);


extern
void 
ponos_perfidiom_permutability (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter);


extern
void 
ponos_chunked_separate_clusters (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, s_chunked_graph_t * CG);


extern
void 
ponos_chunked_set_outer_beta_ranges (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, s_chunked_graph_t * CG);


// *********************************
// Implemented in iparloc.c
// *********************************

extern
void 
ponos_chunked_optimize_reuse (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * cinfo);

extern
void 
ponos_perfidiom_outerpar_innerreuse (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * cinfo, 
  int align_dims);

extern
void 
ponos_perfidiom_outerpar_innerreuse_with_filter (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, 
  s_chunked_graph_t * CG, 
  int align_dims, int clusterid, int * filter);


extern
void 
ponos_perfidiom_fusion_preserving_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter);


// *********************************
// Implemented in igeneric.c
// *********************************

extern
void 
ponos_chunked_rebound_theta_iter (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo);


extern
void 
ponos_chunked_set_easy_coefficients (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo,
    s_chunked_graph_t * CG);


extern
void 
ponos_chunked_auto_satisfy_inter_stmt_dependences (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo, 
    s_chunked_graph_t * CG);

extern
int
ponos_chunked_detect_dependence_satisfaction (s_ponos_space_t* space,
    s_chunked_info_t * CI, s_chunked_graph_t * CG, 
    int * delta_ids, int stmt1_id, int stmt2_id);


extern
void
ponos_chunked_fix_theta_bounds (s_ponos_space_t* space,
    s_ponos_options_t* options);


extern
void
ponos_chunked_fix_theta_skew (s_ponos_space_t* space,
    s_ponos_options_t* options);


extern
int*
ponos_space_get_coefs_stmt (s_ponos_space_t* space,
    scoplib_statement_p stm, int coef_type);


extern
void
ponos_space_create_summation_with_equality_cst (s_ponos_space_t* space,
    int var, int* other_vars,
    int mode,
    int sum_type,
    int val);


extern
void
ponos_codelet_create_ge_cst (s_ponos_space_t* space, int var1, int val1, int cst);


extern
void
ponos_chunked_set_theta_bounds (s_ponos_space_t* space,
    s_ponos_options_t* options, int idx, int lb, int ub);


extern
void
ponos_chunked_space_bulk_var_creation (s_ponos_space_t* space,
    s_ponos_options_t* options, const char * prefix, int n_var);

extern
int *
collect_psi_ids_from_cluster (s_ponos_space_t* space,
  s_chunked_info_t * CI, int level, int * filter);


extern
int *
collect_rho_ids_from_cluster (s_ponos_space_t* space,
  s_chunked_info_t * CI, int level, int * filter);


extern
int *
collect_delta_ids_from_cluster (s_ponos_space_t* space,
  s_chunked_info_t * CI, int level, int * filter);

extern
int *
collect_theta_ids_from_cluster (s_ponos_space_t* space,
  s_chunked_info_t * CI, int level, int * filter, int varmask);


extern
void
ponos_codelet_create_weighted_ge(s_ponos_space_t* space,
			      int var1, int var2, int weight1, int weight2, int cst);


extern
s_ponos_space_t *
ponos_space_clone (s_ponos_space_t* space);


extern
void 
ponos_chunked_satisfy_dependence_once (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo, 
    s_chunked_graph_t * CG, int * filter);

// *********************************
// Implemented in idriver.c
// *********************************

extern
void 
ponos_chunked_create_constraints (s_ponos_space_t* space,
    s_ponos_options_t* options, CandlProgram * cprogram,
    int n_dep, CandlDependence * deps);

extern
void 
ponos_chunked_auto_select_objectives (s_ponos_space_t* space,
    s_ponos_options_t* options, CandlProgram * cprogram, 
    int n_dep, CandlDependence * deps, int space_id);

extern
void 
ponos_chunked_adaptive_assembly (s_ponos_space_t* space,
    s_ponos_options_t* options, CandlProgram * cprogram, 
    int n_dep, CandlDependence * deps, int space_id);

extern
void 
ponos_chunked_create_constraints_pwr9 (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_graph_t * CG,
    s_chunked_info_t * CI);

extern
void 
ponos_chunked_create_constraints_skx (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_graph_t * CG,
    s_chunked_info_t * CI);

extern
void 
ponos_chunked_create_constraints_knl (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_graph_t * CG,
    s_chunked_info_t * CI);

extern
void 
ponos_chunked_create_constraints_cnc (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_graph_t * CG,
    s_chunked_info_t * CI);

extern
void
ponos_multi_objective_space_generate (scoplib_scop_p scop,
    CandlProgram* cprogram,
    CandlDependence* deps,
    s_ponos_space_t * space,
    s_ponos_options_t* options);

// *********************************
// Implemented in iexportcnc.c
// *********************************

extern
int generate_pipes_c_program (scoplib_scop_p scop,
    s_ponos_options_t* options, CandlProgram * cprogram, 
    CandlDependence * deps);


void
ponos_solver_cplex_pprint_solution (FILE* stream, s_ponos_space_t* space);



void
ponos_chunked_show_nodetype (s_fnode_t fnode);



END_C_DECLS





#endif // PONOS_CHUNKED_H
