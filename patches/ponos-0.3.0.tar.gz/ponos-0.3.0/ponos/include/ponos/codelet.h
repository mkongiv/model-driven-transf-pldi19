/*
 * codelet.h: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 * Martin Kong <kongm@cse.ohio-state.edu>
 */
#ifndef PONOS_CODELET_H
# define PONOS_CODELET_H


# ifndef LINEAR_VALUE_IS_LONGLONG
#  define LINEAR_VALUE_IS_LONGLONG
# endif
# ifndef CANDL_SUPPORTS_SCOPLIB
#  define CANDL_SUPPORTS_SCOPLIB
# endif
# include <candl/program.h>
# include <candl/dependence.h>
# include <candl/options.h>
# ifndef SCOPLIB_INT_T_IS_LONGLONG
#  define SCOPLIB_INT_T_IS_LONGLONG
# endif
# include <scoplib/scop.h>
# include <ponos/space.h>


BEGIN_C_DECLS


/**
 * 
 * This is the G matrix of the PLDI'13-Spiral paper
 *
 */
struct s_af_iterator_map 
{
  int * nonfvd;
  int * fvd;
  int dim;
  struct s_af_iterator_map * next;
  int stmt_id;
  int ref_id;
  int array_id;
  int array_dim;
  int sum_nonfvd;
  int sum_fvd;
  scoplib_statement_p stmt;
};


typedef struct s_af_iterator_map s_af_iterator_map_t;



/**
 * 
 * Allocate an iterator map (aka G-Matrix of references)
 *
 */
extern
s_af_iterator_map_t *
ponos_codelet_alloc_af_iterator_map (int dim);


/**
 * 
 * Free the linked list of iterator maps
 *
 */
extern
void
ponos_codelet_free_af_iterator_map (s_af_iterator_map_t * G);


/**
 * 
 * Print a single access function iterator map
 *
 */
extern
void
ponos_codelet_print_af_iterator_map (s_af_iterator_map_t * G);



/**
 * 
 * Print the complete linked list of access function iterator maps
 *
 */
extern
void
ponos_codelet_print_all_af_iterator_map (s_af_iterator_map_t * G);


/**
 * 
 * Build the iterator map for one lhs or rhs of an statement (ref)
 *
 */
extern
s_af_iterator_map_t *
ponos_codelet_build_af_iterator_map (s_ponos_options_t* options,
    int dim, int stmt_id, int * ref_id_p, 
    scoplib_matrix_p ref, scoplib_statement_p stmt);



/**
 * 
 * Build the iterator map for all access functions
 *
 */
extern
s_af_iterator_map_t *
ponos_codelet_build_complete_af_iterator_map (
  s_ponos_space_t * space, s_ponos_options_t* options);


/**
 *
 * Adds the stride-0/1 constraints to the space
 *
 */
extern
void
ponos_codelet_codelet_stride_constraints (s_ponos_space_t* space,
        s_af_iterator_map_t * G,
				s_ponos_options_t* options);


/**
 *
 * Creates the constraint:
 * var1 - var2 \ge 0
 *
 */
extern
void
ponos_codelet_create_ge(s_ponos_space_t* space,
			      int var1, int var2, int cst);



/**
 *
 * Creates the weighted summation constraint
 * \sum_i ( weight[i] \times other_vars[i]) - weight \times var  >= constant
 *
 */
extern
void
ponos_codelet_create_weighted_summation (s_ponos_space_t* space,
			      int var, int* other_vars,
            int weight, int* other_weights,
            int constant);


/**
 *
 * Set boolean constraints on a give type of variable
 *
 */
extern
void
ponos_codelet_boolean_constraints (s_ponos_space_t* space,
				s_ponos_options_t* options,
        int coef_type );


/**
 *
 * Adds \gamma_{i,j}  constraints:
 *  \theta_{i,j} \ge \gamma_{i,j}
 *
 */
extern
int 
ponos_codelet_gamma_constraints (s_ponos_space_t* space,
        s_af_iterator_map_t * G,
				s_ponos_options_t* options);


void
extern
ponos_codelet_print_vars_by_dim_type (FILE* stream, 
    s_ponos_space_t* space, 
    scoplib_statement_p stmt,
    int dim, int coef_type);


/**
 *
 * Adds the stride-0/1 constraints to the space
 *
 */
extern
void
ponos_codelet_stride_constraints (s_ponos_space_t* space,
        s_af_iterator_map_t * G,
				s_ponos_options_t* options);


/**
 * Returns a -1-terminated array of variable positions in the space,
 * that match a variable type
 *
 * For instance, to get all column ids (positions) of theta
 * coefficients of the first dimension, call with 
 * coef_type=PONOS_VAR_THETA.
 *
 */
extern
int*
ponos_codelet_get_coefs_type (s_ponos_space_t* space, int coef_type);





/**
 *
 * Copy a subset of ids into myids.
 * The subset is determined by the bits that are set to 1
 * in the argument x, e.g., if ids = [a b c d] then
 * a is associated to the first bit, b to the second, and so
 * 
 **/
static
int ponos_codelet_fill_combination (int * ids, int * myids,unsigned int x,int n);



/**
 *
 * n: number of statements
 * m: number of variables to consider in the constraint
 * Generate C(n,m) * 2 constraints.
 * Each of the C(n,m) combinations uses only m variables from ids,
 * and is bounded by lb and ub.
 *
 */
extern
int ponos_codelet_force_dist_constraint_bounds (
  s_ponos_space_t* space,
  s_ponos_options_t* options,
  unsigned int n, unsigned int m,
  int * ids, int * myids, int lb, int ub);



/**
 *
 * Force distribution at a constant level
 *
 */
extern
void
ponos_codelet_force_dist_constraints (s_ponos_space_t* space,
				   s_ponos_options_t* options,
           int level);


/**
 *
 * Force full distribution of statements at level dim
 *
 */
extern
int ponos_codelet_force_fision_constraints_boolean (
  s_ponos_space_t* space,
  s_ponos_options_t* options, 
  int dim);











// Codelet specific objective functions

/**
 *
 * Embed constraints for maximizing the number of stride-0/1 references
 *
 */
extern
void
ponos_codelet_objective_max_stride01_refs(s_ponos_space_t* space,
				s_ponos_options_t* options);


/**
 *
 * Embed constraints for maximizing stride-0/1 property
 *
 */
extern
void
ponos_codelet_objective_max_stride01_prop(s_ponos_space_t* space,
				s_ponos_options_t* options);



/**
 *
 * Objective function for forcing maximum distribution of statements
 *
 */
extern
void
ponos_codelet_objective_max_dist (s_ponos_space_t* space,
				s_ponos_options_t* options);


/**
 *
 * Objective function for forcing maximum fusion at outer dimensions 
 *
 */
extern
int ponos_codelet_objective_force_outer_fusion (
  s_ponos_space_t* space,
  s_ponos_options_t* options);



/**
 *
 * Objective function for minimizing sum of iters at level 2d
 *
 */
extern
int ponos_codelet_objective_min_inner_coefs (
  s_ponos_space_t* space,
  s_ponos_options_t* options,
  int dim);


/**
 *
 * Objective function for minimizing sum of gammas for a given iterator
 *
 */
extern
void ponos_codelet_objective_min_gamma_iterator (
  s_ponos_space_t* space,
  s_ponos_options_t* options, 
  int * gamma_col, int it_id );



/**
 *
 * Objective function for minimizing sum of gammas for 
 * each iterator column of gamma
 *
 */
extern
void ponos_codelet_objectives_min_each_gamma_iterator (
  s_ponos_space_t* space,
  s_ponos_options_t* options, 
  int ** gamma_iters);


extern
void ponos_codelet_smart_stride_constraints (s_ponos_space_t* space,
        s_af_iterator_map_t * G,
				s_ponos_options_t* options);

#endif // PONOS_CODELET_H
