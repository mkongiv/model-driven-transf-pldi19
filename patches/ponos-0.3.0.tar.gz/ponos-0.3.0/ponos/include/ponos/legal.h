/*
 * legal.h: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#ifndef PONOS_LEGAL_H
# define PONOS_LEGAL_H

# ifndef LINEAR_VALUE_IS_LONGLONG
#  define LINEAR_VALUE_IS_LONGLONG
# endif
# ifndef CANDL_SUPPORTS_SCOPLIB
#  define CANDL_SUPPORTS_SCOPLIB
# endif
# include <candl/candl.h>
# include <candl/program.h>
# include <candl/dependence.h>
# include <candl/options.h>
# ifndef SCOPLIB_INT_T_IS_LONGLONG
#  define SCOPLIB_INT_T_IS_LONGLONG
# endif
# include <scoplib/scop.h>

#ifndef FM_HAS_GMP_SUPPORT
# define FM_HAS_GMP_SUPPORT
#endif
# include <fm/system.h>
# include <fm/solution.h>
# include <fm/solver.h>
# include <fm/compsol.h>

# include <ponos/options.h>
# include <ponos/space.h>


BEGIN_C_DECLS


/**
 * Creates the full scheduling space, without any constraint.
 *
 * Space is organized as follows:
 * [ D1,1 D2,1 ... R1,1 R1,2 ... iS1,1 jS1,1 iS2,1 ... iS1,2 ...]
 *
 * where in notation x,y x represents the id of the
 * dependence/statement, y represents the schedule dimension (0 to
 * max_sched_dim-1).
 *
 */
extern
s_ponos_space_t*
ponos_legal_build_universe (scoplib_scop_p scop,
			    CandlDependence* deps,
			    int max_sched_dim,
			    s_ponos_options_t* options);

/**
 * Build a local system using the Farkas lemma.
 *
 * From a dependence, it produces the local space with the associated
 * variables with the same representation as when building the
 * universe system.
 * In addition, temporary dimensions are added for the Farkas multipliers.
 *
 * The legality constraint built is:
 *
 * \begin{eqnarray}
 *   \textit{(i)} && \forall \mathcal{D}_{R,S},~\forall p,
 *   ~\delta_{p}^{\mathcal{D}_{R,S}} \in \{0,1\}
 *   \nonumber \					\
 *   \textit{(ii)} &&  \forall \mathcal{D}_{R,S},
 *   ~\sum_{p = 1}^{m} \delta_p^{\mathcal{D}_{R,S}} \ge 1
 *   \label{eq:alldepssolved} \				\
 *   \textit{(iii)} &&  \forall \mathcal{D}_{R,S},
 *   ~\forall p \in \{1,\ldots,m\},
 *   ~\forall \left\langle \vec{x}_R, \vec{x}_S
 *   \right\rangle \in \mathcal{D}_{R,S}, \label{eq:convexcondforlegality} \ \
 *   && \quad \Theta_p^S(\vec x_S) - \Theta_p^R(\vec x_R) \ge - \sum_{k=1}^{p-1} (\delta_{k}^{\mathcal{D}_{R,S}}  -\rho_{k}^{\mathcal{D}_{R,S}}) . (K . \vec n + K) +  \delta_{p}^{\mathcal{D}_{R,S}} \nonumber
 * \end{eqnarray}
 *
 * In plain English: two binary decision variables, delta and rho, are
 * introduced per dimension x dependence. The legality condition
 * implemented is, for a given dependence 'dep' and a dimension 'dim',
 *
 * ThetaS(x) - ThetaR(y) >= \sum_{i=0}^{dim-1}(delta_i^{dep} -
 *                                rho_i^{dep}).(K.\vec n + K) +delta_{dim}^{dep}
 *
 */
s_ponos_space_t*
ponos_legal_build_farkas_one_dependence (s_ponos_space_t* global,
					 CandlDependence* dep,
					 int dim,
					 int dep_id,
					 int* num_farkas_multipliers,
					 int mode,
					 s_ponos_options_t* options);



/**
 * Project out the Farkas multipliers in a local system.
 *
 *
 */
extern
s_ponos_space_t*
ponos_legal_eliminate_farkas_multipliers (s_ponos_space_t* space,
					  int num_farkas_multipliers,
					  s_ponos_options_t* options);

/**
 * Build all semantics-preserving constraints for a program.
 *
 * Output space is organized as follows:
 * [ D1,1 D2,1 ... R1,1 R1,2 ... iS1,1 jS1,1 iS2,1 ... iS1,2...]
 *
 * Where D are delta variables, R are rho variables, iSxx are the
 * schedule coefficents. They are organized as
 *  iS1,1 iS2,1 iS1,2, iS2,2 pS1,1 pS2,1 ... cS1,1 cS2,1...
 *
 * where i means "iterator" coefficient, S1 means statement 1, S1,1
 * means coefficients of the first chedule row, p means "parameter"
 * coefficients and c means "constant" coefficients.
 *
 */
extern
s_ponos_space_t*
ponos_legal_build_semantics_constraints (scoplib_scop_p scop,
					 CandlDependence* deps,
					 s_ponos_options_t* options);



END_C_DECLS


#endif // PONOS_LEGAL_H
