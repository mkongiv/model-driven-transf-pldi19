/*
 * objectives.h: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#ifndef PONOS_OBJECTIVES_H
# define PONOS_OBJECTIVES_H

# ifndef LINEAR_VALUE_IS_LONGLONG
#  define LINEAR_VALUE_IS_LONGLONG
# endif
# ifndef CANDL_SUPPORTS_SCOPLIB
#  define CANDL_SUPPORTS_SCOPLIB
# endif
# include <candl/candl.h>
# include <candl/program.h>
# include <candl/dependence.h>
# include <candl/options.h>
# ifndef SCOPLIB_INT_T_IS_LONGLONG
#  define SCOPLIB_INT_T_IS_LONGLONG
# endif
# include <scoplib/scop.h>

#ifndef FM_HAS_GMP_SUPPORT
# define FM_HAS_GMP_SUPPORT
#endif
# include <fm/system.h>
# include <fm/solution.h>
# include <fm/solver.h>
# include <fm/compsol.h>

# include <ponos/options.h>
# include <ponos/space.h>


# define PONOS_OBJECTIVE_MINIMIZE 1
# define PONOS_OBJECTIVE_MAXIMIZE 2


BEGIN_C_DECLS



/**
 * Minimizes the sum of variables of type 'type' at dimension 'dim'.
 *
 */
extern
void
ponos_objectives_minimize_sum_of_dim (s_ponos_space_t* space,
				      int type,
				      int dim);


/**
 * Maximizes the sum of variables of type 'type' at dimension 'dim'.
 *
 */
extern
void
ponos_objectives_maximize_sum_of_dim (s_ponos_space_t* space,
				      int type,
				      int dim);


/**
 * Embed constraints for maximal outer parallelism.
 *
 *
 */
extern
void
ponos_objectives_max_outer_par (s_ponos_space_t* space,
				s_ponos_options_t* options);


/**
 * Embed constraints for maximal inner parallelism.
 *
 *
 */
extern
void
ponos_objectives_max_inner_par (s_ponos_space_t* space,
				s_ponos_options_t* options);


/**
 * Embed constraints for maximal permutability.
 *
 */
extern
void
ponos_objectives_max_permutability (s_ponos_space_t* space,
				    s_ponos_options_t* options);


/**
 * Minimize dependence distance.
 *
 */
extern
void
ponos_objectives_min_dep_distance (s_ponos_space_t* space,
				   s_ponos_options_t* options);


/**
 * Embed constraints for maximal dependence solving (Feautrier multi-dim).
 *
 *
 */
extern
void
ponos_objectives_max_dep_solve (s_ponos_space_t* space,
				s_ponos_options_t* options);


/**
 * Testing gamma related stuff
 *
 *
 */
extern
void
ponos_objectives_gamma_pos (s_ponos_space_t* space,
			    s_ponos_options_t* options);

extern
void
ponos_objectives_min_iter_coef (s_ponos_space_t* space,
				s_ponos_options_t* options);

/**
 * New scheduler, in development.
 *
 *
 */
extern
void
ponos_objectives_tasched (s_ponos_space_t* space,
			  s_ponos_options_t* options);


END_C_DECLS


#endif // PONOS_OBJECTIVES_H
