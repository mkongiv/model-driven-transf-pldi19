/*
 * options.h: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#ifndef PONOS_OPTIONS_H
# define PONOS_OPTIONS_H

/**
 * types of constraints/objectives
 */
// Max. number of custom constraint/objectives.
# define PONOS_MAX_CST_OBJ_NUM			64
// List of constraints/objectives. Each have a unique id.
# define PONOS_CONSTRAINTS_SUM_ITER_POS		0
# define PONOS_CONSTRAINTS_PARAM_COEF_ZERO	1
# define PONOS_OBJECTIVES_MAX_OUTER_PAR		2
# define PONOS_OBJECTIVES_MAX_INNER_PAR		3
# define PONOS_OBJECTIVES_MAX_PERMUTABILITY	4
# define PONOS_OBJECTIVES_MIN_DEP_DISTANCE	5
# define PONOS_OBJECTIVES_MAX_DEP_SOLVE		6
# define PONOS_CONSTRAINTS_LINEAR_INDEP		7
# define PONOS_OBJECTIVES_GAMMA_POS		8
# define PONOS_OBJECTIVES_TASCHED		9
# define PONOS_OBJECTIVES_MIN_THETA_ITER	10
// From solver.h
# define PONOS_SOLVER_PIP			1
# define PONOS_SOLVER_CPLEX			2
# define PONOS_SOLVER_CPLEX_INCREMENTAL		3
// From objectives.h
# define PONOS_OBJECTIVES_NONE		0
# define PONOS_OBJECTIVES_CODELET	1
# define PONOS_OBJECTIVES_PLUTO		2
# define PONOS_OBJECTIVES_CUSTOM       	3
# define PONOS_OBJECTIVES_CHUNKED 4


#define PONOS_CHUNKED_ARCH_NONE 0
#define PONOS_CHUNKED_ARCH_FILE 1
#define PONOS_CHUNKED_ARCH_KNL  2
#define PONOS_CHUNKED_ARCH_SKX  3
#define PONOS_CHUNKED_ARCH_PWR9 4
#define PONOS_CHUNKED_ARCH_CNC  5
#define PONOS_CHUNKED_ARCH_TILED_CNC  6
#define PONOS_CHUNKED_ARCH_FAKE 7

BEGIN_C_DECLS

struct s_ponos_options
{
  int debug;
  int build_2d_plus_one;
  int maxscale_solver;
  int noredundancy_solver;
  int legality_constant; // The K in popl formulation.
  int schedule_bound; // each |schedule coef| is <= schedule bound.
  int schedule_size;
  int solver;
  int solver_precond;
  int quiet;
  int schedule_coefs_are_pos;
  int objective;
  int candl_deps_isl_simplify;
  int candl_deps_prune_transcover;
  int objective_list[PONOS_MAX_CST_OBJ_NUM]; // -1 terminated array.
  int pipsolve_lp;
  int pipsolve_gmp;
  int solver_cplex;
  char* output_file_template;
  int legal_space_normalization;

	int chunked               ;
	int chunked_max_fusion    ;
	int chunked_min_fusion    ;
	int chunked_loop_max_stmt ;
	int chunked_loop_max_ref  ;
	int chunked_loop_max_lat  ;
  int chunked_arch;
  char * chunked_arch_file;
  int fp_precision;
  int chunked_auto;
  int chunked_genpipes;
  int chunked_olist;
  int extract_pipes_t_schedule;
  int extract_pipes_p_schedule;
  int generate_pipes_df;
  int generate_pipes_c;
  int generate_pipes_c_harness;
  int chunked_multi_obj_space; // read from file
  int chunked_adaptive_assembly;
  char * mdt_db_file;
};
typedef struct s_ponos_options s_ponos_options_t;

/**
 *
 */
extern
s_ponos_options_t* ponos_options_malloc();


/**
 *
 */
extern
void ponos_options_free(s_ponos_options_t* opts);




END_C_DECLS


#endif // PONOS_OPTIONS_H
