/*
 * pipes.h: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Martin Kong <martin.richard.kong@gmail.com>
 */

#ifndef PONOS_PIPES_H
# define PONOS_PIPES_H


# ifndef LINEAR_VALUE_IS_LONGLONG
#  define LINEAR_VALUE_IS_LONGLONG
# endif
# ifndef CANDL_SUPPORTS_SCOPLIB
#  define CANDL_SUPPORTS_SCOPLIB
# endif
# include <candl/program.h>
# include <candl/dependence.h>
# include <candl/options.h>
# ifndef SCOPLIB_INT_T_IS_LONGLONG
#  define SCOPLIB_INT_T_IS_LONGLONG
# endif
# include <scoplib/scop.h>
# include <ponos/space.h>

#include <ctype.h>
#include <isl/ctx.h>
#include <isl/set.h>  
#include <isl/union_set.h>
#include <isl/map.h>
#include <isl/union_map.h>
#include <isl/ast_build.h>
#include <isl/ast.h>
#include <isl/printer.h>
#include <isl/options.h>

BEGIN_C_DECLS

#define PIPES_MAX_STR 100000

#define PIPES_DIM_IN 'i'
#define PIPES_DIM_OUT 'o'
#define PIPES_DIM_PAR 'p'
#define PIPES_DIM_ARRDIM 'a'

#define PIPES_DEBUG_MAP(map,msg) \
  fprintf (stderr, "%s: ", msg); \
  isl_map_dump (map); 

#define PIPES_DEBUG_SET(set,msg) \
  fprintf (stderr, "%s: ", msg); \
  isl_set_dump (set); 

#define PIPES_DEBUG_UMAP(union_map,msg) \
  fprintf (stderr, "%s: ", msg); \
  isl_union_map_dump (union_map); 

#define PIPES_DEBUG_USET(union_set,msg) \
  fprintf (stderr, "%s: ", msg); \
  isl_union_set_dump (union_set); 

struct p_reference
{
  scoplib_matrix_p scop_matrix;
  int is_write; // 1: write; 0: read
  int was_write; // 1: was write in original scop, now is a 'first read'
  int uaid;
  int row;  // starting row in scop matrix;
  int ndim; // number of space dimensions;
  isl_map * accrel;
  isl_map * dsa_accrel;
  int no_write;
  int no_read;
  int is_dsa;
  void * stmt; // pointer to pipes_statement;
};
typedef struct p_reference pipes_reference;

struct p_statement
{
  scoplib_statement_p scop_stmt;
  int sid;
  isl_set * domain;
  isl_map * schedule;
  isl_map * tile_schedule;
  int n_ref;
  int is_dsa;
  pipes_reference ** refs;
  int is_init;
  int init_one; // 1 ==> init to 1, 0 ==> init to 0
};
typedef struct p_statement pipes_statement;

struct p_block
{
  int arrayid;
  isl_set * domain;
  char * name;
  int ndim;
};
typedef struct p_block pipes_block;

struct p_scop
{
  pipes_statement ** stmt;
  pipes_block ** block;
  scoplib_scop_p scop;
  int n_stmt;
  int n_block; // associated to pipes_block ** block field
  int num_sched_dim;
  int num_params;
  int created;
  isl_ctx * ctx;
  isl_union_map * schedule; // all schedules
  isl_union_map * schedule_tile; // all schedules
  isl_union_set * domains;
  isl_union_map * accrels;
  isl_union_set * us_blocks;
  isl_union_map * dsac_map;
  int is_dsa;
  FILE * fout;
};
typedef struct p_scop pipes_scop;


#define PIPES_GEN_MODE_PIPES 0
#define PIPES_GEN_MODE_BASELINE 1
#define PIPES_GEN_MODE_INIT_RO 2
#define PIPES_GEN_MODE_INIT_RW 3
#define PIPES_GEN_MODE_TILED_PIPES 4
#define PIPES_GEN_MODE_CHECK 5

#define PIPES_E_REGION   0
#define PIPES_E_PRODUCER 1
#define PIPES_E_CONSUMER 2

#define PIPES_BLOCK 0
#define PIPES_STATEMENT 1
#define PIPES_MAP 2

#define PIPES_SCHEDULE_TILE_FULL   0
#define PIPES_SCHEDULE_TILE_OUTER  1
#define PIPES_SCHEDULE_TILE_INNER  2
#define PIPES_SCHEDULE_TILE_CODEGEN 3



extern
void
generate_pipes_df_program (
  pipes_scop * pscop, pipes_scop * ews, pipes_scop * ers);

extern
int
generate_pipes_c_harness
  ( scoplib_scop_p scop, s_ponos_options_t* options, CandlProgram * cprogram, 
    CandlDependence * deps);

extern
int
generate_pipes_programs ( 
  scoplib_scop_p scop, s_ponos_options_t* options, CandlProgram * cprogram, 
  CandlDependence * deps);

extern
int
generate_pipes_df
  ( scoplib_scop_p scop, s_ponos_options_t* options, CandlProgram * cprogram, 
    CandlDependence * deps);

END_C_DECLS





#endif // PONOS_PIPES_H
