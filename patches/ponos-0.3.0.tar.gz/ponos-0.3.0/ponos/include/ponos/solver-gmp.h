/*
 * solver-gmp.h: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#ifndef PONOS_SOLVER_GMP_H
# define PONOS_SOLVER_GMP_H

# ifndef LINEAR_VALUE_IS_LONGLONG
#  define LINEAR_VALUE_IS_LONGLONG
# endif
# ifndef CANDL_SUPPORTS_SCOPLIB
#  define CANDL_SUPPORTS_SCOPLIB
# endif
# include <candl/candl.h>
# include <candl/program.h>
# include <candl/dependence.h>
# include <candl/options.h>
# ifndef SCOPLIB_INT_T_IS_LONGLONG
#  define SCOPLIB_INT_T_IS_LONGLONG
# endif
# include <scoplib/scop.h>

#ifndef FM_HAS_GMP_SUPPORT
# define FM_HAS_GMP_SUPPORT
#endif
# include <fm/system.h>
# include <fm/solution.h>
# include <fm/solver.h>
# include <fm/compsol.h>
# include <ponos/options.h>
# include <ponos/space.h>


# define PONOS_SOLVER_PIP 1


BEGIN_C_DECLS



/**
 * Find a solution to a system using PIP, and embed the schedule found
 * in the scop.
 *
 */
void
ponos_solver_gmp_pip (s_ponos_space_t* space,
		      scoplib_scop_p scop,
		      int max_schedule_dim,
		      s_ponos_options_t* options);


/**
 * Find a solution to a system, and embed the schedule found in the scop.
 *
 */
void
ponos_solver_gmp (s_ponos_space_t* space,
		  scoplib_scop_p scop,
		  s_ponos_options_t* options);


END_C_DECLS


#endif // PONOS_SOLVER_GMP_H
