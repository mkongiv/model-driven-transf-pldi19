/*
 * space.h: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#ifndef PONOS_SPACE_H
# define PONOS_SPACE_H

# include <stdio.h>


# ifndef LINEAR_VALUE_IS_LONGLONG
#  define LINEAR_VALUE_IS_LONGLONG
# endif
# ifndef CANDL_SUPPORTS_SCOPLIB
#  define CANDL_SUPPORTS_SCOPLIB
# endif
# include <candl/program.h>
# include <candl/dependence.h>
# include <candl/options.h>
# ifndef SCOPLIB_INT_T_IS_LONGLONG
#  define SCOPLIB_INT_T_IS_LONGLONG
# endif
# include <scoplib/scop.h>

#ifndef FM_HAS_GMP_SUPPORT
# define FM_HAS_GMP_SUPPORT
#endif
# include <fm/solution.h>
# include <fm/compsol.h>

# include <ponos/options.h>


/**
 * Maximal value any integer variable can take.
 *
 */
#define PONOS_SPACE_MAX_INT_VAL	100000

/**
 * Constants to represent the different kinds of variables in a space
 * of constraints.
 *
 */
# define PONOS_MAKE_BIN_ID(x) (1 << (x))

/**
 * individual variable type.
 */
# define PONOS_VAR_THETA_ITER		PONOS_MAKE_BIN_ID(1)
# define PONOS_VAR_THETA_PARAM		PONOS_MAKE_BIN_ID(2)
# define PONOS_VAR_THETA_CST		PONOS_MAKE_BIN_ID(3)
# define PONOS_VAR_DELTA		PONOS_MAKE_BIN_ID(4)
# define PONOS_VAR_RHO			PONOS_MAKE_BIN_ID(5)
# define PONOS_VAR_GAMMA_ITER		PONOS_MAKE_BIN_ID(6)
# define PONOS_VAR_GAMMA_PARAM		PONOS_MAKE_BIN_ID(7)
# define PONOS_VAR_GAMMA_CST		PONOS_MAKE_BIN_ID(8)
# define PONOS_VAR_SIGMA	        PONOS_MAKE_BIN_ID(9)
# define PONOS_VAR_U_DIST	        PONOS_MAKE_BIN_ID(10)

# define PONOS_VAR_OPT_SUM_VAR	        PONOS_MAKE_BIN_ID(11)
# define PONOS_VAR_CST_SUM_VAR	        PONOS_MAKE_BIN_ID(12)

# define PONOS_VAR_GAMMA_REF		PONOS_MAKE_BIN_ID(13)
# define PONOS_VAR_NU_REF		PONOS_MAKE_BIN_ID(14)
# define PONOS_VAR_ORDER		PONOS_MAKE_BIN_ID(15)

# define PONOS_VAR_BETA_ITER		PONOS_MAKE_BIN_ID(16)

# define PONOS_VAR_BIN_USERDEF		PONOS_MAKE_BIN_ID(17)
# define PONOS_VAR_INT_USERDEF		PONOS_MAKE_BIN_ID(18)

# define PONOS_VAR_PHI      PONOS_MAKE_BIN_ID(19)
# define PONOS_VAR_OMEGA    PONOS_MAKE_BIN_ID(20)
# define PONOS_VAR_PI       PONOS_MAKE_BIN_ID(21)
# define PONOS_VAR_PSI       PONOS_MAKE_BIN_ID(22)
# define PONOS_VAR_FUS_PROF       PONOS_MAKE_BIN_ID(23)

/**
 * Sets of variable types.
 */
# define PONOS_VAR_THETA		(PONOS_VAR_THETA_ITER | PONOS_VAR_THETA_PARAM | PONOS_VAR_THETA_CST)
# define PONOS_VAR_GAMMA		(PONOS_VAR_GAMMA_ITER | PONOS_VAR_GAMMA_PARAM | PONOS_VAR_GAMMA_CST)
# define PONOS_VAR_BIN_LEGAL		(PONOS_VAR_DELTA | PONOS_VAR_RHO)
# define PONOS_VAR_BIN_OPT		(PONOS_VAR_SIGMA)



/**
 * Type of modes for adding a summation constraint.
 */
# define PONOS_CONSTRAINT_EQUAL		1
# define PONOS_CONSTRAINT_GREATEREQUAL	2
# define PONOS_CONSTRAINT_GREATER	3
# define PONOS_CONSTRAINT_LOWEREQUAL	4
# define PONOS_CONSTRAINT_LOWER		5
/**
 * Type of mode for an 'equal' summation constraint. Maximizes leads to encoding
 * -optvar = ... instead of optvar = ...
 */
# define PONOS_OBJECTIVE_MINIMIZE	1
# define PONOS_OBJECTIVE_MAXIMIZE	2
# define PONOS_OBJECTIVE_MAXIMIZE_POS	3

# define PONOS_UNUSED_VALUE		0


BEGIN_C_DECLS

/**
 * Internal representation of each variable in the space.
 *
 */
struct s_ponos_var
{
  char* name;
  int type;
  int is_boolean;
  int is_nonnegative;
  int lower_bound;
  long long int upper_bound;
  int optimal_value;
  int is_maximized;
  int pos;
  void* scop_ptr; // points to scoplib_statement_p or CandlDependence*
  int abs_pos;
  int dim;
  void* usr;
  int cpx_skip;
};
typedef struct s_ponos_var s_ponos_var_t;

/**
 * A space of constraints.  Contains an array of variables (vars), a
 * set of constraints (space), the total number of variables in the
 * space, and the total number of parameters in the program modeled.
 *
 */
struct s_ponos_space
{
  s_ponos_var_t** vars;
  s_fm_solution_t* space;
  int num_vars;
  int num_vars_prealloc;
  int num_pars;
  int num_sched_dim;
  int max_coef_pos_val;
  scoplib_scop_p scop; // shallow copy of a scop.
  int has_valid_optimal_solution;
  double last_solver_time;
};
typedef struct s_ponos_space s_ponos_space_t;


/**
 * Return a fresh variable.
 *
 */
extern
s_ponos_var_t*
ponos_space_var_create (char* name, int type, int dim,
			int local_pos, int global_pos,
			void* data);

/**
 * Free a variable.
 *
 */
extern
void
ponos_space_var_free (s_ponos_var_t* var);

/**
 * Set a variable type to Boolean.
 *
 */
extern
void
ponos_space_var_set_boolean (s_ponos_var_t* var);

/**
 * Set a variable type to non-negative, with upper bound.
 *
 */
extern
void
ponos_space_var_set_bounds (s_ponos_var_t* var, int lower_bound,
			    int upper_bound);


/**
 * Allocate a new space (empty).
 */
extern
s_ponos_space_t*
ponos_space_malloc();


/**
 * Free an existing space.
 */
extern
void
ponos_space_free(s_ponos_space_t* s);


/**
 * Set the number of variables, and allocate the structures.
 */
extern
void
ponos_space_set_size(s_ponos_space_t* s, int dim);


/**
 * Print a space.
 */
extern
void
ponos_space_print (FILE* stream, s_ponos_space_t* space);

/**
 * Print the variables in a space.
 */
extern
void
ponos_space_print_vars (FILE* stream, s_ponos_space_t* space);

/**
 * Print the constraint system in readable form.
 */
void
ponos_space_pprint_cst (FILE* stream, s_ponos_space_t* space);


/**
 * Returns a -1-terminated array of variable positions in the space,
 * that match a variable type.
 *
 * For instance, to get all column ids (positions) of theta
 * coefficients call with coef_type=PONOS_VAR_THETA.
 *
 */
int*
ponos_space_get_coefs (s_ponos_space_t* space,
		       int coef_type);


/**
 * Returns a -1-terminated array of variable positions in the space,
 * that match a variable type and dimension.
 *
 * For instance, to get all column ids (positions) of theta
 * coefficients of the first dimension, call with dim=0,
 * coef_type=PONOS_COEF_THETA.
 *
 */
extern
int*
ponos_space_get_coefs_dim (s_ponos_space_t* space,
			   int dim,
			   int coef_type);


/**
 * Returns a -1-terminated array of variable positions in the space,
 * that match a variable type and dimension for a given statement.
 *
 * For instance, to get all column ids (positions) of theta
 * coefficients of the first dimension, call with dim=0,
 * coef_type=PONOS_VAR_THETA.
 *
 */
extern
int*
ponos_space_get_coefs_dim_stmt (s_ponos_space_t* space,
				scoplib_statement_p stm,
				int dim,
				int coef_type);


/**
 * Set a particular variable at position 'pos' in the space->vars[pos]
 * to 'val'.
 *
 * mode is one of:
 * PONOS_CONSTRAINT_EQUAL
 * PONOS_CONSTRAINT_GREATEREQUAL
 * PONOS_CONSTRAINT_GREATER
 * PONOS_CONSTRAINT_LOWEREQUAL
 * PONOS_CONSTRAINT_LOWER
 */
extern
void
ponos_space_set_variable_to_value (s_ponos_space_t* space,
				   int pos,
				   int val,
				   int mode);


/**
 * Count the number of variables of a certain type at a given dimension.
 *
 */
extern
int
ponos_space_count_var_type_dim (s_ponos_space_t* space,
				int dim,
				int type);


/**
 * Count the number of variables of a certain type.
 *
 */
extern
int
ponos_space_count_var_type (s_ponos_space_t* space,
			    int type);


/**
 * Creates a summation constraint
 * var = \sum_i other_vars[i]
 *
 * mode is one of:
 * PONOS_CONSTRAINT_EQUAL
 * PONOS_CONSTRAINT_GREATEREQUAL
 * PONOS_CONSTRAINT_GREATER
 * PONOS_CONSTRAINT_LOWEREQUAL
 * PONOS_CONSTRAINT_LOWER
 *
 * sum_type is one of
 * PONOS_OBJECTIVE_MINIMIZE
 * PONOS_OBJECTIVE_MAXIMIZE
 * sum_type is used only if PONOS_CONSTRAINT_EQUAL is given.
 *
 * set val to PONOS_UNUSED_VALUE, unless you know what you are doing.
 */
extern
void
ponos_space_create_summation (s_ponos_space_t* space,
			      int var, int* other_vars,
			      int mode,
			      int sum_type,
			      int val);



/**
 * Pretty-print a FM vector.
 *
 */
extern
void
ponos_space_pretty_print_vector (FILE* stream,
				 s_ponos_space_t* space,
				 s_fm_vector_t* v);


/**
 * Insert a new variable in the space at position pos.
 *
 */
extern
void
ponos_space_insert_variable_at_pos (s_ponos_space_t* space,
				    s_ponos_var_t* var,
				    int pos);


/**
 * Insert a new variable in the space in first position.
 *
 */
extern
void
ponos_space_insert_variable_first (s_ponos_space_t* space,
				   s_ponos_var_t* var);


/**
 * Insert a new variable in the space in last position.
 *
 */
extern
void
ponos_space_insert_variable_last (s_ponos_space_t* space,
				  s_ponos_var_t* var);


extern
void
ponos_space_bulk_variable_insertion_at_start (s_ponos_space_t* space,
    s_ponos_var_t** vars,
    int n_var);

extern
void
ponos_space_bulk_variable_insertion_at_end (s_ponos_space_t* space,
    s_ponos_var_t** vars,
    int n_var);

/**
 * Creates a summation constraint
 * var.var_weight = \sum_i other_vars[i].other_vars_weight[i]
 *
 */
extern
void
ponos_space_create_weighted_summation (s_ponos_space_t* space,
				       int var, int var_weight,
				       int* other_vars,
				       int* other_vars_weight,
				       int mode,
				       int sum_type,
				       int val);

extern
  void
ponos_space_var_skip_cplex (s_ponos_var_t* var);

END_C_DECLS


#endif // PONOS_SPACE_H
