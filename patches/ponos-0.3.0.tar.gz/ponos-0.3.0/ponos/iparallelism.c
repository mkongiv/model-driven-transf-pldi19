/*
 * iparallelism.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012-2018 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Authors:
 * Martin Kong <martin.richard.kong@gmail.com>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>
#include <ponos/objectives.h>
#include <ponos/codelet.h>
#include <ponos/chunked.h>

#include <time.h>
#include <sys/time.h>
#include "iutil.c"


/*
 * For each dependence create 2 variables, sumDL and sumDS.
 * The former sums the deltas of the two outermost linear dimensions.
 * The latter sums the deltas of the two outermost scalar dimensions.
 * Both variables (for each dependence) are bounded by the constraint:
 *   sumDL + sumDS <= 2
 * The sumDL are inserted ahead, whereas the sumDS are inserted behind.
 * Thus sumDLs are minimizes, and dependence satisfactions are pushed towards
 * the scalar dimensions.
 */
#define PAT_GEMM 1
#define PAT_SOLVER 2
#define PAT_MATVEC 4
#define PAT_STENCIL_NONJAC 8
#define PAT_STENCIL_JAC 16
#define PAT_STENCIL (PAT_STENCIL_NONJAC | PAT_STENCIL_JAC)
#define PAT_UNKNOWN 6


int
ponos_chunked_scop_can_use_outer_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, 
    s_chunked_graph_t * CG)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return 0;

  int n_scc = CG->n_scc;
  int ii,jj;

  int SDSCC[n_scc];
  for (ii = 0; ii < n_scc; ii++)
    SDSCC[ii] = 0;
  int * deltas = ponos_space_get_coefs_dim (space, 0, PONOS_VAR_DELTA); 
  for (ii = 0; deltas && deltas[ii] != -1; ii++)
  {
    int varid = deltas[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
    int is_self = dep->source == dep->target;
    if (!is_self)
      continue;
    SDSCC[CG->scc_map[dep->source->label]]++;
  }
  XFREE (deltas);
  for (ii = 0; ii < n_scc; ii++)
    if (SDSCC[ii] > 1)
      return 0;
  return 1;
}

void 
ponos_chunked_choose_outer_parallelism (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, 
  s_chunked_graph_t * CG)
{
  int use_outer;
  use_outer = ponos_chunked_scop_can_use_outer_parallelism (space, options, CI, CG);
  if (use_outer)
    ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 1);
  else
    ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 3);
}



/*
 * For each dependence variable \delta, if necessary, try to choose between 
 * outer parallelism and outer distribution.
 * Basically we do: \deltaK_0 + \deltaK_1 <= 1
 */
void 
ponos_chunked_select_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int ii;
  int nstmt;
  scoplib_statement_p stmt;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  int * ids;
  int min_id = space->num_vars;
  ids = ponos_space_get_coefs (space, PONOS_VAR_DELTA);
  for (ii = 0; ids[ii] != -1; ii++)
    if (ids[ii] < min_id)
      min_id = ids[ii];
  int n_dep = cinfo->n_dep;
  int shift = n_dep;

  int delta_ids[3]; 
  delta_ids[2] = -1;
  int weights[5];
  for (ii = 0; ii < 5; ii++)
    weights[ii] = ii + 1;

  for (ii = 0; ii < n_dep; ii++)
  {
    int pos = ids[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[ii]->scop_ptr);
    if (dep->source != dep->target)
      continue;
    delta_ids[0] = min_id + ii;
    delta_ids[1] = min_id + ii + shift;
    ponos_space_create_summation (space, -1, delta_ids, 
      PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);
  }
  XFREE (ids);
}

void 
ponos_chunked_maximize_outer_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo, s_chunked_graph_t * CG,
    int n_dep, int pattern)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  scoplib_statement_p stmt;
  int i, j;
  int nstmt = cinfo->n_stmt;

  scoplib_statement_p * SA = cinfo->SA;

  int * outer_ids;
  int * weights;
  outer_ids = XMALLOC (int,  2 * n_dep + 1);
  weights = XMALLOC (int, 2 * n_dep + 1);

  char buffer[32]; 
  s_ponos_var_t * front_var[n_dep + 1]; 
  for (i = 0; i < n_dep; i++)
  {
    sprintf (buffer, "OPT_Dlin%d",i);
    front_var[i] = ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, i, 0, 0, NULL);
  }
  ponos_space_bulk_variable_insertion_at_start (space, front_var, n_dep);

  s_ponos_var_t* optvar;
  sprintf (buffer, "OPT_Par");
  optvar = ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);

  int start = space->num_vars - 1;
  for (i = 0; i < n_dep; i++)
  {
    char buffer[32]; 
    s_ponos_var_t* optvar;
    sprintf (buffer, "OPT_Dsca%d",i);
    optvar = ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, i, 0, 0, NULL);
    ponos_space_insert_variable_last (space, optvar);
  }

  int min_id = space->num_vars;
  int * ids;
  ids = ponos_space_get_coefs (space, PONOS_VAR_DELTA);
  for (i = 0; ids[i] != -1; i++)
    if (ids[i] < min_id)
      min_id = ids[i];
  int shift = i / space->num_sched_dim;

  int delta_ids[3]; 
  delta_ids[2] = -1;
  int linW[2];
  int scaW[2];
  for (i = 0; i < n_dep; i++)
  {
    int dist;
    // set sumDL = delta_1 + delta_3
    delta_ids[0] = min_id + i + shift;
    delta_ids[1] = min_id + i + 3 * shift;

    CandlDependence * dep;
    dep = (CandlDependence*)(space->vars[min_id+i]->scop_ptr);
    if (dep->source != dep->target)
    {
      // inter statement dependence: prefer: distribution
      dist = 1;
      if (pattern == PAT_STENCIL)
      {
        linW[0] = 1;
        linW[1] = 5;
        scaW[0] = 5; 
        scaW[1] = 5;
        weights[2*i] = 1;   // linear weights
        weights[2*i+1] = 2; // scalar weights
      }
      else
      {
        int use_outer = ponos_chunked_scop_can_use_outer_parallelism (
            space, options, cinfo, CG);
        if (use_outer)
        {
          linW[0] = 3;
          linW[1] = 4;
        }
        else
        {
          linW[0] = 4;
          linW[1] = 3;
        }
        scaW[0] = 1; 
        scaW[1] = 3;
        weights[2*i] = 2;   // linear weights
        weights[2*i+1] = 1; // scalar weights
      }
      //printf ("Dependence %s has weights %d,%d,%d,%d\n",space->vars[min_id+i]->name,linW[0],linW[1],scaW[0],scaW[1]);
    }
    else
    {
      // self-dependence: obviously prefeer outer parallelism over 2nd outer par
      /*
      if (SA[dep->source->label]->nb_iterators <= 2)
      {
        dist = 1;
        linW[0] = 2;
        linW[1] = 1;
        scaW[0] = 5; 
        scaW[1] = 5;
      }
      else 
        */
      {
        if (pattern == PAT_SOLVER)
        {
          // For solver-like pattern, force dependence satisfaction on the outermost two dimensions.
          // Then, prefer linear level 1 over linear level 2
          dist = 1;
          linW[0] = 1;
          linW[1] = 2;
        }
        else if (pattern == PAT_GEMM)
        {

          int use_outer = ponos_chunked_scop_can_use_outer_parallelism (
            space, options, cinfo, CG);
          dist = 0;
          // Interpretation: lower weight means the dependence will try to be satisfied at that level
          // for gemm, leave it as 1,2;
          // for syr2k, invert to 2,1
          if (use_outer)
          {
            linW[0] = 1;
            linW[1] = 2;
          }
          else
          {
            linW[0] = 2;
            linW[1] = 1;
          }
        }
        else if (pattern == PAT_MATVEC)
        {
          dist = 0;
          linW[0] = 2;
          linW[1] = 1;
        } 
        else
        {
          dist = 1;
          linW[0] = 1;
          linW[1] = 2;
        }
        scaW[0] = 5; 
        scaW[1] = 5;
      }
      weights[2*i] = 1;
      weights[2*i+1] = 2;
    }
    outer_ids[2*i] = i+1;

    //printf ("Adding weighted constraints to outer linear dimensions ...\n");
    ponos_space_create_weighted_summation (space, i+1, 1, delta_ids, linW,
      PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

    int ub = n_dep;

    // set sumDS = delta_0 + delta_2
    delta_ids[0] = min_id + i;
    delta_ids[1] = min_id + i + 2 * shift;
    outer_ids[2*i+1] = start + i + 1;
    //printf ("Adding weighted constraints to outer scalar dimensions ...\n");
    ponos_space_create_weighted_summation (space, start + i + 1, 1, delta_ids, scaW,
      PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);


    // set sumDL + sumDS <= 1
    delta_ids[0] = i+1;
    delta_ids[1] = start + i+1;
    //printf ("Adding non-weighted constraints to potentially force dependence satisfaction on scalar and linear dimensions ...\n");
    ponos_space_create_summation (space, -1, delta_ids, 
      PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, dist);

  }

  outer_ids[2*n_dep] = -1;
  ponos_space_create_weighted_summation (space, 0, 1, outer_ids, weights,
    PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  XFREE (outer_ids);
  XFREE (ids);
}


/*
 * Inner Parallelism (IP) objective:
 * Use \psi variables to maximize parallelism at the innermost
 * schedule level. This, in turn, minimizes the number of dependences
 * satisfied at the same level.
 */
void
ponos_perfidiom_inner_parallelism (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, 
  s_chunked_graph_t * CG, int clusterid, int * filter)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  s_fnode_t * fnode = &CG->fgraph->nodes[clusterid];

  double timer_start, timer_end;
  timer_start = rtclock ();

  if (clusterid == SINGLECLUSTER)
  {
    int n_chunks;
    int CS = 4;
    n_chunks = CI->n_dep / CS;
    if (CI->n_dep % CS > 0)
      n_chunks++;
    int ii;
    for (ii = 0; ii < n_chunks; ii++)
    {
      char buffer[32]; 
      s_ponos_var_t* optvar ;

      // Create the stride var
      sprintf (buffer, "INNER_PAR_CHUNK%d",ii);
      optvar =
        ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, ii, 0, 0, NULL);
      ponos_space_insert_variable_first (space, optvar);
    }
    int * ids;
    ids = ponos_space_get_coefs_dim (
      space, space->num_sched_dim - 2, PONOS_VAR_DELTA);
    int jj = 0;
    int jds[CS+1];
    for (ii = 0; ii < n_chunks; ii++)
    {
      int kk;
      for (jj = 0, kk = 0; jj < CS && ids[CS*ii + jj] != -1; jj++)
      {
        //jds[jj] = ids[CS*ii + jj]; 
        int varid = ids[CS*ii + jj]; 
        scoplib_statement_p stmt = (scoplib_statement_p)(space->vars[varid]->scop_ptr);
        if (stmt->nb_iterators < space->num_sched_dim / 2)
          continue;
        jds[kk++] = varid;
      }
      jds[kk] = -1;
      ponos_space_create_summation (space, ii, jds, 
        PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
    }
    XFREE (ids);
  }
  else
  {
    int depth;
    scoplib_statement_p stmt;
    int idx;

    // Create the stride var
    char buffer[100]; 
    s_ponos_var_t* optvar;
    sprintf (buffer, "INNER_PAR_CHUNK%d_NEG",clusterid);
    optvar = ponos_space_var_create (
      buffer, PONOS_VAR_OPT_SUM_VAR, clusterid, 0, 0, NULL);
    ponos_space_insert_variable_first (space, optvar);

    sprintf (buffer, "INNER_PAR_CHUNK%d_POS",clusterid);
    optvar = ponos_space_var_create (
      buffer, PONOS_VAR_OPT_SUM_VAR, clusterid, 0, 0, NULL);
    ponos_space_insert_variable_last (space, optvar);

    // Collect all psi variables. Below we select the corresponding
    // innermost dimension depending on the number of iterators that
    // a statement has.
    int * psi_ids = collect_psi_ids_from_cluster (space, CI, -1, filter);
    int n_psi = count_ids (psi_ids);
    //fprintf (CI->logfile, "Number of collected psi variables: %d\n", n_psi);
    int * ids = XMALLOC (int, n_psi + 1);
    int * WW = XMALLOC (int, n_psi + 1);
    int count = 0;
    for (int idx = 0; idx < CI->n_stmt; idx++)
      if (filter[idx])
    {
      int dim = CI->SA[idx]->nb_iterators;
      if (dim <= 2)
        continue;
      for (int ii = 0; psi_ids && psi_ids[ii] != -1; ii++)
      {
        s_ponos_var_t * ponvar = space->vars[psi_ids[ii]];
        //fprintf (CI->logfile, "PSI var (%p), cand = %p, levels : %d - %d\n",
        //  ponvar->scop_ptr, CI->SA[idx], ponvar->dim, dim * 2 -1);
        if ((scoplib_statement_p)(ponvar->scop_ptr) == CI->SA[idx] && 
            ponvar->dim == dim * 2 - 1)
        {
          ids[count] = psi_ids[ii];
          WW[count] = 1;
          fprintf (CI->logfile, "Contents of ids[%d] = %d\n",count, ids[count]);
          count++;
        }
      }
    }
    fprintf (CI->logfile, "Count variable is %d\n",count);
    ids[count] = -1;

    // We do not need to create a constraint for the optimum if we haven't
    // found any 
    if (count > 0)
    {
      fprintf (CI->logfile, "Inserting inner parallelism (IP) performance objective\n");
      ponos_space_create_weighted_summation (space, space->num_vars - 1, 1, ids, WW,
        PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

      int jds[3];
      jds[0] = 0;
      jds[1] = space->num_vars - 1;
      jds[2] = -1;
      int weights[2];
      weights[0] = weights[1] = 1;
      ponos_space_create_weighted_summation (space, -1, 0, jds, weights,
        PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, count);
    }
    ponos_chunked_set_var_lb_ub (space, 0, 1, 0, count);
    ponos_chunked_set_var_lb_ub (space, space->num_vars - 1, 1, 0, count);
    ponos_space_var_set_bounds (space->vars[0], 0, count);
    ponos_space_var_set_bounds (space->vars[space->num_vars - 1], 0, count);
    XFREE (psi_ids);
    XFREE (ids);
    XFREE (WW);

  }

  timer_end = rtclock ();
 fprintf (CI->logfile, "[Ponos/Chunked] Max.InnerPar time: %.4fs\n",timer_end - timer_start);
}


void
ponos_perfidiom_skew_parallelism (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, 
  s_chunked_graph_t * CG, int clusterid, int * filter)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int nodetype = CG->fgraph->nodes[clusterid].nodetype;

  // Create the stride var
  char buffer[100]; 
  s_ponos_var_t* frontvars[4];
  s_ponos_var_t* backvar;

  sprintf (buffer, "SKWPAR_SUM_DELTA_CHUNK%d_NEG",clusterid);
  frontvars[0] = ponos_space_var_create (
    buffer, PONOS_VAR_OPT_SUM_VAR, clusterid, 1, 0, NULL);

  sprintf (buffer, "SKWPAR_SUM_THETA_CHUNK%d",clusterid);
  frontvars[1] = ponos_space_var_create (
    buffer, PONOS_VAR_OPT_SUM_VAR, clusterid, 1, 0, NULL);

  ponos_space_bulk_variable_insertion_at_start (space, frontvars, 2);

  sprintf (buffer, "SKWPAR_SUM_DELTA_CHUNK%d_POS",clusterid);
  backvar = ponos_space_var_create (
    buffer, PONOS_VAR_OPT_SUM_VAR, clusterid, 1, 0, NULL);
  ponos_space_insert_variable_last (space, backvar);


  int * delta_ids = collect_delta_ids_from_cluster (space, CI, 1, filter);
  int * theta_ids = collect_theta_ids_from_cluster (space, CI, 1, filter, PONOS_VAR_THETA_ITER);

  int nn;

  /*
  for (nn = 0; delta_ids && delta_ids[nn] != -1; nn++)
  {
    s_ponos_var_t * delta_var = space->vars[delta_ids[idx]];
    CandlDependence* dep = ((CandlDependence*)(delta_var->scop_ptr));
    if (!filter[dep->source->label] || !filter[dep->target->label])
      continue;
  }
  */

  for (nn = 0; delta_ids && delta_ids[nn] != -1; nn++);
  ponos_space_var_set_bounds (space->vars[0], -nn, nn);
  int WW[nn+1];
  for (nn = 0; delta_ids && delta_ids[nn] != -1; nn++)
    WW[nn] = -1;
  int n_dep = nn;

  for (nn = 0; theta_ids && theta_ids[nn] != -1; nn++);
  ponos_space_var_set_bounds (space->vars[1], 0, CI->n_stmt * options->schedule_bound );

  ponos_space_create_summation (space, 1, theta_ids, 
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  ponos_space_create_weighted_summation (space, space->num_vars - 1, -1, delta_ids, WW,
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, n_dep);

  int ids[3];
  ids[0] = 0;
  ids[1] = space->num_vars - 1;
  ids[2] = -1;
  WW[0] = 1;
  WW[1] = 1;

  ponos_space_create_weighted_summation (space, -1, 1, ids, WW,
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, n_dep);
  
  ponos_space_var_set_bounds (space->vars[0], 0, n_dep);
  ponos_space_var_set_bounds (space->vars[ids[1]], 0, n_dep);

  XFREE (delta_ids);
  XFREE (theta_ids);
}


/*
 * Create \psi variables for each statement and linear schedule level.
 * Abort if it already has been invoked by some other objective.
 * For each statement S and schedule dimension l, create the boolean PSI_S_l.
 * For each \delta^{R,S}_l, l linear dimension do:
 *  \psi^R_l >= 1 - \delta^{R,S}_l and 
 *  \psi^S_l >= 1 - \delta^{R,S}_l
 * Then create:
 *  SUM_PSI_CLUSTER_POS_l = \sum_S \psi^S_l
 * Also:
 *  0 <= SUM_PSI_CLUSTER_NEG_l, SUM_PSI_CLUSTER_POS_l <= cluster_size
 * Only create optima variables for the given level (@level).
 * Include all if @level = -1
 */
void 
ponos_perfidiom_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter, int level)
{
  if (! space || !space->vars || !space->space || !space->scop || !filter)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  // Determine the cluster size.
  int n_stmt = CI->n_stmt;
  int cluster_size = (clusterid == SINGLECLUSTER ? 
    CI->n_stmt : CG->fgraph->nodes[clusterid].n_members);
  int ii;
  char buffer[100];

  // Abort function if it already has been previously invoked.
  // Works fine with multiple invocations to the same level.
  // FIXME:
  // Might have some issues when invoking with level=-1 after invoking
  // for some specific level.
  int * checkids = collect_psi_ids_from_cluster (space, CI, level, filter);
  int already_embedded = checkids && checkids[0] != -1;
  XFREE (checkids);
  if (already_embedded)
    return;

  // Create the psi variables at the (current) end of the system.
  int var_start = space->num_vars;
  s_ponos_var_t ** newvars;
  newvars = XMALLOC (s_ponos_var_t*, n_stmt * space->num_sched_dim + 1);
  int count = 0;
  int offset[n_stmt];
  for (ii = 0; ii < n_stmt; ii++)
    if (filter[ii])
  {
    offset[ii] = var_start + count;
    for (int ll = 0; ll < space->num_sched_dim; ll++)
    {
      sprintf (buffer, "PSI_S%d_L%d",ii,ll);
      newvars[count++] = ponos_space_var_create (buffer, 
        PONOS_VAR_PSI, ll, 0, 0, CI->SA[ii]);
      ponos_space_insert_variable_last (space, newvars[count-1]);
      ponos_space_var_set_boolean (newvars[count-1]);
    }
  }
  // New variables are added as: S0_l0, S0_l1,.. S0_lD, S1_l0...
  //ponos_space_bulk_variable_insertion_at_end (space, newvars, count);
  fprintf (CI->logfile, "Number of variables pre-bulk insertion: %d (after = %d)\n",var_start,space->num_vars);
  for (int vv = 0; vv < count; vv++)
  {
    int shift = var_start;
    int ll = space->vars[shift+vv]->dim;
    int ub = (ll % 2 == 1 ? 1 : 0);
    //fprintf (CI->logfile, "The variable that was inserted was %s\n",space->vars[shift+vv]->name);
    ponos_chunked_set_var_lb_ub (space, shift+vv, 1, 0, ub);
  }
  XFREE (newvars);

  // Although we create psi variables for all the schedule dimensions,
  // they actually only make sense for the linear dimensions.
  for (int ll = 0; ll < space->num_sched_dim; ll++)
    if (ll % 2 == 1)
  {
    // For each \delta^{R,S}_l do:
    // \psi^S_l <= 1 - \delta^{R,S}_l
    // \psi^R_l <= 1 - \delta^{R,S}_l
    // i.e. if the dependence is satisfied at level l, then 
    // parallelism is nullified.
    int * delta_ids = collect_delta_ids_from_cluster (space, CI, ll, filter);
    int ii;
    int n_dep = count_ids (delta_ids);
    //fprintf (CI->logfile, "number of dependence variables collected: %d\n",n_dep);
    for (ii = 0; ii < n_dep; ii++)
    {
      int varid = delta_ids[ii];
      CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
      int stmt_src_id = dep->source->label;
      int stmt_dst_id = dep->target->label;

      int src_offset = offset[stmt_src_id] + ll;
      int dst_offset = offset[stmt_dst_id] + ll;

     //fprintf (CI->logfile, "Variable used : %s\n",space->vars[varid]->name);
     //fprintf (CI->logfile, "Variable used : %s\n",space->vars[src_offset]->name);
     //fprintf (CI->logfile, "Variable used : %s\n",space->vars[dst_offset]->name);

      int ids[3];
      int WW[2];
      // Do: 1 - psi^S_k - delta^{R,S} >= 0
      ids[0] = varid;
      ids[1] = src_offset;
      ids[2] = -1;
      WW[0] = -1;
      WW[1] = -1;

      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, -1);

      // Do: 1 - psi^R_k - delta^{R,S} >= 0
      ids[1] = dst_offset;
      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, -1);

    }
    XFREE (delta_ids);
  }

  // Create sum optimization variables, both neg and pos.
  // As usual, neg are bulk inserted at the beginning and the pos
  // are inserted at the end.
  // Bounds for both are set.
  // Also enforce the constraint: neg + pos = cluster_size
  // Note also that each PSI_SUM_CLUSTER variable is bounded
  // by the number of statements in the cluster.
  // This is ok since we have one PSI_SUM_CLUSTER variable per level.
  // Indirectly this maximizes the number of parallel dimensions.
  #if 1
  s_ponos_var_t ** frontvars;
  frontvars = XMALLOC (s_ponos_var_t *, space->num_sched_dim + 1);
  count = 0;
  for (int ll = 0; ll < space->num_sched_dim; ll++)
    if (ll % 2 == 1 && (ll == level || level == -1))
  {
    sprintf (buffer, "PSI_SUM_CLUSTER%d_L%d_NEG",clusterid,ll);
    frontvars[count] = ponos_space_var_create (buffer, 
      PONOS_VAR_OPT_SUM_VAR, ll, 0, 0, NULL);
    ponos_space_var_set_bounds (frontvars[count], 0, cluster_size);
    count ++;
  }
  frontvars[count] = NULL;
  ponos_space_bulk_variable_insertion_at_start (space, frontvars, count);
  int start_back = space->num_vars;
  for (int ll = 0; ll < space->num_sched_dim; ll++)
    if (ll % 2 == 1 && (ll == level || level == -1))
  {
    sprintf (buffer, "PSI_SUM_CLUSTER%d_L%d_POS",clusterid,ll);
    s_ponos_var_t * posvar  = ponos_space_var_create (buffer, 
      PONOS_VAR_OPT_SUM_VAR, ll, 0, 0, NULL);
    ponos_space_var_set_bounds (posvar, 0, cluster_size);
    ponos_space_insert_variable_last (space, posvar);
    ponos_space_var_skip_cplex (posvar);
  }
  for (int ll = 0, count = 0; ll < space->num_sched_dim; ll++)
    if (ll % 2 == 1 && (ll == level || level == -1))
  {
    int * psi_vars = collect_psi_ids_from_cluster (space, CI, ll, filter);

    int kk;
    int n_psi = count_ids (psi_vars);
    if (n_psi < cluster_size)
    {
     fprintf (CI->logfile, "found %d psi variables, expected %d\n",kk, cluster_size);
     fprintf (CI->logfile, "WARNING: FOUND LESS PSI VARIABLES THAN EXPECTED.\n");
     fprintf (CI->logfile, "Possible reason: #of non-full dimensional statements.\n");
    }
    int * WW = XMALLOC (int, n_psi + 1);
    for (kk = 0; kk <= n_psi; kk++)
      WW[kk] = 1;

    // psi_sum_k_neg + psi_sum_k_pos = cluster_size
    int ids[3];
    ids[0] = count;
    ids[1] = start_back + count;
    ids[2] = -1;
    int ZZ[2];
    ZZ[0] = 1;
    ZZ[1] = 1;
    for (kk = 0; ids && ids[kk] != -1; kk++)
    {
     fprintf (CI->logfile, "+ %d %s ", ZZ[kk], space->vars[ids[kk]]->name);
    }
   fprintf (CI->logfile, "\n");
    ponos_space_create_weighted_summation (space, -1, 1, ids, ZZ,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, cluster_size);

    if (n_psi == 0)
    {
      XFREE (psi_vars);
      continue;
    }

    for (kk = 0; psi_vars && psi_vars[kk] != -1; kk++)
    {
      fprintf (CI->logfile, "+ %d %s ", WW[kk], space->vars[psi_vars[kk]]->name);
    }
    fprintf (CI->logfile, "\n");

    // psi_sum_k_pos <= \sum psi_k
    ponos_space_create_weighted_summation (
      space, start_back + count, 1, psi_vars, WW,
      PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MAXIMIZE, 0);

    XFREE (psi_vars);
    XFREE (WW);
    count++;
  }
  XFREE (frontvars);
  #endif

  timer_end = rtclock ();
 fprintf (CI->logfile, "[Ponos/Chunked] PSI Parallelism time: %.4fs\n",timer_end - timer_start);
}


void 
ponos_perfidiom_outer_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter, int level)
{
  if (! space || !space->vars || !space->space || !space->scop || !filter)
    return;

  if (level % 2 == 0)
  {
    printf ("ponos/iparallelism.c: WARNING! Attempting to use outer parallelism");
    printf (" performance idiom on a scalar dimension.");
    return;
  }

  if (level > CG->fgraph->nodes[clusterid].max_depth * 2 - 1)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  // Determine the cluster size.
  int n_stmt = CI->n_stmt;

  char buffer[100]; 
  s_ponos_var_t* optvar;
  sprintf (buffer, "OPAR_L%d_CHUNK%d_NEG",(level<0?99:level),clusterid);
  optvar = ponos_space_var_create (
    buffer, PONOS_VAR_OPT_SUM_VAR, clusterid, 0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);

  sprintf (buffer, "OPAR_L%d_CHUNK%d_POS",(level<0?99:level),clusterid);
  optvar = ponos_space_var_create (
    buffer, PONOS_VAR_OPT_SUM_VAR, clusterid, 0, 0, NULL);
  ponos_space_insert_variable_last (space, optvar);

  int last = space->num_vars - 1;

  int nn;
  int * psi_ids = collect_psi_ids_from_cluster (space, CI, level, filter);
  for (nn = 0; psi_ids && psi_ids[nn] != -1; nn++);

  ponos_space_create_summation (space, last, psi_ids, 
    PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  int opt[3];
  opt[0] = 0;
  opt[1] = last;
  opt[2] = -1;

  ponos_space_create_summation (space, -1, opt, 
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, nn);

  ponos_chunked_set_var_lb_ub (space, 0, 1, 0, nn);
  ponos_space_var_set_bounds (space->vars[0], 0, nn);

  ponos_chunked_set_var_lb_ub (space, last, 1, 0, nn);
  ponos_space_var_set_bounds (space->vars[last], 0, nn);

  XFREE (psi_ids);
}


void 
ponos_perfidiom_force_dependence_at_level (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter, int level)
{
  if (! space || !space->vars || !space->space || !space->scop || !filter)
    return;

  if (level > CG->fgraph->nodes[clusterid].max_depth * 2)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  int n_stmt = CI->n_stmt;

  char buffer[100]; 
  s_ponos_var_t* optvar;
  sprintf (buffer, "MAXDEP_L%d_CHUNK%d_NEG",(level<0?99:level),clusterid);
  optvar = ponos_space_var_create (
    buffer, PONOS_VAR_OPT_SUM_VAR, clusterid, 0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);

  sprintf (buffer, "MAXDEP_L%d_CHUNK%d_POS",(level<0?99:level),clusterid);
  optvar = ponos_space_var_create (
    buffer, PONOS_VAR_OPT_SUM_VAR, clusterid, 0, 0, NULL);
  ponos_space_insert_variable_last (space, optvar);

  int last = space->num_vars - 1;

  int nn;
  int * delta_ids = collect_delta_ids_from_cluster (space, CI, level, filter);
  for (nn = 0; delta_ids && delta_ids[nn] != -1; nn++);

  ponos_space_create_summation (space, last, delta_ids, 
    PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  int opt[3];
  opt[0] = 0;
  opt[1] = last;
  opt[2] = -1;

  ponos_space_create_summation (space, -1, opt, 
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, nn);

  ponos_chunked_set_var_lb_ub (space, 0, 1, 0, nn);
  ponos_space_var_set_bounds (space->vars[0], 0, nn);

  ponos_chunked_set_var_lb_ub (space, last, 1, 0, nn);
  ponos_space_var_set_bounds (space->vars[last], 0, nn);

  XFREE (delta_ids);
}


void 
ponos_perfidiom_minimize_iterator_coefficient_sum (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter, int level)
{
  if (! space || !space->vars || !space->space || !space->scop || !filter)
    return;

  if (level > CG->fgraph->nodes[clusterid].max_depth * 2)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  // Determine the cluster size.
  int n_stmt = CI->n_stmt;


  char buffer[100]; 
  s_ponos_var_t* optvar;
  sprintf (buffer, "sum_theta_iter_L%d_CHUNK%d_NEG",(level<0? 99 : level),clusterid);
  optvar = ponos_space_var_create (
    buffer, PONOS_VAR_OPT_SUM_VAR, clusterid, 0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);


  int last = space->num_vars - 1;

  int nn;
  int * theta_ids = collect_theta_ids_from_cluster (space, CI, level, filter, PONOS_VAR_THETA_ITER);
  for (nn = 0; theta_ids && theta_ids[nn] != -1; nn++);

  ponos_space_create_summation (space, 0, theta_ids, 
    PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  int opt[3];
  opt[0] = 0;
  opt[1] = last;
  opt[2] = -1;


  ponos_chunked_set_var_lb_ub (space, 0, 1, 0, nn);
  ponos_space_var_set_bounds (space->vars[0], 0, nn);

  XFREE (theta_ids);
}
