/*
 * iparloc.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012-2018 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Authors:
 * Martin Kong <martin.richard.kong@gmail.com>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>
#include <ponos/objectives.h>
#include <ponos/codelet.h>
#include <ponos/chunked.h>

#include <time.h>
#include <sys/time.h>
#include "iutil.c"


/*
 * For each dependence variable \delta, if necessary, try to choose between 
 * outer parallelism and outer distribution.
 * Basically we do: \deltaK_0 + \deltaK_1 <= 1
 */
void 
ponos_chunked_constraints_fusion_par (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo,
    int n_dep)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  int * ids;
  int min_id = space->num_vars;
  ids = ponos_space_get_coefs (space, PONOS_VAR_DELTA);
  for (i = 0; ids[i] != -1; i++)
    if (ids[i] < min_id)
      min_id = ids[i];
  int shift = i / space->num_sched_dim;

  int delta_ids[3]; 
  delta_ids[2] = -1;
  for (i = 0; i < n_dep; i++)
  {
    delta_ids[0] = min_id + i;
    delta_ids[1] = min_id + i + shift;
    ponos_space_create_summation (space, -1, delta_ids, 
      PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);
  }
  XFREE (ids);
}



/*
 * Add all the delta variables associated to each scalar and linear dimensions
 * into their own sum variables. Then guarantee that their sum must
 * be greater or equal to the number of dependences.
 */
void
ponos_chunked_scalar_dependence_objective (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int max_dim = 2 * CI->max_dim + 1;

  char buffer[32]; 

  int all[2 * CI->n_dep + 1];
  s_ponos_var_t ** svars;
  svars = XMALLOC (s_ponos_var_t*, max_dim);
  int nd = 0;
  for (i = 0; i < max_dim; i++)
  {
    sprintf (buffer, "sum_delta_sca_%d_neg", i);
    svars[i] = ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, i, 0, 0, NULL);
    all[nd++] = i;
  }

  ponos_space_bulk_variable_insertion_at_start (space, svars, max_dim);

  int pos_start = space->num_vars;
  for (i = 0; i < max_dim; i++)
  {
    sprintf (buffer, "sum_delta_sca_%d_pos", i);
    svars[i] = ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, i, 0, 0, NULL);
    ponos_space_insert_variable_last (space, svars[i]);
    all[nd++] = pos_start + i;
  }
  all[nd] = -1;

  XFREE (svars);

  for (i = 0; i < max_dim; i++)
  {
    int* ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_DELTA);
    int tempid[CI->n_dep+1];
    int jj;
    int kk;
    for (jj = 0, kk = 0; ids && ids[jj] != -1; jj++)
    {
      int varid = ids[jj];
      CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
      int src_id = dep->source->label;
      int dst_id = dep->target->label;
      if (src_id == dst_id)
        continue;
      tempid[kk++] = varid;
    }
    tempid[kk] = -1;

    if (i % 2 == 0)
    {
      // Do: sum_delta_sca_K_pos = \sum \delta_i for all inter-statement deps
      ponos_space_create_summation (space, pos_start + i, tempid, 
        PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
    }

    int ub = CI->n_dep - CI->n_self_dep;
    // bound the pos variables
    ponos_codelet_create_ge_cst (space, pos_start + i, -1, -ub);
    ponos_codelet_create_ge_cst (space, pos_start + i, 1, 0);

    // bound the neg variables
    ponos_codelet_create_ge_cst (space, i, -1, -ub);
    ponos_codelet_create_ge_cst (space, i, 1, 0);

    ids[0] = i;
    ids[1] = pos_start + i;
    ids[2] = -1;

    ponos_space_create_summation (space, -1, ids,
      PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);

    XFREE (ids);
  }
  ponos_space_create_summation (space, -1, all,
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, CI->n_dep - CI->n_self_dep);
}



void 
ponos_chunked_optimize_reuse (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  int i, j;
  int nstmt = CI->n_stmt;
  scoplib_statement_p stmt;
  
  s_chunked_statement_info_t * SI;
  SI = XMALLOC (s_chunked_statement_info_t, nstmt);
  int idx;
  for (stmt=space->scop->statement, idx=0; stmt; stmt = stmt->next, idx++)
  {
    SI[idx].id = idx;
    SI[idx].n_ref = 0;
    SI[idx].scop_stmt = stmt;
    SI[idx].n_dim = stmt->nb_iterators;
    SI[idx].ref = XMALLOC (s_chunked_ref_info_t, 1);
  }

  fprintf (CI->logfile, "Created statement info array ...\n");

  for (idx = 0; idx < nstmt; idx++)
  {
    stmt = SI[idx].scop_stmt;
   fprintf (CI->logfile, "Collecting info of statement %d (%s)...\n",idx,stmt->body);
    scoplib_matrix_p refs;
    refs = stmt->read;
    int n_iter = stmt->nb_iterators;
    int col;
    
    // Determine the number of read references by counting the number 
    // of non-zeros on the first column of the matrix
    int row;
    int n_rows = refs->NbRows;
    int ranges[n_rows+1];
    int n_refs = 0;
   fprintf (CI->logfile, "Collected ranges ...\n");
    for (row = 0; row < n_rows; row++)
      if (SCOPVAL_pos_p(refs->p[row][0]))
    {
      ranges[n_refs++] = row;
    }
    ranges[n_refs] = row;
    SI[idx].n_ref = n_refs + 1; // the +1 is for the written ref (lhs)
    // Allocate an array of reference info
   fprintf (CI->logfile, "Allocating %d references on statement %d\n",SI[idx].n_ref,idx);
    SI[idx].ref = XMALLOC (s_chunked_ref_info_t, SI[idx].n_ref);
    int jref;
    // For each reference, allocate space for its iterator mask
    // and initialize it to a zero vector
    // Then, populate it by traversing the scoplib_matrix pointers
    int ref_id = 0;
    // references ids start from 0 on the read list
    int n_non_const_ref = 0;
    for (jref = 0; jref < n_refs; jref++)
    {
     fprintf (CI->logfile, "Collecting info of statement %d, reference %d ...\n",idx,jref);
      SI[idx].ref[jref].mask = XMALLOC (int, n_iter);
      SI[idx].ref[jref].id = ref_id++;
      int iter;
      for (iter = 0; iter < n_iter; iter++)
        SI[idx].ref[jref].mask[iter] = 0;
      // Collect information from each array reference
      int is_const_ref = 1;
      int n_ref_iter = 0;
      for (iter = ranges[jref]; iter < ranges[jref+1]; iter++)
      {
        SI[idx].ref[jref].row_start = ranges[jref];
        // For the given row (iter) set the mask entry to 1 if the
        // respective column is non-zero
        for (col = 1; col <= n_iter; col++)
        {
          if (SCOPVAL_notzero_p(refs->p[iter][col]))       
          {
           SI[idx].ref[jref].mask[col-1] ++;
           n_ref_iter++;
           is_const_ref = 0;
          }
        }
        SI[idx].ref[jref].n_dim = n_ref_iter;
        SI[idx].ref[jref].is_const = n_ref_iter == 0;
      }
      if (n_ref_iter > 0)
      {
        n_non_const_ref++;
      }
    }

   fprintf (CI->logfile, "Collecting info of write ref of statement %d ...\n",idx);
    refs = stmt->write;
    int n_ref_iter = 0;
   fprintf (CI->logfile, "Write ref = %d, #refs on statement %d = %d\n",jref,idx,SI[idx].n_ref);
    // Do the same for the write reference
    SI[idx].ref[jref].mask = XMALLOC (int, n_iter);
    SI[idx].ref[jref].id = ref_id++;
    for (row = 0; row < refs->NbRows; row++)
      for (col = 1; col <= n_iter; col++)
    {
      if (SCOPVAL_notzero_p(refs->p[row][col]))       
      {
        SI[idx].ref[jref].mask[col-1] ++;
        n_ref_iter++;
      }
    }
   fprintf (CI->logfile, "Pretty much done with statement %d...\n",idx);
    if (n_ref_iter > 0)
    {
      n_non_const_ref++;
    }
    SI[idx].ref[jref].is_const = n_ref_iter == 0;
    SI[idx].ref[jref].n_dim = refs->NbRows;
    SI[idx].n_non_const_ref = n_non_const_ref;
  }
 fprintf (CI->logfile, "Done collecting array info\n");

  int n_new_vars = 0;
  for (idx = 0; idx < nstmt; idx++)
  {
   fprintf (CI->logfile, "Counting %d + 1 variables for statement %d\n",SI[idx].n_non_const_ref,idx);
    n_new_vars += SI[idx].n_non_const_ref + 1;
  }

 fprintf (CI->logfile, "Creating %d new variables ...\n",n_new_vars);

  char buffer[100]; 
  s_ponos_var_t** optvar ;
  optvar = XMALLOC (s_ponos_var_t*, n_new_vars);
  
  int ii;
  // Create the objective variable for each statement in leading position
  for (ii = 0; ii < nstmt; ii++)
  {
    sprintf (buffer, "OUTER_STRIDE_S%d",ii);
    optvar[ii] = ponos_space_var_create (buffer, 
      PONOS_VAR_BIN_USERDEF, 0, 0, 0, SI[ii].scop_stmt);

  }
  fprintf (CI->logfile, "Done creating OUTER_STRIDE_S# variables ...\n");

  int kk = nstmt;
  // Create the reference cost variables aftet the statement cost variables
  for (ii = 0; ii < nstmt; ii++)
  {
    int jj;
    for (jj = 0; jj < SI[ii].n_ref; jj++)
    {
      if (SI[ii].ref[jj].is_const)
        continue;
      sprintf (buffer, "OUTER_STRIDE_S%d_%d",ii,jj);
      assert (kk < n_new_vars);
      optvar[kk++] = ponos_space_var_create (buffer, 
        PONOS_VAR_BIN_USERDEF, 0, 0, 0, NULL);
      fprintf (CI->logfile, "Done creating OUTER_STRIDE_S%d_%d variable ...\n",ii,jj);
    }
  }

  fprintf (CI->logfile, "Performing bulk insertion ...\n");
  ponos_space_bulk_variable_insertion_at_start (space, optvar, n_new_vars);
  for (ii = n_new_vars - 1; ii >= 0; ii--)
  {
  //  ponos_space_insert_variable_first (space, optvar[ii]);
  }
  XFREE (optvar);

  for (ii = 0; ii < n_new_vars; ii++)
  {
   fprintf (CI->logfile, "%s(%d) ",space->vars[ii]->name,ii);
  }
  fprintf (CI->logfile, "\n");


  fprintf (CI->logfile, "Adding reuse constraint for each statement ...\n");
  // create the constraints of type OUTER_STRIDE_S% = \sum OUTER_STRIDE_S%_%d
  int offset = nstmt;
  for (ii = 0; ii < nstmt; ii++)
  {
    int n_iter = SI[ii].n_dim;
    int ids[n_iter+1];
    int jj;
    ids[n_iter] = -1;
    //printf ("Constraint: %s = ",space->vars[ii]->name);
    fprintf (CI->logfile, "Constraint: [%d] = ",ii);
    for (jj = 0; jj < SI[ii].n_non_const_ref; jj++, offset++)
    {
      ids[jj] = offset;
      //printf (" + %s",space->vars[offset]->name);
     fprintf (CI->logfile, " + [%d]",offset);
    }
    ids[jj] = -1;
   fprintf (CI->logfile, "\n");

    ponos_space_create_summation (space, ii, ids,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
   fprintf (CI->logfile, "Created reuse constraint for statement %d ...\n",ii);
  }

  // now create the constraints of type OUTER_STRIDE_S%_% = \sum \theta_i,j
  offset = nstmt;
  for (ii = 0; ii < nstmt; ii++)
  {
    int jj = 0;
    scoplib_statement_p stmt = SI[ii].scop_stmt;
    int n_iter = SI[ii].n_dim;
    int ids[n_iter * n_iter +1];
    int * theta_ids = ponos_space_get_coefs_stmt (
      space, stmt, PONOS_VAR_THETA_ITER);

    for (jj = 0; jj < SI[ii].n_ref; jj++)
    {
      if (SI[ii].ref[jj].is_const)
        continue;
      int row, col;
      int cc = 0;
      for (row = 0; row < n_iter; row++)
      {
        for (col = 0; col < n_iter; col++)
        {
          if (!SI[ii].ref[jj].mask[row])
            continue;
          if (!SI[ii].ref[jj].mask[col])
            continue;
          ids[cc++] = theta_ids[row * n_iter + col]; 
        }
      }
      ids[cc] = -1;
      ponos_space_create_summation (space, offset, ids,
        PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
      //printf ("Created reuse reference constraint for statement %d ...\n",ii,jj);
      offset++;
    }

    XFREE (theta_ids);
  }

  for (ii = 0; ii < nstmt; ii++)
  {
    int jj;
    for (jj = 0; jj < SI[ii].n_ref; jj++)
    {
     fprintf (CI->logfile, "Freeing mask of reference %d, statement %d\n",jj,ii);
      XFREE (SI[ii].ref[jj].mask);
    }
   fprintf (CI->logfile, "Freeing statement %d\n",ii);
    XFREE (SI[ii].ref);
  }
  XFREE (SI);

 fprintf (CI->logfile, "Done with all outer stride stuff\n");

  timer_end = rtclock ();
 fprintf (CI->logfile, "[Ponos/Chunked] Max.Reuse time: %.4fs\n",timer_end - timer_start);
}


/*
 *
 */
void 
ponos_perfidiom_outerpar_innerreuse (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, 
  int align_dims)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  int i, j;

  int nstmt = CI->n_stmt;
  scoplib_statement_p stmt;
  
  s_chunked_statement_info_t * SI;
  SI = XMALLOC (s_chunked_statement_info_t, nstmt);
  int idx;
  for (stmt=space->scop->statement, idx=0; stmt; stmt = stmt->next, idx++)
  {
    SI[idx].id = idx;
    SI[idx].n_ref = 0;
    SI[idx].scop_stmt = stmt;
    SI[idx].n_dim = stmt->nb_iterators;
    SI[idx].ref = XMALLOC (s_chunked_ref_info_t, 1);
    SI[idx].skip = 0;
  }

  // Populate the array structure info.
  // For each statement determine:
  // 1) Number of references in it
  // 2) Iterators used in each reference (number of iters too), if it's constant
  // 3) Store the scop pointer
  // 4) Dimensionality of statement
  CI->n_ref = 0;
  for (idx = 0; idx < nstmt; idx++)
  {
    stmt = SI[idx].scop_stmt;
    fprintf (CI->logfile, "Collecting info of statement %d (%s)...\n",idx,stmt->body);
    scoplib_matrix_p refs;
    refs = stmt->read;
    int n_iter = stmt->nb_iterators;
    int col;
    
    // Determine the number of read references by counting the number 
    // of non-zeros on the first column of the matrix
    int row;
    int n_rows = refs->NbRows;
    int ranges[n_rows+1];
    int n_refs = 0;
    
    for (row = 0; row < n_rows; row++)
      if (SCOPVAL_pos_p(refs->p[row][0]))
    {
      ranges[n_refs++] = row;
    }
    ranges[n_refs] = row;
    SI[idx].n_ref = n_refs + 1; // the +1 is for the written ref (lhs)
    // Allocate an array of reference info
   fprintf (CI->logfile, "Allocating %d references on statement %d\n",SI[idx].n_ref,idx);
    SI[idx].ref = XMALLOC (s_chunked_ref_info_t, SI[idx].n_ref);
    int jref;
    // For each reference, allocate space for its iterator mask
    // and initialize it to a zero vector
    // Then, populate it by traversing the scoplib_matrix pointers
    int ref_id = 0;
    // references ids start from 0 on the read list
    int n_non_const_ref = 0;
    for (jref = 0; jref < n_refs; jref++)
    {
     fprintf (CI->logfile, "Collecting info of statement %d, reference %d ...\n",idx,jref);
      SI[idx].ref[jref].mask = XMALLOC (int, n_iter);
      SI[idx].ref[jref].id = ref_id++;
      int iter;
      for (iter = 0; iter < n_iter; iter++)
        SI[idx].ref[jref].mask[iter] = 0;
      SI[idx].ref[jref].skip = 0;
      int space_dim;
      // Coef field is hard-wired to a 4x5 array!!!
      for (space_dim = 0; space_dim < 4; space_dim++)
      {
        for (iter = 0; iter < 5; iter++)
          SI[idx].ref[jref].coef[space_dim][iter] = 0;
      }
      // Collect information from each array reference
      int is_const_ref = 1;
      int n_ref_iter = 0;
      int iter_start = ranges[jref];
      int scop_array_id = SCOPVAL_get_si(refs->p[ranges[jref]][0]) - 1; // array names in scop matrix are 1-offset, not 0-offset
     fprintf (CI->logfile, "Found array %s on position %d (range=%d)\n",
        space->scop->arrays[scop_array_id],scop_array_id,ranges[jref]);
      SI[idx].ref[jref].name = space->scop->arrays[scop_array_id];
      for (iter = ranges[jref]; iter < ranges[jref+1]; iter++)
      {
        SI[idx].ref[jref].row_start = ranges[jref];
        // For the given row (iter) set the mask entry to 1 if the
        // respective column is non-zero
        int n_iter_in_dim = 0;
        for (col = 1; col <= n_iter; col++)
        {
          if (SCOPVAL_notzero_p(refs->p[iter][col]))       
          {
            SI[idx].ref[jref].mask[col-1] ++;
            n_ref_iter++;
            n_iter_in_dim ++;
            is_const_ref = 0;
            SI[idx].ref[jref].coef[iter - iter_start][col-1] = 1;
          }
        }
        SI[idx].ref[jref].n_dim = ranges[jref+1] - ranges[jref];//n_ref_iter;
        SI[idx].ref[jref].is_const = (n_ref_iter == 0);
        SI[idx].ref[jref].skip = SI[idx].ref[jref].skip || (n_iter_in_dim > 1);
      }
      if (n_ref_iter > 0)
      {
        n_non_const_ref++;
      }

      {
        int rr,cc;
       fprintf (CI->logfile, "Showing access function of collected read references S%d_%s\n",idx,SI[idx].ref[jref].name);
        for (rr = 0; rr < 4; rr++)
        {
          for (cc = 0; cc < 5; cc++)
           fprintf (CI->logfile, "%d ",SI[idx].ref[jref].coef[rr][cc]);
         fprintf (CI->logfile, "\n");
        }
      }
    }

   fprintf (CI->logfile, "Collecting info of write ref of statement %d ...\n",idx);
    refs = stmt->write;
    int n_ref_iter = 0;
   fprintf (CI->logfile, "Write ref = %d, #refs on statement %d = %d\n",jref,idx,SI[idx].n_ref);
    // Do the same for the write reference
    SI[idx].ref[jref].mask = XMALLOC (int, n_iter);
    SI[idx].ref[jref].id = ref_id++;
    int scop_array_id = SCOPVAL_get_si(refs->p[0][0]) - 1;
    SI[idx].ref[jref].name = space->scop->arrays[scop_array_id];

    // Initialize write ref mask and coef arrays (last jref is the write ref)
    {
      int iter;
      for (iter = 0; iter < n_iter; iter++)
        SI[idx].ref[jref].mask[iter] = 0;
      int space_dim;
      // Coef field is hard-wired to a 4x5 array!!!
      for (space_dim = 0; space_dim < 4; space_dim++)
      {
        for (iter = 0; iter < 5; iter++)
          SI[idx].ref[jref].coef[space_dim][iter] = 0;
      }
    }
    for (row = 0; row < refs->NbRows; row++)
    {
      int n_iter_in_dim = 0;
      for (col = 1; col <= n_iter; col++)
      {
        if (SCOPVAL_notzero_p(refs->p[row][col]))       
        {
          SI[idx].ref[jref].mask[col-1] ++;
          n_ref_iter++;
          SI[idx].ref[jref].coef[row][col-1] = 1;
          n_iter_in_dim ++;
        }
      }
      SI[idx].ref[jref].skip = SI[idx].ref[jref].skip || (n_iter_in_dim > 1);
    }
    
    {
      int rr,cc;
     fprintf (CI->logfile, "Showing access function of collected write reference S%d_%s\n",idx,SI[idx].ref[jref].name);
      for (rr = 0; rr < 4; rr++)
      {
        for (cc = 0; cc < 5; cc++)
         fprintf (CI->logfile, "%d ",SI[idx].ref[jref].coef[rr][cc]);
       fprintf (CI->logfile, "\n");
      }
    }
   fprintf (CI->logfile, "Pretty much done with statement %d...\n",idx);
    if (n_ref_iter > 0)
    {
      n_non_const_ref++;
    }
    SI[idx].ref[jref].is_const = (n_ref_iter == 0);
    SI[idx].ref[jref].n_dim = refs->NbRows;
    SI[idx].n_non_const_ref = n_non_const_ref;
    //SI[idx].ref[jref].skip = (n_iter_in_dim > 1);

    // skip the process for the statement if any ref must be skipped
    for (jref = 0; jref < n_refs; jref++)
    {
      SI[idx].skip =  SI[idx].skip || SI[idx].ref[jref].skip;
    }
    CI->n_ref += SI[idx].n_ref;
  }
 fprintf (CI->logfile, "Done collecting array info\n");

  // Count how many new vars will we need (objective vars and Z vars)
  // |Z^{S,F_A}| = min{iters(S)-1,dim(A)}
  // n_new_vars = \sum_{F \in S} |Z^F|
  // We also count the number of objectives we will have
  int n_new_vars = 0;
  int reusing_dim = 0; // maximum number of outer dimensions that induce reuse
  int ii;
  for (ii = 0; ii < nstmt; ii++)
  {
    int jj;
    for (jj = 0; jj < SI[ii].n_ref; jj++)
    {
      if (SI[ii].ref[jj].is_const)
        continue;
      //if (SI[ii].ref[jj].n_dim >= SI[ii].n_dim)
      //  continue;

      assert (SI[ii].ref[jj].n_dim >= 0 && SI[ii].ref[jj].n_dim <= 4);
      int min_dim = SI[ii].n_dim;
      if (SI[ii].ref[jj].n_dim < min_dim)
        min_dim = SI[ii].ref[jj].n_dim;
      if (min_dim > reusing_dim)
        reusing_dim = min_dim;
      n_new_vars += min_dim;
     fprintf (CI->logfile, "Adding %d variables for S%d_REF%d (newvars=%d)\n",min_dim,ii,jj,n_new_vars);
    }
  }
 fprintf (CI->logfile, "Will create %d new variables ...\n",n_new_vars);

  char buffer[100]; 
  s_ponos_var_t** optvar;
  optvar = XMALLOC (s_ponos_var_t*, nstmt);

  // Create the SUM_Z_S_neg variables
  for (ii = 0; ii < nstmt; ii++)
  {
    sprintf (buffer, "SUM_Z_S%d_neg",ii);
    optvar[ii] = ponos_space_var_create (buffer, 
      PONOS_VAR_BIN_USERDEF, ii, 0, 0, NULL);
  }
  // Perform bulk insertion
  ponos_space_bulk_variable_insertion_at_start (space, optvar, nstmt);
  XFREE (optvar);
  
  // Create the SUM_Z_pos variables for each reusing dimension
  int count = 0;
  optvar = XMALLOC (s_ponos_var_t*, nstmt + n_new_vars);
  for (ii = 0; ii < nstmt; ii++)
  {
    sprintf (buffer, "SUM_Z_S%d_pos",ii);
    optvar[count++] = ponos_space_var_create (buffer, 
      PONOS_VAR_BIN_USERDEF, ii, 0, 0, NULL);
  }
  // Create the Z variables for each F \in S, forall S
  int sched_dim = space->num_sched_dim;
  for (ii = 0; ii < nstmt; ii++)
  {
    int jj;
    for (jj = 0; jj < SI[ii].n_ref; jj++)
    {
     fprintf (CI->logfile, "Testing statement %d, reference %s\n",ii,SI[ii].ref[jj].name);
      if (SI[ii].ref[jj].is_const)
        continue;
     fprintf (CI->logfile, "Proceding with statement %d, reference %s (%d,%d)\n",ii,SI[ii].ref[jj].name,
        SI[ii].n_dim, SI[ii].ref[jj].n_dim);
      //if (SI[ii].ref[jj].n_dim >= SI[ii].n_dim)
      //  continue;
      int min_dim = SI[ii].n_dim;
      if (SI[ii].ref[jj].n_dim < min_dim)
        min_dim = SI[ii].ref[jj].n_dim;
      int kk;
      for (kk = 0; kk < min_dim; kk++)
      {
        sprintf (buffer, "Z%d_S%d_%s_%d",kk,ii,SI[ii].ref[jj].name,jj);
       fprintf (CI->logfile, "Creating space variable %s\n",buffer);
        optvar[count++] = ponos_space_var_create (buffer, 
          PONOS_VAR_BIN_USERDEF, kk, 0, 0, SI[ii].scop_stmt);
      }
    }
  }
  //printf ("Count = %d, reusing dim = %d, n_new_vars = %d\n",count, reusing_dim, n_new_vars);
  assert (count <= nstmt + n_new_vars);
  // Now insert the variables at the end of the space
  int new_var_start = space->num_vars;
 fprintf (CI->logfile, "New vars start at position %d\n", new_var_start);
  for (ii = 0; ii < count; ii++)
  {
    ponos_space_insert_variable_last (space, optvar[ii]);
  }
  XFREE (optvar);
 fprintf (CI->logfile, "Done creating SUM_Z pos, Z variables and super deltas...\n");



  // Compute the upper bounds for objective variables
  // The upper bound is 2 + 1 (delta) + number of reuse theta coefficients
  int obj_ub[nstmt];
  for (ii = 0; ii < nstmt; ii++)
    obj_ub[ii] = 0;
  #define mysqr(x) ((x) * (x))

 fprintf (CI->logfile, "Reaching nasty part ...\n");
  
  // Collect all deltas
  int * delta_ids;
  delta_ids = ponos_space_get_coefs (space, PONOS_VAR_DELTA);
 fprintf (CI->logfile, "Adding reuse constraint forall S, F, D^{S,S} ...\n");
  sched_dim = space->num_sched_dim / 2;
  int z_count = 0;
  for (ii = 0; ii < nstmt; ii++)
  {
    if (SI[ii].skip)
      continue;
    int n_iter = SI[ii].n_dim;
    int n_var_cst = mysqr(sched_dim) + 3; // + 3 accounts for delta and Z variable
    int ids[n_var_cst];
    int weights[n_var_cst];
    // Collect theta ids of the statement
    int * theta_ids = ponos_space_get_coefs_stmt (
      space, SI[ii].scop_stmt, PONOS_VAR_THETA_ITER);
    int num_theta = 0;
    for (num_theta = 0; theta_ids[num_theta] != -1; num_theta++);
    // Copy only the linear theta ids to a 2D array
    // theta ids array includes linear and scalar dimensions for all iterators
    int lin_theta[sched_dim][sched_dim];
    int jj;
    int n_theta_per_level = num_theta / space->num_sched_dim;
    int mycount = 0;
    for (jj = 0; theta_ids[jj] != -1; jj++);
    assert (jj == space->num_sched_dim * n_iter);
    assert (n_theta_per_level == n_iter);
    for (jj = 0; theta_ids[jj] != -1; jj++)
      if (space->vars[theta_ids[jj]]->dim % 2 == 1)
    {
      int row = space->vars[theta_ids[jj]]->dim / 2;
      int col = jj % n_theta_per_level;
      lin_theta[row][col] = theta_ids[jj];
      mycount ++;

    }
    XFREE (theta_ids);

    {
      int rr,cc;
      for (rr = 0; rr < space->num_sched_dim / 2; rr++)
      {
        for (cc = 0; cc < n_iter; cc++)
         fprintf (CI->logfile, "THETA[%d][%d] = %s\n",rr,cc,space->vars[lin_theta[rr][cc]]->name);
       fprintf (CI->logfile, "\n");
      }
    }

    #if 1
    // Enforce only 1 iterator is used per dimension
    for (jj = 0; jj < space->num_sched_dim/2; jj++)
    {
      int local_id[10];
      int WW[10];
      int kk;
      for (kk = 0; kk < n_iter; kk++)
      {
        local_id[kk] = lin_theta[jj][kk];
        WW[kk] = 1;
      }
      local_id[kk] = -1;

      ponos_space_create_weighted_summation (space, -1, 0, local_id, WW,
        PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);
    }
    #endif
    
   fprintf (CI->logfile, "Mycount of linear theta vars is %d, expected %d\n",mycount, mysqr(sched_dim));
    assert (mycount <= (mysqr(sched_dim)));


    int sched_padding = space->num_sched_dim / 2 - n_iter;

    // Make each schedule padding row i equal to the first non-padded row
    if (sched_padding > 0)
    {
      int rr,cc;
      int local_id[3];
      int local_WW[2];
      local_WW[0] = -1;
      local_WW[1] = 1;
      for (rr = 0; rr < sched_padding; rr++)
      {
        for (cc = 0; cc < n_iter; cc++)
        {
          local_id[0] = lin_theta[rr][cc];
          //local_id[1] = lin_theta[rr+sched_padding][cc];
          local_id[1] = lin_theta[sched_padding][cc];
          local_id[2] = -1;
          ponos_space_create_weighted_summation (space, -1, 0, local_id, local_WW,
            PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0); 
        }
      }
    }
     
    //printf ("Constraint: %s = ",space->vars[ii]->name);
    //printf ("Constraint: [%d] = ",ii);
    for (jj = 0; jj < SI[ii].n_ref; jj++)
    {
      if (SI[ii].ref[jj].is_const)
        continue;
      //if (SI[ii].ref[jj].n_dim >= SI[ii].n_dim)
      //  continue;

      #define mymin(x,y) ((x) < (y) ? (x) : (y))
      //int min_dim = SI[ii].ref[jj].n_dim; 
      int min_dim = mymin(SI[ii].ref[jj].n_dim,SI[ii].n_dim);
      int kk;

      {
        int aa,bb;
       fprintf (CI->logfile, "Showing access matrix of statement %d, referebce %d, array %s\n",ii,jj,SI[ii].ref[jj].name);
        for (aa = 0; aa < SI[ii].ref[jj].n_dim; aa++)
        {
          for (bb = 0; bb < SI[ii].n_dim; bb++)
           fprintf (CI->logfile, "%d ",SI[ii].ref[jj].coef[aa][bb]);
         fprintf (CI->logfile, "\n");
        }
       fprintf (CI->logfile, "\n");
      }

      // Schedule and data-space dimensions
      for (kk = 0; kk < min_dim; kk++)
      {
        // Upper bound of Z variable
        int ub = 2 + 1 + (space->num_sched_dim / 2 - 1 - kk);
        obj_ub[ii] += ub;
        ids[0] = nstmt + new_var_start + z_count;
       fprintf (CI->logfile, "Z variable for constraints to follow:  %s [%d]\n",space->vars[ids[0]]->name,ids[0]);
        weights[0] = -1;
        z_count++;

        int count = 1; // ID count
       fprintf (CI->logfile, "Preparing constraints for S%d %s L%d\n",ii,SI[ii].ref[jj].name,kk);
        int ll;
        // Iterators on access function
        // Fill the thetas that map schedule to spatial dimensions
        for (ll = 0; ll < SI[ii].n_dim; ll++)
        {
         fprintf (CI->logfile, "1) id var count is %d, max is %d\n",count,n_var_cst);
          assert (count < n_var_cst);
         fprintf (CI->logfile, "Statement %d, reference %d, iterator %d, sched level %d (%d,%d)\n",
            ii, jj, ll, kk, SI[ii].ref[jj].mask[ll], SI[ii].ref[jj].coef[kk][ll]);
          if (SI[ii].ref[jj].mask[ll])
          {
           fprintf (CI->logfile, "Statement %d, reference %d, uses iterator %d (current count = %d)\n",ii,jj,ll,count);
            if (SI[ii].ref[jj].coef[kk][ll])
            {
              ids[count] = lin_theta[sched_padding + kk][ll];
              weights[count] = 2;
            }
            else
            {
              ids[count] = lin_theta[sched_padding + kk][ll];
              weights[count] = -1;
            }
            count++;
          }
        }
        // fill the thetas that account for reuse
        for (ll = 0; ll < SI[ii].n_dim; ll++)
          if (!SI[ii].ref[jj].mask[ll])
        {
          int hh;
          //for (hh = kk + 1; hh < sched_dim; hh++)
          for (hh = kk + 1; hh < mymin(sched_dim,SI[ii].n_dim); hh++)
          {
           fprintf (CI->logfile, "2) id var count is %d, max is %d\n",count,n_var_cst);
            assert (count < n_var_cst);
            ids[count] = lin_theta[sched_padding + hh][ll];
            weights[count] = space->num_sched_dim / 2 - hh; // 1;
            count++;
          }
        }
       fprintf (CI->logfile, "3) id var count is %d, max is %d\n",count,n_var_cst);
        assert (count < n_var_cst);


        int dd;
        // Add delta variable to slot 1 of the ids array
        // Create a constraint for each
        int has_dep = 0;
        for (dd = 0; delta_ids && delta_ids[dd] != -1 && ! align_dims; dd++)
        {
          int varid = delta_ids[dd];
          CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
          //printf ("Got dependence %d (%p -> %p)\n",dd,dep->source, dep->target);
          if (dep->type != CANDL_RAW)
            continue;
          //printf ("\tDependence is RAW (%p vs %p)\n",dep->source,dep->target);
          if (dep->source != dep->target)
            continue;
          //printf ("\t\tIt's also a self-dependence\n");
          if (space->vars[varid]->dim != 2 * kk + 1)
            continue;
          int cstmt_pos; // candl statement position
          for (cstmt_pos = 0; cstmt_pos < CI->cprogram->nb_statements; cstmt_pos++)
          {
            //printf ("candl statement %d : %p vs %p\n",cstmt_pos,
              //CI->cprogram->statement[cstmt_pos], dep->target);
            if (CI->cprogram->statement[cstmt_pos] == dep->target)
              break;
          }
          //printf ("\t\t\tMatches the schedule level (%d,%d)\n",cstmt_pos,ii);
          assert (cstmt_pos < nstmt);
          if (cstmt_pos != ii) // I hope the statement ids in candl start from 0
            continue;
          //printf ("\t\t\t\tMatches the current statement (S%d,REF %s)\n",ii,SI[ii].ref[jj].name);
          //ids[1] = varid;
          //ids[count] = -1;
          ids[count] = varid;
          ids[count+1] = -1;
          weights[count] = -1;

          has_dep = 1;
          int xx;
         fprintf (CI->logfile, "new constraint (with dep) ==> ");
          #define mysign(x) ((x) < 0 ? '-' : '+')
          #define myabs(x)  ((x) >= 0 ? (x) : -(x))
          for (xx = 0; ids[xx] != -1; xx++)
          {
            //printf ("ids[%d] = %d\n",xx,ids[xx]);
            assert (ids[xx] < space->num_vars);
           fprintf (CI->logfile, "%c %d x %s (%d)",mysign(weights[xx]),myabs(weights[xx]),space->vars[ids[xx]]->name,ids[xx]);
          }
         fprintf (CI->logfile, "\n");

         fprintf (CI->logfile, "Adding constraint: S%d x %s x L%d x D%d\n",ii,SI[ii].ref[jj].name,kk,dd);
          ponos_space_create_weighted_summation (space, -1, 0, ids, weights,
            PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, -1); 
          // above  -1 stands for  +1 on the RHS of >=
        }
        if (!has_dep || align_dims)
        {
         fprintf (CI->logfile, "Previously collected %d variables in ids array\n",count);
          {
            int yy;
            for (yy = 0; yy < count; yy++)
             fprintf (CI->logfile, "space[%d] = %s\n",ids[yy],space->vars[ids[yy]]->name);
           fprintf (CI->logfile, "\n");
          }
          ids[count] = -1;
          int xx;

          int local_id[3];
          int local_WW[3];
          local_id[0] = ids[0];
          // Search for all variables in the current ids array that have a 
          // a weight of 2. These are the "good" theta coefficients.
          // Create an inequality of the form theta_{i,j} >= Z_level^ref
          for (xx = 0; ids[xx] != -1; xx++)
            if (weights[xx] == 2)
            {
              local_id[1] = ids[xx];
              break;
            }
          local_id[2] = -1;
          local_WW[0] = -1;
          local_WW[1] = 1;
         fprintf (CI->logfile, "new constraint (without dep) ==> ");
          #define mysign(x) ((x) < 0 ? '-' : '+')
          #define myabs(x)  ((x) >= 0 ? (x) : -(x))
          for (xx = 0; ids[xx] != -1; xx++)
          {
            //printf ("ids[%d] = %d\n",xx,ids[xx]);
            if (ids[xx] >= space->num_vars)
            {
              //printf ("Current ids %d = %d\n",xx,ids[xx]);
              ponos_space_print_vars (stdout, space);
            }
            assert (ids[xx] < space->num_vars);
            fprintf (CI->logfile, "%c %d x %s (%d)",mysign(weights[xx]),myabs(weights[xx]),space->vars[ids[xx]]->name,ids[xx]);
          }
         fprintf (CI->logfile, "\n");

          // Create the constraint Z_level_Ref <= theta expression
          ponos_space_create_weighted_summation (space, -1, 0, local_id, local_WW,
            PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0); 

          // Pull down the upper bound of the Z variable
          // This minimizes the chances of skewing and iterator scaling
          ponos_codelet_create_ge_cst (space, ids[0], -1, -1);
        }

        // Set upper and lower bound for current Z variable
        ponos_codelet_create_ge_cst (space, ids[0], -1, - ub);
        ponos_codelet_create_ge_cst (space, ids[0], 1, 0);
      }
    }
  }
  XFREE (delta_ids);

  // Set bounds for SUM_Z variables 
  for (ii = 0; ii < nstmt ; ii++)
  {
    if (SI[ii].skip)
      continue;
    int ids[3+count];
    ids[0] = ii;
    ids[1] = new_var_start + ii;
    ids[2] = -1;
    // Bounds of objective variables depend on both the dimensionality
    // of the statement and the dimensionality of the array reference
    ponos_space_create_summation (space, -1, ids,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, obj_ub[ii]);

    ponos_codelet_create_ge_cst (space, ids[0], -1, -obj_ub[ii]);
    ponos_codelet_create_ge_cst (space, ids[0], 1, 0);
    ponos_codelet_create_ge_cst (space, new_var_start + ii, -1, -obj_ub[ii]);
    ponos_codelet_create_ge_cst (space, new_var_start + ii, 1, 0);

  
    int jj,kk;
    int WW[3+count];
    for (jj = 0, kk = new_var_start + nstmt; kk < space->num_vars; kk++)
    {
      scoplib_statement_p stmt = (scoplib_statement_p)(space->vars[kk]->scop_ptr);
      if (stmt == SI[ii].scop_stmt)
      //if (space->vars[kk]->dim == ii)
      {
        ids[jj] = kk;
        //WW[jj] = space->num_sched_dim / 2 - space->vars[kk]->dim / 2;
        sscanf (space->vars[kk]->name,"Z%d_",&WW[jj]);
        WW[jj] = space->num_sched_dim / 2 - WW[jj];
        jj++;
      }
    }
    int sum_z_var = new_var_start + ii;
    ids[jj] = sum_z_var;
    WW[jj] = -1;
    jj++;
    ids[jj] = -1;
    ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
  }


  // Be clean
  for (ii = 0; ii < nstmt; ii++)
  {
    int jj;
    for (jj = 0; jj < SI[ii].n_ref; jj++)
      //if (!SI[ii].ref[jj].is_const)
    {
     fprintf (CI->logfile, "Freeing mask of reference %d, statement %d\n",jj,ii);
      XFREE (SI[ii].ref[jj].mask);
    }
   fprintf (CI->logfile, "Freeing statement %d\n",ii);
    XFREE (SI[ii].ref);
  }
  XFREE (SI);

 fprintf (CI->logfile, "Done with all outer stride stuff\n");

  timer_end = rtclock ();
 fprintf (CI->logfile, "[Ponos/Chunked] Max.Reuse time: %.4fs\n",timer_end - timer_start);
}



/*
 * Constraints and objectives for OPIR and ADA.
 *
 */
void 
ponos_perfidiom_outerpar_innerreuse_with_filter (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, 
  s_chunked_graph_t * CG, 
  int align_dims, int clusterid, int * filter)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  int i, j;

  fprintf (CI->logfile, "showing array ids and names:\n");
  for (i = 0; i < space->scop->nb_arrays; i++)
    fprintf (CI->logfile, "Array %d = %s\n",i,space->scop->arrays[i]);

  int nstmt = CI->n_stmt;
  int cluster_size = (clusterid == SINGLECLUSTER ? 
    CI->n_stmt : CG->fgraph->nodes[clusterid].n_members);
  scoplib_statement_p stmt;
  
  s_chunked_statement_info_t * SI;
  SI = XMALLOC (s_chunked_statement_info_t, nstmt);
  int idx;
  for (stmt=space->scop->statement, idx=0; stmt; stmt = stmt->next, idx++)
  {
    SI[idx].id = idx;
    SI[idx].n_ref = 0;
    SI[idx].scop_stmt = stmt;
    SI[idx].n_dim = stmt->nb_iterators;
    SI[idx].ref = XMALLOC (s_chunked_ref_info_t, 1);
    SI[idx].skip = !filter[idx];
  }

  fprintf (CI->logfile, "Created statement info array ...\n");

  // Populate the array structure info.
  // For each statement determine:
  // 1) Number of references in it
  // 2) Iterators used in each reference (number of iters too), if it's constant
  // 3) Store the scop pointer
  // 4) Dimensionality of statement
  CI->n_ref = 0;
  for (idx = 0; idx < nstmt; idx++)
    if (filter[idx])
  {
    stmt = SI[idx].scop_stmt;
   fprintf (CI->logfile, "Collecting info of statement %d (%s)...\n",idx,stmt->body);
    scoplib_matrix_p refs;
    refs = stmt->read;
    int n_iter = stmt->nb_iterators;
    int col;
    
    // Determine the number of read references by counting the number 
    // of non-zeros on the first column of the matrix
    int row;
    int n_rows = refs->NbRows;
    int ranges[n_rows+1];
    int n_refs = 0;
   fprintf (CI->logfile, "Collected ranges ...\n");
    for (row = 0; row < n_rows; row++)
      if (SCOPVAL_pos_p(refs->p[row][0]))
    {
      ranges[n_refs++] = row;
    }
    ranges[n_refs] = row;
    SI[idx].n_ref = n_refs + 1; // the +1 is for the written ref (lhs)
    // Allocate an array of reference info
   fprintf (CI->logfile, "Allocating %d references on statement %d\n",SI[idx].n_ref,idx);
    SI[idx].ref = XMALLOC (s_chunked_ref_info_t, SI[idx].n_ref);
    int jref;
    // For each reference, allocate space for its iterator mask
    // and initialize it to a zero vector
    // Then, populate it by traversing the scoplib_matrix pointers
    int ref_id = 0;
    // references ids start from 0 on the read list
    int n_non_const_ref = 0;
    for (jref = 0; jref < n_refs; jref++)
    {
     fprintf (CI->logfile, "Collecting info of statement %d, reference %d ...\n",idx,jref);
      SI[idx].ref[jref].mask = XMALLOC (int, n_iter);
      SI[idx].ref[jref].id = ref_id++;
      int iter;
      for (iter = 0; iter < n_iter; iter++)
        SI[idx].ref[jref].mask[iter] = 0;
      SI[idx].ref[jref].skip = 0;
      int space_dim;
      // Coef field is hard-wired to a 4x5 array!!!
      for (space_dim = 0; space_dim < 4; space_dim++)
      {
        for (iter = 0; iter < 5; iter++)
          SI[idx].ref[jref].coef[space_dim][iter] = 0;
      }
      // Collect information from each array reference
      int is_const_ref = 1;
      int n_ref_iter = 0;
      int iter_start = ranges[jref];
      int scop_array_id = SCOPVAL_get_si(refs->p[ranges[jref]][0]) - 1; // array names in scop matrix are 1-offset, not 0-offset
     fprintf (CI->logfile, "Found array %s on position %d (range=%d)\n",
        space->scop->arrays[scop_array_id],scop_array_id,ranges[jref]);
      SI[idx].ref[jref].name = space->scop->arrays[scop_array_id];
      for (iter = ranges[jref]; iter < ranges[jref+1]; iter++)
      {
        SI[idx].ref[jref].row_start = ranges[jref];
        // For the given row (iter) set the mask entry to 1 if the
        // respective column is non-zero
        int n_iter_in_dim = 0;
        for (col = 1; col <= n_iter; col++)
        {
          if (SCOPVAL_notzero_p(refs->p[iter][col]))       
          {
            SI[idx].ref[jref].mask[col-1] ++;
            n_ref_iter++;
            n_iter_in_dim ++;
            is_const_ref = 0;
            SI[idx].ref[jref].coef[iter - iter_start][col-1] = 1;
          }
        }
        SI[idx].ref[jref].n_dim = ranges[jref+1] - ranges[jref];//n_ref_iter;
        SI[idx].ref[jref].is_const = (n_ref_iter == 0);
        SI[idx].ref[jref].skip = SI[idx].ref[jref].skip || (n_iter_in_dim > 1);
      }
      if (n_ref_iter > 0)
      {
        n_non_const_ref++;
      }

      {
        int rr,cc;
       fprintf (CI->logfile, "Showing access function of collected read references S%d_%s\n",idx,SI[idx].ref[jref].name);
        for (rr = 0; rr < 4; rr++)
        {
          for (cc = 0; cc < 5; cc++)
           fprintf (CI->logfile, "%d ",SI[idx].ref[jref].coef[rr][cc]);
         fprintf (CI->logfile, "\n");
        }
      }
    }

   fprintf (CI->logfile, "Collecting info of write ref of statement %d ...\n",idx);
    refs = stmt->write;
    int n_ref_iter = 0;
   fprintf (CI->logfile, "Write ref = %d, #refs on statement %d = %d\n",jref,idx,SI[idx].n_ref);
    // Do the same for the write reference
    SI[idx].ref[jref].mask = XMALLOC (int, n_iter);
    SI[idx].ref[jref].id = ref_id++;
    int scop_array_id = SCOPVAL_get_si(refs->p[0][0]) - 1;
    SI[idx].ref[jref].name = space->scop->arrays[scop_array_id];

    // Initialize write ref mask and coef arrays (last jref is the write ref)
    {
      int iter;
      for (iter = 0; iter < n_iter; iter++)
        SI[idx].ref[jref].mask[iter] = 0;
      int space_dim;
      // Coef field is hard-wired to a 4x5 array!!!
      for (space_dim = 0; space_dim < 4; space_dim++)
      {
        for (iter = 0; iter < 5; iter++)
          SI[idx].ref[jref].coef[space_dim][iter] = 0;
      }
    }
    for (row = 0; row < refs->NbRows; row++)
    {
      int n_iter_in_dim = 0;
      for (col = 1; col <= n_iter; col++)
      {
        if (SCOPVAL_notzero_p(refs->p[row][col]))       
        {
          SI[idx].ref[jref].mask[col-1] ++;
          n_ref_iter++;
          SI[idx].ref[jref].coef[row][col-1] = 1;
          n_iter_in_dim ++;
        }
      }
      SI[idx].ref[jref].skip = SI[idx].ref[jref].skip || (n_iter_in_dim > 1);
    }
    
    {
      int rr,cc;
     fprintf (CI->logfile, "Showing access function of collected write reference S%d_%s\n",idx,SI[idx].ref[jref].name);
      for (rr = 0; rr < 4; rr++)
      {
        for (cc = 0; cc < 5; cc++)
         fprintf (CI->logfile, "%d ",SI[idx].ref[jref].coef[rr][cc]);
       fprintf (CI->logfile, "\n");
      }
    }
   fprintf (CI->logfile, "Pretty much done with statement %d...\n",idx);
    if (n_ref_iter > 0)
    {
      n_non_const_ref++;
    }
    SI[idx].ref[jref].is_const = (n_ref_iter == 0);
    SI[idx].ref[jref].n_dim = refs->NbRows;
    SI[idx].n_non_const_ref = n_non_const_ref;
    //SI[idx].ref[jref].skip = (n_iter_in_dim > 1);

    // skip the process for the statement if any ref must be skipped
    for (jref = 0; jref < n_refs; jref++)
    {
      SI[idx].skip =  SI[idx].skip || SI[idx].ref[jref].skip;
    }
    CI->n_ref += SI[idx].n_ref;
  }
  fprintf (CI->logfile, "Done collecting array info\n");

  // Count how many new vars will we need (objective vars and Z vars)
  // |Z^{S,F_A}| = min{iters(S)-1,dim(A)}
  // n_new_vars = \sum_{F \in S} |Z^F|
  // We also count the number of objectives we will have
  int n_new_vars = 0;
  int reusing_dim = 0; // maximum number of outer dimensions that induce reuse
  int ii;
  for (ii = 0; ii < nstmt; ii++)
    // only proceed with statements selected by filter argument
    if (filter[ii])
  {
    int jj;
    for (jj = 0; jj < SI[ii].n_ref; jj++)
    {
      if (SI[ii].ref[jj].is_const)
        continue;
      //if (SI[ii].ref[jj].n_dim >= SI[ii].n_dim)
      //  continue;

      assert (SI[ii].ref[jj].n_dim >= 0 && SI[ii].ref[jj].n_dim <= 4);
      int min_dim = SI[ii].n_dim;
      if (SI[ii].ref[jj].n_dim < min_dim)
        min_dim = SI[ii].ref[jj].n_dim;
      if (min_dim > reusing_dim)
        reusing_dim = min_dim;
      n_new_vars += min_dim;
     fprintf (CI->logfile, "Adding %d variables for S%d_REF%d (newvars=%d)\n",min_dim,ii,jj,n_new_vars);
    }
  }
  fprintf (CI->logfile, "OPIR: Will create %d new variables ...\n",n_new_vars);

  char buffer[100]; 
  s_ponos_var_t** optvar;
  optvar = XMALLOC (s_ponos_var_t*, cluster_size);

  // Create the SUM_Z_S_neg variables
  int iisel;
  for (ii = 0, iisel = 0; ii < nstmt; ii++)
    if (filter[ii])
  {
    sprintf (buffer, "SUM_Z_S%d_neg",ii);
    optvar[iisel] = ponos_space_var_create (buffer, 
      PONOS_VAR_BIN_USERDEF, iisel, 0, 0, NULL);
    iisel ++;
  }
  int n_selected = iisel;
  // Perform bulk insertion
  ponos_space_bulk_variable_insertion_at_start (space, optvar, n_selected);
  XFREE (optvar);

  // Create the SUM_Z_pos variables for each reusing dimension
  int count = 0;
  optvar = XMALLOC (s_ponos_var_t*, n_selected + n_new_vars);
  for (ii = 0; ii < nstmt; ii++)
    if (filter[ii])
  {
    sprintf (buffer, "SUM_Z_S%d_pos",ii);
    optvar[count++] = ponos_space_var_create (buffer, 
      PONOS_VAR_BIN_USERDEF, ii, 0, 0, NULL);
  }

  fprintf (CI->logfile, "OPIR: Number of statements in cluster: %d (total = %d)\n",nstmt,CI->n_stmt);
  // Create the Z variables for each F \in S, forall S
  int sched_dim = space->num_sched_dim;
  for (ii = 0; ii < nstmt; ii++)
    if (filter[ii])
  {
    int jj;
    for (jj = 0; jj < SI[ii].n_ref; jj++)
    {
      fprintf (CI->logfile, "Testing statement %d, reference %s\n",ii,SI[ii].ref[jj].name);
      if (SI[ii].ref[jj].is_const)
        continue;
      fprintf (CI->logfile, "Proceding with statement %d, reference %s (%d,%d)\n",ii,SI[ii].ref[jj].name,
        SI[ii].n_dim, SI[ii].ref[jj].n_dim);
      //if (SI[ii].ref[jj].n_dim >= SI[ii].n_dim)
      //  continue;
      int min_dim = SI[ii].n_dim;
      if (SI[ii].ref[jj].n_dim < min_dim)
        min_dim = SI[ii].ref[jj].n_dim;
      int kk;
      for (kk = 0; kk < min_dim; kk++)
      {
        sprintf (buffer, "Z%d_S%d_%s_%d",kk,ii,SI[ii].ref[jj].name,jj);
        fprintf (CI->logfile, "Creating space variable %s\n",buffer);
        optvar[count++] = ponos_space_var_create (buffer, 
          PONOS_VAR_BIN_USERDEF, kk, 0, 0, SI[ii].scop_stmt);
      }
    }
  }
  //printf ("Count = %d, reusing dim = %d, n_new_vars = %d\n",count, reusing_dim, n_new_vars);
  assert (count <= n_selected + n_new_vars);
  // Now insert the variables at the end of the space
  int new_var_start = space->num_vars;
  fprintf (CI->logfile, "New vars start at position %d\n", new_var_start);
  for (ii = 0; ii < count; ii++)
  {
    ponos_space_insert_variable_last (space, optvar[ii]);
  }
  XFREE (optvar);
  fprintf (CI->logfile, "OPIR: Done creating SUM_Z pos, Z variables and super deltas...\n");



  // Compute the upper bounds for objective variables
  // The upper bound is 2 + 1 (delta) + number of reuse theta coefficients
  int obj_ub[nstmt];
  for (ii = 0; ii < nstmt; ii++)
    obj_ub[ii] = 0;
  #define mysqr(x) ((x) * (x))

  // Collect all deltas
  int * delta_ids;
  delta_ids = ponos_space_get_coefs (space, PONOS_VAR_DELTA);
  fprintf (CI->logfile, "Adding reuse constraint forall S, F, D^{S,S} ...\n");
  sched_dim = space->num_sched_dim / 2;
  int z_count = 0;
  for (ii = 0; ii < nstmt; ii++)
    if (filter[ii])
  {
    if (SI[ii].skip)
      continue;
    int n_iter = SI[ii].n_dim;
    int n_var_cst = mysqr(sched_dim) + 4; // + 4 accounts for delta, psi and Z variable (ending with -1)
    int ids[n_var_cst];
    int weights[n_var_cst];
    // Collect theta ids of the statement
    int * theta_ids = ponos_space_get_coefs_stmt (
      space, SI[ii].scop_stmt, PONOS_VAR_THETA_ITER);

    int * psi_ids = ponos_space_get_coefs_stmt (
        space, CI->SA[ii], PONOS_VAR_PSI);
    int pids = count_ids (psi_ids);
    fprintf (CI->logfile, "here we collected %d psi ids\n",pids);
    int num_theta = 0;
    for (num_theta = 0; theta_ids[num_theta] != -1; num_theta++);
    // Copy only the linear theta ids to a 2D array
    // theta ids array includes linear and scalar dimensions for all iterators
    int lin_theta[sched_dim][sched_dim];
    int jj;
    int n_theta_per_level = num_theta / space->num_sched_dim;
    int mycount = 0;
    for (jj = 0; theta_ids[jj] != -1; jj++);
    assert (jj == space->num_sched_dim * n_iter);
    assert (n_theta_per_level == n_iter);
    for (jj = 0; theta_ids[jj] != -1; jj++)
      if (space->vars[theta_ids[jj]]->dim % 2 == 1)
    {
      int row = space->vars[theta_ids[jj]]->dim / 2;
      int col = jj % n_theta_per_level;
      lin_theta[row][col] = theta_ids[jj];
      mycount ++;
    }
    XFREE (theta_ids);

    {
      int rr,cc;
      for (rr = 0; rr < space->num_sched_dim / 2; rr++)
      {
        for (cc = 0; cc < n_iter; cc++)
         fprintf (CI->logfile, "THETA[%d][%d] = %s\n",rr,cc,space->vars[lin_theta[rr][cc]]->name);
        fprintf (CI->logfile, "\n");
      }
    }

    #if 1
    // Enforce only 1 iterator is used per dimension
    for (jj = 0; jj < space->num_sched_dim/2; jj++)
    {
      int local_id[10];
      int WW[10];
      int kk;
      for (kk = 0; kk < n_iter; kk++)
      {
        local_id[kk] = lin_theta[jj][kk];
        WW[kk] = 1;
      }
      local_id[kk] = -1;

      ponos_space_create_weighted_summation (space, -1, 0, local_id, WW,
        PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);
    }
    #endif
    
   fprintf (CI->logfile, "OPIR Mycount of linear theta vars is %d, expected %d\n",mycount, mysqr(sched_dim));
    assert (mycount <= (mysqr(sched_dim)));


    int sched_padding = space->num_sched_dim / 2 - n_iter;

    // Make each schedule padding row i equal to the first non-padded row
    if (sched_padding > 0)
    {
      int rr,cc;
      int local_id[3];
      int local_WW[2];
      local_WW[0] = -1;
      local_WW[1] = 1;
      for (rr = 0; rr < sched_padding; rr++)
      {
        for (cc = 0; cc < n_iter; cc++)
        {
          local_id[0] = lin_theta[rr][cc];
          //local_id[1] = lin_theta[rr+sched_padding][cc];
          local_id[1] = lin_theta[sched_padding][cc];
          local_id[2] = -1;
          ponos_space_create_weighted_summation (space, -1, 0, local_id, local_WW,
            PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0); 
        }
      }
    }
     
    for (jj = 0; jj < SI[ii].n_ref; jj++)
    {
      if (SI[ii].ref[jj].is_const)
        continue;

      #define mymin(x,y) ((x) < (y) ? (x) : (y))
      //int min_dim = SI[ii].ref[jj].n_dim; 
      int min_dim = mymin(SI[ii].ref[jj].n_dim,SI[ii].n_dim);
      int kk;


      // Schedule and data-space dimensions
      for (kk = 0; kk < min_dim; kk++)
      {
       fprintf (CI->logfile, "Starting with dimension %d\n",kk);
        // Upper bound of Z variable
        int ub = 2 + 1 + (space->num_sched_dim / 2 - 1 - kk) + 1;
        obj_ub[ii] += ub;
        ids[0] = cluster_size + new_var_start + z_count;
       fprintf (CI->logfile, "Z variable constraints to follow:  %s [%d]\n",space->vars[ids[0]]->name,ids[0]);
        weights[0] = -1;
        z_count++;

        int count = 1; // ID count
       fprintf (CI->logfile, "Preparing constraints for S%d %s L%d\n",ii,SI[ii].ref[jj].name,kk);
        int ll;
        // Iterators on access function
        // Fill the thetas that map schedule to spatial dimensions
        for (ll = 0; ll < SI[ii].n_dim; ll++)
        {
          if (count >= n_var_cst)
          {
           fprintf (CI->logfile, "1) id var count is %d, max is %d\n",count,n_var_cst);
           fprintf (CI->logfile, "Statement %d, reference %d, iterator %d, sched level %d (%d,%d)\n",
              ii, jj, ll, kk, SI[ii].ref[jj].mask[ll], SI[ii].ref[jj].coef[kk][ll]);
          }
          assert (count < n_var_cst && "OPIR: out-of-bounds space index (1).");
          if (SI[ii].ref[jj].mask[ll])
          {
           fprintf (CI->logfile, "Statement %d, reference %d, uses iterator %d (current count = %d)\n",ii,jj,ll,count);
            if (SI[ii].ref[jj].coef[kk][ll])
            {
              ids[count] = lin_theta[sched_padding + kk][ll];
              weights[count] = 2;
            }
            else
            {
              ids[count] = lin_theta[sched_padding + kk][ll];
              weights[count] = -1;
            }
            count++;
          }
        }

        int z_bound = 0;
        // fill the thetas that account for reuse
        for (ll = 0; ll < SI[ii].n_dim; ll++)
          if (!SI[ii].ref[jj].mask[ll])
        {
          int hh;
          //for (hh = kk + 1; hh < sched_dim; hh++)
          for (hh = kk + 1; hh < mymin(sched_dim,SI[ii].n_dim); hh++)
          {
            //printf ("2) id var count is %d, max is %d\n",count,n_var_cst);
            assert (count < n_var_cst);
            assert (count < n_var_cst && "OPIR: out-of-bounds space index (2).");
            ids[count] = lin_theta[sched_padding + hh][ll];
            weights[count] = space->num_sched_dim / 2 - hh; // 1;
            if (weights[count] > z_bound)
              z_bound = weights[count];
            count++;
          }
        }
        //printf ("3) id var count is %d, max is %d\n",count,n_var_cst);
        assert (count < n_var_cst && "OPIR: out-of-bounds space index (3).");


        int dd;
        // Add delta variable to slot 1 of the ids array
        // Create a constraint for each
        int has_dep = 0;
        for (dd = 0; delta_ids && delta_ids[dd] != -1 && ! align_dims; dd++)
        {
          int varid = delta_ids[dd];
          CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
          //printf ("Got dependence %d (%p -> %p)\n",dd,dep->source, dep->target);
          if (dep->type != CANDL_RAW)
            continue;
          //printf ("\tDependence is RAW (%p vs %p)\n",dep->source,dep->target);
          if (dep->source != dep->target)
            continue;
          //printf ("\t\tIt's also a self-dependence\n");
          if (space->vars[varid]->dim != 2 * kk + 1)
            continue;
          int cstmt_pos; // candl statement position
          for (cstmt_pos = 0; cstmt_pos < CI->cprogram->nb_statements; cstmt_pos++)
          {
            //printf ("candl statement %d : %p vs %p\n",cstmt_pos,
              //CI->cprogram->statement[cstmt_pos], dep->target);
            if (CI->cprogram->statement[cstmt_pos] == dep->target)
              break;
          }
          //printf ("\t\t\tMatches the schedule level (%d,%d)\n",cstmt_pos,ii);
          assert (cstmt_pos < nstmt);
          if (cstmt_pos != ii) // I hope the statement ids in candl start from 0
            continue;
          //printf ("\t\t\t\tMatches the current statement (S%d,REF %s)\n",ii,SI[ii].ref[jj].name);
          //ids[1] = varid;
          //ids[count] = -1;

          // This sets the delta at the current level
          //ids[count] = psi_ids[space->vars[varid]->dim];//varid;
          //weights[count] = -1 * z_bound;// * (CI->archinfo.n_cores > 10 ? 2 : 1);
          ids[count] = varid;
          weights[count] = -2;// * (CI->archinfo.n_cores > 10 ? 2 : 1);

          #if 0
          // if PSI vars were inserted before, we can use them
          if (psi_ids && kk < CI->SA[ii]->nb_iterators && psi_ids[0] != -1 && psi_ids[kk * 2 + 1] != -1)
          {
            count++;
            ids[count] = psi_ids[CI->SA[ii]->nb_iterators * 2 - 1];
            //obj_ub[ii] += (CI->archinfo.simdlen / CI->archinfo.fp_precision);
            weights[count] = 1; //(CI->archinfo.simdlen / CI->archinfo.fp_precision);
           fprintf (CI->logfile, "Inserting parallelism condition with %d / %d\n",
              CI->archinfo.simdlen, CI->archinfo.fp_precision);
          }
          #endif
          ids[count+1] = -1;

          has_dep = 1;
          int xx;
          fprintf (CI->logfile, "new constraint (with dep) ==> ");
          #define mysign(x) ((x) < 0 ? '-' : '+')
          #define myabs(x)  ((x) >= 0 ? (x) : -(x))
          for (xx = 0; ids[xx] != -1; xx++)
          {
            //printf ("ids[%d] = %d\n",xx,ids[xx]);
            assert (ids[xx] < space->num_vars);
            fprintf (CI->logfile, "%c %d x %s (%d)",mysign(weights[xx]),myabs(weights[xx]),space->vars[ids[xx]]->name,ids[xx]);
          }
         fprintf (CI->logfile, "\n");

         fprintf (CI->logfile, "Adding constraint: S%d x %s x L%d x D%d\n",ii,SI[ii].ref[jj].name,kk,dd);
          ponos_space_create_weighted_summation (space, -1, 0, ids, weights,
            PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, -2); 
          //  PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, -1); 
          // above  -1 stands for  +1 on the RHS of >=
        }


        if (!has_dep || align_dims)
        {
         fprintf (CI->logfile, "Previously collected %d variables in ids array\n",count);
          {
            int yy;
            for (yy = 0; yy < count; yy++)
             fprintf (CI->logfile, "space[%d] = %s\n",ids[yy],space->vars[ids[yy]]->name);
           fprintf (CI->logfile, "\n");
          }
          ids[count] = -1;
          int xx;

          int local_id[3];
          int local_WW[3];
          local_id[0] = ids[0];
          // Search for all variables in the current ids array that have a 
          // a weight of 2. These are the "good" theta coefficients.
          // Create an inequality of the form theta_{i,j} >= Z_level^ref
          for (xx = 0; ids[xx] != -1; xx++)
            if (weights[xx] == 2)
            {
              local_id[1] = ids[xx];
              break;
            }
          local_id[2] = -1;
          local_WW[0] = -1;
          local_WW[1] = 1;
         fprintf (CI->logfile, "new constraint (without dep) ==> ");
          #define mysign(x) ((x) < 0 ? '-' : '+')
          #define myabs(x)  ((x) >= 0 ? (x) : -(x))
          for (xx = 0; ids[xx] != -1; xx++)
          {
            //printf ("ids[%d] = %d\n",xx,ids[xx]);
            if (ids[xx] >= space->num_vars)
            {
              //printf ("Current ids %d = %d\n",xx,ids[xx]);
              ponos_space_print_vars (stdout, space);
            }
            assert (ids[xx] < space->num_vars);
           fprintf (CI->logfile, "%c %d x %s (%d)",mysign(weights[xx]),myabs(weights[xx]),space->vars[ids[xx]]->name,ids[xx]);
          }
         fprintf (CI->logfile, "\n");

          // Create the constraint Z_level_Ref <= theta expression
          ponos_space_create_weighted_summation (space, -1, 0, local_id, local_WW,
            PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0); 

          // Pull down the upper bound of the Z variable
          // This minimizes the chances of skewing and iterator scaling
          ponos_codelet_create_ge_cst (space, ids[0], -1, -1);
        }

        // Set upper and lower bound for current Z variable
        ponos_chunked_set_var_lb_ub (space, ids[0], 1, 0, ub);
        ponos_space_var_set_bounds (space->vars[ids[0]], 0, ub);

       fprintf (CI->logfile, "Done with dimension %d\n",kk);
      }
    }

    XFREE (psi_ids);
  }
  XFREE (delta_ids);

  // Set bounds for SUM_Z variables 
  for (ii = 0, idx = 0; ii < nstmt; ii++)
    if (filter[ii])
  {
    if (SI[ii].skip)
      continue;

    int last_lin_dim = CI->SA[ii]->nb_iterators - 1;
    int * psi_ids = ponos_space_get_coefs_stmt (
        space, CI->SA[ii], PONOS_VAR_PSI);
    int npsi = count_ids (psi_ids);
    if (0)//psi_ids && psi_ids[0] != -1 && psi_ids[last_lin_dim * 2 + 1] != -1)
    {
      //obj_ub[ii] = (CI->archinfo.simdlen / CI->archinfo.fp_precision) * (CI->archinfo.n_cores / 10);
      //if ((CI->archinfo.simdlen / CI->archinfo.fp_precision) * (CI->archinfo.n_cores ) > obj_ub[ii])
      //  obj_ub[ii] = (CI->archinfo.simdlen / CI->archinfo.fp_precision) * (CI->archinfo.n_cores);

     fprintf (CI->logfile, "Before updating upper SUM_Z upper bound: %d\n", obj_ub[ii]);

      obj_ub[ii] += (CI->archinfo.simdlen / CI->archinfo.fp_precision);
      obj_ub[ii] += (CI->archinfo.n_cores / 10);
     fprintf (CI->logfile, "After updating upper SUM_Z upper bound: %d\n", obj_ub[ii]);
      //ub += (CI->archinfo.simdlen / CI->archinfo.fp_precision);
    }

    int ids[4+count+npsi];
  
    int jj,kk;
    int WW[3+count+npsi];
    //for (jj = 0, kk = new_var_start + nstmt; kk < space->num_vars; kk++)
    for (jj = 0, kk = new_var_start + cluster_size; kk < space->num_vars; kk++)
    {
      scoplib_statement_p stmt = (scoplib_statement_p)(space->vars[kk]->scop_ptr);
      if (stmt == SI[ii].scop_stmt)
      //if (space->vars[kk]->dim == ii)
      {
        ids[jj] = kk;
        //WW[jj] = space->num_sched_dim / 2 - space->vars[kk]->dim / 2;
        sscanf (space->vars[kk]->name,"Z%d_",&WW[jj]);
        WW[jj] = (space->num_sched_dim / 2 - WW[jj]);
        jj++;
      }
    }
    int par_delta = CI->archinfo.n_cores / CI->SA[ii]->nb_iterators;
    int n_cores = CI->archinfo.n_cores;
    int vec_width = (CI->archinfo.simdlen / CI->archinfo.fp_precision);
    int vec_delta = vec_width / (CI->SA[ii]->nb_iterators );
    int n_vec = vec_delta;
    int n_iter = CI->SA[ii]->nb_iterators;
    #if 1
    for (kk = 0; kk < npsi; kk++)
      if (kk % 2 == 1)
    {
      ids[jj] = psi_ids[kk];
      WW[jj] = (n_vec * n_cores);// * n_iter;
      obj_ub[ii] += n_vec * n_cores;
      n_cores -= par_delta;
      //n_vec += vec_delta;
      n_iter --;
      jj++;
    }
    #endif
    int sum_z_var = new_var_start + idx;
    ids[jj] = sum_z_var;
    if (vec_width * 1.25 >= n_cores)
      WW[jj] = -1 * n_cores; // e.g. KNL
    else
      WW[jj] = 1 * n_cores; // e.g. SKX
    jj++;

    ids[jj] = -1;
    // HERE : EQUAL => LOWEREQUAL
    ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
      PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

    ids[0] = idx;
    ids[1] = new_var_start + idx;
    ids[2] = -1;
    // Bounds of objective variables depend on both the dimensionality
    // of the statement and the dimensionality of the array reference
    ponos_space_create_summation (space, -1, ids,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, obj_ub[ii]);

    fprintf (CI->logfile, "Setting constraint: %d <= %s <= %d\n",0, space->vars[ids[0]]->name, obj_ub[ii]);
    int mylb = -obj_ub[ii];
    int myub = obj_ub[ii];
    ponos_chunked_set_var_lb_ub (space, ids[0], 1, 0, myub);
    ponos_space_var_set_bounds (space->vars[ids[0]],  0, myub);

    fprintf (CI->logfile, "Setting constraint: %d <= %s <= %d\n",0, space->vars[new_var_start + idx]->name, obj_ub[ii]);
    ponos_chunked_set_var_lb_ub (space, new_var_start + idx, 1,  0, myub);
    ponos_space_var_set_bounds (space->vars[new_var_start + idx], 0, myub);

    #if 1
    ids[0] = psi_ids[1];
    ids[1] = new_var_start + idx;
    ids[2] = -1;
    WW[0] = -0.9 * myub;
    WW[1] = 1;
    #endif

    ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
      PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

    idx ++;
    XFREE (psi_ids);
  }


  // Be clean
  for (ii = 0; ii < nstmt; ii++)
    if (filter[ii])
  {
    int jj;
    for (jj = 0; jj < SI[ii].n_ref; jj++)
      //if (!SI[ii].ref[jj].is_const)
    {
      //printf ("Freeing mask of reference %d, statement %d\n",jj,ii);
      XFREE (SI[ii].ref[jj].mask);
    }
    //printf ("Freeing statement %d\n",ii);
    XFREE (SI[ii].ref);
  }
  XFREE (SI);

  timer_end = rtclock ();
 fprintf (CI->logfile, "[Ponos/Chunked] OPIR (with filter) time: %.4fs\n",timer_end - timer_start);
}


/*
 * Build constraints for fusion profitability that preservers parallelism.
 * Uses already inserted \psi variables.
 * If the \psi variables have not been inserted yet, we call them here.
 * Insert phi variables.
 * Insert FUS_PROF_CLUSTER_[neg|pos]_l variables
 * Main constraints (l is a scalar dimension, and not the last one)
 *   \phi_R_S_l >= 1 - \psi_R_{l+1} + \psi_S_{l+1}
 *   \phi_R_S_l >= 1 + \psi_R_{l+1} - \psi_S_{l+1}
 *
 * From the above, \phi_R_S_l is 1 when the \psi variables are equal,
 * and 0 when the \psi variable with neg coefficient is 1 and 
 * the other variable is 0.
 * The other combination of 0/1 for the psi variables are removed
 * by the fact that \phi is a binary variable.
 * 
 * Then, FUS_PROF_CLUSTER_pos_l = \sum ZZ_i x \phi_R_S_i_l
 * We also have: 
 *  FUS_PROF_CLUSTER_pos_l + FUS_PROF_CLUSTER_neg_l = some_upper_bound
 * The upper bound is computed while building the constraints.
 */
void 
ponos_perfidiom_fusion_preserving_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter)
{
  if (! space || !space->vars || !space->space || !space->scop || !filter)
    return;

  double timer_start, timer_end;
  timer_start = rtclock ();

  int n_stmt = CI->n_stmt;
  int cluster_size = (clusterid == SINGLECLUSTER ? 
    CI->n_stmt : CG->fgraph->nodes[clusterid].n_members);

  s_ponos_var_t * negvars[space->num_sched_dim];
  s_ponos_var_t * posvars[space->num_sched_dim]; 
  char buffer[100];
  int count = 0;
  for (int ll = 0; ll < space->num_sched_dim - 1; ll++)
    if (ll % 2 == 0)
  {
    assert (ll < space->num_sched_dim);
    assert (count < space->num_sched_dim);
    sprintf (buffer,"FUS_PROF_CLUSTER%d_NEG_L%d",clusterid,ll);
    negvars[count] = ponos_space_var_create (buffer, PONOS_VAR_FUS_PROF, ll, 0, 0, NULL);
    ponos_space_var_set_bounds (negvars[count], 0, cluster_size);
    count++;
  }
  ponos_space_bulk_variable_insertion_at_start (space, negvars, count);
  int start_pos = space->num_vars;
  count = 0;
  for (int ll = 0; ll < space->num_sched_dim - 1; ll++)
    if (ll % 2 == 0)
  {
    assert (ll < space->num_sched_dim);
    assert (count < space->num_sched_dim);
    sprintf (buffer,"FUS_PROF_CLUSTER%d_POS_L%d",clusterid,ll);
    posvars[count] = ponos_space_var_create (buffer, PONOS_VAR_FUS_PROF, ll, 0, 0, NULL);
    ponos_space_var_set_bounds (posvars[count], 0, cluster_size);
    //ponos_space_var_skip_cplex (posvars[count]);
    ponos_space_insert_variable_last (space, posvars[count]);
    count++;
  }
  int n_fus_pro = count;

  for (int ii = 0; ii < count; ii++)
  {
    fprintf (CI->logfile, "Var created at position %d: %s\n",ii,space->vars[ii]->name);
    fprintf (CI->logfile, "Var created at position %d: %s\n",ii + start_pos, space->vars[start_pos + ii]->name);
  }

  fprintf (CI->logfile, "Inserted fusion profitability varibles (FUS_PROF,%d)\n",n_fus_pro);

  // Matrix RR will store the number of array references that
  // two statements have in common.
  // TODO: scale this later, for instance, with the dimensionality
  // of the array.
  int RR[n_stmt][n_stmt];
  for (int ii = 0; ii < n_stmt; ii++)
    for (int jj = 0; jj < n_stmt; jj++)
  {
    RR[ii][jj] = 0;
  }

  for (int ii = 0; ii < n_stmt; ii++)
    for (int jj = 0; jj < n_stmt; jj++)
      if (filter[ii] && filter[jj])
  {
    //RR[ii][jj] = 0;
    for (int aa = 1; aa <= space->scop->nb_arrays; aa++)
    {
      int found1 = 0;
      int found2 = 0;
      #if 1
      scoplib_matrix_p ref;
      ref = CI->SA[ii]->read;
      for (int rr = 0; rr < ref->NbRows; rr++)
      {
        int si = SCOPVAL_get_si (ref->p[rr][0]);
        if (si == aa)
        {
          found1 = 1;
          break;
        }
      }
      ref = CI->SA[jj]->read;
      for (int rr = 0; rr < ref->NbRows; rr++)
      {
        int si = SCOPVAL_get_si (ref->p[rr][0]);
        if (si == aa)
        {
          found2 = 1;
          break;
        }
      }
      if (found1 && found2)
        RR[ii][jj] ++;
      #endif
    }
  }
 fprintf (CI->logfile, "Counted number of common variables between pairs of statements\n");

  for (int ii = 0; ii < n_stmt; ii++)
  {
    for (int jj = 0; jj < n_stmt; jj++)
     fprintf (CI->logfile, "R[%d][%d] = %d\n",ii,jj,RR[ii][jj]);
   fprintf (CI->logfile, "\n");
  }

 fprintf (CI->logfile, "Attempting to allocate %d variables\n",n_stmt);
  int phis[(n_stmt * n_stmt + 1)];
  int ZZ[n_stmt * n_stmt + 1];

  int * beta_ids = collect_theta_ids_from_cluster (space, CI, -1, NULL, PONOS_VAR_THETA_CST);
  int * psi_ids = collect_psi_ids_from_cluster (space, CI, -1, filter);

 fprintf (CI->logfile, "Collected delta, beta and psi variables\n");

  int psi_exist = 1;
  {
    int ii;
    for (ii = 0; beta_ids && beta_ids[ii] != -1; ii++);
   fprintf (CI->logfile, "Number of betas found : %d\n",ii);

    for (ii = 0; psi_ids && psi_ids[ii] != -1; ii++);
   fprintf (CI->logfile, "Number of psis found : %d\n",ii);
    if (!psi_ids || !ii)
      psi_exist = 0;
  }

  if (!psi_exist)
  {
    // Create the psi variables and constraints.
    ponos_perfidiom_parallelism (space, options, CI, CG, clusterid, filter, -1);
    if (psi_ids)
      XFREE (psi_ids);
    // Collect again the psi ids.
    psi_ids = collect_psi_ids_from_cluster (space, CI, -1, filter);
  }

  int n_levels = space->num_sched_dim;


  // Collect the delta variables from at level 0 of the schedule.
  // We just want to know the number of dependences we will have inside
  // the cluster.
  int * tmp_ids = collect_delta_ids_from_cluster (space, CI, 0, filter);
  int n_dep;

  // Need to count the number of dependences collected because
  // we are using the filter mode, i.e. we only want the dependences
  // that fall within the current cluster.
  for (int dd = 0, n_dep = 0; tmp_ids && tmp_ids[dd] != -1; dd++, n_dep++);
  int prev_phi[n_dep];
  for (int dd = 0, n_dep = 0; tmp_ids && tmp_ids[dd] != -1; dd++, n_dep++)
    prev_phi[dd] = -1;
  XFREE (tmp_ids);

  int scaldim = 0;
  int cov[n_stmt][n_stmt];
  for (int ll = 0; ll < n_levels - 1; ll++)
    if (ll % 2 == 0)
  {
    int fus_ub = 0;
    int count = 0;

    for (int ii = 0; ii < n_stmt; ii++)
      for (int jj = 0; jj < n_stmt; jj++)
    {
      cov[ii][jj] = 0;
    }

   fprintf (CI->logfile, "Adding constraints and objectives for cluster%d, level %d\n",clusterid,ll);

    // Collect deltas at current level. 
    // We only process scalar dimensions (which affect fusion).
    int * delta_ids = collect_delta_ids_from_cluster (space, CI, ll, filter);

    for (int dd = 0; delta_ids && delta_ids[dd] != -1; dd++)
    {
      int varid = delta_ids[dd];
      //printf ("Attempting to access variable %s (%d,max = %d)\n",
      //  space->vars[varid]->name, varid, space->num_vars - 1);
      CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
      int stmt_R_id = dep->source->label;
      int stmt_S_id = dep->target->label;
      int stmt_R_cid = get_stmt_number_in_cluster (stmt_R_id, filter);
      int stmt_S_cid = get_stmt_number_in_cluster (stmt_S_id, filter);

      // No point in processing self-dependences.
      if (stmt_R_id == stmt_S_id)
        continue;

      //printf ("%d <= %d, %d <= %d\n", stmt_R_id, n_stmt - 1, stmt_S_id, n_stmt - 1);

      // Skip if it has already been covered previously.
      if (cov[stmt_R_id][stmt_S_id])
        continue;

      // Skip the rest of the statement is lower dimensional that the
      // full schedule.
      if (ll > CI->SA[stmt_R_id]->nb_iterators || 
          ll > CI->SA[stmt_S_id]->nb_iterators)
        continue;

      // Create the PHI variable between statements R and S at level ll.
      char buffer[100];
      sprintf (buffer,"PHI_S%d_S%d_L%d",stmt_R_id, stmt_S_id, ll);
     fprintf (CI->logfile, "Attempting to insert variable %s\n",buffer);
      s_ponos_var_t * phi_R_S = ponos_space_var_create (buffer, PONOS_VAR_PHI, ll, 0, 0, NULL);
      //ponos_space_var_set_boolean (phi_R_S);
      //ponos_space_var_set_bounds (phi_R_S, 0, 1);
      ponos_space_insert_variable_last (space, phi_R_S);
      int phi_r_s_id_ll_curr  = space->num_vars - 1;

      ponos_chunked_set_var_lb_ub (space, space->num_vars - 1, 1, 0, 1);

     fprintf (CI->logfile, "Inserted variable %s\n",space->vars[phi_r_s_id_ll_curr]->name);
      //show_collected_variables (space, psi_ids);

      int psi_R = psi_ids[stmt_R_cid * n_levels + (ll + 1)];
      int psi_S = psi_ids[stmt_S_cid * n_levels + (ll + 1)];
      int ids[5];
      ids[0] = space->num_vars - 1;
      ids[1] = psi_R;
      ids[2] = psi_S;
      ids[3] = -1;
      int WW[5];
      WW[0] = -1;
      WW[1] = -1;
      WW[2] = 1;

      //printf ("Last inserted var is %d (%s)\n",ids[0], space->vars[ids[0]]->name);
      //printf ("PSI_R is %d \n",psi_R);//,space->vars[psi_R]->name );
      //printf ("PSI_S is %d \n",psi_S);//,space->vars[psi_S]->name);


     fprintf (CI->logfile, "Added constraint 1: 1 - %d %s + %d %s + %d %s >= 0\n",
        WW[0], space->vars[ids[0]]->name, 
        WW[1], space->vars[ids[1]]->name, 
        WW[2], space->vars[ids[2]]->name);

      // Add constraints: \phi_R_S_l <= 1 - \psi_R_l + \psi_S_l
      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, -1);


      WW[1] = 1;
      WW[2] = -1;

     fprintf (CI->logfile, "Added constraint 2: 1 - %d %s + %d %s + %d %s >= 0\n",
        WW[0], space->vars[ids[0]]->name, 
        WW[1], space->vars[ids[1]]->name, 
        WW[2], space->vars[ids[2]]->name);

      // Add constraints: \phi_R_S_l <= 1 + \psi_R_l - \psi_S_l
      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, -1);


      // Note: we collected ALL beta ids (all statements, all levels)
      int beta_R = beta_ids[ll * n_stmt + stmt_R_id];
      int beta_S = beta_ids[ll * n_stmt + stmt_S_id];
      ids[0] = beta_R;
      ids[1] = beta_S;
      ids[2] = psi_R;
      ids[3] = psi_S;
      ids[4] = -1;
      WW[0] = -1;
      WW[1] = 1;
      WW[2] = 1;
      WW[3] = -1;

      // \beta_S - \beta_R >= - \psi_R + \psi_S
      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

     fprintf (CI->logfile, "Added constraint 3: %d %s + %d %s + %d %s + %d %s >= 0\n",
        WW[0], space->vars[ids[0]]->name, 
        WW[1], space->vars[ids[1]]->name, 
        WW[2], space->vars[ids[2]]->name,
        WW[3], space->vars[ids[3]]->name);

      WW[2] = -1;
      WW[3] = 1;

      // \beta_S - \beta_R >= \psi_R - \psi_S
      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

     fprintf (CI->logfile, "Added constraint 4: %d %s + %d %s + %d %s + %d %s >= 0\n",
        WW[0], space->vars[ids[0]]->name, 
        WW[1], space->vars[ids[1]]->name, 
        WW[2], space->vars[ids[2]]->name,
        WW[3], space->vars[ids[3]]->name);

      // Do phi^{R,S}_k <= phi^{R,S}_{k-2}
      if (0) //ll > 0) // && prev_phi[dd] != -1)
      {
        int phi_r_s_id_ll_prev = prev_phi[dd];
        ids[0] = phi_r_s_id_ll_curr;
        ids[1] = phi_r_s_id_ll_prev;
        ids[2] = -1;
        WW[0] = -1;
        WW[1] = 1;

        ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
          PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

       fprintf (CI->logfile, "Added constraint: %d %s + %d %s >= 0\n",
          WW[0], space->vars[ids[0]]->name, 
          WW[1], space->vars[ids[1]]->name);
      }

      assert (count < n_stmt * n_stmt + 1);

      // This builds the constraint:
      // FUS_PROF_POS_l = \sum ZZ_l x \phi_r_s_l
      // Also computes the upper bound for FUS_PROF_POS_l
      if (RR[stmt_R_id][stmt_S_id])
      {
        phis[count] = phi_r_s_id_ll_curr;
        ZZ[count] = - RR[stmt_R_id][stmt_S_id];

        fus_ub += - ZZ[count];
        count ++;
      }

      cov[stmt_R_id][stmt_S_id] = 1;
      prev_phi[dd] = phi_r_s_id_ll_curr;
    }
    XFREE (delta_ids);

    //ponos_space_pprint_cst (stdout, space);

   fprintf (CI->logfile, "Done inserting constraint for dependences at level %d (# PHI vars = %d)\n",ll,count);
    for (int kk = 0; kk < count; kk++)
    {
     fprintf (CI->logfile, "PHI variable: %d %s\n",ZZ[kk], space->vars[phis[kk]]->name);
    }

    assert (count < n_stmt * n_stmt + 1);
    phis[count] = -1;
    int posvar = start_pos + scaldim;
    int negvar = scaldim;
    if (count > 0)
    {
      // Add constraint: fus_prof_pos_l = \sum ZZ_l x \phi_r_s_l
      ponos_space_create_weighted_summation (space, posvar, -1, phis, ZZ,
        PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
    }

    fprintf (CI->logfile, "Bounding fusion profitability variables\n");
    ponos_chunked_set_var_lb_ub (space, negvar, 1, 0, fus_ub);
    ponos_chunked_set_var_lb_ub (space, posvar, 1, 0, fus_ub);
    ponos_space_var_set_bounds (space->vars[negvar], 0, fus_ub);
    ponos_space_var_set_bounds (space->vars[posvar], 0, fus_ub);

    // fusprof_neg + fusprof_pos = fus_ub
    phis[0] = negvar;
    phis[1] = posvar;
    phis[2] = -1;
    ZZ[0] = -1;
    ZZ[1] = -1;
    fprintf (CI->logfile, "Bounding equation fusion profitability variables to total # of references\n");
    ponos_space_create_weighted_summation (space, -1, 0, phis, ZZ,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, -fus_ub);
    
    scaldim++;
  }

  fprintf (CI->logfile, "Done insertring FPP objectives\n");

  
  XFREE (beta_ids);
  XFREE (psi_ids);
  timer_end = rtclock ();
  fprintf (CI->logfile, "[Ponos/Chunked] Fusion Preserving Parallelism (FPP) time: %.4fs\n",
    timer_end - timer_start);
}


