/*
 * istencil.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012-2018 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Authors:
 * Martin Kong <martin.richard.kong@gmail.com>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>
#include <ponos/objectives.h>
#include <ponos/codelet.h>
#include <ponos/chunked.h>

#include <time.h>
#include <sys/time.h>

#include "iutil.c"




void
ponos_chunked_stencil_objectives (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int ii;
  int max_dim = space->num_sched_dim;
  int WFD[max_dim];
  int WNFD[max_dim];
  int scalw = max_dim / 2;// max_dim / 2 + 1;
  int linw =  max_dim / 2;

  scalw++;
  linw = 1;
  for (ii = 0; ii < max_dim; ii++)
  {
    if (ii % 2 == 0)
    {
      WFD[ii] = scalw;
      WNFD[ii] = scalw;
      scalw--;
    }
    else
    {
      WFD[ii] = linw;
      WNFD[ii] = linw;
      linw++;
    }
  }
  WFD[max_dim-1] = max_dim;
  WNFD[max_dim-1] = max_dim;
  int nflow_idx = 1;
  ponos_chunked_space_bulk_var_creation (space, options, "NONFLOW_PREF", 1);
  int flow_idx = 0;
  ponos_chunked_space_bulk_var_creation (space, options, "FLOW_PREF", 1);
  int* delta_ids = ponos_space_get_coefs (space, PONOS_VAR_DELTA);

  scoplib_statement_p stmt;
  int nstmt;
  //for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);
  nstmt = CI->n_stmt;
  scoplib_statement_p * SS;
  SS = XMALLOC (scoplib_statement_p, nstmt);
  for (ii = 0, stmt=space->scop->statement; stmt; stmt = stmt->next, ii++)
    SS[ii] = stmt;

  int * fids = XMALLOC (int, max_dim * CI->n_dep + 1);
  int * nfids = XMALLOC (int, max_dim * CI->n_dep + 1);
  int * fWW =  XMALLOC (int, max_dim * CI->n_dep + 1);
  int * nfWW =  XMALLOC (int, max_dim * CI->n_dep + 1);
  int kk_flow = 0;
  int kk_nflow = 0;
  int n_dep = CI->n_dep;
  // Collect all the delta variables IDs. Store them into two different sets,
  // depending on whether they are flow or non-flow dependences.
  for (ii = 0; ii < max_dim; ii++)
  {
    int jj;
    for (jj = 0; jj < n_dep; jj++)
    {
      int idx = ii * n_dep + jj;
      int varid = delta_ids[idx];
      CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr);
      int is_self = dep->source == dep->target;
      const char * deptype;
      if (dep->type == CANDL_RAW)
        deptype = "RAW";
      if (dep->type == CANDL_RAR)
        deptype = "RAR";
      if (dep->type == CANDL_WAW)
        deptype = "WAW";
      if (dep->type == CANDL_WAR)
        deptype = "WAR";
     fprintf (CI->logfile, "Dependence %d, is_self = %d, type = %s, level = %d\n",ii,is_self,deptype,dep->depth);
      if (dep->type == CANDL_RAW)
      {
        fids[kk_flow] = varid;
        fWW[kk_flow] = WFD[ii];
        kk_flow ++;
        // This adds constraints that try to skew when a dependence is satisfied
        if (ii % 2 == 1 && ii > 1 && 0) // && CI->n_stmt <= 2)
        {
          int src_id = dep->source->label;
          int dst_id = dep->target->label;
          int * theta_src_ids = ponos_space_get_coefs_dim_stmt (space, SS[src_id], ii, PONOS_VAR_THETA);
          int * theta_dst_ids = ponos_space_get_coefs_dim_stmt (space, SS[dst_id], ii, PONOS_VAR_THETA);
          int ll;
          int n_src;
          int n_dst;
          for (ll = 0; theta_src_ids[ll] != -1; ll++);
          n_src = ll;
          for (ll = 0; theta_dst_ids[ll] != -1; ll++);
          n_dst = ll;
          int * DC = XMALLOC (int, n_src + n_dst + 2);
          int * WDC =  XMALLOC (int, n_src + n_dst + 2);
          for (ll = 0; theta_dst_ids[ll] != -1; ll++)
          {
            DC[ll] = theta_dst_ids[ll];
            WDC[ll] = 1;
          }
          for (ll = 0; theta_src_ids[ll] != -1; ll++)
          {
            DC[n_dst+ll] = theta_src_ids[ll];
            WDC[n_dst+ll] = -1;
          }
          DC[n_dst + n_src] = varid;
          WDC[n_dst + n_src] = -4;
          DC[n_dst + n_src + 1] = -1;
          ponos_space_create_weighted_summation (space, -1, 0, DC, WDC,
            PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
          XFREE (DC);
          XFREE (WDC);
          XFREE (theta_src_ids);
          XFREE (theta_dst_ids);
        }
      }
      else
      {
        nfids[kk_nflow] = varid;
        nfWW[kk_nflow] = WNFD[ii];
        kk_nflow ++;
      }
    }
  }
  fids[kk_flow] = -1;
  nfids[kk_nflow] = -1;

  ponos_space_create_weighted_summation (space, flow_idx, 1, fids, fWW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
  ponos_space_create_weighted_summation (space, nflow_idx, 1, nfids, nfWW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  XFREE (delta_ids);
  XFREE (SS);
  XFREE (fids);
  XFREE (nfids);
  XFREE (fWW);
  XFREE (nfWW);
}


void 
ponos_chunked_stencil_skewing_constraints (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  scoplib_statement_p stmt;

  for (stmt=space->scop->statement, nstmt=0; stmt; stmt = stmt->next, nstmt++);

  int * ids;
  int * jds;
  int n_iter;
  int max_depth = (space->num_sched_dim - 1) / 2; 
  int weights[2 * max_depth];
  int all_ids[2 * max_depth + 1];
  all_ids[2 * max_depth] = -1;

  int prime[10];
  prime[0] = 0;
  prime[1] = 0;
  prime[2] = 0;
  prime[3] = 0;
  prime[4] = 0;
  int bigM[10][10];
  bigM[0][0] = 1;
  bigM[0][1] = 1;
  bigM[0][2] = 1;
  bigM[0][3] = 1;

  bigM[1][0] = 1;
  bigM[1][1] = 1;
  bigM[1][2] = 1;
  bigM[1][3] = 1;

  bigM[2][0] = 1;
  bigM[2][1] = 1;
  bigM[2][2] = 1;
  bigM[2][3] = 1;

  bigM[3][0] = 1;
  bigM[3][1] = 1;
  bigM[3][2] = 1;
  bigM[3][3] = 1;

  int is_SS[nstmt]; 
  int n_SS = 0;
  for (i = 0, stmt=space->scop->statement; i < nstmt; i++, stmt = stmt->next)
  {
    int must_skew = is_stencil_statement (stmt);
    is_SS[i] = must_skew;

    //if (is_SS[i])
    {
      char buffer[32]; sprintf (buffer, "ANTI_SKEW_S%d",i);
      s_ponos_var_t* optvar =
        ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
      ponos_space_insert_variable_first (space, optvar);
      n_SS++;
    }
  }

  int * xds[nstmt][max_depth];
  for (stmt=space->scop->statement, i = 0; stmt; stmt = stmt->next, i++)
  {
    n_iter = stmt->nb_iterators;
    for (j = 0; j < max_depth; j++)
      if (j < n_iter)
        xds[i][j] = ponos_space_get_coefs_dim_stmt (space, 
          stmt, 2*j + 1, PONOS_VAR_THETA_ITER);
      else
        xds[i][j] = NULL;
  }
  
  int l,k;
  int SSid = 0;
  for (i = 0, stmt=space->scop->statement; i < nstmt; i++, stmt = stmt->next)
  {
    n_iter = stmt->nb_iterators;
    int must_skew = is_stencil_statement (stmt);
    fprintf (CI->logfile, "Statement %s is stencil = %d\n",stmt->body, must_skew);
    //if (!must_skew)
    //  continue;
   fprintf (CI->logfile, "Adding skewing constraints on statement %d (%s)\n",i,(stmt->body));
    // For each statement, force the coefficients of two consecutive rows s.t:
    // \sum_j \theta_{i,j} - \sum \theta_{i-1,j} > 1
    for (j = 1; j < n_iter; j++)
    {

      k = 0;
      int sign;
      sign = -1; // -1 means row_i < row_{i-1}, 1 means row_i > row_{i-1}
      for (l = 0; xds[i][j][l] != -1; l++)
        if (xds[i][j][l])
      {
        all_ids[k] = xds[i][j][l];
        weights[k] = sign * bigM[j][l];
        k++;
      }

      for (l = 0; xds[i][j-1][l] != -1; l++)
        if (xds[i][j-1][l])
      {
        all_ids[k] = xds[i][j-1][l];
        weights[k] = - sign * bigM[j-1][l];
        k++;
      }

      all_ids[k] = -1;

     fprintf (CI->logfile, "Adding descending sum constraint for level %d\n",j);
      ponos_space_create_weighted_summation (space, -1, 0, all_ids, weights,
        PONOS_CONSTRAINT_GREATER, PONOS_OBJECTIVE_MINIMIZE, 0) ;//prime[j-1]); 

      //int OID[3];
      //OID[0] = xds[i][j][0];
    }


    #if 1
    if (nstmt >= 2) // (nstmt >= 2 && nstmt <= 4)
    {
      // this works well for seidel-2d, fdtd-2d and jacobi-2d, but gives no solution for dynprog and reg_detect 
     fprintf (CI->logfile, "Adding skew avoiding constraints ...\n");
      //for (l = n_iter - 1; l < n_iter; l++)
      l = n_iter - 1;
      {
        k = 0;
        int sign;
        sign = 1;
        all_ids[1] = -1;
        for (j = 0; j < n_iter; j++)
          if (xds[i][j][l])
        {
          all_ids[k] = xds[i][j][l];
          int the_id = xds[i][j][l];
          weights[k] = sign * bigM[j][l];
          assert (the_id >= 0 && "Cannot have a negative index here!!!");
          if (j < n_iter - 1)
          {
            ponos_space_create_weighted_summation (space, -1, 0, all_ids, weights,
              PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
            //ponos_space_set_variable_to_value (space, the_id, 0, PONOS_CONSTRAINT_EQUAL);
           fprintf (CI->logfile, "Nullified iterator of statement %d, dimensions %d, iterator %d\n",i,j,l);
          }
          else
          {
           fprintf (CI->logfile, "Forcing iterator of statement %d, dimension %d, iterator %d to be 1\n",i,j,l);
            ponos_space_create_weighted_summation (space, -1, 0, all_ids, weights,
              PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);

            //ponos_space_set_variable_to_value (space, the_id, 1, PONOS_CONSTRAINT_EQUAL);
          }
          // set the time-dimension coefficient of the innermost loop to 0
          int anid[2];
          anid[0] = xds[i][n_iter-1][0];
          anid[1] = -1;
          ponos_space_create_weighted_summation (space, -1, 0, anid, weights,
            PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

        
          // set the time-dimension coefficient of the outermost loop to the 
          // number of linear dimensions
          anid[0] = xds[i][0][0];
          anid[1] = -1;
          ponos_space_create_weighted_summation (space, -1, 0, anid, weights,
            PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, n_iter - 2);

        }
        for (j = 1; j < n_iter - 1; j++)
        {
          // set \theta^i(2j+1,0) to x
          int anid[2];
          anid[0] = xds[i][j][0];
          anid[1] = -1;
          ponos_space_create_weighted_summation (space, -1, 0, anid, weights,
            PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, n_iter - j - 1);

          // set \theta^i(2j+1,j) to y
          anid[0] = xds[i][j][j];
          anid[1] = -1;
          ponos_space_create_weighted_summation (space, -1, 0, anid, weights,
            PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, n_iter - j - 2);

          // set \theta^i(1,j) to z
          anid[0] = xds[i][0][j];
          anid[1] = -1;
          ponos_space_create_weighted_summation (space, -1, 0, anid, weights,
            PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
        }
        //ponos_chunked_set_theta_bounds (space, options, xds[i][0][0], 1, 2);

      }

      ponos_codelet_create_ge_cst (space, SSid, -1, 0);
      ponos_codelet_create_ge_cst (space, SSid, 1, 0);
    }
    #endif
    else if (0) //nstmt > 1)
    {
      all_ids[n_iter] = -1;
      for (j = 0; j < n_iter; j++)
      {
        all_ids[j] = xds[i][j][n_iter-1];   
        if (j < n_iter - 1)
          weights[j] = 3;
        else
          weights[j] = 1;
      }

      // SSid is the statement ID. This ties to the ANTI_SKEW variable
      ponos_space_create_weighted_summation (space, SSid, 1,
        all_ids, weights, PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
     fprintf (CI->logfile, "Done with stencil constraints for statement (%s)\n",stmt->body);


      ponos_codelet_create_ge_cst (space, SSid, -1, -n_iter * 3);
      ponos_codelet_create_ge_cst (space, SSid, 1, 1);

      SSid ++;
    }
  }

  for (i = 0; i < nstmt; i++)
  {
    for (j = 0; j < max_depth; j++)
      if (xds[i][j] != NULL)
        XFREE (xds[i][j]);
  }
 fprintf (CI->logfile, "Done with all stencil constraints\n");
}



void 
ponos_chunked_stencil_max_parallelism (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter)
{
  int n_stmt = CI->n_stmt;
  int cluster_size;
  if (clusterid == SINGLECLUSTER)
    cluster_size = n_stmt;
  else
    cluster_size = CG->fgraph->nodes[clusterid].n_members;
  
  int nodetype = CG->fgraph->nodes[clusterid].nodetype;
  if (nodetype != FNODE_TYPE_STEN)
    return;

  char buffer[100];
  sprintf (buffer,"STEN_MAX_PAR_CLUSTER_N%d",clusterid);
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);

  sprintf (buffer,"STEN_MAX_PAR_CLUSTER_P%d",clusterid);
  optvar =
    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
  ponos_space_insert_variable_last (space, optvar);

  int negvar = 0;
  int posvar = space->num_vars - 1;

  int ii;
  int * deltas = collect_delta_ids_from_cluster (space, CI, 1, filter);
  int * selfdeltas = XMALLOC (int, CI->n_dep);
  int count = 0;
  int WW[CI->n_dep];
  for (ii = 0; deltas && deltas[ii] != -1; ii++)
  {
    int varid = deltas[ii];
    CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr); 

    int src_id = dep->source->label;
    int dst_id = dep->target->label;

    if (src_id != dst_id)
      continue;

    if (!filter[src_id])
      continue;
      
    WW[count] = -1;
    selfdeltas[count++] = deltas[ii]; 
  }
  selfdeltas[count] = -1;

  ponos_space_create_weighted_summation (space, posvar, 1, selfdeltas, WW, 
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE, 0);

  int ids[3];
  ids[0] = negvar;
  ids[1] = posvar;
  ids[2] = -1;
  ponos_space_create_weighted_summation (space, -1, 0, ids, WW, 
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MAXIMIZE, -count);
  
  ponos_chunked_set_var_lb_ub (space, negvar, 1, 0, count);
  ponos_chunked_set_var_lb_ub (space, posvar, 1, 0, count);

  XFREE (deltas);
  XFREE (selfdeltas);
}


void 
ponos_chunked_stencil_par_constraints (s_ponos_space_t* space,
    s_ponos_options_t* options, 
    s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter)
{
  s_fnode_t * fnode = &CG->fgraph->nodes[clusterid];
  int n_stmt = CI->n_stmt;
  int cluster_size;
  if (clusterid == SINGLECLUSTER)
    cluster_size = n_stmt;
  else
    cluster_size = fnode->n_members;
  int ii;
  double timer_start, timer_end;
  timer_start = rtclock ();

  int n_lin_dim =  fnode->max_depth; //space->num_sched_dim / 2; 
  int n_sched_dim = n_lin_dim * 2 + 1; //space->num_sched_dim;

  // WARNING: we are collecting all statements here, even from other clusters.
  int * theta_ids = ponos_space_get_coefs (space, PONOS_VAR_THETA_CST);
  //int * theta_ids = collect_theta_ids_from_cluster (space, CI, -1, filter, PONOS_VAR_THETA_CST);



  // WARNING: the below macro uses "n_stmt" = all statements in the SCoP
  #define get_cst_coef(ss,ll) (theta_ids[(2*(ll)+1) * n_stmt + ss])

  int * delta_ids = collect_delta_ids_from_cluster (space, CI, 0, filter);
  fprintf (CI->logfile, "Showing collected variables for stencil par constraints: \n");
  //show_collected_variables (space, delta_ids);
  int ids[3];

  fprintf (CI->logfile, "Initializing covering matrix\n");
  int COV[n_stmt][n_stmt];
  for (ii = 0; ii < n_stmt; ii++)
  {
    int jj;
    for (jj = 0; jj < n_stmt; jj++)
      COV[ii][jj] = 0;
  }

  int op_per_vec = CI->archinfo.simdlen / CI->archinfo.fp_precision;
  int skew_ok = CI->archinfo.n_cores < 2 * op_per_vec;

 fprintf (CI->logfile, "Performing space and time shifting ...\n");
  // This only affects RAW dependences
  for (ii = 0; delta_ids && delta_ids[ii] != -1; ii++)
  {
    int WW[2];
    CandlDependence * dep = (CandlDependence*)(space->vars[delta_ids[ii]]->scop_ptr); 

    if (dep->type != CANDL_RAW)
      continue;

    int src_id = dep->source->label;
    int dst_id = dep->target->label;
    
    // skip self dependences
    if (src_id == dst_id)
      continue;

    // Skip statements that are not mapped to the same SCC
    if (CG->scc_map[src_id] != CG->scc_map[dst_id])
      continue;

    if (COV[src_id][dst_id] || COV[dst_id][src_id])
      continue;

    if (!filter[src_id] || !filter[dst_id])
      continue;

    fprintf (CI->logfile,"Collected delta variable %s (%d->%d)\n",
      space->vars[delta_ids[ii]]->name, src_id, dst_id);

    // Should not reach this point if we have only one statement in the cluster
    assert (cluster_size > 1);

    // For a "space shift" on the first space dimension (2nd linear dimension)
    // like so : cst^dst_1 - cst^src_1 >= 16
    ids[0] = get_cst_coef(dst_id,1);
    ids[1] = get_cst_coef(src_id,1);
    ids[2] = -1;
    WW[0] = 1;
    WW[1] = -1;

    int space_shift = (skew_ok ? 1 : 16);
    if (!skew_ok)
    {
      // Applies only to KNL.
      // Not necessary when skewing is applied.
      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 16);
    }

    // Force a "time shift" on the outer linear dimension (time dimension)
    // like so: cst^dst_0 - cst^src_0 >= 1
    ids[0] = get_cst_coef(dst_id,0);
    ids[1] = get_cst_coef(src_id,0);
    ids[2] = -1;
    WW[0] = 1;
    WW[1] = -1;

    // Mostly used with skewing for parallelism.
    ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
      PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);

    // Update the covering matrix to skip future ocurrences pertaining the
    // same set of statements
    COV[src_id][dst_id] = 1;
    COV[dst_id][src_id] = 1;
  }

  fprintf (CI->logfile,"Freeing used thetas and deltas\n");

  XFREE (theta_ids);
  XFREE (delta_ids);


 fprintf (CI->logfile, "Adding skewing constraints (1) (skew_ok = %d\n",skew_ok);
  for (ii = 0; ii < n_stmt; ii++)
    if (filter[ii])
  {
    int * thetas;
    thetas = ponos_space_get_coefs_stmt (space, CI->SA[ii], PONOS_VAR_THETA_ITER);
    int nn;
    for (nn = 0; thetas[nn] != -1; nn++);
    nn = nn / space->num_sched_dim; //n_sched_dim;
    int ids[2 * n_lin_dim + 1]; 
    int WW[2 * n_lin_dim + 1]; 

    int n_iter = CI->SA[ii]->nb_iterators;

    int jj;
    for (jj = 1; jj < n_iter; jj++)
    {
      #if 0
      // - T[0,0] + T[K,0] >= 0 => T[K,0] >= T[0,0]
      ids[0] = thetas[(0 * 2 + 1) * nn + 0];
      ids[1] = thetas[(jj * 2 + 1) * nn + 0];
      ids[2] = -1;
      WW[0] = -1;
      WW[1] = 1;

      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
      #endif

      #if 0
      // - T[K,J] + T[K,0] >= 0 => T[K,0] >= T[K,J]
      ids[0] =  thetas[(jj * 2 + 1) * nn + jj]; // space coef
      ids[1] = thetas[(jj * 2 + 1) * nn + 0];
      ids[2] = -1;
      WW[0] = -1;
      WW[1] = 1;

      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
      #endif
  
      #if 1
      // T[K,J] >= 1
      ids[0] =  thetas[(jj * 2 + 1) * nn + jj]; // space coef
      ids[1] = -1;
      WW[0] = 1;
      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);
      #endif
    }

    XFREE (thetas);
  }

  // Count number of full dimensional statements
  int nfds = 0;
  for (ii = 0; ii < n_stmt; ii++)
    if (filter[ii])
  {
    int n_iter = CI->SA[ii]->nb_iterators;
    if (n_iter * 2 + 1 == n_sched_dim) //space->num_sched_dim)
      nfds++;
  }

  // Forall linear dimensions k: \sum \theta^R_k,j - \theta^R k+1,j >= 0
  for (ii = 0; ii < n_stmt && skew_ok; ii++)
    if (filter[ii])
  {
    int jj;
    int n_iter = CI->SA[ii]->nb_iterators;
    int * theta_ids = ponos_space_get_coefs_stmt (
      space, CI->SA[ii], PONOS_VAR_THETA_ITER);
    int ids[2 * n_iter + 1];
    ids[2 * n_iter] = -1;
    int WW[2 * n_iter];
    // sanity check:
    for (jj = 0; theta_ids && theta_ids[jj] != -1; jj++);
    assert (jj == space->num_sched_dim * n_iter);
    for (jj = 0; jj < n_iter; jj++)
    {
      WW[jj] = 1;
      WW[n_iter + jj] = -1;
    }

    //for (jj = 0; jj < space->num_sched_dim / 2 - 1; jj++)
    for (jj = 0; jj < n_lin_dim - 1; jj++)
    {
      int kk;
      int min_dist  = (jj > 0 ? 1 : 0);
      for (kk = 0; kk < n_iter; kk++)
        ids[kk] = theta_ids[(2 * jj + 1) * n_iter + kk];
      for (kk = 0; kk < n_iter; kk++)
        ids[n_iter + kk] = theta_ids[(2 * (jj + 1) + 1) * n_iter + kk];
      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, min_dist);

    }

    // Set the sum of coefficients of the first linear dimension
    // to be >= than the number of full dimensional statements
    if (n_iter * 2 + 1 == n_sched_dim) //space->num_sched_dim)
    {
      for (jj = 0; jj < n_iter; jj++)
        ids[jj] = theta_ids[n_iter + jj];
      ids[jj] = -1;
      ponos_space_create_summation (space, -1, ids,
        PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, nfds);
    }

    XFREE (theta_ids);
  }

  fprintf (CI->logfile, "Creating DELTA_SUM* variables\n");

  // Create new variables here. We will collect deltas right after this.
  char buffer[100];
  sprintf (buffer,"DELTA_SUM_SELF_N_CLUSTER_%d",clusterid);
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
  ponos_space_insert_variable_first (space, optvar);

  sprintf (buffer,"DELTA_SUM_SELF_P_CLUSTER_%d",clusterid);
  optvar =
    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
  ponos_space_insert_variable_last (space, optvar);
  int last_id = space->num_vars - 1;

  // Enforce a particular type of skewing transfo
  int constraint[2 * n_lin_dim + 2];
  int WW[2 * n_lin_dim + 2];
  //int * deltas = ponos_space_get_coefs (space, PONOS_VAR_DELTA);
  int * deltas = collect_delta_ids_from_cluster (space, CI, -1, filter);
  int n_dep;
  for (n_dep = 0; deltas && deltas[n_dep] != -1; n_dep++);
  n_dep = n_dep / space->num_sched_dim;
  for (ii = 0; ii < n_lin_dim + 2; ii++)
    WW[ii] = 1;


 fprintf (CI->logfile, "Adding skewing constraints ...\n");
  for (ii = 0; ii < n_stmt; ii++)
    if (filter[ii])
  {
    // Collect the theta iter of statement ii
    int * theta_s = ponos_space_get_coefs_stmt (
      space, CI->SA[ii], PONOS_VAR_THETA_ITER);

    int n_iter = CI->SA[ii]->nb_iterators;

    int dd;
   fprintf (CI->logfile, "Found dependences in par.const (skewing): %d\n",n_dep);
    for (dd = 0; dd < n_dep; dd++)
    {
      CandlDependence * dep = (CandlDependence*)(space->vars[deltas[dd]]->scop_ptr); 

      int src_id = dep->source->label;
      int dst_id = dep->target->label;
        
      // skip dependences which are not self
      if (src_id != dst_id)
        continue;

      if (src_id != ii)
        continue;

      // Skip if the dependence does not belong to the cluster
      if (!filter[src_id])
        continue;

      fprintf (CI->logfile,"==> Dependence %d (%d->%d)\n", dd, src_id, dst_id);

      int ll = (cluster_size == 1 ? 0 : 1);
      //for (ll = 0; ll <= 1; ll++) //n_iter; ll++)
      {
        // Build constraint: T^S[ll,0] + \sum_{i=1 to ll - 1} \delta^{S,S}_{i} >= 1
        int jj;
        int tid = theta_s[(2 * ll + 1) * n_iter + 0];
        constraint[0] = deltas[(2 * ll + 1) * n_dep + dd];
        constraint[1] = -1;
        WW[0] = 1;
        WW[1] = -1;

        fprintf (CI->logfile, "Showing skewing constraint for stmt %d, dependence %d, level %d (n_iter=%d)\n",ii, dd, ll, n_iter);
        for (jj = 0; constraint[jj] != -1; jj++)
          fprintf (CI->logfile, "+ %s ",space->vars[constraint[jj]]->name);
        fprintf (CI->logfile, ">= 1\n");

        ponos_space_create_weighted_summation (space, tid, 1, constraint, WW,
          PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
      }
    }

   fprintf (CI->logfile, "Mark, statement %d\n",ii);

    // Do: \sum_{i=1 to n_iter} \theta^s_{1,i} - \sum_{i=1 to n_iter} \theta^s_{3,i} > 0

    XFREE (theta_s);
  }

 fprintf (CI->logfile, "Mark here\n");

  // Create an objective to solve the deltas of the self dependences at
  // the second linear dimension (1st space dimension)

  int dids[n_dep + 3];
  int ZZ[n_dep + 3];
  //dids[0] = 0;
  dids[0] = last_id;
  int idx = 1;
  ZZ[0] = 1;
  ZZ[1] = 1;
 fprintf (CI->logfile, "Number of dependences at this point: %d\n",n_dep);
  int n_self_deps = 0;
  for (ii = 0; ii < n_dep; ii++)
  {
    int varid = deltas[(1 * 2 + 1) * n_dep + ii]; // use deltas at level 1
    CandlDependence * dep = (CandlDependence*)(space->vars[varid]->scop_ptr); 

    int src_id = dep->source->label;
    int dst_id = dep->target->label;
      
    // skip dependences which are not self
    if (src_id != dst_id)
      continue;

    if (!filter[src_id])
      continue;

    n_self_deps++; // Cannot rely on CI->n_self_dep, since we might be in cluster mode

    // Only delta variables of the 1st space dimension
    dids[idx] = varid;
    ZZ[idx] = -1;
    idx++;
  }
  dids[idx] = -1;
  fprintf (CI->logfile, "Optimization function : ");
  for (ii = 0; dids[ii] != -1; ii++)
    fprintf (CI->logfile, " + (%d) x %s",ZZ[ii],space->vars[dids[ii]]->name);
  fprintf (CI->logfile, "\n");

  // Do: neg + pos = sum of deltas at level 3
  ponos_space_create_weighted_summation (space, -1, 0, dids, ZZ,
    PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
  
  // This does: neg + pos = n_self_deps
  dids[1] = 0;
  ZZ[1] = 1;
  dids[2] = -1;
  ponos_space_create_weighted_summation (space, -1, 0, dids, ZZ,
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, n_self_deps);

  ponos_codelet_create_ge_cst (space, 0, 1, 0);
  ponos_codelet_create_ge_cst (space, 0, -1, - n_self_deps);
  ponos_codelet_create_ge_cst (space, last_id, 1, 0);
  ponos_codelet_create_ge_cst (space, last_id, -1, - n_self_deps);

  XFREE (deltas);
  timer_end = rtclock ();
 fprintf (CI->logfile, "[Ponos/Chunked] StencilParCons time: %.4fs\n",timer_end - timer_start);
}



void 
ponos_chunked_stencil_minimize_vector_skewing (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
    int clusterid, int * filter)
{
  int n_stmt = CI->n_stmt;
  int cluster_size = (clusterid == SINGLECLUSTER ? 
    n_stmt : CG->fgraph->nodes[clusterid].n_members);
  double timer_start, timer_end;
  timer_start = rtclock ();

  int n_lin_dim = space->num_sched_dim / 2; 
  int n_sched_dim = space->num_sched_dim;

  s_ponos_var_t ** frontv;
  frontv = XMALLOC (s_ponos_var_t *, cluster_size + 1);

  // Create front variables to which we will sum the deltas
  int ii;
  int count = 0;
  for (ii = 0; ii < CI->n_stmt; ii++)
    if (filter[ii])
  {
    char buffer[100];
    sprintf (buffer,"S%d_VEC_SKEW",ii);
    frontv[count++] = ponos_space_var_create (
      buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, CI->SA[ii]);
  }
  frontv[count] = NULL;
  ponos_space_bulk_variable_insertion_at_start (space, frontv, cluster_size);
  XFREE (frontv);

  int obj_var = 0; 
  for (ii = 0; ii < n_stmt; ii++)
    if (filter[ii])
  {
    int * theta_ids;
    int n_iter = CI->SA[ii]->nb_iterators;

    int ids[n_sched_dim * 2 + 1];
    theta_ids = ponos_space_get_coefs_stmt (space, CI->SA[ii], PONOS_VAR_THETA_ITER);

    int count = 0;
    // Force \sum theta_{inner_linear} <= 1
    int jj;
    for (jj = 0; jj < n_iter; jj++, count++)
    {
      ids[count] = theta_ids[(space->num_sched_dim - 2) * n_iter + jj];
    }

    // Force that the sum of the coefficients on the vector dim iterator <= 1
    for (jj = 0; jj < space->num_sched_dim - 2; jj++)
      if (jj % 2 == 1)
    {
      ids[count] = theta_ids[jj * n_iter + n_iter - 1];
      count++;
    }
    ids[count] = -1;

    ponos_space_create_summation (space, obj_var, ids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

    obj_var++;
    XFREE (theta_ids);
  }
}


/*
 * Add constraints that push dependence satisfaction into specific
 * dimensions. Consider number of statements and types of dependences
 * including if they are forward or backward.
 *
 */
void 
ponos_chunked_stencil_dependence_classification (s_ponos_space_t* space,
  s_ponos_options_t* options, s_chunked_info_t * CI, s_chunked_graph_t * CG,
  int clusterid, int * filter)
{
  // number of statements in cluster
  int n_stmt = CI->n_stmt;
  int cluster_size = (clusterid == SINGLECLUSTER ? 
    n_stmt : CG->fgraph->nodes[clusterid].n_members);
  int n_dep = CI->n_dep;
  int ii;
  double timer_start, timer_end;
  timer_start = rtclock ();

  int * delta_ids = collect_delta_ids_from_cluster (space, CI, 0, filter);
  for (ii = 0; delta_ids && delta_ids[ii] != -1; ii++);
  n_dep = ii;
  XFREE (delta_ids);

  // Add bounds to number of times a dependence is satisfied (max 2)
  // \sum_k \delta_k <= 2
  #ifdef PLDI19_BOUND_DEP_SAT
  delta_ids = collect_delta_ids_from_cluster (space, CI, -1, filter);
  for (ii = 0; ii < n_dep; ii++)
  {
    int ll;
    int ids[space->num_sched_dim+1];
    int WW[space->num_sched_dim];
    for (ll = 0; ll < space->num_sched_dim; ll++)
    {
      ids[ll] = delta_ids[ll * space->num_sched_dim + ii];
      WW[ll] = 1;
    }
    ids[ll] = -1;

    ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
      PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 2);
  }
  XFREE (delta_ids);
  #endif

  s_ponos_var_t ** frontv;
  s_ponos_var_t ** backv;
  int n_sched_dim = space->num_sched_dim;
  frontv = XMALLOC (s_ponos_var_t *, n_sched_dim + 1);
  backv = XMALLOC (s_ponos_var_t *, n_sched_dim + 1);

  // Create front variables to which we will sum the deltas
  for (ii = 0; ii < space->num_sched_dim; ii++)
  {
    char buffer[100];
    sprintf (buffer,"STEN_DELTA_DC_SUM_NEG_CLUSTER%d_L%d",clusterid,ii);
    frontv[ii] = ponos_space_var_create (
      buffer, PONOS_VAR_CST_SUM_VAR, ii, 0, 0, NULL);
  }
  frontv[ii] = NULL;
  ponos_space_bulk_variable_insertion_at_start (space, frontv, space->num_sched_dim);

  int back_start = space->num_vars;
  // Create the back variables corresponding to the variables above
  for (ii = 0; ii < space->num_sched_dim; ii++)
  {
    char buffer[100];
    sprintf (buffer,"STEN_DELTA_DC_SUM_POS_CLUSTER%d_L%d",clusterid,ii);
    backv[ii] = ponos_space_var_create (
      buffer, PONOS_VAR_CST_SUM_VAR, ii, 0, 0, NULL);
    ponos_space_insert_variable_last (space, backv[ii]);
  }
  XFREE (frontv);
  XFREE (backv);

 fprintf (CI->logfile, "Creating constraints on STEN_DELTA_DC variables\n");

  // Create the constraints.
  // For each level k: 
  //   neg_k + pos_k = n_dep
  //   0 <= neg_k, pos_k <= n_dep
  for (ii = 0; ii < space->num_sched_dim; ii++)
  {
    // Set neg bounds: 0 <= neg <= n_dep  (all in cluster)
    ponos_chunked_set_var_lb_ub (space, ii, 1, 0, n_dep);
    // Ditto for pos variables
    ponos_chunked_set_var_lb_ub (space, back_start + ii, 1, 0, n_dep);

    int ids[3], WW[2];
    ids[0] = ii;
    ids[1] = back_start + ii;
    ids[2] = -1;
    WW[0] = 1;
    WW[1] = 1;

    // neg + pos = n_dep
    ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, n_dep);
  }

  #if 1
  // Set \sum pos = num dep
  int jds[n_sched_dim + 1];
  for (ii = 0; ii < space->num_sched_dim; ii++)
  {
    jds[ii] = back_start + ii;
  }
  jds[ii] = -1;
  
  ponos_space_create_summation (space, -1, jds, 
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, n_dep);
  #endif

  int op_per_vec = CI->archinfo.simdlen / CI->archinfo.fp_precision;
  int skew_ok = CI->archinfo.n_cores < 2 * op_per_vec;


 fprintf (CI->logfile, "Linking /\\ variables to deltas ...\n");

  int ids[n_dep + 1];
  int WW[n_dep + 1];
  for (ii = 0; ii < space->num_sched_dim; ii++)
  {
    int * delta_ids;
    int * theta_ids;
    delta_ids = collect_delta_ids_from_cluster (space, CI, ii, filter);
    theta_ids = collect_theta_ids_from_cluster (space, CI, ii, filter, PONOS_VAR_THETA_CST);

   fprintf (CI->logfile, "Showing collected delta variables: \n");
    show_collected_variables (space, delta_ids);
   fprintf (CI->logfile, "Showing collected theta variables: \n");
    show_collected_variables (space, theta_ids);
    int jj;
    int count = 1;
    ids[0] = back_start + ii;
    WW[0] = 1;
    for (jj = 0; delta_ids && delta_ids[jj] != -1; jj++)
    {
      CandlDependence * dep;
      dep = (CandlDependence*)(space->vars[delta_ids[jj]]->scop_ptr); 
      int src_id = dep->source->label;
      int dst_id = dep->target->label;
     fprintf (CI->logfile, "Processing delta variable: (S%d->S%d)_%d\n",src_id,dst_id,ii);
      
      // self-deps, satisfy at second linear dimension
     fprintf (CI->logfile, "n_stmt here = %d\n", cluster_size);
      if (cluster_size > 1 && src_id == dst_id && ii == 3)
      {
        ids[count] = delta_ids[jj];
        WW[count] = -1;
        count++;
      }

      // seidel-2d case, split dependences among linear dimensions except
      // 1st space dimension
      if (cluster_size == 1 && ii != 3 && ii % 2 == 1)
      {
        ids[count] = delta_ids[jj];
        WW[count] = -1;
        count++;
      }

      // forward non-self deps, outer linear
      if (src_id < dst_id && ii == 1)
      {
        ids[count] = delta_ids[jj];
        WW[count] = -1;
        count++;
      }

      // backward non-self deps, scalar dimensions
      if (src_id > dst_id && ii % 2 == 0)
      {
        ids[count] = delta_ids[jj];
        WW[count] = -1;
        count++;
        int jds[4];
        int ZZ[3];
        assert (dst_id  >= 0);
        assert (src_id  >= 0);
        // Do: beta^S_k - beta^R_k - delta^{D_{R,S}}_k >= 0
        jds[0] = theta_ids[dst_id];
        jds[1] = theta_ids[src_id];
        jds[2] = delta_ids[jj];
        jds[3] = -1;
        ZZ[0] = 1;
        ZZ[1] = -1;
        ZZ[2] = -1;
        ponos_space_create_weighted_summation (space, -1, 0, jds, ZZ,
          PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

      }
    }
    ids[count] = -1;

    if (skew_ok || cluster_size == 1)
    {
     fprintf (CI->logfile, "Variables used for skew || cluster_size == 1 case: \n");
      show_collected_variables (space, ids);
      ponos_space_create_weighted_summation (space, -1, 0, ids, WW,
       //PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
        PONOS_CONSTRAINT_LOWEREQUAL, PONOS_OBJECTIVE_MAXIMIZE, 0);
    }

    XFREE (delta_ids);
    XFREE (theta_ids);
  }

  // assign weights to dimensions

  #ifdef PLDI19_PRIORITIZE_LEVELS
  char buffer[100];
  s_ponos_var_t * ponvar;
  sprintf (buffer,"STEN_DELTA_DC_SUM_SUM_POS_CLUSTER%d",clusterid);
  ponvar  = ponos_space_var_create (
    buffer, PONOS_VAR_CST_SUM_VAR, 0, 0, 0, NULL);
  ponos_space_insert_variable_first (space, ponvar);
  int ZZ[space->num_sched_dim];
  int ids2[space->num_sched_dim+2];
  int ub = space->num_sched_dim - 3;
  int ll;
  for (ll = 0; ll < space->num_sched_dim; ll++)
  {
    if (ll == 3)
      ZZ[ll] = space->num_sched_dim - 1;
    else if (ll == 1)
      ZZ[ll] = 1;
    else if (ll == space->num_sched_dim - 2)
      ZZ[ll] = space->num_sched_dim - 2;
    else 
      ZZ[ll] = ub--;
    ids2[ll] = back_start + 1 + ll;
  }
  ids2[ll] = -1;
  ponos_space_create_weighted_summation (space, 0, 1, ids2, ZZ,
    PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);
  ids2[1] = -1;
  ponos_space_create_weighted_summation (space, 0, 1, ids2, ZZ,
    PONOS_CONSTRAINT_GREATEREQUAL, PONOS_OBJECTIVE_MINIMIZE, 1);
  #endif
}




void
ponos_chunked_parallelize_stencil (s_ponos_space_t* space,
    s_ponos_options_t* options, s_chunked_info_t * cinfo)
{
  if (! space || !space->vars || !space->space || !space->scop)
    return;

  int i, j;
  int nstmt;
  int max_dim = 2 * cinfo->max_dim + 1;
  scoplib_statement_p stmt;
  int k_lin, k_sca;

  char buffer[32]; 
  int sum_delta_sca_id;
  int sum_delta_lin_id;

  s_ponos_var_t ** svars;
  svars = XMALLOC (s_ponos_var_t*, max_dim + 1);
  int * weights;
  weights = XMALLOC (int, max_dim);

  sprintf (buffer, "dist_deltas");
  svars[0] = ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0, 0, 0, NULL);
  for (i = 0; i < max_dim; i++)
  {
    sprintf (buffer, "sum_delta_%d", i);
    svars[i+1] = ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, i, 0, 0, NULL);
  }

  ponos_space_bulk_variable_insertion_at_start (space, svars, max_dim + 1);

  XFREE (svars);

  int sca_w = (max_dim) / 2;
  int lin_w = 1;
  int * newids = XMALLOC (int, max_dim + 2);
  for (i = 0; i < max_dim; i++)
    newids[i] = i+1;
  newids[i] = -1;
  for (i = 0; i < max_dim; i++)
  {
    int delta_sum_level_id = i + 1;
    if (i % 2 == 0)
    {
      if (i != max_dim - 1)
        weights[i] = sca_w--;
      else
        weights[i] = (max_dim + 1) / 2;
    }
    else
    {
      weights[i] = lin_w++;
    }

    int* ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_DELTA);

    ponos_space_create_summation (space, delta_sum_level_id, ids, 
      PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

    int ub = cinfo->n_dep;
    ponos_codelet_create_ge_cst (space, delta_sum_level_id, -1, -ub);
    ponos_codelet_create_ge_cst (space, delta_sum_level_id, 1, 0);

    XFREE (ids);
  }

  ponos_space_create_weighted_summation (space, 0, 1, newids, weights,
    PONOS_CONSTRAINT_EQUAL, PONOS_OBJECTIVE_MINIMIZE, 0);

  XFREE (weights);

}
