/*
 * objectives.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>
#include <ponos/objectives.h>


/**
 * Minimizes the sum of variables of type 'type' at dimension 'dim'.
 *
 */
static
void
ponos_objectives_opt_sum_of_dim (s_ponos_space_t* space,
				 int type,
				 int dim,
				 int mode)
{
  #if 1 // breaking down big summations
  // 1. Create the optimization variable.
  char buffer[64]; sprintf (buffer, "Opt_%d_%d", type, dim);
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
			    0, 0, NULL);

  // 2. Insert it in the space, in first position.
  ponos_space_insert_variable_first (space, optvar);

  // 3. Collect all delta positions for the first dimension.
  int* ids = ponos_space_get_coefs_dim (space, dim, type);

  // 4. Set summation of variables equal to newvar (or -newvar if mode
  // is maximize).
  ponos_space_create_summation (space, 0, ids, PONOS_CONSTRAINT_EQUAL, mode,
				PONOS_UNUSED_VALUE);

  // 5. Compute the lower/upper bound for the optimization variable.
  int i;
  long long int w = 0;
  for (i = 0; ids && ids[i] != -1; ++i)
    w += space->vars[ids[i]]->upper_bound;
  if (mode != PONOS_OBJECTIVE_MAXIMIZE_POS)
    optvar->upper_bound = w;
  if (mode == PONOS_OBJECTIVE_MAXIMIZE_POS)
    {
      optvar->lower_bound = PONOS_SPACE_MAX_INT_VAL - w;
      optvar->upper_bound = PONOS_SPACE_MAX_INT_VAL;
    }
  if (mode == PONOS_OBJECTIVE_MAXIMIZE)
    {
      optvar->lower_bound = -w;
      optvar->is_maximized = 1;
    }
  
  #else

  #define LOCAL_CHUNK_SIZE 4
  // 3. Collect all delta positions for the first dimension.
  int* ids = ponos_space_get_coefs_dim (space, dim, type);
  int n_id = 0;
  int ii;
  for (ii = 0; ids[ii] != -1; ii++, n_id++);
  int n_chunks = n_id / LOCAL_CHUNK_SIZE;
  if (n_id % LOCAL_CHUNK_SIZE > 0)
    n_chunks ++;

  for (ii = 0; ii < n_chunks; ii++)
  {
    // 1. Create the optimization variable.
    char buffer[64]; sprintf (buffer, "Opt_%d_%d", type, dim);
    s_ponos_var_t* optvar =
      ponos_space_var_create (buffer, PONOS_VAR_OPT_SUM_VAR, 0,
            0, 0, NULL);
    // 2. Insert it in the space, in first position.
    ponos_space_insert_variable_first (space, optvar);
  }

  for (ii = 0; ii < n_chunks; ii++)
  {
    int jds[LOCAL_CHUNK_SIZE+1];
    int jj;
    for (jj = 0; jj < LOCAL_CHUNK_SIZE && ids[jj] != -1; jj++)
    {
      jds[jj] = ids[LOCAL_CHUNK_SIZE * ii + jj] + LOCAL_CHUNK_SIZE;
    }
    jds[jj] = -1;
    int real_chunk_size = jj;

    // 4. Set summation of variables equal to newvar (or -newvar if mode
    // is maximize).
    ponos_space_create_summation (space, ii, jds, PONOS_CONSTRAINT_EQUAL, mode,
          PONOS_UNUSED_VALUE);

    // 5. Compute the lower/upper bound for the optimization variable.
    int i;
    long long int w = 0;
    s_ponos_var_t * optvar = space->vars[ii];
    for (i = 0; real_chunk_size > 0 && jds[i] != -1; ++i)
      w += space->vars[ids[i]]->upper_bound;
    if (mode != PONOS_OBJECTIVE_MAXIMIZE_POS)
      optvar->upper_bound = w;
    if (mode == PONOS_OBJECTIVE_MAXIMIZE_POS)
      {
        optvar->lower_bound = PONOS_SPACE_MAX_INT_VAL - w;
        optvar->upper_bound = PONOS_SPACE_MAX_INT_VAL;
      }
    if (mode == PONOS_OBJECTIVE_MAXIMIZE)
      {
        optvar->lower_bound = -w;
        optvar->is_maximized = 1;
      }
  }
  #endif
  // Be clean.
  XFREE(ids);
}


/**
 * Minimizes the sum of variables of type 'type' at dimension 'dim'.
 *
 */
void
ponos_objectives_minimize_sum_of_dim (s_ponos_space_t* space,
				      int type,
				      int dim)
{
  ponos_objectives_opt_sum_of_dim (space, type, dim, PONOS_OBJECTIVE_MINIMIZE);
}


/**
 * Maximizes the sum of variables of type 'type' at dimension 'dim'.
 *
 */
void
ponos_objectives_maximize_sum_of_dim (s_ponos_space_t* space,
				      int type,
				      int dim)
{
  ponos_objectives_opt_sum_of_dim (space, type, dim, PONOS_OBJECTIVE_MAXIMIZE);
}


/**
 * Maximizes the sum of variables of type 'type' at dimension 'dim'.
 * Works only if the variables to be summed are non-negative (>= 0).
 */
void
ponos_objectives_maximize_sum_of_dim_posonly (s_ponos_space_t* space,
					      int type,
					      int dim)
{
  ponos_objectives_opt_sum_of_dim (space, type, dim,
				   PONOS_OBJECTIVE_MAXIMIZE_POS);
}


/**
 * Embed constraints for maximal outer parallelism.
 *
 *
 */
void
ponos_objectives_max_outer_par (s_ponos_space_t* space,
				s_ponos_options_t* options)
{
  if (options->build_2d_plus_one)
    {
/*       ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, 1); */
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 1);
    }
  else
    {
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, 0);
    }
}


/**
 * Embed constraints for maximal inner parallelism.
 *
 *
 */
void
ponos_objectives_max_inner_par (s_ponos_space_t* space,
				s_ponos_options_t* options)
{
  /* else */
    ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA,
					  space->num_sched_dim - 1);
  if (options->build_2d_plus_one)
    ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA,
					  space->num_sched_dim - 2);
}



/**
 * Embed constraints for maximal dependence solving (Feautrier multi-dim).
 *
 *
 */
void
ponos_objectives_max_dep_solve (s_ponos_space_t* space,
				s_ponos_options_t* options)
{
  int i;
  for (i = space->num_sched_dim - 1; i >= 0; --i)
    ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA, i);
}



/**
 * Testing gamma related stuff
 *
 *
 */
void
ponos_objectives_gamma_pos (s_ponos_space_t* space,
			    s_ponos_options_t* options)
{
  // 1. Insert the maximization of sigma in last position.
  char buffer[512];
  sprintf (buffer, "SIG_opt");
  s_ponos_var_t* optvar =
    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0,
			    0, 0, NULL);
  int optvarid = space->num_vars;
  ponos_space_insert_variable_last (space, optvar);

  // 2. Insert the gammas, in last position. Bulk update.
  int i;
  for (i = 0; i < space->num_sched_dim; ++i)
    {
      int* ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_THETA);
      int count = ponos_space_count_var_type_dim (space, i, PONOS_VAR_THETA);
      s_ponos_var_t* newvars[count + 1];
      int j;
      for (j = 0; ids[j] != -1; ++j)
	{
	  sprintf (buffer, "G%d_%d_%d", j, space->vars[ids[j]]->pos, i);
	  int type;
	  switch (space->vars[ids[j]]->type)
	    {
	    case PONOS_VAR_THETA_ITER:
	      type = PONOS_VAR_GAMMA_ITER; break;
	    case PONOS_VAR_THETA_PARAM:
	      type = PONOS_VAR_GAMMA_PARAM; break;
	    case PONOS_VAR_THETA_CST:
	      type = PONOS_VAR_GAMMA_CST; break;
	    }
	  newvars[j] = ponos_space_var_create (buffer, type,
					       i, space->vars[ids[j]]->pos,
					       j + space->num_vars,
					       space->vars[ids[j]]->scop_ptr);
	}
      newvars[j] = NULL;
      space->vars = XREALLOC (s_ponos_var_t*, space->vars,
			      space->num_vars + count + 1);
      for (j = 0; newvars[j]; ++j)
	space->vars[space->num_vars + j] = newvars[j];
      space->vars[space->num_vars + j] = NULL;
      space->num_vars += j;
      fm_solution_extend (space->space, space->num_vars);
      XFREE(ids);
    }

  // 3. Set that:
  // \Theta_{i,j} >= \Gamma_{i,j}
  // 0 <= \Gamma_{i,j} <= 1
  for (i = 0; i < space->num_sched_dim; ++i)
    {
      int* idsT = ponos_space_get_coefs_dim (space, i, PONOS_VAR_THETA);
      int* idsS = ponos_space_get_coefs_dim (space, i, PONOS_VAR_GAMMA);
      int j;
      for (j = 0; idsT[j] != -1 && idsS[j] != -1; ++j)
	{
	  int val[2];
	  val[0] = idsS[j]; val[1] = -1;
	  ponos_space_create_summation (space, idsT[j], val,
					PONOS_CONSTRAINT_GREATEREQUAL,
					PONOS_OBJECTIVE_MINIMIZE,
					PONOS_UNUSED_VALUE);
	  ponos_space_create_summation (space, -1, val,
					PONOS_CONSTRAINT_GREATEREQUAL,
					PONOS_OBJECTIVE_MINIMIZE,
					0);
	  ponos_space_create_summation (space, -1, val,
					PONOS_CONSTRAINT_LOWEREQUAL,
					PONOS_OBJECTIVE_MINIMIZE,
					1);
	}
      XFREE(idsT);
      XFREE(idsS);
    }
  // 4. Maximize \sum \Gamma
  int* ids = ponos_space_get_coefs (space, PONOS_VAR_GAMMA);
  ponos_space_create_summation (space, optvarid, ids,
				PONOS_CONSTRAINT_EQUAL,
				PONOS_OBJECTIVE_MAXIMIZE_POS,
				PONOS_UNUSED_VALUE);
  XFREE(ids);
}




/**
 * Embed constraints for maximal permutability.
 *
 */
void
ponos_objectives_max_permutability (s_ponos_space_t* space,
				    s_ponos_options_t* options)
{
  int i;
  for (i = space->num_sched_dim - 1; i >= 0; --i)
    {
/*       // Skip scalar dimensions? */
       if (options->build_2d_plus_one && ((i % 2) == 0)) 
 	continue; 
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_RHO, i);
/*       ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA, i); */
    }
}



/**
 * Minimize dependence distance.
 *
 */
void
ponos_objectives_min_dep_distance (s_ponos_space_t* space,
				   s_ponos_options_t* options)
{
  // Simply put the objective variables U first, by introducing a new
  // variable U_opt.
  int i, j;
  for (i = space->num_sched_dim - 1; i >= 0; --i)
    {
/*       // Skip scalar dimensions? */
/*       if (options->build_2d_plus_one && ((i % 2) == 0)) */
/* 	continue; */

      // 1. Collect all U positions for dim i.
/*       for (j = 0; ids[j] != -1; ++j) */
/* 	{ */
	  // 2. Create the constraint variable.
	  char buffer[32]; sprintf (buffer, "U_opt%d_%d", 0, i);
	  s_ponos_var_t* optvar =
	    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, 0,
				    0, 0, NULL);
	  ponos_space_var_set_bounds (optvar, 0, options->legality_constant);
	  
	  // 3. Add it. We choose first here.
	  ponos_space_insert_variable_first (space, optvar);

	  int* ids = ponos_space_get_coefs_dim (space, i, PONOS_VAR_U_DIST);

	  // 4. Set summation.
/* 	  int myids[2]; */
/* 	  myids[0] = ids[j]; myids[1] = -1; */
	  ponos_space_create_summation (space, 0, ids,
					PONOS_CONSTRAINT_EQUAL,
					PONOS_OBJECTIVE_MINIMIZE,
					PONOS_UNUSED_VALUE);
/* 	} */
      XFREE(ids);
    }
}


/**
 *
 *
 */
void
ponos_objectives_min_iter_coef (s_ponos_space_t* space,
				s_ponos_options_t* options)
{
  int i;
  for (i = space->num_sched_dim - 1; i >= 0; --i)
    {
       if (options->build_2d_plus_one && ((i % 2) == 0)) 
 	continue; 
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_THETA_ITER, i);
    }
}


/**
 * New scheduler, in development.
 * contact: Travis Augustine <Travis.Augustine@colostate.edu>.
 *
 */
void
ponos_objectives_tasched (s_ponos_space_t* space,
			  s_ponos_options_t* options)
{
  int i, j, stmt_id;
  scoplib_statement_p s;
  char buffer[64];


  // Enforce linear independence (this may lead to no feasible schedule).
  ponos_constraints_linear_indep (space, options);
  // Make the parameter coefficients of linear dimensions = 0.
  ponos_constraints_param_coef_zero (space, options);

  // Embed parallelization objectives. These are lower priority
  // than no-skewing here.
  if(space->num_sched_dim == 1 || space->num_sched_dim == 2)
    ponos_objectives_minimize_sum_of_dim(space, PONOS_VAR_DELTA, 0);
  else
    {
      ponos_objectives_minimize_sum_of_dim(space, PONOS_VAR_DELTA, 0);
      ponos_objectives_maximize_sum_of_dim (space, PONOS_VAR_DELTA,
						    space->num_sched_dim - 2);
      ponos_objectives_minimize_sum_of_dim (space, PONOS_VAR_DELTA,
					    space->num_sched_dim - 1);
    }
  
  // Count the number of statements.
  int nb_stmt;
  for (s = space->scop->statement, nb_stmt = 0; s; s = s->next, ++nb_stmt)
    ;

  // Embed the no-skewing objective. This is higher priority.
  // Loop through each dim i.
  for (i = 0; i < space->num_sched_dim; i++) {
    // Array to store positions of \alpha_i variables, for each statement.
    int alphas[nb_stmt + 1];
    int alphas_index = 0;

    // Loop through each stmt s.
    for (s = space->scop->statement, stmt_id = 0; s; s = s->next, ++stmt_id) {

      // Collect all theta positions at dim i for stmt s.
      int *ids = ponos_space_get_coefs_dim_stmt (space, s, i,
						 PONOS_VAR_THETA_ITER);

      // Determine number of beta variables that will be inserted at
      // dim i for stmt s.
      for(j = 0; ids[j] != -1; j++)
  	;

      // Array to store positions of all of the beta variables
      // inserted at dim i for stmt s (+1 for the -1 terminator).
      int betas[j+1];
      int betas_index = 0;

      // Loop through each theta variable at dim i for stmt s.
      for(j = 0; ids[j] != -1; j++) {

  	// Create new beta variable.
  	sprintf(buffer, "Beta_S%d_%d_%d", stmt_id, i, j);
  	s_ponos_var_t* betavar =
  	  ponos_space_var_create (buffer, PONOS_VAR_BETA_ITER, i, 0, 0, s);
	ponos_space_var_set_boolean (betavar);

  	// Insert the beta variable last in the space.
  	ponos_space_insert_variable_last (space, betavar);

  	// Add the beta variable's position to the list for this dim,
  	// stmt combo.
  	betas[betas_index++] = space->num_vars - 1;

  	// Create -1 terminated array containing only the position of
  	// the beta variable.
  	int vars[2] = { space->num_vars - 1, -1 };
  	int weights[2] = { options->legality_constant, -1};

  	// 0 <= beta i,j
  	ponos_space_create_summation (space, -1, vars,
  				      PONOS_CONSTRAINT_GREATEREQUAL,
  				      PONOS_OBJECTIVE_MINIMIZE, 0);

  	// 1 >= beta i,j
  	ponos_space_create_summation (space, -1, vars,
  				      PONOS_CONSTRAINT_LOWEREQUAL,
  				      PONOS_OBJECTIVE_MINIMIZE, 1);

  	// theta i,j >= beta i,j
  	ponos_space_create_summation(space, ids[j], vars,
  				     PONOS_CONSTRAINT_GREATEREQUAL,
  				     PONOS_UNUSED_VALUE, 0);

  	// theta i,j <= K*beta i,j
  	ponos_space_create_weighted_summation (space, ids[j], 1,
  					       vars, weights,
  					       PONOS_CONSTRAINT_LOWEREQUAL,
  					       PONOS_OBJECTIVE_MINIMIZE, 0);
      }

      betas[betas_index] = -1;

      // Create boolean alpha variable for the statement.
      sprintf(buffer, "Alpha_S%d_%d", stmt_id, i);
      s_ponos_var_t* alphavar =
  	ponos_space_var_create (buffer, PONOS_VAR_BIN_USERDEF, i, 0, 0, s);
      ponos_space_var_set_boolean (alphavar);
      ponos_space_insert_variable_last (space, alphavar);
      // Register the new variable, for subsequent summation.
      alphas[alphas_index++] = space->num_vars - 1;

      int alphapos[2] = { space->num_vars - 1, -1 };
      // 0 <= alpha
      ponos_space_create_summation (space, -1, alphapos,
  				    PONOS_CONSTRAINT_GREATEREQUAL,
  				    PONOS_OBJECTIVE_MINIMIZE, 0);

      // 1 >= alpha
      ponos_space_create_summation (space, -1, alphapos,
  				    PONOS_CONSTRAINT_LOWEREQUAL,
  				    PONOS_OBJECTIVE_MINIMIZE, 1);

      // constraint:   \sum_j \beta_{i,j} <= 1 + \alpha_i * K
      //           <=> \alpha_i * K - \sum_j \beta_{i,j} >= -1
      int sum_vars[betas_index + 2];
      int weight_vars[betas_index + 2];
      for (j = 0; j < betas_index; ++j)
  	{
  	  sum_vars[j] = betas[j];
  	  weight_vars[j] = -1;
  	}
      sum_vars[j] = alphapos[0];
      weight_vars[j] = options->legality_constant;
      sum_vars[j + 1] = weight_vars[j + 1] = -1;
      ponos_space_create_weighted_summation (space, -1, 0,
  					     sum_vars, weight_vars,
  					     PONOS_CONSTRAINT_GREATEREQUAL,
  					     PONOS_OBJECTIVE_MINIMIZE, -1);

      // Be clean.
      XFREE(ids);
    }
    // Minimize \sum_s \alpha_i_s. SumAlpha_i = 0 => no skewing at dimension i.
    alphas[alphas_index] = -1;
    sprintf(buffer, "SumAlpha_%d", i);
    s_ponos_var_t* sumalpha =
      ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, i, 0, 0, NULL);
    ponos_space_var_set_bounds (sumalpha, 0, nb_stmt);
    ponos_space_insert_variable_first (space, sumalpha);

    // Offset the alphas ids by +1, as we just inserted a variable at first
    // position.
    for (j = 0; alphas[j] != -1; ++j)
      alphas[j]++;

    // SumAlpha >= 0
    ponos_space_create_summation (space, 0, NULL,
    				  PONOS_CONSTRAINT_GREATEREQUAL,
    				  PONOS_OBJECTIVE_MINIMIZE, 0);
    ponos_space_create_summation (space, 0, alphas,
    				  PONOS_CONSTRAINT_EQUAL,
    				  PONOS_OBJECTIVE_MINIMIZE, 0);
  }
  /* ponos_constraints_delta_up (space, options); */

  // Embed loop constraint: for a statement of depth d, there should
  // be d schedule dimensions which are loops (i.e., non-constant
  // dimensions).
  // For d schedule rows, \sum_j \beta_{i,j} > 0.
  for (s = space->scop->statement, stmt_id = 0; s; s = s->next, ++stmt_id)
    {
      int stmt_depth = s->nb_iterators;

      int* ids[space->num_sched_dim];
      int zettaids[space->num_sched_dim + 1];
      int zetta_pos = 0;
      for (i = 0; i < space->num_sched_dim; ++i)
	{
	  ids[i] = ponos_space_get_coefs_dim_stmt (space, s, i,
						   PONOS_VAR_BETA_ITER);
	  // 1. Encode \zetta_i = 1 if \sum_j \beta_{i,j} > 0, 0 otherwise.
	  sprintf (buffer, "Zetta_S%d_%d", stmt_id, i);
	  s_ponos_var_t* zettavar =
	    ponos_space_var_create (buffer, PONOS_VAR_CST_SUM_VAR, i, 0, 0, s);
	  ponos_space_var_set_boolean (zettavar);
	  ponos_space_insert_variable_last (space, zettavar);
	  // \zetta_i . #j <= \sum_j \beta_{i,j}
	  int cnt;
	  for (cnt = 0; ids[i][cnt] != -1; ++cnt)
	    ;
	  int unitweights[cnt + 1];
	  for (cnt = 0; ids[i][cnt] != -1; ++cnt)
	    unitweights[cnt] = 1;
	  ponos_space_create_weighted_summation (space,
						 space->num_vars - 1, 1,
						 ids[i], unitweights,
						 PONOS_CONSTRAINT_LOWEREQUAL,
						 PONOS_OBJECTIVE_MINIMIZE, 0);
	  zettaids[zetta_pos++] = space->num_vars - 1;
	}
      zettaids[zetta_pos++] = -1;
      
      // Sum_i \zetta_i >= d
      ponos_space_create_summation (space,
				    -1,
				    zettaids, 
				    PONOS_CONSTRAINT_GREATEREQUAL,
				    PONOS_OBJECTIVE_MINIMIZE,
				    stmt_depth);
      
      // Be clean.
      for (i = 0; i < space->num_sched_dim; ++i)
	XFREE(ids[i]);
    }
  
  
  if (options->debug)
    {
      ponos_space_print_vars(stdout, space);
      ponos_space_print(stdout, space);
      ponos_space_pprint_cst(stdout, space);
    }

}
