/*
 * ponos.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
// Assume candl has been built with ISL support.
#ifndef CANDL_SUPPORTS_ISL
# define CANDL_SUPPORTS_ISL
#endif
#include <ponos/ponos.h>
#include <ponos/space.h>
#include <ponos/legal.h>
#include <ponos/solver-gmp.h>
#include <ponos/objectives.h>
#include <ponos/constraints.h>
#include <ponos/codelet.h>
#include <ponos/solver.h>
#include <ponos/chunked.h>
#include <candl/dependence.h>

static
double rtclock()
{
    struct timeval Tp;
    int stat;
    stat = gettimeofday (&Tp, NULL);
    if (stat != 0)
      printf ("Error return from gettimeofday: %d", stat);
    return (Tp.tv_sec + Tp.tv_usec * 1.0e-6);
}


  int
ponos_scheduler_from_deplist (scoplib_scop_p scop,
    CandlProgram* cprogram,
    CandlDependence* deps,
    s_ponos_options_t* options)
{
  if (! options->quiet)
    printf ("[Ponos] Start scheduling\n");

  // Experimental.
  if (options->candl_deps_prune_transcover)
    deps = candl_dependence_prune_transitively_covered (deps);
  // Simplify dependences with ISL, if needed.
  /// FIXME: Broken?
  if (options->candl_deps_isl_simplify)
    candl_dependence_isl_simplify(deps, cprogram);
    //deps = candl_dependence_isl_super_simplify (deps, cprogram);

  // Set FM mode to gmp.
  fm_mode_set_to_gmp ();

  double timer_start, timer_end;
  timer_start = rtclock ();

  // Compute semantics-preserving space, using deltas and rhos.
  if (! options->quiet)
    printf ("[Ponos] Build legality constraints\n");
  s_ponos_space_t* space =
    ponos_legal_build_semantics_constraints (scop, deps, options);

  timer_end = rtclock ();

  //if (options->debug)
  {
    //ponos_space_print (stdout, space);
    ponos_space_print_vars (stdout, space);
  }

  printf ("[Ponos] Legal space construction time: %.4fs\n",
    timer_end - timer_start);



  /// FIXME: Set here space->max_coef_pos_val. Now default to 100000.

  if (options->debug == 1)
    printf ("space has %d vars\n", space->num_vars);

  // Embed optimization objective constraints.
  if (options->chunked_multi_obj_space)
  {
    ponos_multi_objective_space_generate (scop, cprogram, deps, space, options);
  }
  else if (options->objective == PONOS_OBJECTIVES_CODELET)
  {
    if (! options->quiet)
      printf ("[Ponos] Embed objective constraints: codelet\n");
    /// FIXME: Martin: Yours go here.

    // Create iterator map for non-fvd and fvd (See PLDI'13 paper)
    s_af_iterator_map_t * G =
      ponos_codelet_build_complete_af_iterator_map (space, options);

    ponos_constraints_param_coef_zero (space, options);
    ponos_constraints_sum_iter_pos (space, options);


    /* #define MINE */

    /* #ifdef MINE */
    /*       ponos_codelet_gamma_constraints (space, G, options); */
    /*       ponos_codelet_boolean_constraints (space, options, PONOS_VAR_GAMMA); */
    /* #else */
    ponos_objectives_gamma_pos (space, options);
    /* #endif */

    //int ** gamma_iters;
    ponos_codelet_stride_constraints (space, G, options);

    ponos_codelet_boolean_constraints (space, options, PONOS_VAR_SIGMA);
    ponos_codelet_boolean_constraints (space, options, PONOS_VAR_NU_REF);
    ponos_codelet_boolean_constraints (space, options, PONOS_VAR_GAMMA_REF);

    // Force distribution at 2nd innermost constant level
    //ponos_codelet_force_dist_constraints (space, options, space->num_sched_dim-3);

    /*
       ponos_codelet_force_fision_constraints_boolean (
       space, options, space->num_sched_dim-3);
     */

    // Objectives (+ <--- importance -----> -):
    // inner-par, stride01-refs, perm, dep-dist, stride-prop


    // ponos_objectives_gamma_pos
    //ponos_codelet_objective_max_stride01_prop (space, options);

    /* ponos_objectives_min_dep_distance (space, options); */
    /* ponos_objectives_max_permutability (space, options); */

    /*
       ponos_codelet_objective_min_inner_coefs (space, options, 5);
       ponos_codelet_objective_min_inner_coefs (space, options, 3);
       ponos_codelet_objective_min_inner_coefs (space, options, 1);
     */


    ponos_codelet_objective_max_stride01_refs (space, options);

    //ponos_codelet_objective_force_outer_fusion (space, options);

    ponos_constraints_linear_indep (space, options);

    ponos_objectives_max_inner_par (space, options);
    ponos_objectives_min_iter_coef (space, options);


    //       ponos_space_pprint_cst (stdout, space);

    // Free the iterator map
    ponos_codelet_free_af_iterator_map (G);

  }
  else if (options->objective == PONOS_OBJECTIVES_CHUNKED)
  {
    if (! options->quiet)
      printf ("[Ponos] Embed objective constraints: chunked \n");

    CandlDependence* mydep;
    int n_dep = 0;
    for (mydep = deps; mydep; mydep = mydep->next, n_dep++);
    int n_stmt = 0;
    {
      scoplib_statement_p stmt;
      for (stmt=space->scop->statement, n_stmt=0; stmt; stmt = stmt->next, n_stmt++);
    }

    ponos_constraints_param_coef_zero (space, options);
    ponos_constraints_sum_iter_pos (space, options);

    #if 0
    //if (n_dep * 1.0 / n_stmt < 4.0 && n_dep / space->num_sched_dim <= n_stmt)
    if (!is_jacobi (n_dep,n_stmt,space->num_sched_dim))
    {
      printf ("Adding stride constraints ...\n");
      ponos_objectives_gamma_pos (space, options);
      ponos_codelet_stride_constraints (space, G, options);
      ponos_codelet_smart_stride_constraints (space, G, options);
      ponos_codelet_boolean_constraints (space, options, PONOS_VAR_SIGMA);
      ponos_codelet_boolean_constraints (space, options, PONOS_VAR_NU_REF);
      ponos_codelet_boolean_constraints (space, options, PONOS_VAR_GAMMA_REF);
    }
    #endif

    //printf ("Maximizing permutability...\n");

    // Objectives (+ <--- importance -----> -):
    //ponos_objectives_max_permutability (space, options); 

    //if (n_dep * 1.0 / n_stmt < 4.0 && n_dep / space->num_sched_dim <= n_stmt)
    //ponos_objectives_min_dep_distance (space, options); // do not need this

    //printf ("Adding csts for LI...\n");
    ponos_constraints_linear_indep (space, options);
    //printf ("Minimizing iterator coefficients...\n");
    //ponos_objectives_min_iter_coef (space, options);

    printf ("Entering chunked constraints...\n");
    // Chunked constraints

    // Note: to read the objective lists from a file, chunked_auto must be
    // set to 1.
    if (options->chunked_adaptive_assembly)
    {
      ponos_chunked_adaptive_assembly (space, options, cprogram, n_dep, deps, 999999);
    }
    else if (options->chunked_auto)
    {
      ponos_chunked_auto_select_objectives (space, options, cprogram, n_dep, deps, 999999);
    }
    else
    {
      ponos_chunked_create_constraints (space, options, cprogram, n_dep, deps);
    }


    if (n_dep < 40 || options->debug)
    //if (options->debug)
    {
      ponos_space_pprint_cst (stdout, space);
    }

    // End of chunked part (ICS'18, CGO'19, PLDI'19)
  }
  else if (options->objective == PONOS_OBJECTIVES_PLUTO)
  {
    if (! options->quiet)
      printf ("[Ponos] Embed objective constraints: pluto\n");

    // Constraints first.
    ponos_constraints_param_coef_zero (space, options);
    ponos_constraints_sum_iter_pos (space, options);

    // Objectives then, in reverse order of importance.
    /*       ponos_objectives_max_inner_par (space, options); */
    ponos_objectives_max_dep_solve (space, options);
    ponos_objectives_max_outer_par (space, options);
    ponos_objectives_max_permutability (space, options);
    ponos_objectives_min_dep_distance (space, options);

    if (options->debug)
      ponos_space_print_vars (stdout, space);
  }
  else if (options->objective == PONOS_OBJECTIVES_CUSTOM)
  {
    if (! options->quiet)
      printf ("[Ponos] Embed objective constraints: custom\n");
    int i;
    for (i = 0; options->objective_list[i] != -1; ++i)
    {
      switch (options->objective_list[i])
      {
        case PONOS_CONSTRAINTS_SUM_ITER_POS:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed constraint: sum of iter are pos\n");
            ponos_constraints_sum_iter_pos (space, options);
            break;
          }
        case PONOS_CONSTRAINTS_PARAM_COEF_ZERO:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed constraint: param coef are 0\n");
            ponos_constraints_param_coef_zero (space, options);
            break;
          }
        case PONOS_OBJECTIVES_MAX_OUTER_PAR:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed objective: max outer par\n");
            ponos_objectives_max_outer_par (space, options);
            break;
          }
        case PONOS_OBJECTIVES_MAX_INNER_PAR:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed objective: max inner par\n");
            ponos_objectives_max_inner_par (space, options);
            break;
          }
        case PONOS_OBJECTIVES_MAX_PERMUTABILITY:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed objective: max permutability\n");
            ponos_objectives_max_permutability (space, options);
            break;
          }
        case PONOS_OBJECTIVES_MIN_DEP_DISTANCE:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed objective: min dep distance\n");
            ponos_objectives_min_dep_distance (space, options);
            break;
          }
        case PONOS_OBJECTIVES_MAX_DEP_SOLVE:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed objective: max #dep solved\n");
            ponos_objectives_max_dep_solve (space, options);
            break;
          }
        case PONOS_CONSTRAINTS_LINEAR_INDEP:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed constraint: linear independence\n");
            ponos_constraints_linear_indep (space, options);
            break;
          }
        case PONOS_OBJECTIVES_GAMMA_POS:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed constraint: gamma pos\n");
            ponos_objectives_gamma_pos (space, options);
            break;
          }
        case PONOS_OBJECTIVES_TASCHED:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed constraint: TA scheduler\n");
            ponos_objectives_tasched (space, options);
            break;
          }
        case PONOS_OBJECTIVES_MIN_THETA_ITER:
          {
            if (! options->quiet)
              printf ("[Ponos] Embed constraint: TA scheduler\n");
            ponos_objectives_min_iter_coef (space, options);
            break;
          }
        default:
          if (! options->quiet)
            printf ("[Ponos][WARNING] Constraint/objective not implemented\n");
          break;
      }
    }
  }
  // Solve the system.
  if (! options->quiet)
    printf ("[Ponos] Solve PIP\n");
  if (options->pipsolve_gmp)
    ponos_solver_gmp (space, scop, options);
  else
    ponos_solver (space, scop, options);


  // Be clean.
  ponos_space_free (space);

  if (! options->quiet)
    printf ("[Ponos] done scheduling\n");

  return EXIT_SUCCESS;
}

/**
 * Entry point.
 *
 */
  int
ponos_scheduler (scoplib_scop_p scop, s_ponos_options_t* options)
{
  if (! options->quiet)
    printf ("[Ponos] Start scheduling\n");

  // Perform candl.
  /// TODO: support readind dependences from the scop.
  CandlOptions* coptions = candl_options_malloc ();
  CandlProgram* cprogram = candl_program_convert_scop (scop, NULL);
  CandlDependence* deps = candl_dependence (cprogram, coptions);
  //deps = candl_dependence_isl_super_simplify (deps, cprogram);

  int retval;
  int use_pipes = 0;
  #if 0
  if (options->generate_pipes_c_harness)
  {
    printf ("Generating PIPES .C harness\n");
    retval = generate_pipes_c_harness (scop, options, cprogram, deps);
    use_pipes = 1;
  }
  if (options->generate_pipes_c || options->generate_pipes_df)
  {
    printf ("Generating PIPES (DF/C) programs\n");
    retval = generate_pipes_programs (scop, options, cprogram, deps);
    retval = generate_pipes_df (scop, options, cprogram, deps);
    use_pipes = 1;
    exit (0);
  }
  if (0 && options->chunked_arch == PONOS_CHUNKED_ARCH_TILED_CNC)
  {
    retval = generate_pipes_tiled_program (scop, options, cprogram, deps);
    exit (0);
  }
  #endif

  if (!use_pipes)
    retval = ponos_scheduler_from_deplist (scop, cprogram, deps, options);

  // Be clean.
  candl_dependence_free (deps);
  candl_program_free (cprogram);
  candl_options_free (coptions);

  return retval;
}
