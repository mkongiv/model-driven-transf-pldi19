/*
 * solver-cplex.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2017 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@colostate.edu>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <math.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>


#ifndef FM_HAS_GMP_SUPPORT
# define FM_HAS_GMP_SUPPORT
#endif
# include <fm/system.h>
# include <fm/solution.h>
# include <fm/solver.h>
# include <fm/compsol.h>


#include <fm/piptools.h>
#include <ponos/common.h>
#include <ponos/solver-cplex.h>

/*
 * Deal with getting the source path, to call scripts.
 */
# define TO_STRING__(x) #x
# define TO_STRING_(x) TO_STRING__(x)
# define STR_POCC_ROOT_DIR TO_STRING_(PONOS_SRC_ROOT_DIR)



static
double rtclock()
{
    struct timeval Tp;
    int stat;
    stat = gettimeofday (&Tp, NULL);
    if (stat != 0)
      printf ("Error return from gettimeofday: %d", stat);
    return (Tp.tv_sec + Tp.tv_usec * 1.0e-6);
}

static
scoplib_matrix_p
convert_fm_system_to_scoplib_matrix (s_fm_system_t* s)
{
  int i, j;
  scoplib_matrix_p ret = scoplib_matrix_malloc (s->nb_lines, s->nb_cols);
  for (i = 0; i < s->nb_lines; ++i)
    for (j = 0; j < s->nb_cols; ++j)
      {
	SCOPVAL_set_si(ret->p[i][j], Z_GET_SI(s->lines[i]->vector[j].num));
      }
  return ret;
}


/**
 * Pretty-print the solution found by Cplex. The solution must have
 * been embedded in the space first, via:
 * ponos_solver_cplex_embed_solution_in_space (s_ponos_space_t* space,
 *					       char* cplex_output);
 *
 */
//static
void
ponos_solver_cplex_pprint_solution (FILE* stream, s_ponos_space_t* space)
{
    int i;
    if (space->has_valid_optimal_solution)
      for (i = 0; i < space->num_vars; ++i)
        if (space->vars[i]->optimal_value == 0)
  	  fprintf (stream, "%s = %d\n", space->vars[i]->name,
	           space->vars[i]->optimal_value);
        else
	  fprintf (stream, "%s = %d ****\n", space->vars[i]->name,
	 	   space->vars[i]->optimal_value);
    else
      fprintf (stdout,
	       "[Ponos][WARNING] Optimal solution not (fully) computed\n");
}


/**
 * Embed the solution found by Cplex in the space: edit
 * each space->vars[i]->optimal_value with the solution.
 */
static
int
ponos_solver_cplex_embed_solution_in_space (s_ponos_space_t* space,
					    char* sol)
{
    int pos = 0;
    char buffer[32];

    space->has_valid_optimal_solution = 0;

    while (sol && *sol != '\0')
      {
	char* buf = buffer;
	while (sol && *sol != '\n' && *sol != '\0')
	  *(buf++) = *(sol++);
	*buf = '\0';
	int val = atoi (buffer);
  double fval; sscanf (buffer,"%lf",&fval);
  fval = round(fval);
  val = trunc(fval);
  fprintf (stderr,"Space_var (%d:%s) = %s => %d\n", pos, space->vars[pos]->name, buffer, val);
	space->vars[pos++]->optimal_value = val;
	if (*sol == '\n')
	  ++sol;
      }
    if (space->num_vars != pos)
      {
	fprintf (stdout, "[Ponos][Cplex] Error: incomplete solution: %d/%d variables are solved\n", pos, space->num_vars);
	fprintf (stdout, "[Ponos][Cplex] Cplex output: %s\n", sol);
	return EXIT_FAILURE;
      }

    space->has_valid_optimal_solution = 1;

    return EXIT_SUCCESS;
}

static
//long long int *
double *
ponos_solver_cplex_compute_weights_ (s_ponos_space_t * space)
{
  int ii;
	for (ii = 0; ii < space->num_vars; ii++)
    if (space->vars[ii]->type & PONOS_VAR_THETA)
      break;
  int last_id = space->num_vars;
  double * ret = XMALLOC (double, space->num_vars);
  ret[last_id-1] = 1;
	for (ii = 0; ii < last_id; ii++)
  {
    //if (ii > 0)
    {
      double ub;
      int jj;
      double w = 1;
      for (jj = ii + 1; jj < last_id; jj++)
      {
        if (space->vars[jj]->is_maximized)
          ub = -space->vars[jj]->lower_bound;
        else
          ub = space->vars[jj]->upper_bound;
        w = (ub > w ? ub : w);
      }
      w = w * (last_id - ii) / ((ii + 1) * 1000);
      ret[ii] = w;
      //if (ret[ii] == 0)
      //  ret[ii] = 1;
    }
  }
  for (ii = last_id; ii < space->num_vars; ii++)
    ret[ii] = 1;

  return ret;
}



/**
 * Print a .lp file with the Cplex problem to solve.
 * Uses weighted sum approach for lexicographic optimization.
 *
 */
static
void
ponos_solver_cplex_pprint_ (FILE* stream, s_ponos_space_t* space,
			    s_fm_system_t* system, int check_emptiness_only)
{
  /* stream = stdout; */
  if (stream && space)
    {
      fprintf (stream, "Minimize\n");
      fprintf (stream, "obj1: ");
      // Compute the objective function: weighted sum.
      int i, j;
      if (! check_emptiness_only)
	{
    int first = 0;
    double * ww = ponos_solver_cplex_compute_weights_(space);
    int last_id = space->num_vars;
	  for (i = 0;  i < last_id; i++)
	    {
        #if 0
        //if (space->vars[i]->cpx_skip)
        //  continue;
	      long long int w = 0;
	      for (j = i;  j < space->num_vars; ++j)
	  	{
	  	  if (space->vars[j]->is_maximized)
	  	    w += -space->vars[j]->lower_bound;
	  	  else
	  	    w += space->vars[j]->upper_bound;
	  	}
	      if (!first) //i == 0)
        {
	  	fprintf (stream, "%lld%s ", w, space->vars[i]->name);
      first = 1;
        }
	      else
	  	{
	  	  if (w >= 0)
	  	    fprintf (stream, "+ %lld%s ", w, space->vars[i]->name);
	  	  else
	  	    fprintf (stream, " %lld%s ", w, space->vars[i]->name);
	  	}
        #endif
	      if (!first) //i == 0)
        {
	  	fprintf (stream, "%lf%s ", ww[i], space->vars[i]->name);
      first = 1;
        }
	      else
	  	{
	  	  if (ww[i] >= 0)
	  	    fprintf (stream, "+ %lf%s ", ww[i], space->vars[i]->name);
	  	  else
	  	    fprintf (stream, " %lf%s ", ww[i], space->vars[i]->name);
	  	}
	    }
    XFREE (ww);
	}
      else
	{
	  // Emptiness test. Simply solve for the first variable in the system.
	  fprintf (stream, "%s", space->vars[0]->name);
	}
      fprintf (stream, "\n");
      fprintf (stream, "Subject To\n");
      // Print the system of constraints.
      s_fm_system_t* s = system;
      for (i = 0; i < s->nb_lines; ++i)
	{
	  fprintf (stream, "c%d: ", i + 1);
	  ponos_space_pretty_print_vector (stream, space, s->lines[i]);
	}

      // Print the bounds on each variable.
      fprintf (stream, "Bound\n");
      for (i = 0; i < space->num_vars; ++i)
	{
	   if (space->vars[i]->is_boolean)
	     continue;
	   if (space->vars[i]->is_nonnegative)
	     fprintf (stream, "0 <= %s <= %lld\n", space->vars[i]->name,
		      space->vars[i]->upper_bound);
	   else
	     fprintf (stream, "%d <= %s <= %lld\n", space->vars[i]->lower_bound,
		      space->vars[i]->name,
		      space->vars[i]->upper_bound);
	}

      // Print the variables which are Booleans, and those which are
      // integers.
      fprintf (stream, "Binary\n");
      for (i = 0; i < space->num_vars; ++i)
	if (space->vars[i]->is_boolean == 1)
	  fprintf (stream, "%s ", space->vars[i]->name);
      fprintf (stream, "\n");
      fprintf (stream, "General\n");
      for (i = 0; i < space->num_vars; ++i)
	if (space->vars[i]->is_boolean == 0)
	  fprintf (stream, "%s ", space->vars[i]->name);
      fprintf (stream, "\n");
      fprintf (stream, "End\n");
    }
}


/**
 * Print a .lp file with the Cplex problem to solve.
 * Uses weighted sum approach for lexicographic optimization.
 *
 */
static
void
ponos_solver_cplex_pprint(FILE* stream, s_ponos_space_t* space,
			  s_fm_system_t* system)
{
  ponos_solver_cplex_pprint_ (stream, space, system, 0);
}


/**
 * Print a .lp file with the Cplex problem to solve.
 * Only checks emptiness of the system.
 *
 */
static
void
ponos_solver_cplex_pprint_emptiness_only(FILE* stream, s_ponos_space_t* space,
					 s_fm_system_t* system)
{
  ponos_solver_cplex_pprint_ (stream, space, system, 1);
}


/**
 * Execute a command line (supplied by args) and return a string from
 * its standard output (supposed to be the metric, eg, cycles).
 *
 */
static
char*
my_pocc_execprog_ (char** args, int return_result, int show_output, int noexit,
		   int nowarning_if_error)
{
  pid_t pid;
  int rv;
  int commpipe[2];
  char buf[32000];
  int i;

  if (pipe (commpipe))
    {
      fprintf (stderr, "Pipe error.\n");
      exit (1);
    }

  if((pid = fork ()) == -1)
    {
      fprintf (stderr, "Fork error.\n");
      exit (1);
    }

  if (pid)
    {
      // Parent.
      int stdin_copy = dup (0);
      dup2 (commpipe[0], 0);
      close (commpipe[1]);
      for (i = 0; i < 32000; ++i)
	buf[i] = '\0';
      while (read (0, buf, 32000))
	if (show_output)
	  printf ("%s", buf);
      wait (&rv);
      if (rv != 0)
	{
	  char* err_type;
	  if (noexit)
	    err_type = "WARNING:";
	  else
	    err_type = "FATAL:";
	  if (! nowarning_if_error)
	    {
	      fprintf (stderr, "[PoCC] %s error executing ", err_type);
	      for (i = 0; args[i]; ++i)
		fprintf (stderr, "%s ", args[i]);
	      fprintf (stderr, "\n");
	      if (strlen (buf) != 0)
		fprintf (stderr, "[PoCC] %s execv output: %s\n", err_type, buf);
	      else
		fprintf (stderr, "[PoCC] %s command is not executable\n",
			 err_type);
	      fprintf (stderr, "[PoCC] %s execv exit status: %d\n", err_type, rv);
	    }
	  if (! noexit)
	    exit (rv);
	  else
	    {
	      close (commpipe[0]);
	      dup2 (stdin_copy, 0);
	      close (stdin_copy);
	      return NULL;
	    }
	}
      close (commpipe[0]);
      dup2 (stdin_copy, 0);
      close (stdin_copy);
    }
  else
    {
      // Child.
      dup2 (commpipe[1], 1);
      dup2 (commpipe[1], 2);
      close (commpipe[0]);
      if (execvp (args[0], args) == -1)
	{
	  // fprintf (stderr, "execv Error.\n");
	  exit (1);
	}
      close (commpipe[1]);
    }

  if (return_result)
    return strdup (buf);
  return NULL;
}


/**
 * Perform optimization with Cplex.
 *
 */
static
char*
ponos_solver_cplex_solve(s_ponos_space_t* space,
			 s_ponos_options_t* options,
			 s_fm_system_t* sys,
			 int check_emptiness_only)
{
  if (space == NULL || sys == NULL)
    {
      fprintf (stderr, "[Ponos][Cplex-Solver] Error: space/system is NULL\n");
      return NULL;
    }

  // 1. Emit cplex problem.
  int len = strlen (options->output_file_template);
  char* fname = XMALLOC(char, len + 4);
  strcpy (fname, options->output_file_template);
  strcat (fname, ".lp");
  FILE* f = fopen(fname, "w");
  if (! f)
    {
      fprintf (stderr, "[Ponos][Cplex-Solver] Error: cannot create file 'problem.cplex'\n");
      return NULL;
    }
  if (check_emptiness_only == 0)
    ponos_solver_cplex_pprint (f, space, sys);
  else
    ponos_solver_cplex_pprint_emptiness_only (f, space, sys);
  fclose (f);

  // 2. Run cplex.
  char* args[4];
  args[3] = NULL;
  if (options->solver == PONOS_SOLVER_CPLEX)
    args[0] = STR_POCC_ROOT_DIR "/ponos/scripts/cplex_solver.sh";
  else if (options->solver == PONOS_SOLVER_CPLEX_INCREMENTAL)
    args[0] = STR_POCC_ROOT_DIR "/ponos/scripts/cplex_solver_incremental.sh";
  args[1] = fname;
  args[2] = options->output_file_template;

  // Execute.
  if (! options->quiet)
    {
      fprintf (stdout, "[Ponos][INFO] Starting Cplex solver\n");
      fprintf (stdout, "[Ponos][INFO] Cplex generated files: problem=%s script=%s.script solution=%s.xml\n", args[1], args[2], args[2]);
    }
  double timer_start = rtclock();
  char* res = my_pocc_execprog_ (args, 1, 0, 1, 1);
  double timer_end = rtclock();

  if (! options->quiet)
    printf ("[Ponos][INFO] Solver time: %0.4fs\n", timer_end - timer_start);
  space->last_solver_time = timer_end - timer_start;

  XFREE (args[1]);

  return res;
}

/**
 * Returns 1 if 'sys' has no solution.
 *
 */
int
ponos_solver_cplex_check_is_empty(s_ponos_space_t* space,
				  s_ponos_options_t* options,
				  s_fm_system_t* sys)
{
  char* output = ponos_solver_cplex_solve (space, options, sys, 1);
  if (output)
    {
      XFREE(output);
      return 0;
    }
  return 1;
}


/**
 * Embed the Cplex solution inside the scop schedules.
 * Requires ponos_solver_cplex_embed_solution_in_space to have
 * been called before.
 *
 */
static
void
ponos_solver_cplex_embed_solution_in_scop (s_ponos_space_t* space,
					   scoplib_scop_p scop,
					   s_ponos_options_t* options)
{
  scoplib_statement_p stmt = scop->statement;
  int nb_stmt;
  for (stmt = scop->statement, nb_stmt = 0; stmt; stmt = stmt->next, ++nb_stmt)
    ;
  s_fm_system_t* scheds_s[nb_stmt];
  int i, j;
  // Prepare the scheduling matrices.
  for (stmt = scop->statement, i = 0; stmt; stmt = stmt->next, ++i)
    scheds_s[i] = fm_system_alloc
      (options->schedule_size, stmt->domain->elt->NbColumns);

  stmt = scop->statement;
  scoplib_statement_p last = stmt;
  int dim = 0;
  int pos = 0;
  int idx = 0;
  while (pos < space->num_vars)
    {
      // Skip non-theta variables.
      if ((space->vars[pos]->type & PONOS_VAR_THETA) == 0)
	{
	  ++pos;
	  continue;
	}

      // Get the appropriate stmt/schedule matrix.
      /// FIXME: LNP: this requires the same scop has been used
      /// to build the legal space and to solve.
      if (space->vars[pos]->scop_ptr != last)
	{
	  stmt = stmt->next;
	  idx++;
	  if (stmt == NULL)
	    {
	      stmt = scop->statement;
	      idx = 0;
	    }
	  last = stmt;
	}

      // Place the value in the scheduling matrix.
      int offset = 0;
      if (space->vars[pos]->type == PONOS_VAR_THETA_PARAM)
	offset += stmt->nb_iterators;
      else if (space->vars[pos]->type == PONOS_VAR_THETA_CST)
	offset += stmt->nb_iterators + space->num_pars;

      z_type_t znum; Z_INIT(znum);
      Z_ASSIGN_SI(znum, space->vars[pos]->optimal_value);
      z_type_t zdenum; Z_INIT(zdenum); Z_ASSIGN_SI(zdenum, 1);
      fm_rational_assign (&(scheds_s[idx]->lines[space->vars[pos]->dim]->vector[1 + space->vars[pos]->pos + offset]), znum, zdenum);
      Z_CLEAR(znum); Z_CLEAR(zdenum);

      ++pos;
    }

  idx = 0;
  for (stmt = scop->statement; stmt; stmt = stmt->next)
    {
      // Converting the rational solution into an integer schedule.
      s_fm_system_t* tmps = fm_system_to_z (scheds_s[idx]);
      fm_system_free (scheds_s[idx]);
      stmt->schedule = convert_fm_system_to_scoplib_matrix (tmps);
      fm_system_free (tmps);
      ++idx;

      if (! options->quiet)
	{
	  int i, j;
	  printf ("Theta_S%d = (", idx - 1);
	  for (i = 0; i < stmt->schedule->NbRows; ++i)
	    {
	      int last = 0;
	      for (j = 1; j < stmt->schedule->NbColumns; ++j)
		{
		  int val = SCOPVAL_get_si(stmt->schedule->p[i][j]);
		  if (val)
		    {
		      if (last != 0)
			printf (" +");
		      last = 1;
		      char* str;
		      if (j <= stmt->nb_iterators)
			str = stmt->iterators[j - 1];
		      else if (j < stmt->schedule->NbColumns - 1)
			str = scop->parameters[j - 1 - stmt->nb_iterators];
		      else
			str = NULL;
		      char neg = ' ';
		      if (val < 0)
			neg = '-';
		      if (str && (val < 1 || val > 1))
			printf ("%c%d%s", neg, val, str);
		      else if (str)
			printf ("%c%s", neg, str);
		      else
			printf ("%c%d", neg, val);
		    }
		}
	      if (last == 0)
		printf ("0");
	      if (i < stmt->schedule->NbRows - 1)
		printf (", ");
	    }
	  printf (")\n");
	}
  
      if (options->debug)
	{
	  printf ("*** Schedule for S%d:\n", idx);
	  scoplib_matrix_print (stdout, stmt->schedule);
	}
    }
}


/**
 * Solve the ILP using Cplex.
 *
 */
void
ponos_solver_cplex (s_ponos_space_t* space,
		    scoplib_scop_p scop,
		    s_ponos_options_t* options)
{
  if (space == NULL || space->space == NULL)
    {
      fprintf (stderr, "[Ponos][ERROR] the system is NULL\n");
      return;
    }

  int max_schedule_dim = options->schedule_size;
  if (options->solver_precond)
    {
      if (! options->quiet)
	printf ("[Ponos][INFO] Precondition PIP problem\n");
      // Detect implicit equalities, perform redundancy elimination.
      s_fm_compsol_t* cs = fm_compsol_init_sol (space->space);
      fm_solution_free (space->space);
      space->space = fm_compsol_expand (cs);
    }

  s_fm_system_t* sys = fm_solution_to_system (space->space);

  if (! options->quiet)
    printf ("[Ponos][INFO] Solving system with %d variables and %d constraints\n", sys->nb_cols - 2, sys->nb_lines);


  // Run Cplex.
  char* cplex_out = ponos_solver_cplex_solve (space, options, sys, 0);

  if (cplex_out)
    {
      // We got a solution. Integrate it in the space.
      int err = ponos_solver_cplex_embed_solution_in_space (space, cplex_out);
      if (err == EXIT_SUCCESS)
	{
	  //if (options->debug)
	    {
	      fprintf (stdout, "[Ponos][INFO] Cplex result:\n");
	      ponos_solver_cplex_pprint_solution (stdout, space);
	    }

	  // Insert solution (theta variables) in scop.
	  ponos_solver_cplex_embed_solution_in_scop (space, scop, options);
	}
    }
  else
  {
	  printf ("[Ponos][WARNING] System has no solution.\n");
	  printf ("[Ponos][INFO] Consider using more schedule dimensions.\n");
  }

  // Be clean.
  XFREE(cplex_out);
  fm_system_free (sys);
}
