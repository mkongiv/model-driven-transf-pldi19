/*
 * solver-pip.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <math.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>


#include <fm/piptools.h>
#include <ponos/common.h>
#include <ponos/solver-pip.h>


static
double rtclock()
{
    struct timeval Tp;
    int stat;
    stat = gettimeofday (&Tp, NULL);
    if (stat != 0)
      printf ("Error return from gettimeofday: %d", stat);
    return (Tp.tv_sec + Tp.tv_usec * 1.0e-6);
}


static
void
quast_pretty_print (FILE* stream,
		    PipQuast* sol,
		    s_ponos_space_t* space,
		    s_ponos_options_t* options)
{
  if (sol == NULL)
    {
      fprintf (stream, "[VOID]\n");
      return;
    }
  PipList* lst = sol->list;
  int pos = 0;
  while (lst)
    {
      int num = CANDL_get_si(lst->vector->the_vector[0]);
      int denum = CANDL_get_si(lst->vector->the_deno[0]);
#define floord(x,y) ceil((double)x/(double)y)
      if (denum != 1)
	fprintf (stream, "%s = %d/%d\n", space->vars[pos]->name, num, denum);
      else
	{
	  if (num != 0)
	    fprintf (stream, "%s = %d ****\n", space->vars[pos]->name, num);
	  else
	    fprintf (stream, "%s = %d\n", space->vars[pos]->name, num);
	}
      ++pos;
      lst = lst->next;
    }
}


static
void
quast_embed_solution_in_space(PipQuast* sol,
			      s_ponos_space_t* space)
{
  if (sol == NULL)
    return;

  PipList* lst = sol->list;
  int pos = 0;
  if (lst)
    space->has_valid_optimal_solution = 1;
  
  while (lst)
    {
      int num = CANDL_get_si(lst->vector->the_vector[0]);
      int denum = CANDL_get_si(lst->vector->the_deno[0]);
      if (denum)
	space->vars[pos]->optimal_value = num / denum;
      else
	space->vars[pos]->optimal_value = num;
      ++pos;
      lst = lst->next;
    }
}


static
PipQuast*
ponos_piptools_pip (s_fm_system_t* sys, s_fm_system_t* context, int mode,
		    int var_are_pos, int has_parameters,
		    int verbose,
		    s_ponos_space_t* space)
{
  int i, j;
  PipOptions* pipoptions;
  PipQuast* solution;

  pipoptions = pip_options_init ();
  pipoptions->Simplify = 1;
  if (! has_parameters)
    pipoptions->Urs_parms = 0;
  if (var_are_pos)
    pipoptions->Urs_unknowns = 0;
  else
    pipoptions->Urs_unknowns = -1;
  if (verbose)
    pipoptions->Verbose = 2;

  PipMatrix* syst = fm_piptools_st_to_pipmatrix (sys);
  PipMatrix* contx = fm_piptools_st_to_pipmatrix (context);

  if (mode == FM_PIPTOOLS_RAT)
    {
      if (verbose)
	printf ("[Ponos][INFO] Solver mode: LP\n");
      pipoptions->Nq = 0;
    }
  else
    {
      if (verbose)
	printf ("[Ponos][INFO] Solver mode: ILP\n");
      pipoptions->Nq = 1;
    }

/*   s_fm_compsol_t* cs = fm_compsol_init_sys (sys); */
/*   s_fm_system_t* syst = fm_solution_to_system (cs->poly); */
  double timer_start, timer_end;
  timer_start = rtclock ();
  //pip_matrix_print (stdout, syst);
  solution = pip_solve (syst, contx, -1, pipoptions);
  timer_end = rtclock ();
  if (verbose)
    printf ("[Ponos][INFO] Solver time: %0.4fs\n", timer_end - timer_start);
  space->last_solver_time = timer_end - timer_start;
  pip_matrix_free (syst);
  pip_options_free (pipoptions);

  return solution;
}

static
scoplib_matrix_p
convert_fm_system_to_scoplib_matrix (s_fm_system_t* s)
{
  int i, j;
  scoplib_matrix_p ret = scoplib_matrix_malloc (s->nb_lines, s->nb_cols);
  for (i = 0; i < s->nb_lines; ++i)
    for (j = 0; j < s->nb_cols; ++j)
      {
	SCOPVAL_set_si(ret->p[i][j], Z_GET_SI(s->lines[i]->vector[j].num));
      }
  return ret;
}


/**
 * Format the solution into a schedule, embedded in the SCoP.
 *
 *
 */
static
void
embed_solution_in_scop (s_ponos_space_t* space,
			PipQuast* sol,
			scoplib_scop_p scop,
			int max_schedule_dim,
			s_ponos_options_t* options)
{
  scoplib_statement_p stmt = scop->statement;
  PipList* lst = sol->list;
  if (sol->condition != NULL)
    {
      fprintf (stderr, "[Ponos][WARNING] The solution quast contains conditionals.\n");
      fprintf (stderr, "[Ponos][WARNING] Correctness not guaranteed.\n");
      assert (sol->condition == NULL);
    }
  int nb_stmt;
  for (stmt = scop->statement, nb_stmt = 0; stmt; stmt = stmt->next, ++nb_stmt)
    ;
  s_fm_system_t* scheds_s[nb_stmt];
  int i, j;
  // Prepare the scheduling matrices.
  for (stmt = scop->statement, i = 0; stmt; stmt = stmt->next, ++i)
    scheds_s[i] = fm_system_alloc
      (max_schedule_dim, stmt->domain->elt->NbColumns);

  /// TODO: deal with parametric solutions!
  stmt = scop->statement;
  scoplib_statement_p last = stmt;
  int dim = 0;
  int pos = 0;
  int idx = 0;
  while (lst)
    {
      // Skip non-theta variables.
      if ((space->vars[pos]->type & PONOS_VAR_THETA) == 0)
	{
	  ++pos;
	  lst = lst->next;
	  continue;
	}

      // Get the appropriate stmt/schedule matrix.
      /// FIXME: LNP: this requires the same scop has been used
      /// to build the legal space and to solve.
      if (space->vars[pos]->scop_ptr != last)
	{
	  stmt = stmt->next;
	  idx++;
	  if (stmt == NULL)
	    {
	      stmt = scop->statement;
	      idx = 0;
	    }
	  last = stmt;
	}

      // Place the value in the scheduling matrix.
      int offset = 0;
      if (space->vars[pos]->type == PONOS_VAR_THETA_PARAM)
	offset += stmt->nb_iterators;
      else if (space->vars[pos]->type == PONOS_VAR_THETA_CST)
	offset += stmt->nb_iterators + space->num_pars;
      // Get the value.
      int num = CANDL_get_si(lst->vector->the_vector[0]);
      int denum = CANDL_get_si(lst->vector->the_deno[0]);
#define floord(x,y) ceil((double)x/(double)y)
      int val = floord(num, denum);
      z_type_t znum; Z_INIT(znum); Z_ASSIGN_SI(znum, num);
      z_type_t zdenum; Z_INIT(zdenum); Z_ASSIGN_SI(zdenum, denum);
      fm_rational_assign (&(scheds_s[idx]->lines[space->vars[pos]->dim]->vector[1 + space->vars[pos]->pos + offset]), znum, zdenum);
      Z_CLEAR(znum); Z_CLEAR(zdenum);

      ++pos;
      lst = lst->next;
    }

  idx = 0;
  for (stmt = scop->statement; stmt; stmt = stmt->next)
    {
      // Converting the rational solution into an integer schedule.
      s_fm_system_t* tmps = fm_system_to_z (scheds_s[idx]);
      fm_system_free (scheds_s[idx]);
      stmt->schedule = convert_fm_system_to_scoplib_matrix (tmps);
      fm_system_free (tmps);
      ++idx;

      if (! options->quiet)
	{
	  int i, j;
	  printf ("Theta_S%d = (", idx - 1);
	  for (i = 0; i < stmt->schedule->NbRows; ++i)
	    {
	      int last = 0;
	      for (j = 1; j < stmt->schedule->NbColumns; ++j)
		{
		  int val = SCOPVAL_get_si(stmt->schedule->p[i][j]);
		  if (val)
		    {
		      if (last != 0)
			printf (" +");
		      last = 1;
		      char* str;
		      if (j <= stmt->nb_iterators)
			str = stmt->iterators[j - 1];
		      else if (j < stmt->schedule->NbColumns - 1)
			str = scop->parameters[j - 1 - stmt->nb_iterators];
		      else
			str = NULL;
		      char neg = ' ';
		      if (val < 0)
			neg = '-';
		      if (str && (val < 1 || val > 1))
			printf ("%c%d%s", neg, val, str);
		      else if (str)
			printf ("%c%s", neg, str);
		      else
			printf ("%c%d", neg, val);
		    }
		}
	      if (last == 0)
		printf ("0");
	      if (i < stmt->schedule->NbRows - 1)
		printf (", ");
	    }
	  printf (")\n");
	}
      if (options->debug)
	{
	  printf ("*** Schedule for S%d:\n", idx);
	  scoplib_matrix_print (stdout, stmt->schedule);
	}
    }
/*   if (options->debug) */
/*     scoplib_scop_print (stdout, scop); */
}


/**
 * Find a solution to a system using PIP, and embed the schedule found
 * in the scop.
 *
 */
void
ponos_solver_pip (s_ponos_space_t* space,
		  scoplib_scop_p scop,
		  s_ponos_options_t* options)
{
  if (space == NULL || space->space == NULL)
    {
      fprintf (stderr, "[Ponos][ERROR] the system is NULL\n");
      return;
    }

  int max_schedule_dim = options->schedule_size;
  if (options->solver_precond)
    {
      if (! options->quiet)
	printf ("[Ponos][INFO] Precondition PIP problem\n");
      // Detect implicit equalities, perform redundancy elimination.
      s_fm_compsol_t* cs = fm_compsol_init_sol (space->space);
      fm_solution_free (space->space);
      space->space = fm_compsol_expand (cs);
    }

  s_fm_system_t* sys = fm_solution_to_system (space->space);

  if (! options->quiet)
    printf ("[Ponos][INFO] Solving system with %d variables and %d constraints\n", sys->nb_cols - 2, sys->nb_lines);

  // Our systems never have parameters, by design.
  PipQuast* sol;
  if (options->pipsolve_lp)
    sol = ponos_piptools_pip (sys, NULL, FM_PIPTOOLS_RAT,
			      0, 0,
			      !options->quiet, space);
  else
    sol = ponos_piptools_pip (sys, NULL, FM_PIPTOOLS_INT,
			      0, 0,
			      !options->quiet, space);

  if (options->debug)
    {
      quast_pretty_print (stdout, sol, space, options);
      /*       pip_quast_print (stdout, sol, 0); */
    }

  if (!((sol != NULL) &&
	((sol->list != NULL) || (sol->condition != NULL))))
    {
      if (! options->quiet)
	{
	  printf ("[Ponos][WARNING] System has no solution.\n");
	  printf ("[Ponos][INFO] Consider using more schedule dimensions.\n");
	  return;
	}
    }

  // Register the current optimal solution.
  quast_embed_solution_in_space (sol, space);

  // Put the solution as a schedule in the SCoP.
  embed_solution_in_scop (space, sol, scop, max_schedule_dim, options);

  // Be clean.
  fm_system_free (sys);
  pip_quast_free (sol);
}
