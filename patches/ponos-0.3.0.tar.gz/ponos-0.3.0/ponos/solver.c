/*
 * solver.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/solver.h>
#include <ponos/solver-cplex.h>
#include <ponos/solver-pip.h>


/**
 * Find a solution to a system, and embed the schedule found in the scop.
 *
 */
void
ponos_solver (s_ponos_space_t* space,
	      scoplib_scop_p scop,
	      s_ponos_options_t* options)
{
  if (options->solver == PONOS_SOLVER_PIP)
    {
      ponos_solver_pip (space, scop, options);
    }
  else if (options->solver == PONOS_SOLVER_CPLEX ||
	   options->solver == PONOS_SOLVER_CPLEX_INCREMENTAL)
    {
      ponos_solver_cplex (space, scop, options);
    }
}
