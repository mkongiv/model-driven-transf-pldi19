/*
 * punroll.c: This file is part of the PAST-unroller project.
 *
 * Punroller: a library to perform unroll-and-jam on PAST trees.
 *
 * Copyright (C) 2011 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#if HAVE_CONFIG_H
# include <punroller/config.h>
#endif

#include <assert.h>
#include <math.h>

#include <punroller/common.h>
#include <punroller/punroll.h>
#include <past/past_api.h>
#include <past/pprint.h>

//#define DEBUG_CHUNKED_UNROLL


static
double rtclock()
{
    struct timeval Tp;
    int stat;
    stat = gettimeofday (&Tp, NULL);
    if (stat != 0)
      printf ("Error return from gettimeofday: %d", stat);
    return (Tp.tv_sec + Tp.tv_usec * 1.0e-6);
}

static
void traverse_update_refs (s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_varref))
    {
      PAST_DECLARE_TYPED(varref, pv, node);
      void** args = (void**)data;
      s_symbol_t* iter = args[0];
      if (symbol_equal (pv->symbol, iter))
	{
	  int* factor = args[1];
	  s_past_node_t*** map = args[2];
	  s_past_node_t* inc = past_node_value_create_from_int (*factor);
	  s_past_node_t* rep;
	  s_past_node_t* next = node->next;
	  node->next = NULL;
	  rep = past_node_binary_create (past_add, past_clone (node), inc);
	  int i;
	  for (i = 0; map[i][0]; ++i)
	    ;
	  map[i][0] = node;
	  map[i][1] = rep;
	  node->next = next;
	}
    }
}


int
punroll_update_increment (s_past_for_t* node, int size)
{
  s_past_node_t* inc = NULL;
  s_past_node_t* var = NULL;
  int val = 1;

  if (past_node_is_a (node->increment, past_inc_before) ||
      past_node_is_a (node->increment, past_inc_after))
    {
      PAST_DECLARE_TYPED(unary, pu, node->increment);
      if (! past_node_is_a (pu->expr, past_varref))
	return -1;
      inc = node->increment;
      var = pu->expr;
    }
  else if (past_node_is_a (node->increment, past_assign))
    {
      PAST_DECLARE_TYPED(binary, pb, node->increment);
      if (! past_node_is_a (pb->lhs, past_varref))
	return -1;
      PAST_DECLARE_TYPED(varref, pv, pb->lhs);
      if (! past_node_is_a (pb->rhs, past_add))
	return -1;
      PAST_DECLARE_TYPED(binary, pb2, pb->rhs);
      if (! past_node_is_a (pb2->lhs, past_varref))
	return -1;
      PAST_DECLARE_TYPED(varref, pv2, pb2->lhs);
      if (! symbol_equal (pv->symbol, pv2->symbol))
	return -1;
      if (! past_node_is_a (pb2->rhs, past_value))
	return -1;
      PAST_DECLARE_TYPED(value, pval, pb2->rhs);
      if (pval->type != e_past_value_int)
	return -1;
      val = pval->value.intval;
      if (val < 1)
	return -1;
    }
  else
    return -1;

  s_past_node_t* newinc =
    past_node_binary_create
    (past_assign, past_node_varref_create (node->iterator),
     past_node_binary_create
     (past_add, past_node_varref_create (node->iterator),
      past_node_value_create_from_int (size * val)));
  past_deep_free (node->increment);
  node->increment = newinc;

  return val;
}

static
int unroll_cost_model_adjust (s_past_node_t* node, int size, int nb_register)
{
  // Count the number of statements in the loop.
  int num_stmts = past_count_statements (node);

  // cost model: num_stmts * 2.5 * size < nb_register.
  int ret  = round ((float)nb_register / (num_stmts * 2.5));
  if (ret > size)
    ret = size;
  if (ret == 0)
    ret = 1;
  return ret;
}

static
s_past_node_t* create_init (s_past_varref_t* iter, int size)
{
  if (size == 0)
    size = 1;
  s_past_node_t* ret =
    past_node_binary_create
    (past_assign, past_clone ((s_past_node_t*)iter),
     past_node_binary_create
     (past_sub, past_clone ((s_past_node_t*)iter),
      past_node_value_create_from_int (size - 1)));

  return ret;
}


/**
 * Export for psimdkzer.
 *
 *
 */
void
punroll_unroll_cost (s_past_node_t* node, int size,
		     s_symbol_t* iter,
		     int nb_register)
{
  assert (past_node_is_a (node, past_for));
  PAST_DECLARE_TYPED(for, pf, node);
  // Cannot unroll without an ub.
  if (pf->test == NULL)
    return;
  // Nothing to do is size is 1.
  if (size == 1)
    return;

  // Adapt the unroll factor using a naive cost model based on the
  // number of statements and number of register.
  if (nb_register != -1)
    size = unroll_cost_model_adjust (node, size, nb_register);

  s_past_node_t* next;
  s_past_node_t* tmp;
  int i, j, k;

  // Duplicate the loop.
  s_past_node_t* loopepilog = past_clone (node);
  PAST_DECLARE_TYPED(for, pl, loopepilog);
	pl->body = past_clone(pf->body);
  past_deep_free (pl->init);
  pl->init = NULL;


  // Increment the loop body by the unroll size.
  int base_loop_inc = punroll_update_increment (pf, size);
  if (base_loop_inc < 1)
    {
      printf ("[PUnroll][WARNING] Unsupported loop increment\n");
      past_deep_free (loopepilog);
      return;
    }


  // Change the loop ub to ub - size, doing "iter -> iter - size + 1".
  int num_var_ref = 0;
  for (tmp = pf->test; tmp; tmp = tmp->next)
    num_var_ref += past_count_nodetype (tmp, past_varref);
  s_past_node_t*** map = XMALLOC(s_past_node_t**, num_var_ref + 1);
  for (i = 0; i < num_var_ref + 1; ++i)
    {
      map[i] = XMALLOC(s_past_node_t*, 2);
      map[i][0] = map[i][1] = NULL;
    }
  int factor = (base_loop_inc * size) - 1;
  void* args[3]; args[0] = iter; args[1] = &factor; args[2] = map;
  past_visitor (pf->test, traverse_update_refs, (void*)args, NULL, NULL);
  for (j = 0; map[j][0]; ++j)
    {
      past_replace_node (map[j][0], map[j][1]);
      past_deep_free (map[j][0]);
    }
  for (i = 0; i < num_var_ref + 1; ++i)
    XFREE(map[i]);
  XFREE(map);

  // Create a map to store the replacements.
  num_var_ref = 0;
  for (tmp = pf->body; tmp; tmp = tmp->next)
    num_var_ref += past_count_nodetype (tmp, past_varref);
  map = XMALLOC(s_past_node_t**, num_var_ref + 1);
  for (i = 0; i < num_var_ref + 1; ++i)
    {
      map[i] = XMALLOC(s_past_node_t*, 2);
      map[i][0] = map[i][1] = NULL;
    }
  // Find the end of the body.
  for (next = pf->body; next->next; next = next->next)
    ;

  // Duplicate the body.
  s_past_node_t* newbody[size - 1];
  for (i = 0; i < size - 1; ++i)
    newbody[i] = past_clone (pf->body);

  // Duplicate the body 'size - 1' times.
  for (i = 0; i < size - 1; ++i)
    {
      past_set_parent (newbody[i]);
      // Find the varref
      int ufact = (i + 1) * base_loop_inc;
      void* args[3]; args[0] = iter; args[1] = &ufact; args[2] = map;
      past_visitor (newbody[i], traverse_update_refs, (void*)args, NULL, NULL);

      // Substitute.
      for (j = 0; map[j][0]; ++j)
	{
	  s_past_node_t* nextp = map[j][0]->next;
	  map[j][0]->next = NULL;
	  past_replace_node (map[j][0], map[j][1]);
	  map[j][1]->next = nextp;
	  past_deep_free (map[j][0]);
	  map[j][0] = map[j][1] = NULL;
	}

      // Insert.
      next->next = newbody[i];
      newbody[i]->parent = node;
      for (next = newbody[i]; next && next->next; next = next->next)
	;
    }

  // Final insert.
//	printf("epilog print\n");
//	past_pprint(stdout,loopepilog);
  loopepilog->next = node->next;
//	printf("node next print\n");
//	past_pprint(stdout,node->next);
  node->next = loopepilog;

  // Be clean.
  for (i = 0; i < num_var_ref + 1; ++i)
    XFREE(map[i]);
  XFREE(map);
}

/**
 * Unroll systematically all inner loops by 'size'.
 *
 */
void
punroll_dummy (scoplib_scop_p scop, s_past_node_t* root, int size)
{
  past_set_parent (root);

  // 1- Find all inner-most loops.
  s_past_node_t** inner = past_inner_loops (root);

  // 2- Unroll them by the unroll factor.
  int i;
  for (i = 0; inner[i]; ++i)
    {
      assert (past_node_is_a (inner[i], past_for));
      PAST_DECLARE_TYPED(for, pf, inner[i]);
      punroll_unroll_cost (inner[i], size, pf->iterator, -1);
    }
  past_set_parent (root);
}

/**
 * Unroll inner-loops in order to not exceed register size. Rough
 * estimate (does not consider intra-register reuse). Do not exceed
 * max_ufactor unrolling of the loop anyway.
 *
 */
void
punroll (scoplib_scop_p scop, s_past_node_t* root,
	 int unroll_factor, int nb_register)
{
  past_set_parent (root);
  // 1- Find all inner-most loops.
  s_past_node_t** inner = past_inner_loops (root);

  // 2- Unroll them by the unroll factor.
  int i;
  for (i = 0; inner[i]; ++i)
    {
      // Do not unroll simd loops.
      if (past_node_is_a (inner[i], past_parfor))
	continue;
      assert (past_node_is_a (inner[i], past_for));
      PAST_DECLARE_TYPED(for, pf, inner[i]);
      punroll_unroll_cost (inner[i], unroll_factor, pf->iterator, nb_register);
    }

  past_set_parent (root);
}

// MK: Modified version of update_increment. Get the current increment of the unrolled loop
int punroll_get_increment (s_past_for_t* node)
{
  s_past_node_t* inc = NULL;
  s_past_node_t* var = NULL;
  int val = 1;

  if (past_node_is_a (node->increment, past_inc_before) ||
      past_node_is_a (node->increment, past_inc_after))
    {
      PAST_DECLARE_TYPED(unary, pu, node->increment);
      if (! past_node_is_a (pu->expr, past_varref))
	return -1;
      inc = node->increment;
      var = pu->expr;
    }
  else if (past_node_is_a (node->increment, past_assign))
    {
      PAST_DECLARE_TYPED(binary, pb, node->increment);
      if (! past_node_is_a (pb->lhs, past_varref))
	return -1;
      PAST_DECLARE_TYPED(varref, pv, pb->lhs);
      if (! past_node_is_a (pb->rhs, past_add))
	return -1;
      PAST_DECLARE_TYPED(binary, pb2, pb->rhs);
      if (! past_node_is_a (pb2->lhs, past_varref))
	return -1;
      PAST_DECLARE_TYPED(varref, pv2, pb2->lhs);
      if (! symbol_equal (pv->symbol, pv2->symbol))
	return -1;
      if (! past_node_is_a (pb2->rhs, past_value))
	return -1;
      PAST_DECLARE_TYPED(value, pval, pb2->rhs);
      if (pval->type != e_past_value_int)
	return -1;
      val = pval->value.intval;
      if (val < 1)
	return -1;
    }
  else
    return -1;

  return val;
}

static
s_past_node_t* get_enclosed_node (s_past_node_t* node)
{
	if (past_node_is_a (node,past_block))
		{
			PAST_DECLARE_TYPED (block, pb, node);
			return get_enclosed_node (pb->body);
		}
	else
		return node;
}

// test nestedness of inner loop with respect to
// its enclosing loop.
int punroll_is_perfectly_nested (s_past_node_t* inner)
{
	s_past_node_t* parent;
	for (parent = inner->parent;
			! past_node_is_a (parent, past_for);
			parent = parent->parent);
	PAST_DECLARE_TYPED (for, pfparent, parent);
	s_past_node_t* child = get_enclosed_node (pfparent->body) ;
	int i, pos_inner;
	// counts number of statements and inner loop position
	for (i = 0, pos_inner = -1 ; child; child = child->next, ++i)
		{
			if (child == inner) pos_inner = i;
		}
	// inner loop is the only statement inside its parent
	// hence it's perfectly nested
	if (i-1 == pos_inner && i == 1)
		{
			return 1;
		}
	// not perfecly nested
	else if (pos_inner != -1)
		{
			return 0;
		}
	// inner loop is not a child of its parent,
	// hence tree is inconsistent. This should not happen.
	return -1;
}

// checks for the existance of an affine guard/if
// conditional between an inner loop and the first
// enclosing outer loop
static
int has_nested_conditional (s_past_node_t* inner)
{
	s_past_node_t* pred;
	for (pred = inner->parent;
		pred && !past_node_is_a (pred, past_for);
		pred = pred->parent)
		if (past_node_is_a (pred, past_affineguard) ||
				past_node_is_a (pred, past_if))
			return 1;
	// must find an outer loop, otherwise abort
	assert (pred);
	// didn't find a conditional
	return 0;
}

// Unroll a single statement. Used for unrolling prologs and epilogs
s_past_node_t *
punroll_single_statement ( s_past_node_t * node, int size , s_past_for_t * loop)
{
	int base_loop_inc = punroll_get_increment ( loop );
  // Create a map to store the replacements.
  int num_var_ref ;
	int i,j;
	s_past_node_t*** map ;
  num_var_ref = past_count_nodetype (node, past_varref);
  map = XMALLOC(s_past_node_t**, num_var_ref + 1);
  for (i = 0; i < num_var_ref + 1; ++i)
    {
      map[i] = XMALLOC(s_past_node_t*, 2);
      map[i][0] = map[i][1] = NULL;
    }

  s_past_node_t* newbody[size - 1];
  for (i = 0; i < size - 1; ++i){
    newbody[i] = past_clone (node);
		newbody[i]->next  = NULL;
	}
  // Duplicate the body 'size - 1' times.
  for (i = 0; i < size - 1; ++i)
  {
      past_set_parent (newbody[i]);
      // Find the varref
      int ufact = (i + 1) * base_loop_inc;
      void* args[3]; args[0] = loop->iterator; args[1] = &ufact; args[2] = map;
      past_visitor (newbody[i], traverse_update_refs, (void*)args, NULL, NULL);
      // Substitute.
      for (j = 0; map[j][0]; ++j)
			{
						s_past_node_t* nextp = map[j][0]->next;
						map[j][0]->next = NULL;
						past_replace_node (map[j][0], map[j][1]);
						map[j][1]->next = nextp;
						past_deep_free (map[j][0]);
						map[j][0] = map[j][1] = NULL;
			}

      // Insert.
			node->next = newbody[i];
      newbody[i]->parent = (s_past_node_t*)loop;
			node = node->next;
   }
	return node; // return last node
}


/// MK: when called from polyopt loop statements might be enclosed
//	in multiple braces, and when unrolling and jamming imperfectly
//	nested loops, this becomes a problem. So  we remove them here.
static
void
remove_useless_blocks (s_past_node_t* outer)
{
	PAST_DECLARE_TYPED (for, pfo, outer);
	PAST_DECLARE_TYPED (block, pb, pfo->body);
	int is_useless = past_node_is_a (pb->body, past_block) ||
					past_node_is_a (pb->body, past_statement);
	if (! is_useless)
		return;
	s_past_node_t* first = NULL;
	s_past_node_t* last = NULL;
	s_past_node_t* currblock;
	s_past_node_t* curr;
	for (currblock = pfo->body; currblock; currblock = currblock->next)
		{
			curr = past_clone (get_enclosed_node (currblock));
			if (! last)
				first = last = curr;
			else
				last->next = curr;
			for ( ; last->next; last = last->next);
		}
	last->next = NULL;
	s_past_node_t* old_body = pfo->body;
	past_replace_node (old_body, first);
	past_deep_free (old_body);
}


// Loop 1: outer, loop 2: inner.
static
void
punroll_and_jam_loops_imperfect (scoplib_scop_p scop, s_past_node_t* root,
		       s_past_node_t* loop1, s_past_node_t* loop2,
		       int* size, int nb_register)
{
	if (past_node_is_a (loop1, past_for) && past_node_is_a (loop2, past_for))
		{
			PAST_DECLARE_TYPED (for, pf1, loop1);
			PAST_DECLARE_TYPED (for, pf2, loop2);
			int i;
			int perf_nest = punroll_is_perfectly_nested (loop2);
			// must not be perfectly nested.
			// Either way it won't get here if it's perfectly nested
			// and called from punroll_and_jam_loops,
			// So this must not happen. Nevertheless, someday someone
			// might decide to call this function in a direct manner.
			assert (perf_nest == 0);
			// First clone outer loop into the unrolled loop and the epilog
			s_past_node_t* outer_unrolled = past_clone (loop1);
			s_past_node_t* outer_epilog 	= past_clone (loop1);
			// unroll new outer loop
			punroll_unroll_cost (outer_unrolled, size[0], pf1->iterator, nb_register);
			// remove init node from epilog
			PAST_DECLARE_TYPED (for, pf1e, outer_epilog);
			past_deep_free (pf1e->init);
			pf1e->init = NULL;
			// link outer unrolled and outer epilog
			outer_unrolled->next = outer_epilog;
			// remove potential double braces which break
			// cause problems.
			remove_useless_blocks (outer_unrolled);
			// collect inner loops of outer_unrolled for unrolling them
			PAST_DECLARE_TYPED (for, pfou, outer_unrolled);
			s_past_node_t* first_child;
			s_past_node_t* first;
			// fetch the very fist statement of the unrolled loop body
			first_child = first = get_enclosed_node (pfou->body);
			s_past_node_t** inner = past_inner_loops (outer_unrolled);
			// unroll each inner loop and link properly.
			// do not use past_replace_node because this function
			// seems to replace node by node and not node by list.
			for (i = 0; inner[i]; ++i)
				{
					// store node that follows the current inner loop
					s_past_node_t* child_next = inner[i]->next;
					// clone inner loop
					s_past_node_t* new_inner = past_clone (inner[i]);
					// remove double braces if present
					remove_useless_blocks (new_inner);
					// unroll it
					punroll_unroll_cost (new_inner, size[1], pf2->iterator, nb_register);
					// most complicated part. Chain the nodes nicely.
					s_past_node_t* prev;
					s_past_node_t* next;
					// This conditional handles the case wherein the
					// inner loop is precisely the first statement of
					// the outer_unrolled.
					if (first_child == inner[i])
						{
							first = new_inner;
							past_replace_node (first_child, new_inner);
						}
					else
						{
							for (prev = first, next = first->next;
								 next != inner[i];
								 prev = next, next = next->next);
							prev->next = new_inner;
						}
					// unrolled inner loop has an epilog so use the
					// next->next field.
					new_inner->next->next = child_next;
					// unhook next of the original inner loop
					// before deep freeing.
					inner[i]->next = NULL;
					past_deep_free (inner[i]);
				}
			// set the parent field of the linked list
			past_set_parent (first);
			// replace old outer loop by new outer loop
			past_replace_node (loop1, outer_unrolled);
			// just in case link manually
			outer_epilog->next = loop1->next;
			loop1->next = NULL;
			// free old outer loop
			past_deep_free (loop1);
		}
  else
		fprintf (stderr, "[Punroll][WARNING] Input loops are not loops!\n");
}




// Unroll and jam perfectly nested loops.
// Loop 1: outer, loop 2: inner.
static
void
punroll_and_jam_loops_perfect (scoplib_scop_p scop, s_past_node_t* root,
		       s_past_node_t* loop1, s_past_node_t* loop2,
		       int* size, int nb_register)
{
  if (past_node_is_a (loop1, past_for) && past_node_is_a (loop2, past_for))
    {
			int perf_nest = punroll_is_perfectly_nested ( loop2 );
			assert ( perf_nest );

      PAST_DECLARE_TYPED(for, pf1, loop1);
      PAST_DECLARE_TYPED(for, pf2, loop2);
      // 0- Backup original body of outer loop.
      s_past_node_t* loop1_backup = past_clone (loop1);

      // 1- Unroll loop2 with loop2 iterator.
      s_past_node_t* backup_inc2 = past_clone (pf2->increment);
      punroll_unroll_cost (loop2, size[1], pf2->iterator, nb_register);
      // Backup correct loop2 increment.
      s_past_node_t* correct_inc2 = pf2->increment;
      // Restore original loop bound.
      pf2->increment = backup_inc2;
      backup_inc2 = past_clone (pf2->increment);
      // Backup new test.
      s_past_node_t* loop2_test = past_clone (pf2->test);

      // 2- Unroll loop2 with loop1 iterator.
			// This 2 lines were the bug:
			//s_past_node_t* l2_epilog = loop2->next;
			//loop2->next = NULL;
      punroll_unroll_cost (loop2, size[0], pf1->iterator, nb_register);
			// Bug fix:
			s_past_node_t* l2_epilog = loop2->next->next;
			loop2->next = NULL;
      // Delete useless epilog.
      past_deep_free (loop2->next);
      loop2->next = NULL;
      // Restore correct test.
      past_deep_free (pf2->test);
      pf2->test = loop2_test;
      // Restore correct increment.
      past_deep_free (pf2->increment);
      pf2->increment = correct_inc2;

			// MK: unroll loop prolog
			s_past_node_t * l1_prolog = pf1->body;
			if ( l1_prolog != loop2 )
			{
				while (l1_prolog != loop2 )
				{
					s_past_node_t* next = l1_prolog->next;
					l1_prolog = punroll_single_statement(l1_prolog,size[0], pf1);
					l1_prolog->next = next;
					l1_prolog = l1_prolog->next;
				}
			}

      // Unroll the epilog code for loop2 with loop1 iterator.
      if (l2_epilog)
			{
				s_past_node_t* le2_epilog = l2_epilog->next;
				l2_epilog->next = NULL;
				punroll_unroll_cost (l2_epilog, size[0], pf1->iterator, nb_register);
				// Set correct increment for epilog of loop2.
				PAST_DECLARE_TYPED(for, pf2e, l2_epilog);
				past_deep_free (pf2e->increment);
				pf2e->increment = backup_inc2;
				past_deep_free (l2_epilog->next);
				l2_epilog->next = le2_epilog;
				loop2->next = l2_epilog;
				/// MK: unroll epilog level 2
				if ( le2_epilog )
				{
					while ( le2_epilog )
					{
						s_past_node_t* next = le2_epilog->next;
						le2_epilog = punroll_single_statement(le2_epilog,size[0], pf1);
						le2_epilog->next = next;
						le2_epilog = le2_epilog->next;
					}
				}
			}

      // 3- unroll outer, to generate the epilogue code for loop1.
      loop1_backup->next = loop1->next;
      punroll_unroll_cost (loop1_backup, size[0], pf1->iterator, nb_register);
      // Insert the generated epilog after loop1.
      loop1->next = loop1_backup->next;
      loop1_backup->next = NULL;
      // Update test and increment of loop1.
      PAST_DECLARE_TYPED(for, pfb, loop1_backup);
      past_deep_free (pf1->test);
      pf1->test = past_clone (pfb->test);
      past_deep_free (pf1->increment);
      pf1->increment = past_clone (pfb->increment);
      // Delete useless unrolled loop.
      past_deep_free (loop1_backup);

      // Set parent node, just in case.
      past_set_parent (root);
    }
  else
    fprintf (stderr, "[Punroll][WARNING] Input loops are not loops!\n");
}


// Checks the nestedness property of the inner loop
// and calls the necessary function.
// Loop 1: outer, loop 2: inner.
void
punroll_and_jam_loops (scoplib_scop_p scop, s_past_node_t* root,
		       s_past_node_t* loop1, s_past_node_t* loop2,
		       int* size, int nb_register)
{
	if (has_nested_conditional (loop2))
	{
	  fprintf (stderr, "[Punroll] Unrolling is not possible due to nested conditionals!\n");
		assert (0);
	}
	if (punroll_is_perfectly_nested (loop2))
		punroll_and_jam_loops_perfect (scop, root,
		       loop1, loop2,
		       size, nb_register);
	else
		punroll_and_jam_loops_imperfect (scop, root,
		       loop1, loop2,
		       size, nb_register);
}


/**
 * Unroll a specific loop.
 *
 */
void punroll_unroll_loop (s_past_for_t* node, int size, int nb_register)
{
  punroll_unroll_cost (&(node->node), size, node->iterator, nb_register);
}


/**
 * FIXME: debug!
 */

void
punroll_and_jam (scoplib_scop_p scop, s_past_node_t* root,
		 int* size, int nb_register)
{
  // 1- Find all maximal perfectly nested loops.
  /// FIXME: TBD.
  /// Dummy test: u-a-j the first inner-most loop and its immediate
  /// parent loop.

  /* martin commented this:
     s_past_node_t* root_back = root;
     root = past_clone (root_back);
     end of martin's comment */
  past_set_parent (root);
  s_past_node_t** inloops = past_inner_loops (root);
  s_past_node_t* loop1 = NULL;
  s_past_node_t* loop2 = NULL;
  if (has_nested_conditional (inloops[0]))
    {
      fprintf (stderr, "[Punroll] Unrolling is not possible due to nested conditionals\n");
      assert (0);
    }

  if (inloops)
    {
      loop2 = inloops[0];
      s_past_node_t* tmp = loop2->parent;
      while (tmp && ! past_node_is_a(tmp, past_for)) tmp = tmp->parent;
      loop1 = tmp;
    }

  //   size[0] = 4;
  //   size[1] = 2;
  punroll_and_jam_loops (scop, root, loop1, loop2, size, nb_register);
  past_set_parent (root);
  //past_deep_free (root);
}




void
punroll_show_info (scoplib_scop_p scop, s_past_node_t * root) 
{
  s_past_node_t ** loops;
  loops = past_collect_nodetype (root, past_for);
  int ii;
  for (ii = 0; loops && loops[ii]; ii++)
  {
    PAST_DECLARE_TYPED(for, pf, loops[ii]);
    int pt = past_node_is_a (loops[ii], past_parfor);
    printf ("Loop %d (par=%d)\n",ii,pt);
    printf ("\t Init     : "); past_pprint (stdout, pf->init); printf ("\n");
    printf ("\t Test     : "); past_pprint (stdout, pf->test); printf ("\n");
    printf ("\t Increment: "); past_pprint (stdout, pf->increment); printf ("\n");
    printf ("\t Property : %d\n",pf->property); printf ("\n");

    if (past_is_outer_for_loop (loops[ii]))
    {

    }
  }
}

static
void
punroll_update_test_by_scale (s_past_node_t * node, int uf)
{
  assert (past_node_is_a (node, past_for));
  PAST_DECLARE_TYPED(for, pf, node);
  PAST_DECLARE_TYPED(binary, old_test, pf->test);
  PAST_DECLARE_TYPED(binary, old_init, pf->init);
  PAST_DECLARE_TYPED(value, pval, old_init->rhs);

  assert (past_node_is_a (pf->test, past_leq));
  s_past_node_t * new_test;
  s_past_node_t * new_test_rhs;
  s_past_node_t * modexpr;

  if (pval->value.intval == 0)
  {
    /*
    modexpr = past_node_ternary_cond_create (
      past_node_binary_create (past_gt,
        past_node_binary_create (past_mod, 
          past_node_binary_create (past_add,
            past_clone (old_test->rhs), 
            past_node_value_create_from_int (1)),
          past_node_value_create_from_int (uf)),
        past_node_value_create_from_int (0)),
      past_node_value_create_from_int (1),
      past_node_value_create_from_int (0));
    */
    modexpr = past_node_value_create_from_int (1);
    
    new_test_rhs = past_node_binary_create (past_sub,
      past_node_binary_create (past_div, 
        past_node_binary_create (past_add,
          past_clone (old_test->rhs), 
          past_node_value_create_from_int (1)),
        past_node_value_create_from_int (uf)),
      modexpr);
  }
  else
  {
    modexpr = past_node_ternary_cond_create (
      past_node_binary_create (past_gt,
        past_node_binary_create (past_mod, 
          past_node_binary_create (past_sub,
            past_node_binary_create (past_add,
              past_clone (old_test->rhs), 
              past_node_value_create_from_int (1)),
            past_clone (old_init->rhs)),
          past_node_value_create_from_int (uf)),
        past_node_value_create_from_int (0)),
      past_node_value_create_from_int (1),
      past_node_value_create_from_int (0));
    
    new_test_rhs = past_node_binary_create (past_sub,
      past_node_binary_create (past_div, 
        past_node_binary_create (past_sub,
          past_node_binary_create (past_add,
            past_clone (old_test->rhs), 
            past_node_value_create_from_int (1)),
          past_clone (old_init->rhs)),
        past_node_value_create_from_int (uf)),
      modexpr);
  }

  new_test = past_node_binary_create (past_leq, 
    past_clone (old_test->lhs), new_test_rhs);

  #if 0
  printf ("Old loop test : ");
  past_pprint (stdout, pf->test);
  printf ("\n");
  printf ("New loop test : ");
  past_pprint (stdout, new_test);
  printf ("\n");
  #endif


  s_past_node_t * tmp = pf->test;
  past_replace_node (pf->test, new_test);
  past_set_parent (pf->test);
  past_deep_free (tmp);
}

static
s_past_node_t * 
punroll_build_new_iterator_expr (s_symbol_t * iter, int uf, int uid)
{
  s_past_node_t * ret;
  s_past_node_t * scale;
  int pp = 0;
  int temp_uf = uf;
  while (temp_uf > 1) { 
    temp_uf = temp_uf >> 1; 
    pp++;
  }
  //scale = past_node_binary_create (past_mul,
  //  past_node_value_create_from_int (uf), past_node_varref_create (iter));

  // Using bit shift instead of MUL for scaling
  scale = past_node_binary_create (past_lshift,
    past_node_varref_create (iter),
    past_node_value_create_from_int (pp));
  ret = past_node_binary_create (past_add, scale,
    past_node_value_create_from_int (uid));
  return ret;
}

// Unrolling info structures

struct s_unroll_objective
{
  int val;
  int reuse;
  int influence;
};

typedef struct s_unroll_objective  s_unroll_objective_t;


typedef struct ast_node ast_node_t;

struct ast_node
{
  ast_node_t * parent;
  ast_node_t * child[10];
  s_past_node_t * pnode;
  int n_child;
  int iterator_id;
  int depth;
  int cost;
  int is_root;
  int is_leaf;
  int is_inner;
  int is_parallel;
  int depends_outer;
  int impacts_write;
  int has_outer_par;
  int allow_outer_unroll;
  int UF;
  //int opt_val;
  //int opt_reuse;
  int * opt_UF;
  s_unroll_objective_t opt_val;
  int * II; // influence (resource cost of an iterator)
  int * RR; // reuse 
  int * WI; // write iters
  int * DS; // Triangular loop info
  int limit;
  char id;
};

struct ast
{
  ast_node_t ** nodes;
  ast_node_t ** stmts;
  ast_node_t ** loops;
  ast_node_t ** roots;
  ast_node_t ** inner;
  // pointers to past nodes
  s_past_node_t ** pnodes;
  s_past_node_t ** ploops;
  s_past_node_t ** pstmts;
  int n_nodes;
  int opt_UF[10];
  int opt_val;
  int opt_reuse;
  int n_stmt;
  int n_loops;
  int n_inner;
  int n_roots;
  int ** adjmat;
  int **WS;
  int limit;
};


static char glob_id = 'a';

typedef struct ast ast_t;

struct s_unroll_info 
{
  int ** influence; // allocated externally; influence per statement
  int ** reuse    ; // allocated externally; vector reuse per statement
  int ** witers   ; // set of write iterators for each statement
  int ** domshape ; // domain shape info
  //int * II; // Influence: factor of registers added by unrolling dimension i
  //int * RR; // Reuse: weight of outer loop iterators to induce vector reuse
  //int * WI; // Writer-Iters: set of write iterators
  int ** space;
  int *** pirw; // polynomial iterator reference weight
  int reg_bound;
  int current_level;
  int max_depth;
  int n_levels;      // maximum number of levels to explore (e.g. 3 for gemm)
  int * stack;       // values to evaluate
  int optimal_value; // product of values in optimal_stack
  int * optimal_stack;
  int optimal_usage; // \sum II[ii] * optimal_stack[ii] <= reg_bound
  int optimal_reuse; // \sum RR[ii] * optimal_stack[ii]
  int outer_par_dim;
  int is_inner_parallel;
  int max_unroll_per_level; // e.g. 32 a single dimension
  int max_factors;
  int allow_outer_unroll; // comes from ponos/chunked
  ast_t * ast;
};



ast_node_t * alloc_node (
  ast_node_t * parent,
  ast_node_t * next)
{
  ast_node_t * ret = malloc (sizeof(ast_node_t));
  ret->n_child = 0;
  ret->iterator_id = -1;
  ret->is_leaf = 0;
  ret->is_root = 0;
  ret->is_inner = 0;
  ret->is_parallel = 0;
  ret->depends_outer = 1;
  //ret->opt_val = 0;
  //ret->opt_reuse = 0;
  ret->opt_UF = NULL;
  ret->UF = 1;
  ret->depth = 0;
  ret->id = glob_id++;
  ret->parent = parent;
  return ret;
}

/*
 * Visit and print the contents of the ast in depth-first
 * preorder fashion.
 */
static
void dfs_print (ast_node_t * node)
{
  int ii;
  printf ("%c (%d) : ",node->id, node->depth);
  if (node->n_child <= 0)
  {
    printf ("\n");
    return;
  }
  for (ii = 0; ii < node->n_child; ii++)
  {
    assert (node->child[ii] && "Found NULL pointer in child");
    node->child[ii]->depth = node->depth + 1;
    if (ii > 0)
      printf (", ");
    printf ("%c (%d)", node->child[ii]->id, node->child[ii]->depth);
  }
  printf ("\n");
  for (ii = 0; ii < node->n_child; ii++)
  {
    dfs_print (node->child[ii]);
  }
}

static
void print_tree (ast_t * ast)
{
  int ii;
  printf ("Nbr. roots in forest: %d\n",ast->n_roots);
  for (ii = 0; ii < ast->n_roots; ii++)
  {
    ast->nodes[ii]->depth = 0;
    printf ("Tree root %c\n",ast->roots[ii]->id);
    dfs_print (ast->roots[ii]);
  }
  printf ("Nbr. nodes in forest: %d\n",ast->n_nodes);
  for (ii = 0; ii < ast->n_nodes; ii++)
  {
    ast_node_t * curr = ast->nodes[ii];
    //if (!curr->is_root)
    //  printf ("Node %c (parent = %c)\n",curr->id, curr->parent->id);
    printf ("Node %c", curr->id);
    printf ("(depth=%d,root=%d,inner=%d,leaf=%d,depouter=%d)\n",
      curr->depth, curr->is_root, curr->is_inner, curr->is_leaf, curr->depends_outer);
  }
  printf ("Statements in tree (%d) : ", ast->n_stmt);
  for (ii = 0; ii < ast->n_stmt; ii++)
  {
    if (ii > 0) printf (", ");
    printf ("%c",ast->stmts[ii]->id);
  }
  printf ("\n");
  /*
  for (ii = 0; ii < ast->n_nodes; ii++)
    if (!ast->nodes[ii]->is_leaf)
  {
    if (ii > 0) printf (", ");
    printf ("%c (%d)",ast->nodes[ii]->id, ast->nodes[ii]->UF);
  }
  */
  printf ("Unrolling factors \n");
  int jj;
  for (jj = 0; jj < ast->n_roots; jj++)
  {
    printf ("UFs for tree %d: ",jj);
    for (ii = 0; ast->roots[jj]->opt_UF[ii]; ii++)
      printf ("%d ",ast->roots[jj]->opt_UF[ii]);
    printf ("\n");
  }
  printf ("\n");
}



typedef struct s_unroll_info s_unroll_info_t;

static
void dealloc_tree (ast_t * forest)
{
  int ii;
  for (ii = 0; ii < forest->n_nodes; ii++)
  {
    ast_node_t * node;
    node = forest->nodes[ii];
    //if (node->is_leaf)
    //  free (node->W);
    if (node->is_root)
      free (node->opt_UF);
    if (node->is_inner)
    {
      free (node->II);
      free (node->RR);
      free (node->WI);
      free (node->DS);
    }
    free (node);
  }

  free(forest->nodes);
  free(forest->stmts);
  free(forest->loops);
  free(forest->roots);
  XFREE(forest->pnodes);
  XFREE(forest->ploops);
  XFREE(forest->pstmts);
  XFREE(forest->adjmat);
  free (forest);
}

static
int has_simple_bounds (ast_t * ast, ast_node_t * node)
{
  int ret = 1;
  ast_node_t * curr;
  assert (node);
  assert (node->pnode);
  PAST_DECLARE_TYPED (for, pf, node->pnode);
  PAST_DECLARE_TYPED (binary, for_init, pf->init);
  PAST_DECLARE_TYPED (binary, for_test, pf->test);
  printf ("Showing init and test of loop: \n");
  past_pprint (stdout, for_init);
  printf ("\n");
  past_pprint (stdout, for_test);
  printf ("\n");
  s_symbol_t ** initsyms;
  s_symbol_t ** testsyms;
  initsyms = past_collect_read_symbols (for_init->rhs);
  testsyms = past_collect_read_symbols (for_test->rhs);
  for (curr = node->parent; curr; curr = curr->parent)
  {
    PAST_DECLARE_TYPED (for, opf, curr->pnode);
    int ii;
    for (ii = 0; initsyms && initsyms[ii]; ii++)
      if (symbol_equal (opf->iterator, initsyms[ii]))
      {
        ret = 0;
        curr->depends_outer = 1;
      }
    for (ii = 0; testsyms && testsyms[ii]; ii++)
      if (symbol_equal (opf->iterator, testsyms[ii]))
      {
        ret = 0;
        curr->depends_outer = 1;
      }
  }
  XFREE (initsyms);
  XFREE (testsyms);
  return ret;
}

static
ast_t * 
build_tree_from_adjacency_matrix (int ** adjmat, int n, int L)
{
  int i,j;
  // Allocate storage for AST structure
  ast_t * ast = XMALLOC (ast_t, 1);
  // Allocate storage for utility arrays
  ast->nodes = XMALLOC (ast_node_t*, n);
  ast->stmts = XMALLOC (ast_node_t*, n);
  ast->loops = XMALLOC (ast_node_t*, n);
  ast->roots = XMALLOC (ast_node_t*, n);
  ast->inner = XMALLOC (ast_node_t*, n);
  for (i = 0; i < n; i++) 
    ast->nodes[i] = alloc_node (NULL,NULL);
  // Assign parent and children pointers
  printf ("Establishing node connections\n");
  for (i = 0; i < n; i++)
  {
    int c = 0;
    for (j = 0; j < n; j++)
      if (adjmat[i][j])
      {
        ast->nodes[i]->child[c++] = ast->nodes[j];
        //ast->nodes[i]->is_leaf = 0;
        ast->nodes[j]->parent = ast->nodes[i];
      }
    ast->nodes[i]->n_child = c;
  }
  printf ("Detecting root nodes\n");
  // Detect the root nodes
  int nR = 0;
  for (j = 0; j < n; j++)
  {
    int has_parent = 0;
    for (i = 0; i < n; i++)
      if (adjmat[i][j])
        has_parent = 1;
    if (!has_parent)
    {
      ast->roots[nR++] = ast->nodes[j];
      ast->nodes[j]->is_root = 1;
      ast->nodes[j]->parent = NULL;
      ast->nodes[j]->opt_UF = malloc (sizeof(int) * n);
      ast->nodes[j]->opt_val.val = 0;
      ast->nodes[j]->opt_val.reuse = 0;
      ast->nodes[j]->opt_val.influence = 0;
      int ii;
      for (ii = 0; ii < n; ii++)
        ast->nodes[j]->opt_UF[ii] = 1;
      ast->nodes[j]->limit = L;
    }
  }
  ast->n_roots = nR;
  printf ("Finding statement nodes and marking them...\n");
  // Detect the statement nodes
  int nS = 0;
  for (i = 0; i < n; i++)
  {
    int has_children = 0;
    for (j = 0; j < n; j++)
      if (adjmat[i][j])
        has_children = 1;
    if (!has_children)
    {
      ast->stmts[nS++] = ast->nodes[i];
      ast->nodes[i]->is_leaf = 1;
    }
  }
  ast->n_stmt = nS;
  printf ("Detecting inner loop nodes...\n");
  // Try to add the parent loop of every statement to 
  // the set of innermost loops (regardless of their dimensionality).
  // Before adding it, we check if we already have stored it.
  int n_inner = 0;
  for (i = 0; i < n; i++)
    ast->inner[i] = NULL;
  for (i = 0; i < ast->n_stmt; i++)
  {
    int found = 0;
    ast_node_t * iloop = ast->stmts[i]->parent;
    if (!iloop)
      continue;
    // Skip the loop if we have already added it
    for (j = 0; j < n_inner && ast->inner[j] != NULL; j++)
      if (ast->inner[j] == iloop)
      {
        found = 1;
        break;
      }
    // j point to the end of the array if the loop is not repeated
    // otherwise found == 1
    int idx = j; 
    // check if the loop has children which are loops, if so, skip
    int has_loops = 0;
    for (j = 0; j < iloop->n_child; j++)
      if (!iloop->child[j]->is_leaf)
        has_loops = 1;
    if (!found && !has_loops)
    {
      //printf ("Adding loop %c to inner loop set\n",iloop->id);
      ast->inner[idx] = iloop;
      iloop->is_inner = 1;
      n_inner ++;
    }
  }
  //printf ("Done collecting info of inner loops (%d)\n",n_inner);

  // Create influence and reuse arrays in inner loop nodes
  for (i = 0; i < n_inner; i++)
  {
    #ifdef DEBUG_CHUNKED_UNROLL
    printf ("Innitializing inner loop %d structures\n",i);
    #endif
    ast->inner[i]->II = XMALLOC (int, n);
    ast->inner[i]->RR = XMALLOC (int, n);
    ast->inner[i]->WI = XMALLOC (int, n);  
    ast->inner[i]->DS = XMALLOC (int, n);
    int j;
    for (j = 0; j < n; j++)
    {
      ast->inner[i]->II[j] = 0;
      ast->inner[i]->RR[j] = 0;
      ast->inner[i]->WI[j] = 0;
      ast->inner[i]->DS[j] = 0;
    }
  }
  ast->n_inner = n_inner;
  ast->limit = L;
  ast->n_nodes = n;

  //ast->WS = W1;
  return ast;
}

static
ast_t * 
build_ast_from_past (
  scoplib_scop_p scop, s_past_node_t * root, s_unroll_info_t * UI)
{
  s_past_node_t ** loops;
  s_past_node_t ** stmts;
  loops = past_collect_nodetype (root, past_for);
  stmts = past_collect_nodetype (root, past_cloogstmt);
  int nn = 0;
  int ii;
  int jj;
  int pp;
  for (ii = 0; loops && loops[ii]; ii++) nn++;
  printf ("Found %d loops in scop\n",nn);
  int temp = nn;
  for (ii = 0; stmts && stmts[ii]; ii++) nn++;
  printf ("Found %d statements in scop\n",nn-temp);
  s_past_node_t ** pnodes;
  pnodes = XMALLOC (s_past_node_t*, nn+1);
  for (ii = 0, pp = 0; loops && loops[ii]; ii++) 
    pnodes[pp++] = loops[ii];
  for (ii = 0; stmts && stmts[ii]; ii++)
    pnodes[pp++] = stmts[ii];
  pnodes[pp] = NULL; 
  // Build an adjacency matrix from the PAST root
  int ** adjmat;
  adjmat = XMALLOC (int*, nn);
  for (ii = 0; ii < nn; ii++)
    adjmat[ii] = XMALLOC (int, nn);
  for (ii = 0; ii < nn; ii++)
    for (jj = 0; jj < nn; jj++)
      adjmat[ii][jj] = 0;
  printf ("Number of past nodes: %d\n", nn);
  for (ii = 0; ii < nn; ii++)
  {
    for (jj = 0; jj < nn; jj++)
    {
      if (ii == jj)
        continue;
      s_past_node_t * curr; 
      //printf ("Testing connectivity (%d <-> %d)\n",ii,jj);
      for ( curr = pnodes[jj]->parent; 
            !past_node_is_a (curr,past_for) && curr != root; 
            curr = curr->parent);
      if (curr == pnodes[ii])
      {
        adjmat[ii][jj] = 1;
      }
    }
  }
  // show the adjacency matrix
  printf ("Adjacency matrix build from PAST: \n");
  for (ii = 0; ii < nn; ii++)
  {
    for (jj = 0; jj < nn; jj++)
      printf ("%d ",adjmat[ii][jj]);
    printf ("\n");
  }
  printf ("\n");

  // Build simplified AST from adjmat
  ast_t * ast;
  ast = build_tree_from_adjacency_matrix (adjmat, nn, UI->reg_bound);
  ast->adjmat = adjmat;
  ast->ploops = loops;
  ast->pstmts = stmts;
  ast->pnodes = pnodes;

  // keep a copy of the past node pointer on each ast node
  // The nodes field in each ast node is defined by 
  // build_tree_from_adjacency_matrix
  for (ii = 0; ii < nn; ii++)
  {
    ast->nodes[ii]->pnode = ast->pnodes[ii];
    ast->nodes[ii]->allow_outer_unroll = UI->allow_outer_unroll;
  }

  // Mark parallel loops too
  // ast nodes are initialized to 0 for the field is_parallel
  for (ii = 0; ii < ast->n_nodes; ii++)
    if (!ast->nodes[ii]->is_leaf && 
        past_node_is_a (ast->pnodes[ii], past_parfor))
      ast->nodes[ii]->is_parallel = 1;

  // check if each loop depends of any outer loop
  for (ii = 0; ii < ast->n_nodes; ii++)
    if (!ast->nodes[ii]->is_leaf) // is a loop
  {
    ast->nodes[ii]->depends_outer = !has_simple_bounds (ast, ast->nodes[ii]);
  }

  // Mark loops which affect the write reference
  for (ii = 0; ii < ast->n_nodes; ii++)
    if (ast->nodes[ii]->is_leaf) // is a statement
  {
    ast_node_t * curr, * par_curr;
    for (curr = ast->nodes[ii]->parent; curr; curr = curr->parent)
    {
      int has = 0;
      for (par_curr = curr->parent; par_curr; par_curr = par_curr->parent)
        if (par_curr->is_parallel)
        {
          has = 1;
        }
      curr->has_outer_par = has;
    }
  }


  return ast;
}
  

static 
s_unroll_info_t * 
punroll_alloc_info_structure (int ** influence, int ** reuse, int ** witers, 
  int ** domshape,
  int reg_bound, int max_levels, int max_unroll_per_dim)
{
  assert (influence);
  assert (reuse);
  assert (witers);
  assert (domshape);
  s_unroll_info_t * info;
  info = XMALLOC (s_unroll_info_t, 1);
  info->influence = influence;
  info->reuse = reuse;
  info->witers = witers;
  info->domshape = domshape;
  info->reg_bound = reg_bound;
  info->max_depth = max_levels;
  info->stack = XMALLOC (int, max_levels);
  info->optimal_stack = XMALLOC (int, max_levels);
  //info->II = XMALLOC(int, max_levels);
  //info->RR = XMALLOC(int, max_levels);
  //info->WI = XMALLOC(int, max_levels);
  info->max_unroll_per_level = max_unroll_per_dim;
  info->space = XMALLOC(int*,max_levels + 2);
  int n = 0;
  while ((1 << n) < max_unroll_per_dim) n++;
  n = n - 1;
  int ii;
  for (ii = 0; ii < max_levels; ii++)
    info->space[ii] = XMALLOC (int, n + 2);
  info->space[ii] = NULL;
  info->max_factors = n + 1;
  return info;
}

static
void punroll_free_info_structure (s_unroll_info_t * info)
{
  XFREE (info->stack);
  XFREE (info->optimal_stack);
  //XFREE (info->II);
  //XFREE (info->RR);
  //XFREE (info->WI);
  int max_levels = info->n_levels;
  int ii;
  for (ii = 0; ii < max_levels; ii++)
    XFREE (info->space[ii]);
  int jj,kk;
  for (ii = 0; info->pirw && info->pirw[ii]; ii++)
  {
    for (jj = 0; info->pirw[ii][jj]; jj++)
      XFREE (info->pirw[ii][jj]);
    XFREE (info->pirw[ii]);
  }
  XFREE (info->pirw);
  XFREE (info->space);
}

static
void punroll_check_init_info_structure (s_unroll_info_t * info)
{
  assert (info);
  //assert (info->II);
  //assert (info->RR);
  //assert (info->WI);
  assert (info->stack);
  assert (info->optimal_stack);
  assert (info->space);
  assert (info->influence);
  assert (info->domshape);
  assert (info->reuse);
}

static
void punroll_reset_info_structure (s_unroll_info_t * info, 
  int outer_par_dim, int is_inner_parallel, int depth)
{
  assert (info);
  printf ("Setting depth to %d\n",depth);
  info->n_levels = depth;
  info->current_level = 0;
  info->optimal_value = 0;
  info->optimal_usage = 100000;
  info->optimal_reuse = 0;
  info->is_inner_parallel = is_inner_parallel;
  info->outer_par_dim = outer_par_dim;
}

static
void punroll_generate_space (s_unroll_info_t * info)
{
  int ii,jj;
  punroll_check_init_info_structure (info);
  for (ii = 0; ii < info->n_levels; ii++)
  {
    int factor = 1;
    //if (ii == outer_par_dim || (ii == info->n_levels - 1 && info->is_inner_parallel))
    if ((ii == info->n_levels - 1 && info->is_inner_parallel))
    {
      info->space[ii][0] = 1;
      info->space[ii][1] = -1;
    }
    else
    {
      for (jj = 0; factor << jj <= info->max_unroll_per_level; jj++)
        info->space[ii][jj] = (factor << jj);
      info->space[ii][jj] = -1;
    }
  }
}

static
void show_space (s_unroll_info_t *info)
{
  int ii,jj;
  printf ("showing exploration space\n");
  for (ii = 0; ii < info->n_levels; ii++)
  {
    for (jj = 0; info->space[ii][jj] != -1; jj++)
      printf ("%d ",info->space[ii][jj]);
    printf ("\n");
  }
}

#if 0
static
void 
punroll_compute_optimal_unroll_factors (s_unroll_info_t * info, int current_level)
{
  if (current_level == 0)
  {
    assert (info->optimal_value == 0 && 
      "Need to invoke punroll_reset_info_structure before computing optimal value.");
  }
  int ii;
  punroll_check_init_info_structure (info);
  if (current_level == info->n_levels)
  {
    int opt_val = 1;
    int usage = 0;
    int reuse = 0;
    for (ii = 0; ii < info->n_levels; ii++)
    {
      opt_val *= info->stack[ii];
      usage += info->stack[ii] * info->II[ii];
      reuse += info->stack[ii] * info->RR[ii];
    }
    if (opt_val > info->optimal_value && usage <= info->reg_bound &&
        reuse > info->optimal_reuse)
    {
      printf ("Updating optimal value: %d (%d <= %d) (%d > %d)\n",
        opt_val, usage, info->reg_bound, reuse, info->optimal_reuse);
      info->optimal_value = opt_val;
      info->optimal_reuse = reuse;
      info->optimal_usage = usage;
      for (ii = 0; ii < info->n_levels; ii++)
        info->optimal_stack[ii] = info->stack[ii];
    }
    return;
  }
  for (ii = 0; info->space[current_level][ii] != -1; ii++)
  {
    //printf ("At level %d, option %d\n",current_level, ii);
    info->stack[current_level] = info->space[current_level][ii];
    punroll_compute_optimal_unroll_factors (info, current_level + 1);
  }
}
#endif

static
void load_unroll_factors (s_unroll_info_t * info, int *uf)
{
  int ii;
  for (ii = 0; ii < info->n_levels; ii++)
    uf[ii] = info->optimal_stack[ii];
  uf[ii] = -1;
}

static
s_past_node_t * 
punroll_replicate_statements_in_block (s_past_node_t * node, int * ufs)
{
  assert (past_node_is_a (node, past_block));
  int nuf;
  int ii;
  for (ii = 0; ufs && ufs[ii] != -1 && ii < 10; ii++);
  assert (ii < 10 && "Did not expect a scop with 10 or more dimensions");
  assert (ufs[ii] == -1 && "Array of unroll factors must be -1 terminated");
  nuf = ii;
  assert (past_node_is_a (node, past_block));
  PAST_DECLARE_TYPED (block, pb, node);
  s_past_node_t * stmts = pb->body;
  /*
  for ( ; !past_node_is_a (stmts,past_statement); )
  {
    if (past_node_is_a (stmts, past_block))
    {
      PAST_DECLARE_TYPED (block, pb, stmts);
      stmts = pb->body;
    }
  }
  */
  int max_depth = past_loop_depth (stmts); 
  s_past_node_t * outer[max_depth+1];
  s_past_node_t * curr;
  int depth;
  #ifdef DEBUG_CHUNKED_UNROLL
  printf ("Max depth is %d\n",max_depth);
  #endif
  for (curr = stmts, depth = max_depth; depth > 0; curr = curr->parent)
  {
    if (past_node_is_a (curr, past_for))
    {
      PAST_DECLARE_TYPED (for, pf, curr);
      #ifdef DEBUG_CHUNKED_UNROLL
      printf ("Iterator at level %d: ", depth); past_pprint (stdout, pf->init); printf ("\n");
      #endif
      outer[depth-1] = curr;
      depth--;
    }
  }
  s_past_node_t * chain_start = stmts;
  s_past_node_t * chain_end = stmts;
  // Find the end of the statement chain
  for (chain_end = stmts;
       chain_end->next; 
       chain_end = chain_end->next)
    ;
  // Proceed to unroll and jam
  for (ii = 0; ufs && ufs[ii] != -1; ii++)
  {
    int UUFF = ufs[ii];
    if (ufs[ii] <= 1)
      continue;
    int loop_depth = past_loop_depth (stmts);
    if (ii >= loop_depth)
      break;
    #ifdef DEBUG_CHUNKED_UNROLL
    printf ("Performing unrolling at level %d\n",ii);
    past_pprint (stdout, chain_start);
    printf ("\n");
    #endif
    int rr;
    // Skip the test update (by scaling) if it already has been
    // updated by the unrolling of a previos inner loop.
    s_past_node_t * chains[UUFF+1];
    s_past_node_t ** has_div = past_collect_nodetype (outer[ii], past_div);
    if (has_div && !has_div[0])
    {
      punroll_update_test_by_scale (outer[ii], UUFF);
    }
    if (has_div)
    {
      XFREE (has_div);
    }
    PAST_DECLARE_TYPED (for, pf, outer[ii]);
    for (rr = 0; rr < ufs[ii]; rr++)
    {
      chains[rr] = past_clone (chain_start);
      #ifdef DEBUG_CHUNKED_UNROLL
      printf ("cloned chain ...\n");
      past_pprint (stdout, chains[rr]);
      #endif
      s_past_node_t * new_iter_expr = punroll_build_new_iterator_expr (
        pf->iterator, UUFF, rr);

      #ifdef DEBUG_CHUNKED_UNROLL
      printf ("built expression (%d,%d): ",UUFF, rr); 
      past_pprint (stdout,new_iter_expr); printf ("\n");
      #endif

      s_past_node_t * tmp;
      for (tmp = chains[rr]; tmp; tmp = tmp->next)
      {
        s_past_node_t ** iters;
        iters = past_collect_nodetype (tmp, past_varref);
        int kk;
        for (kk = 0; iters && iters[kk]; kk++)
        {
          PAST_DECLARE_TYPED(varref, pv, iters[kk]);
          if (symbol_equal (pv->symbol, pf->iterator))
          {
            past_replace_node (iters[kk], past_clone (new_iter_expr));
          }
        }
        XFREE (iters);
      }
      XFREE (new_iter_expr);
    }
    printf ("Linking chains\n");
    if (chain_start != stmts)
      past_deep_free (chain_start);

    chain_start = chains[0];
    for (rr = 0, chain_end = chain_start; rr < UUFF-1; rr++)
    {
      for ( ; chain_end->next; chain_end = chain_end->next);
      chain_end->next = chains[rr+1];
    }
    for ( ; chain_end->next; chain_end = chain_end->next);
    chain_end->next = NULL;
    #ifdef DEBUG_CHUNKED_UNROLL
    printf ("Replicated statement chain: \n");
    past_pprint (stdout, chain_start);
    #endif
  }
  assert (chain_start);
  #ifdef DEBUG_CHUNKED_UNROLL
  printf ("Final Replicated statement chain: \n");
  past_pprint (stdout, chain_start);
  #endif
  //past_replace_node (stmts, past_block_create (chain_start));
  //past_set_parent (node);
  return past_node_block_create (chain_start);
}

#if 0
/*
 * Given a 2D-matrix WW, we sum all the values of each column.
 * Rows of WW are associated to iterator weights of each statement.
 */
static
void
compute_weights (s_unroll_info_t * info, int ** WW, int * weights, 
  s_past_node_t * stmts)
{
  s_past_node_t * ss;
  assert (past_node_is_a (stmts, past_cloogstmt) &&
    "Function collapse_weights expects a chained list of cloogstmt type");
  assert (WW);
  assert (weights);
  int ii;
  for (ii = 0; ii < info->max_factors; ii++)
    weights[ii] = 0;
  for (ss = stmts; ss; ss = ss->next)
  {
    PAST_DECLARE_TYPED (cloogstmt, cstmt, ss);
    int stmt_id = cstmt->stmt_number - 1;
    //printf ("Collapsing statement %d\n", stmt_id);
    for (ii = 0; WW[stmt_id][ii] != -1; ii++)
      weights[ii] += WW[stmt_id][ii];
    weights[ii] = -1;
  }
  printf ("weights: ");
  for (ii = 0; weights[ii] != -1; ii++)
    printf ("%d ",weights[ii]);
  printf ("\n");
}

/*
 * Given an outer loop and inner loop, compute the weights
 * associated to each iterator. Store values of the Influence
 * vector (II) and Reuse vector (RR) in the info structure.
 */
static
int 
punroll_compute_loop_weights (s_unroll_info_t * info,
  s_past_node_t * outer_loop, s_past_node_t * inner_loop)
{
  assert (past_node_is_a (outer_loop, past_for));
  assert (past_node_is_a (inner_loop, past_for));
  // Find the maximum depth of the loop nest
  s_past_node_t * tmp;
  int max_depth = 0;
  for (tmp = inner_loop; tmp != outer_loop->parent; tmp = tmp->parent)
    if (past_node_is_a (tmp, past_for))
      max_depth++;
  printf ("Maximum depth detected in loop nest: %d\n", max_depth);
  int ii;
  // Find the outermost parallel level ... why???
  int dd;
  int par_level = -1;
  for (tmp = inner_loop, dd = max_depth - 1; 
    tmp != outer_loop->parent; tmp = tmp->parent)
  {
    if (tmp != inner_loop && past_node_is_a (tmp, past_parfor))
      par_level = dd;
  }
  // Fetch the list of statements in the innermost loop
  PAST_DECLARE_TYPED (for, pfi, inner_loop);
  s_past_node_t * stmtlist = pfi->body;
  if (past_node_is_a (stmtlist, past_block))
  {
    PAST_DECLARE_TYPED (block, pb, stmtlist);
    stmtlist = pb->body;
  }
  info->outer_par_dim = par_level;
  // For each iterator, sum all the influence and reuse values 
  // across all statements in the innermost loop
  compute_weights (info, info->influence, info->II, stmtlist);
  compute_weights (info, info->reuse, info->RR, stmtlist);
  compute_weights (info, info->witers, info->WI, stmtlist);
  return max_depth;
}
#endif


/*
 * Compute a number of metrics for each statement.
 * These are later aggregated per inner loop depending on the final
 * structure of the AST.
 * The metrics that we consider are influence (all iterators used),
 * reuse (iterators on the FVD of arrays), witers (iterators that
 * appear on the write reference) and domshape (iterators which depend
 * on each other).
 */
static
int compute_iterator_weights (scoplib_statement_p stmt, 
  int *** influence, int *** reuse, int *** witers, int *** domshape)
{
  scoplib_statement_p tmp;
  int n_iter = 0;
  int n_stmt = 0;
  for (tmp = stmt; tmp; tmp = tmp->next, n_stmt++)
    n_iter = n_iter >= tmp->nb_iterators ? n_iter : tmp->nb_iterators;

  int ii;
  (*influence) = XMALLOC (int *, n_stmt + 1);
  (*reuse) = XMALLOC (int *, n_stmt + 1);
  (*witers) = XMALLOC (int *, n_stmt + 1);
  (*domshape) = XMALLOC (int *, n_stmt + 1);
  for (ii = 0; ii < n_stmt; ii++)
  {
    (*influence)[ii] = XMALLOC (int, n_iter + 1);
    (*reuse)[ii] = XMALLOC (int, n_iter + 1);
    (*witers)[ii] = XMALLOC (int, n_iter + 1);
    (*domshape)[ii] = XMALLOC (int, n_iter + 1);
    int jj;
    for (jj = 0; jj < n_iter; jj++)
    {
      (*influence)[ii][jj] = 0;
      (*reuse)[ii][jj] = 0;
      (*witers)[ii][jj] = 0;
      (*domshape)[ii][jj] = 0;
    }
    (*influence)[ii][jj] = -1;
    (*reuse)[ii][jj] = -1;
    (*witers)[ii][jj] = -1;
    (*domshape)[ii][jj] = -1;
  }
  (*influence)[ii] = NULL;
  (*reuse)[ii] = NULL;
  (*witers)[ii] = NULL;
  (*domshape)[ii] = NULL;

  int sched[n_iter][n_iter];

  // Compute the influence, reuse, witers and domshape metrics.
  // influence: number of times that an iterator is used in a statement
  // reuse: number of times that an iterator appears in the FVD of the refs
  // witers: iterators that appear in the write ref 
  // domshape: boolean array that indicates if dimensions depend on each other;
  //   unlike the previous metrics, this one collects its info from the 
  //   iteration domain
  for (tmp = stmt, ii = 0; tmp; tmp = tmp->next, ii++)
  {
    int local_n_iter = tmp->nb_iterators;
    int n_row;
    int row;
    scoplib_matrix_p mat;
    
    // check for triangular type domain
    // if 2 iterators are used in the same constraint, then we mark them
    mat = tmp->domain->elt;
    n_row = mat->NbRows;
    for (row = 0; row < n_row; row++)
    {
      int col;
      int iter_used = 0;
      int used[local_n_iter];
      for (col = 0; col < local_n_iter; col++)
        used[col] = 0;
      for (col = 1; col <= local_n_iter; col++) // stmt->domain->elt->NbColumns; col++)
        if (SCOPVAL_notzero_p(mat->p[row][col]))
        {
          used[col-1] = 1;
          iter_used ++;
        }
      if (iter_used > 1)
      {
        for (col = 0; col < local_n_iter; col++)
          (*domshape)[ii][col] += used[col];
      }
    }


    mat = tmp->read;
    n_row = mat->NbRows;
    for (row = 0; row < n_row; row++)
    {
      int col;
      for (col = 1; col <= local_n_iter; col++)
      {
        if (SCOPVAL_notzero_p (mat->p[row][col]))
          (*influence)[ii][col-1] ++;
      }
      if ((row+1 < n_row && 
          SCOPVAL_notzero_p (mat->p[row+1][0])) || row+1 == n_row)
      {
        for (col = 1; col <= local_n_iter; col++)
        {
          if (SCOPVAL_notzero_p (mat->p[row][col]))
            (*reuse)[ii][col-1] ++;
        }
      }
    }
    mat = tmp->write;
    n_row = mat->NbRows;

    for (row = 0; row < n_row; row++)
    {
      int col;
      for (col = 1; col <= local_n_iter; col++)
      {
        if (SCOPVAL_notzero_p (mat->p[row][col]))
          (*influence)[ii][col-1] ++;
      }
      if (row == n_row - 1)
      {
        for (col = 1; col <= local_n_iter; col++)
        {
          if (SCOPVAL_notzero_p (mat->p[row][col]))
          {
            (*reuse)[ii][col-1] ++;
            (*witers)[ii][col-1] = 1;
          }
        }
      }
    }
    // Copy the schedule from the scop into a matrix
    int jj,kk;
    for (jj = 0; jj < n_iter; jj++)
    {
      for (kk = 0; kk < n_iter; kk++)
      {
        sched[jj][kk] = SCOPVAL_get_si (tmp->schedule->p[jj*2+1][kk+1]);
      }
    }
    // Check if any two rows are identical.
    // If so, then move up all the subsequent rows
    for (jj = 0; jj + 1 < n_iter; jj++)
    {
      for (kk = jj + 1; kk < n_iter; kk++)
      {
        int same = 1;
        int ll;
        for (ll = 0; ll < n_iter; ll++)
          if (sched[jj][ll] != sched[kk][ll])   
            same = 0;
        if (same)
        {
          int mm;
          for (ll = kk; ll + 1 < n_iter; ll++)
            for (mm = 0; mm < n_iter; mm++)
              sched[ll][mm] = sched[ll+1][mm];
          break;
        }
      }
    }
    printf ("Extracted scheduling matrix\n");
    for (jj = 0; jj < n_iter; jj++)
    {
      for (kk = 0; kk < n_iter; kk++)
        printf ("%d ", sched[jj][kk]);
      printf ("\n");
    }
    int permuted[local_n_iter];
    // Permute all the metrics we have collected


    // permute the domshape vector
    for (jj = 0; jj < local_n_iter; jj++)
    {
      permuted[jj] = 0;
      for (kk = 0; kk < local_n_iter; kk++)
        permuted[jj] += sched[jj][kk] * (*domshape)[ii][kk];
    }
    printf ("Permuted domshape vector (count of all iterators used): ");
    for (jj = 0; jj < local_n_iter; jj++)
    {
      (*domshape)[ii][jj] = permuted[jj];
      printf ("%d ",permuted[jj]);
    }
    printf("\n");

    // permute the influence vector
    for (jj = 0; jj < local_n_iter; jj++)
    {
      permuted[jj] = 0;
      for (kk = 0; kk < local_n_iter; kk++)
        permuted[jj] += sched[jj][kk] * (*influence)[ii][kk];
    }
    printf ("Permuted influence vector (count of all iterators used): ");
    for (jj = 0; jj < local_n_iter; jj++)
    {
      (*influence)[ii][jj] = permuted[jj];
      printf ("%d ",permuted[jj]);
    }
    printf("\n");

    // permute the reuse vector
    for (jj = 0; jj < local_n_iter; jj++)
    {
      permuted[jj] = 0;
      for (kk = 0; kk < local_n_iter; kk++)
        permuted[jj] += sched[jj][kk] * (*reuse)[ii][kk];
    }
    printf ("\n");
    printf ("Permuted reuse vector (iterators appearing in FVD of arrays: ");
    for (jj = 0; jj < local_n_iter; jj++)
    {
      (*reuse)[ii][jj] = permuted[jj];
      //printf ("%d ",permuted[jj]);
    }
    printf ("\n");

    // permute the vector containing the iterators of the write ref
    for (jj = 0; jj < local_n_iter; jj++)
    {
      permuted[jj] = 0;
      for (kk = 0; kk < local_n_iter; kk++)
        permuted[jj] += sched[jj][kk] * (*witers)[ii][kk];
    }
    printf ("\n");
    printf ("Permuted write-iterator vector (iters appearing in write ref: ");
    for (jj = 0; jj < local_n_iter; jj++)
    {
      (*witers)[ii][jj] = permuted[jj];
      //printf ("%d ",permuted[jj]);
    }
    printf ("\n");

  }
  return n_stmt;
}

static
void show_matrix (int ** WW, int nn, const char * msg)
{
  int ii,jj;
  printf ("Showing %s matrix ...\n",(char*)(msg));
  for (ii = 0; WW[ii]; ii++)
  {
    for (jj = 0; WW[ii][jj] != -1; jj++)
      printf ("%d ",WW[ii][jj]);
    printf ("\n");
  }
}


static
void show_unroll_factors (int * uf)
{
  int ii;
  printf ("Optimal unroll factors: ");
  for (ii = 0; uf[ii] != -1; ii++)
    printf ("%d ", uf[ii]);
  printf ("\n");
}

static 
int product (int *uf)
{
  int ii;
  int prod = 1;
  for (ii = 0; uf[ii] != -1; ii++)
    prod *= uf[ii]; 
  return prod;
}


static
s_unroll_objective_t
compute_path_value (ast_node_t * root, ast_node_t * inner, int *** pirw)
{
  ast_node_t * curr;
  int ii;
  s_unroll_objective_t ret;
  ret.val = inner->n_child;
  ret.reuse = 1;
  ret.influence = 0;
  //printf ("Computing values from inner loop %c\n",inner->id);
  int depth = 0;
  for (ii = 0, curr = inner; curr != NULL; curr = curr->parent, ii++);
  depth = ii - 1;
  for (ii = 0; ii < inner->n_child; ii++)
  {
    assert (inner->child[ii] && "Found null past node in ast inner loop");
    PAST_DECLARE_TYPED (cloogstmt, cstmt, inner->child[ii]->pnode);
    int stmt_id = cstmt->stmt_number - 1;
    //printf ("Adding contributions of statement %d\n",stmt_id);
    int rr;
    for (rr = 0; pirw && pirw[stmt_id] && pirw[stmt_id][rr]; rr++)
    {
      int inf_factor = 1;
      int it;
      for (it = 0, curr = inner; curr != NULL; curr = curr->parent, it++)
        if (pirw[stmt_id][rr][depth - it] == 1) // && it != 0)
          inf_factor *= curr->UF;
      ret.influence += inf_factor;
      //ret.reuse += inf_factor * inner->RR[depth -
    }
  }
  for (ii = 0, curr = inner; curr != NULL; curr = curr->parent, ii++)
  {
    #ifdef DEBUG_CHUNKED_UNROLL
    printf ("Curr depends outer iter (level %d) = %d\n",ii, curr->depends_outer);
    #endif
    printf ("AOU: %d\n",curr->allow_outer_unroll);
    if (((!curr->has_outer_par && curr->is_parallel && !curr->allow_outer_unroll) ||
        curr->depends_outer ||
        inner->DS[depth - ii]) &&
      curr->UF > 1)
    {
      printf ("level %d] Setting val to zero (outpar=%d,ispar=%d,aou=%d,depouter=%d,DS=%d\n",
        depth - ii, curr->has_outer_par, curr->is_parallel, curr->allow_outer_unroll, curr->depends_outer, inner->DS[depth - ii]);
      ret.val = 0;
    }
    else
      ret.val *= curr->UF;
    assert (curr && "Node must be non-NULL");
    //ret.influence += curr->UF * inner->II[depth - ii];

    #if 0
    if (ii > 0)
      ret.reuse     += 2 * curr->UF * inner->RR[depth - ii];
    else
      ret.reuse     += curr->UF * inner->RR[depth - ii];
    #endif
    //ret.reuse     += (ii + 1) * curr->UF * inner->RR[depth - ii];
    //ret.reuse += (ii + 1) * curr->UF * (inner->RR[depth - ii] - inner->WI[depth - ii]);

    //ret.reuse += -3 * (ii + 1) * curr->UF * (inner->II[depth - ii] - inner->RR[depth - ii]);
    #if 0
    if (ii > 0)
      ret.reuse     -= curr->UF * (inner->II[depth - ii] - inner->RR[depth - ii]);
    else
      ret.reuse     -= curr->UF * (inner->II[depth - ii] - inner->RR[depth - ii]);
    #endif
    //ret.reuse     -= curr->UF * (inner->II[depth - ii] - inner->RR[depth - ii]);

    #if 0
    // Penalize unrolling dimensions that do not have an effect in vector reuse
    if (inner->RR[depth - ii] == 0)
      ret.influence *= curr->UF;
    #endif
    //ret.reuse -= (1 - curr->has_outer_par + curr->is_parallel) * 
    //              curr->UF * (inner->II[depth - ii] - inner->RR[depth - ii]);
    
    //ret.reuse -= (ii + 1) * curr->UF * inner->WI[depth - ii];

    #ifdef DEBUG_CHUNKED_UNROLL
    if (ii == 1)
    {
      printf ("Has outer parallel = %d, is dim parallel = %d, reuse = %d, WI = %d\n",
        curr->has_outer_par, curr->is_parallel, inner->RR[depth - ii],  inner->WI[depth - ii]);
    }
    #endif

    if (ii > 0)
      ret.reuse += (ii + 1) * curr->UF * (3 * inner->RR[depth - ii] + inner->WI[depth - ii]  
        // + 2 * inner->II[depth - ii]
      ) * (1 - (!curr->has_outer_par && curr->is_parallel && !curr->allow_outer_unroll)) * (!inner->DS[depth - ii]);
    if (ii == 0)
      ret.reuse -= curr->UF * (inner->II[depth - ii] - inner->RR[depth - ii]);
    //if (ii > 0)
    //  ret.reuse -= (ii + 1) * (4 - curr->has_outer_par - curr->is_parallel - inner->WI[depth - ii] - inner->RR[depth - ii]) *  curr->UF;
  }
  //printf ("RESOURCE USAGE: %d\n", ret.influence);
  //for (ii = 0, curr = inner; curr != NULL; curr = curr->parent, ii++)
  //{
  //  printf (" + %d x %d",curr->UF, inner->II[depth - ii]);
  //}
  //printf ("\n");
  if (ret.influence > root->limit || ret.val >= root->limit / 2)
  {
    ret.reuse = -1;
    ret.val = -1;
    ret.influence = -1;
  }

  #if 1 //def DEBUG_CHUNKED_UNROLL
  if (ret.influence <= root->limit)
  {
    printf ("REUSE POTENTIAL: ");
    for (ii = 0, curr = inner; curr != NULL; curr = curr->parent, ii++)
    {
      printf (" + %d x %d",curr->UF, inner->RR[depth - ii]);
    }
    printf ("\n");
    printf ("Partial Unrolling objectives: (%d,%d,%d)\n",
      ret.val, ret.reuse, ret.influence);
  }
  #endif
  return ret;
}

static
s_unroll_objective_t
compute_objective_value (ast_node_t * root, ast_node_t ** tree, int *** pirw)
{
  int ii;
  s_unroll_objective_t obj;
  obj.val = 0;
  obj.reuse = 0;
  obj.influence = 0;
  for (ii = 0; tree && tree[ii]; ii++)
  {
    if (tree[ii]->is_inner)
    {
      s_unroll_objective_t val = compute_path_value (root, tree[ii], pirw);
      if (val.val < 0)
        return val;
      obj.val += val.val;
      obj.reuse += val.reuse;
      obj.influence = val.influence > obj.influence ? val.influence : obj.influence;
    }
  }
  //printf ("Unrolling objectives: (%d,%d,%d)\n",
  //  obj.val, obj.reuse, obj.influence);
  return obj;
}

static 
int is_better (s_unroll_objective_t oldo, s_unroll_objective_t newo)
{
  int c1 = oldo.reuse * oldo.val;
  int c2 = newo.reuse * newo.val;
  if (newo.val < 0)
    return 0;
  //if (newo.reuse >= oldo.reuse && newo.val > oldo.val)
  //  return 1;
  //if (newo.val > oldo.val && newo.reuse > oldo.reuse)

  if (newo.reuse * newo.val > oldo.reuse * oldo.val)
    return 1;;

  //if (newo.reuse > oldo.reuse)
  //  return 1;

  //if (newo.reuse == oldo.reuse && newo.val > oldo.val)
  //  return 1;
  //if (c2 > c1)
  //  return 1;
  return 0;
}

/*
 * Compute the optimal unroll values for all nodes rooted at root.
 * Proceed in a recursive fashion.
 * End of recursion is when we find a NULL entry in the variable tree,
 * which contains all nodes (including leaves) of the tree.
 */
void compute_unroll_factors_tree (ast_node_t * root, 
  ast_node_t ** tree, int tid, s_unroll_info_t * info)
{
  int ii, jj;
  int ufs[5] = {1,2,4,8,16};
  int n_uf = 5;

  if (!tree[tid])
  {
    s_unroll_objective_t new_val = 
      compute_objective_value (root, tree, info->pirw);
    if (is_better (root->opt_val, new_val))
    {
      printf ("Old optimal value: (val=%d,reuse=%d,usage=%d);  ",
        root->opt_val.val, root->opt_val.reuse, root->opt_val.influence);
      printf ("Found new optimal value: (val=%d,reuse=%d,usage=%d) =>",
        new_val.val, new_val.reuse, new_val.influence);
      root->opt_val = new_val;
      int nuf = 0;
      for (ii = 0; tree && tree[ii]; ii++)
        if (!tree[ii]->is_leaf)
          root->opt_UF[nuf++] = tree[ii]->UF;
      root->opt_UF[nuf] = 0;
      int kk;
      for (kk = 0; root->opt_UF[kk]; kk++)
        printf (" %d",root->opt_UF[kk]);
      printf ("\n");
    }
    return;
  }

  int depth = tree[tid]->depth;
  //if (tree[tid]->is_root)
  int is_parallel = tree[tid]->is_parallel;
  int is_inner = tree[tid]->is_inner;

  PAST_DECLARE_TYPED (for, pf, tree[tid]->pnode);
  int is_permutable = (pf->property == e_past_fco_loop);

  // FIXME: why is the property field not set?
  //int nn = is_parallel || is_inner ? 1 : n_uf; //(is_inner && is_parallel ? 1 : n_uf);
  int nn = n_uf;
  if (is_inner && is_parallel)
    nn = 1;

  if (tree[tid]->depends_outer)
    nn = 1;
  //else if (!is_parallel)
    //pf->property == e_past_unset_prop || pf->property == e_past_seq_loop)
    // !is_permutable && !is_parallel)
  //  nn = 1;

  printf ("tid/level = %d, nuf = %d, parallel = %d, depends outer = %d, is inner = %d\n", 
    tid, nn, is_parallel, tree[tid]->depends_outer, is_inner);
  for (jj = 0; jj < nn; jj++)
  {
    tree[tid]->UF = ufs[jj];
    //tree[tid]->UF = info->space[current_level][ii];
    compute_unroll_factors_tree (root, tree, tid+1, info);
  }
}

int is_same_tree (ast_node_t * root, ast_node_t * node)
{
  ast_node_t * curr = node;
  while (curr->parent != NULL)
    curr = curr->parent;
  return curr == root;
}

/*
 * Return a NULL-terminated array of ast nodes that are rooted
 * at the node identified by root.
 */
static
ast_node_t ** collect_nodes_in_tree (ast_t * forest, ast_node_t * root)
{
  int ii;
  ast_node_t ** tree;
  tree = XMALLOC (ast_node_t*, forest->n_nodes + 1);
  int nn = 0;
  int legal = 1;
  for (ii = 0; ii < forest->n_nodes; ii++)
  {
    if (is_same_tree (root, forest->nodes[ii]))
    {
      if (forest->nodes[ii]->is_inner)
      {
        int jj;
        for (jj = 0; jj < forest->nodes[ii]->n_child; jj++)
          if (!forest->nodes[ii]->child[jj]->is_leaf)
            legal = 0;
      }
      tree[nn++] = forest->nodes[ii];
    }
  }
  if (!legal)
  {
    XFREE (tree);
    return NULL;
  }
  tree[nn] = NULL;
  return tree;
}

static
void show_collected_nodes (ast_node_t ** tree)
{
  #ifdef DEBUG_CHUNKED_UNROLL
  int ii;
  printf ("Showing collected nodes\n");
  for (ii = 0; tree && tree[ii]; ii++)
  {
    printf ("Node %c\n", tree[ii]->id);
  }
  printf ("\n");
  #endif
}

static
void copy_optimal_factors_to_ast (ast_node_t * root, ast_node_t ** tree)
{
  int ii;
  for (ii = 0; tree && tree[ii]; ii++)
  {
    tree[ii]->UF = root->opt_UF[ii];
  }
}

static 
int is_statement_unrollable (scoplib_scop_p scop, ast_node_t * mystmt)
{
  int ret = 1;
  assert (mystmt);
  assert (mystmt->pnode);
  PAST_DECLARE_TYPED (cloogstmt, pcstmt, mystmt->pnode);
  int stmt_id = pcstmt->stmt_number - 1;
  scoplib_statement_p stmt;
  int ii;

  printf ("Testing unrollableness of statement : ");
  past_pprint (stdout, mystmt->pnode);

  // Determine the max dimensionality of the scop
  int max_dim = 0;
  for (stmt = scop->statement; stmt; stmt = stmt->next)
    max_dim = (stmt->nb_iterators > max_dim ? stmt->nb_iterators : max_dim);


  // Find the correct scop statement
  for (ii = 0, stmt = scop->statement; 
       ii < stmt_id && stmt; stmt = stmt->next, ii++);
  int n_iter = stmt->nb_iterators;

  printf ("Max dim found = %d, num sched rows = %d\n", max_dim, stmt->schedule->NbRows);

  // Deem the subscop illegal for unrolling if the 2d+1 schedule
  // format wasn't used.
  if (2 * max_dim + 1 != stmt->schedule->NbRows)
    return 0;

  printf ("==> Using 2d+1 schedule representation ...\n");

  // Deem unrollable any statement that consists of more than one domain set
  int dom_parts = 0;
  scoplib_matrix_list_p doms;
  for (doms = stmt->domain; doms; doms = doms->next, dom_parts++);

  if (dom_parts != 1)
    return 0;

  printf ("==> Not using union of polyhedra for iteration domains ...\n");

  int used_rows[max_dim];
  int used_cols[max_dim];
  // Check that every row and column of the domain has exactly one entry
  for (ii = 0; ii < n_iter; ii++)
  {
    used_rows[ii] = 0;
    used_cols[ii] = 0;
  }
  int rr,cc;
  for (rr = 0; rr < stmt->domain->elt->NbRows; rr++)
  {
    for (cc = 1; cc <= n_iter; cc++) // stmt->domain->elt->NbColumns; cc++)
      if (SCOPVAL_notzero_p(stmt->domain->elt->p[rr][cc]))
      {
        used_rows[rr]++;
        used_cols[cc-1]++;
      }
  }
  for (ii = 0; ii < n_iter; ii++)
  {
    //ret = ret && used_rows[ii] == 2;
    printf ("==> Iterator %d is used %d times\n",ii,used_cols[ii]);
    ret = ret && used_cols[ii] == 2;
  }
  //if (!ret)
  //  return 0;

  ret = 1;
  // Check that every row and column of the schedule has exactly one entry
  for (ii = 0; ii < max_dim; ii++)
  {
    used_rows[ii] = 0;
    used_cols[ii] = 0;
  }
  for (rr = 0; rr < stmt->schedule->NbRows; rr++)
  {
    if (rr % 2 != 1)
      continue;
    int nnz = 0;
    for (cc = 1; cc <= max_dim; cc++) //stmt->schedule->NbColumns; cc++)
      if (SCOPVAL_notzero_p(stmt->schedule->p[rr][cc]))
      {
        //used_rows[rr/2]++;
        //used_cols[cc-1]++;
        nnz++;
      }
    used_rows[rr/2] = nnz;
  }
  for (ii = 0; ii < n_iter; ii++)
  {
    ret = ret && used_rows[ii] == 1;
    //ret = ret && used_cols[ii] == 1;
  }
  printf ("==> Schedule is performs skewing : %dn",ret);
  return ret;
}

static
int is_subscop_unrollable (scoplib_scop_p scop, 
  ast_node_t * myroot, ast_node_t ** tree)
{
  int legal = 1;
  int ii;
  for (ii = 0; tree && tree[ii]; ii++)
  {
    if (tree[ii]->is_root)
    {
      s_past_node_t ** guards;
      guards = past_collect_nodetype (tree[ii]->pnode, past_affineguard);
      int jj;
      for (jj = 0; guards && guards[jj]; jj++);
      if (guards && jj > 0)
      {
        legal = 0;
      }
      XFREE (guards);
    }
    if (tree[ii]->is_leaf)
    {
      int stmt_legal = is_statement_unrollable (scop, tree[ii]);
      printf ("==> Legal to unroll: %d\n", stmt_legal);
      legal = legal && stmt_legal;
    }
  }
  return legal;
}

static
void compute_scop_unroll_factors (scoplib_scop_p scop, 
  s_past_node_t * proot, s_unroll_info_t * info)
{
  int ii;
  ast_t * forest = info->ast;
  for (ii = 0; ii < forest->n_roots; ii++)
  {
    ast_node_t * root = forest->roots[ii];
    root->cost = 0;
    printf ("Collecting nodes in forest_%d...\n",ii);
    // collect_nodes_in_tree returns NULL if the subtree is not
    // perfectly nested due to having statements and loops inside
    // potentially inner loops
    ast_node_t ** tree = collect_nodes_in_tree (forest, root);
    if (tree)
    {
      show_collected_nodes (tree);
      //tree[0]->opt_val = 0;
      if (is_subscop_unrollable (scop, root, tree))
      {
        printf ("Scop deemed unrollable...\n");
        compute_unroll_factors_tree (root, tree, 0, info);
        printf ("Done computing unrolling factors\n");
        copy_optimal_factors_to_ast (root, tree);
        XFREE (tree);
      }
      else
        printf ("Scop rooted at %d cannot be unrolled\n",ii);
    }
  }
}

static
s_past_node_t *
get_ith_statement_of_loop (s_unroll_info_t * info,
  int inner_id, int stmt_pos)
{
  s_past_node_t * ret = NULL;
  int ii;
  assert (inner_id < info->ast->n_inner);
  assert (stmt_pos < info->ast->inner[inner_id]->n_child);
  ast_node_t * stmt_node = info->ast->inner[inner_id]->child[stmt_pos];
  for (ii = 0; ii < info->ast->n_nodes; ii++)
    if (info->ast->nodes[ii] == stmt_node)
      break;
  if (ii >= info->ast->n_nodes)
    return NULL;
  return info->ast->pnodes[ii];
}


// Aggregate counters of influence, reuse and witers for each
// inner loop:
// iloop->II[iter] = \sum_{stmt} influence^stmt[iter]
// iloop->RR[iter] = \sum_{stmt} reuse^stmt[iter]
// iloop->WI[iter] = \sum_{stmt} witers^stmt[iter]
// iloop->DS[iter] = \sum_{stmt} domshape^stmt[iter]
static
void attach_info_to_ast (scoplib_scop_p scop, 
  s_past_node_t * proot, s_unroll_info_t * info)
{
  int ii;
  printf ("Attaching info to ast...\n");
  // For each inner loop, accumulate the weights of
  // influence (II) and reuse (RR) across all the statements
  // nested within the loop
  printf ("Number of inner loops: %d\n",info->ast->n_inner);
  for (ii = 0; ii < info->ast->n_inner; ii++)
  {
    ast_node_t * inner = info->ast->inner[ii];
    int jj;
    for (jj = 0; jj < inner->n_child; jj++)
    {
      printf ("Trying to attach info to ast (%d,%d)\n", ii, jj);
      s_past_node_t * pstmt;
      pstmt = get_ith_statement_of_loop (info, ii, jj);
      assert (pstmt && "Cloogstatement not found");
      past_pprint (stdout, pstmt);
      PAST_DECLARE_TYPED (cloogstmt, cstmt, pstmt);

      int stmt_id = cstmt->stmt_number - 1;
      int kk;
      for (kk = 0; info->influence[stmt_id][kk] != -1; kk++)
        inner->II[kk] += info->influence[stmt_id][kk];
      inner->II[kk] = -1;

      for (kk = 0; info->reuse[stmt_id][kk] != -1; kk++)
        inner->RR[kk] += info->reuse[stmt_id][kk];
      inner->RR[kk] = -1;

      for (kk = 0; info->witers[stmt_id][kk] != -1; kk++)
        inner->WI[kk] += info->witers[stmt_id][kk];
      inner->WI[kk] = -1;

      for (kk = 0; info->domshape[stmt_id][kk] != -1; kk++)
        inner->DS[kk] += info->domshape[stmt_id][kk];
      inner->DS[kk] = -1;

      printf ("Showing influence vector: ");
      for (kk = 0; inner->II[kk] != -1; kk++)
        printf ("%d ",inner->II[kk]);
      printf ("\n");

      printf ("Showing reuse vector: ");
      for (kk = 0; inner->RR[kk] != -1; kk++)
        printf ("%d ",inner->RR[kk]);
      printf ("\n");

      printf ("Showing w_iter vector: ");
      for (kk = 0; inner->WI[kk] != -1; kk++)
        printf ("%d ",inner->WI[kk]);
      printf ("\n");

      printf ("Showing domshape vector: ");
      for (kk = 0; inner->DS[kk] != -1; kk++)
        printf ("%d ",inner->DS[kk]);
      printf ("\n");
    }
  }
  printf ("Done attaching info for unrolling...\n");
}


static
void unroll_loops (scoplib_scop_p scop, 
  s_past_node_t * proot, s_unroll_info_t * info)
{
  int ii,jj;
  ast_t * ast = info->ast;
  int ufs[10];
  for (ii = 0; ii < ast->n_inner; ii++)
  {
    ast_node_t * curr;
    int lev;
    int depth;
    for (lev = 0, curr = ast->inner[ii]; curr; curr = curr->parent, lev++);
    depth = lev - 1;
    for (lev = 0, curr = ast->inner[ii]; curr; curr = curr->parent, lev++)
      ufs[depth - lev] = curr->UF;
    ufs[depth+1] = -1;
    // ufs array has to be -1 terminated
    if (product (ufs) > 1)
    {
      s_past_node_t * piloop = NULL;
      for (jj = 0; jj < ast->n_nodes; jj++)
        if (ast->nodes[jj] == ast->inner[ii])
        {
          piloop = ast->pnodes[jj];
          break;
        }
      assert (piloop && "Did not find PAST inner loop\n");
      PAST_DECLARE_TYPED(for, pf, piloop);
      s_past_node_t * newbody;
      newbody = punroll_replicate_statements_in_block (pf->body, ufs);
      past_deep_free (pf->body);
      pf->body = newbody;
      past_set_parent (piloop);
    }
  }
}

static
void compute_reference_polycoef (scoplib_statement_p stmt, 
  s_unroll_info_t * info)
{
  scoplib_statement_p tmp;
  int *** coefs;
  int n_iter = 0;
  int n_stmt = 0;
  for (tmp = stmt; tmp; tmp = tmp->next, n_stmt++)
    n_iter = n_iter >= tmp->nb_iterators ? n_iter : tmp->nb_iterators;

  int ii;
  coefs  = XMALLOC (int **, n_stmt + 1);
  coefs[n_stmt] = NULL;
  for (ii = 0, tmp = stmt; ii < n_stmt; ii++, tmp = tmp->next)
  {
    int jj;
    int nref = 1; // Start with 1 for the written reference
    scoplib_matrix_p refs = tmp->read;
    for (jj = 0; jj < refs->NbRows; jj++)
      if (SCOPVAL_notzero_p (refs->p[jj][0]))
        nref++;
    coefs[ii] = XMALLOC (int*, nref + 1);
    coefs[ii][nref] = NULL;
    int n_local_iter = tmp->nb_iterators;
    for (jj = 0; jj < nref; jj++)
    {
      coefs[ii][jj] = XMALLOC (int, n_local_iter + 1);
      coefs[ii][jj][n_local_iter] = -1;
      int kk;
      for (kk = 0; kk < n_local_iter; kk++)
        coefs[ii][jj][kk] = 0;
    }
  }
  info->pirw = coefs;

  int sched[n_iter][n_iter];

  // Compute the influence and reuse metrics.
  // influence: number of times that an iterator is used in a statement
  // reuse: number of times that an iterator appears in the FVD of the refs
  for (tmp = stmt, ii = 0; tmp; tmp = tmp->next, ii++)
  {
    int local_n_iter = tmp->nb_iterators;
    scoplib_matrix_p refs = tmp->read;
    int n_row;
    int row;
    n_row = refs->NbRows;
    int ref_id = 0;
    for (row = 0; row < n_row; row++)
    {
      int col;
      if (SCOPVAL_notzero_p (refs->p[row][0]))
      {
        int row_end;
        for ( row_end = row; 
              row_end + 1 < n_row && !SCOPVAL_notzero_p (refs->p[row_end+1][0]);
              row_end++);
        if (row_end + 1 >= n_row)
          row_end = n_row;
        else
          row_end = row_end + 1;
        int rr;
        ref_id ++; // read references start at position 1
        for (rr = row; rr < row_end; rr++)
          for (col = 1; col <= local_n_iter; col++)
            if (SCOPVAL_notzero_p (refs->p[rr][col]))
              coefs[ii][ref_id][col-1] = 1;
      }
    }
    refs = tmp->write;
    n_row = refs->NbRows;
    for (row = 0; row < n_row; row++)
    {
      int col;
      for (col = 1; col <= local_n_iter; col++)
      {
        if (SCOPVAL_notzero_p (refs->p[row][col]))
          coefs[ii][0][col-1] = 1;
      }
    }
    // Copy the schedule from the scop into a matrix
    int jj,kk;
    for (jj = 0; jj < n_iter; jj++)
    {
      for (kk = 0; kk < n_iter; kk++)
      {
        sched[jj][kk] = SCOPVAL_get_si (tmp->schedule->p[jj*2+1][kk+1]);
      }
    }
    // Check if any two rows are identical.
    // If so, then move up all the subsequent rows
    for (jj = 0; jj + 1 < n_iter; jj++)
    {
      for (kk = jj + 1; kk < n_iter; kk++)
      {
        int same = 1;
        int ll;
        for (ll = 0; ll < n_iter; ll++)
          if (sched[jj][ll] != sched[kk][ll])   
            same = 0;
        if (same)
        {
          int mm;
          for (ll = kk; ll + 1 < n_iter; ll++)
            for (mm = 0; mm < n_iter; mm++)
              sched[ll][mm] = sched[ll+1][mm];
          break;
        }
      }
    }
    printf ("PIRW Extracted scheduling matrix\n");
    for (jj = 0; jj < n_iter; jj++)
    {
      for (kk = 0; kk < n_iter; kk++)
        printf ("%d ", sched[jj][kk]);
      printf ("\n");
    }
    int permuted[local_n_iter];
    // permute the influence vector
    int rr;
    printf ("Showing coefficients of statements %d\n", ii);
    for (jj = 0; coefs[ii][jj]; jj++)
    {
      printf ("  reference %d: ",jj);
      for (rr = 0; coefs[ii][jj][rr] != -1; rr++)
        printf ("%d ", coefs[ii][jj][rr]);
      printf ("\n");
    }
    for (rr = 0; coefs && coefs[ii] && coefs[ii][rr]; rr++)
    {
      printf ("PIRW permuting vector (%d,%d): ",ii,rr);
      for (jj = 0; jj < local_n_iter; jj++)
      {
        permuted[jj] = 0;
        for (kk = 0; kk < local_n_iter && coefs[ii][rr][kk] != -1; kk++)
          //permuted[jj] += sched[jj][kk] * (*influence)[ii][kk];
          permuted[jj] += sched[jj][kk] * coefs[ii][rr][kk];
      }
      printf ("PIRW Permuted vector (%d,%d): ",ii,rr);
      for (jj = 0; jj < local_n_iter; jj++)
      {
        coefs[ii][rr][jj] = permuted[jj];
        printf ("%d ",permuted[jj]);
      }
      printf ("\n");
    }
  }
}


// For all inner loops, if they have an affine guard in it,
// swap it with the inner loop
// conditions:
// 1) the loop iterator of the inner loop must not appear
//    in the condition of the affine guard
// 2) Keep it simple, only consider cases where the inner 
//    loop has one single affine guard
void
punroll_unswitch_inner_for_if (scoplib_scop_p scop, s_past_node_t * root)
{
  s_past_node_t ** iloops;
  iloops = past_inner_loops (root);
  int ii;
  for (ii = 0; iloops && iloops[ii]; ii++)
  {
    s_past_node_t ** pifs;
    pifs = past_collect_nodetype (iloops[ii], past_affineguard);
    int nn;
    for (nn = 0; pifs && pifs[nn]; nn++);
    // skip inner loops that have more that one condition
    if (nn != 1)
      continue;

    PAST_DECLARE_TYPED (affineguard, pag, pifs[0]);
    s_symbol_t** iters;
    iters = past_collect_read_symbols (pag->condition);

    PAST_DECLARE_TYPED (for, pf, iloops[ii]);
    int jj;
    int loop_independent = 1;
    for (jj = 0; iters && iters[jj]; jj++)
      if (symbol_equal (pf->iterator, iters[jj]))
        loop_independent = 0;
    XFREE (iters);

    if (loop_independent)
    {
      s_past_node_t * newpif;
      // newcond = condition of old affine guard
      s_past_node_t * newcond = past_clone (pag->condition);
      s_past_node_t * parent = iloops[ii]->parent;
      s_past_node_t * leftsib;
      s_past_node_t * rightsib;
      // create a new inner loop and replace the body with
      // the body of the old affine guard
      s_past_node_t * newinnerloop = past_clone (iloops[ii]);
      PAST_DECLARE_TYPED (for, newpf, newinnerloop);
      past_deep_free (newpf->body);
      newpf->body = past_clone (pag->then_clause);

      newpif = past_node_affineguard_create (newcond, newinnerloop);
      rightsib = iloops[ii]->next;
      past_replace_node (iloops[ii], newpif);
      newpif->next = rightsib;

      // free the old loop (includes the old affine guard)
      past_deep_free (iloops[ii]);
    }

    XFREE (pifs);
  }
  XFREE (iloops);
  past_set_parent (root);
}

void
punroll_unroll_in_place (scoplib_scop_p scop, s_past_node_t * root, 
  int nb_register, int allow_outer)
{
  punroll_show_info (scop, root);
  scoplib_statement_print (stdout, scop->statement);
  s_past_node_t ** loops;
  loops = past_collect_nodetype (root, past_for);
  int ** influence;
  int ** reuse;
  int ** witers;
  int ** domshape;

  // Quick check of affine guards
  s_past_node_t ** guards;
  int legal = 1;
  guards = past_collect_nodetype (root, past_affineguard);
  int jj;
  for (jj = 0; guards && guards[jj]; jj++);
  if (guards && jj > 0)
  {
    legal = 0;
  }
  XFREE (guards);
  if (!legal) // do nothing
    return;
  
  double time0,time1,time2,time3,time4,time5,time6,time7,time8;

  printf ("computing iterator weights\n");

  time0 = rtclock ();
  compute_iterator_weights (scop->statement, &influence, &reuse, &witers, &domshape);
  time1 = rtclock ();
  s_unroll_info_t * info;
  int max_UF_per_dim = 8;
  int max_depth = past_max_loop_depth (root);
  printf ("Maximum scop depth: %d\n", max_depth);
  show_matrix(influence, max_depth, "influence");
  show_matrix(reuse, max_depth, "reuse");
  show_matrix(domshape, max_depth, "domshape");
  printf ("allocating punroll info structure\n");
  time2 = rtclock ();
  info = punroll_alloc_info_structure (influence, reuse, witers, domshape,
    nb_register, max_depth, max_UF_per_dim);
  time3 = rtclock ();
  printf ("Allow outer in main unroll func: %d\n", allow_outer);
  info->allow_outer_unroll = allow_outer;
  compute_reference_polycoef (scop->statement, info);
  time4 = rtclock ();

  int nl;
  for (nl = 0; loops && loops[nl]; nl++);
  

  #if 1
  //if (nl < 15) // What was this condition for?
  {
    ast_t * ast;
    printf ("Building test ast for unrolling ...\n");
    ast = build_ast_from_past (scop, root, info);
    time5 = rtclock ();
    print_tree (ast);
    info->ast = ast;
    attach_info_to_ast (scop, root, info);
    time6 = rtclock ();
    compute_scop_unroll_factors (scop, root, info);
    time7 = rtclock ();
    print_tree (ast);
    unroll_loops (scop, root, info);
    time8 = rtclock ();
    dealloc_tree (ast);

    printf ("MK UNROLL iterator weights time: %.4f\n",time1-time0);
    printf ("MK UNROLL show weights time: %.4f\n",time2-time1);
    printf ("MK UNROLL info structure time: %.4f\n",time3-time2);
    printf ("MK UNROLL polycoef comp time: %.4f\n",time4-time3);
    printf ("MK UNROLL build ast from past time: %.4f\n",time5-time4);
    printf ("MK UNROLL attach info time: %.4f\n",time6-time5);
    printf ("MK UNROLL compute unroll factors time: %.4f\n",time7-time6);
    printf ("MK UNROLL unroll loops time: %.4f\n",time8-time7);
  }
  #else
  int ii;
  int ufs[10];
  for (ii = 0; loops && loops[ii]; ii++)
  {
    if (past_is_outer_for_loop (loops[ii]))
    {
      s_past_node_t ** inner = past_inner_loops(loops[ii]);
      //punroll_update_increment (pf, 2);

      int jj;
      for (jj = 0; inner && inner[jj]; jj++)
      {
        int outer_par_dim = past_node_is_a (loops[ii], past_parfor);
        int is_inner_parallel = past_node_is_a (inner[jj], past_parfor);
        int depth;
        punroll_reset_info_structure (info, outer_par_dim, is_inner_parallel, depth);
        depth = punroll_compute_loop_weights (info, loops[ii], inner[jj]);
        info->n_levels = depth;
        printf ("Generating space ...\n");
        punroll_generate_space (info);
        show_space (info);
        printf ("Computing optimal unroll factors\n");
        punroll_compute_optimal_unroll_factors (info, 0);
        load_unroll_factors (info, ufs);
        show_unroll_factors (ufs);
        if (product (ufs) > 1)
        {
          PAST_DECLARE_TYPED(for, pf, inner[jj]);
          s_past_node_t * newbody;
          newbody = punroll_replicate_statements_in_block (pf->body, ufs);
          past_deep_free (pf->body);
          pf->body = newbody;
          past_set_parent (inner[jj]);
        }
      }
      XFREE (inner);
    }
  }
  #endif
  XFREE (influence);
  XFREE (reuse);
  XFREE (witers);
  XFREE (loops);
  // FIXME: it worked before adding the witers info
  //punroll_free_info_structure (info);
}
